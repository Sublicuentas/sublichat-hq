import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { canonicalSeller, operationalFilterOptions, filterOperationalRows, roleModules } from '../src/data.js';
import { iptvDefaultUrl, iptvDefaultList, setSellerPhones, sellerPhone } from '../src/operations.js';
import { remoteBaseCatalog, effectiveCatalog } from '../src/calculadora.js';

const SECRET_CLIENTS = [{ id: 'c1', nombre: 'Ana Multi', nombrePerfil: 'Ana Multi', telefono: '99887766', servicios: [{ plataforma: 'netflix', precio: 130, fechaRenovacion: '01/01/2030', vendedor: 'Geissel', correo: 'ana@x.com', clave: 'CLAVE-SECRETA', pinPerfil: '4321', maxPlayerClave: 'MPSECRET', perfiles: [{ nombre: 'Ana', clave: 'CLAVE-SECRETA', pinPerfil: '4321' }] }] }];

test('A · Reload durante una carga queda EN COLA (no se ignora) y solo recarga lo visible', async () => {
  const app = await bootApp({ role: 'sublicuentas', mobileCoreDelayMs: 300 });
  try {
    await app.sleep(1200);
    await app.click('[data-tab="clientes"]', 50);
    const before = app.calls.length;
    await app.click('#refreshData', 30); await app.click('#refreshData', 30);
    await app.sleep(1100);
    const after = app.calls.slice(before).filter(c => c.path === '/api/mobile-core' && c.resource !== 'config');
    const reloads = after.filter(c => c.resource === 'clientes');
    assert.equal(reloads.length, 2, 'la segunda intención se ejecuta al terminar la primera');
    assert.equal(after.length, reloads.length, 'Clientes solo recarga clientes (no inventario ni finanzas)');
    assert.match(app.w.document.body.textContent, /Actualizado \d\d:\d\d|Sincronizado|Actualizado/);
  } finally { app.close(); }
});

test('B · el caché del teléfono no guarda claves/PIN/correos; cerrar sesión lo borra', async () => {
  const app = await bootApp({ role: 'sublicuentas', clients: SECRET_CLIENTS });
  try {
    await app.sleep(1200);
    const dump = Object.keys(app.w.localStorage).map(k => app.w.localStorage.getItem(k)).join('\n');
    for (const bad of ['CLAVE-SECRETA', '4321', 'ana@x.com', 'MPSECRET', 'refreshToken', 'idToken']) assert.ok(!dump.includes(bad), `no debe estar en localStorage: ${bad}`);
    await app.click('[data-tab="mas"]', 200); await app.click('[data-open="perfil"]', 300);
    const out = app.$('#logoutBtn'); if (out) { app.w.confirm = () => true; await app.click(out, 300); }
    assert.equal(app.w.localStorage.getItem('sublicuentas-core-cache-r69'), null, 'caché borrado al cerrar sesión');
  } finally { app.close(); }
});

test('C · Geisell canónica: "Geissel" y "Geisell" son la misma vendedora; ve Control Maestro', () => {
  assert.equal(canonicalSeller('Geissel'), 'geisell'); assert.equal(canonicalSeller(' GEISELL '), 'geisell');
  const rows = [{ vendedor: 'Geissel', fechaRenovacion: '01/01/2030', nombre: 'a' }, { vendedor: 'Geisell', fechaRenovacion: '01/01/2030', nombre: 'b' }];
  assert.deepEqual(operationalFilterOptions(rows).sellers, ['Geisell']);
  assert.equal(filterOperationalRows(rows, { seller: 'Geisell', status: 'vigentes' }).length, 2);
  const m = roleModules('geisell_admin', 'geisell').more; assert.ok(m.includes('control-maestro')); assert.equal(m.at(-1), 'perfil');
});

test('D · Stella TV y Oleada TV no heredan URL ni lista de LatinTV', () => {
  for (const p of ['stellatv1', 'oleadatv1', 'oleada1', 'Oleada TV']) { assert.equal(iptvDefaultUrl(p, ''), ''); assert.equal(iptvDefaultList(p, ''), ''); }
  assert.equal(iptvDefaultUrl('latintv1', ''), 'http://latgt.com:8080');
});

test('F · una mutación reintentada por timeout usa el MISMO operationId; lecturas no llevan', async () => {
  const api = await import('../src/api.js?r69f');
  api.__setSecureStoreForTests({ mode: 'test', get: async () => null, set: async () => {}, remove: async () => {} });
  api.setSession({ usuario: 'sublicuentas', role: 'sublicuentas', idToken: 't', refreshToken: 'r', expiresAt: Date.now() + 3.6e6 });
  const seen = []; let n = 0;
  globalThis.fetch = async (url, init) => { const b = JSON.parse(init.body); seen.push(b); n += 1; if (n === 1) throw new Error('Failed to fetch'); return { ok: true, status: 200, json: async () => ({ ok: true }), text: async () => '{"ok":true}' }; };
  await api.authPost('/api/renovar', { accion: 'renovar', clienteId: 'x' });
  assert.equal(seen.length, 2); assert.ok(seen[0].operationId); assert.equal(seen[0].operationId, seen[1].operationId);
  assert.equal(seen[0].clientMeta.source, 'android');
  seen.length = 0; n = 1; await api.authPost('/api/mobile-core', { resource: 'clientes' });
  assert.equal(seen[0].operationId, undefined);
  api.setCompatibility({ minAppBuild: 99999 });
  await assert.rejects(() => api.authPost('/api/renovar', { accion: 'renovar' }), /Actualizaci/);
  api.setCompatibility({ minAppBuild: 0 }); delete globalThis.fetch;
});

test('G · teléfonos y precios base vienen de la configuración remota', () => {
  setSellerPhones({ Relojes: '3200-0000', malo: '12' }); assert.equal(sellerPhone('relojes'), '32000000'); assert.equal(sellerPhone('malo'), '');
  const cat = effectiveCatalog({}, remoteBaseCatalog({ netflix: 175 })); assert.equal(cat.find(p => p.id === 'netflix').precio, 175);
  const own = effectiveCatalog({ netflix: 160 }, remoteBaseCatalog({ netflix: 175 })); assert.equal(own.find(p => p.id === 'netflix').precio, 160, 'el precio personalizado sigue mandando');
});
