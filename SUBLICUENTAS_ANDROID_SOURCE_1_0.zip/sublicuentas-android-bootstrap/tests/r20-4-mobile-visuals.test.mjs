import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=appSource();
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
test('R20.4 splash is static artwork and only loader is animated',()=>{
  assert.match(main,/class="splash-art"/);
  assert.doesNotMatch(main,/class="splash-video"/);
  assert.match(main,/spinSplashLoaderWithJS/);
  assert.doesNotMatch(css,/splashZoomIn|splashBreath/);
});
test('R26 intro and login fill the full screen without distorting the artwork',()=>{
  assert.match(css,/\.splash-art,\.visual-login-bg\{[^}]*object-fit:cover/);
  assert.doesNotMatch(css,/\.visual-login-bg[^}]*object-fit:fill/);
  assert.match(css,/\.splash-stage,\.visual-login-stage\{[^}]*width:100%/);
});
