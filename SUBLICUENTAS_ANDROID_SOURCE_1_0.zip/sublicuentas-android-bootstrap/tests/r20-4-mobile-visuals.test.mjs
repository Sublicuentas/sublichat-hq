import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
test('R20.4 splash is static artwork and only loader is animated',()=>{
  assert.match(main,/class="splash-art"/);
  assert.doesNotMatch(main,/class="splash-video"/);
  assert.match(css,/\.splash-loader[^}]*animation:splashSpin/);
  assert.doesNotMatch(css,/splashZoomIn|splashBreath/);
});
test('R20.4 intro and login use contained mobile artwork instead of cover crop',()=>{
  assert.match(css,/\.splash-art[^}]*object-fit:contain/);
  assert.match(css,/\.visual-login-bg[^}]*object-fit:contain/);
  assert.match(css,/\.visual-login-stage/);
});
