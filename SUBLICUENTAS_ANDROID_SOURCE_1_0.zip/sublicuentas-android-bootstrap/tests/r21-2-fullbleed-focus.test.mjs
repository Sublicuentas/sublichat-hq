import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
test('intro y login usan ancho completo móvil',()=>{assert.match(css,/\.splash-stage,\.visual-login-stage\{width:100vw;max-width:none\}/);assert.match(css,/\.splash-art\{object-fit:cover/);});
test('interior incorpora jerarquía Focus sin cambiar paleta',()=>{assert.match(css,/R21\.2 · full-bleed intro\/login \+ Focus-inspired interior/);assert.match(css,/\.bottom-nav\{left:10px;right:10px/);assert.match(css,/\.metric:after/);});
