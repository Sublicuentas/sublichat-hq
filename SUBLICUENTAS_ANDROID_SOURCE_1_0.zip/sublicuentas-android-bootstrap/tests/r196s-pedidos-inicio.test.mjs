// R196s · Pedidos de socios (estado real = el mismo de la web) e Inicio «variante 1» por permisos. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { roleModules, roleCapabilities } from '../src/data.js';

const p = (id, estado, publicados = 0, requeridos = 1, extra = {}) => ({ id, socio: 'Jimena', socio_norm: 'jimena', estado, cliente: 'Cliente', monto: 80, productos: [{ renglonId: 'r1', servicio: 'Spotify Premium' }],
  entregaResumen: { estado: publicados === 0 ? 'pendiente' : publicados < requeridos ? 'parcial' : 'entregado', publicados, requeridos, texto: publicados && publicados < requeridos ? `Entrega parcial · ${publicados} de ${requeridos} servicios` : '' }, ...extra });
const COMPRAS = [
  p('web_000C125BD', 'entregado'),            // marcado Entregado en la web, sin entrega publicada (caso de la captura)
  p('web_0000F4FEB', 'entregado'),
  p('web_000E31CE0', 'completado'),
  p('web_000B62BA9', 'pendiente'),            // de verdad pendiente
  p('web_000412862', 'en proceso'),
  p('web_0007C5A0B', 'pendiente', 1, 2),      // parcial real
  p('web_000AAAAAA', 'pendiente', 1, 1),      // entrega publicada → entregado
  p('web_000CANCEL', 'cancelado'),
];

async function abrirPedidos(llamadas = []) {
  const fetchExtra = async (path, b) => { if (path !== '/api/revendedores-admin') return undefined; llamadas.push(b); return b.ruta === 'compras' ? COMPRAS : { ok: false, error: 'no_simulado' }; };
  const app = await bootApp({ role: 'sublicuentas', fetchExtra });
  await app.sleep(300); await app.click('[data-tab="mas"]', 300); await app.click('[data-open="socios-entregas"]', 400);
  await app.waitFor(() => app.$('[data-se-abrir]'));
  return app;
}
const chips = (app) => Object.fromEntries(app.$$('[data-se-filtro]').map((b) => [b.dataset.seFiltro, b.textContent.trim()]));

test('S-01/S-02 · Pedidos marcados «Entregado» en la web ya no salen «Por entregar»; contadores = lista filtrada', async () => {
  const llamadas = [];
  const app = await abrirPedidos(llamadas);
  try {
    const c = chips(app);
    assert.match(c.pendientes, /Por entregar · 3$/, 'B62BA9 pendiente + 412862 en proceso + 7C5A0B parcial');
    assert.match(c.parcial, /Parciales · 1$/);
    assert.match(c.entregado, /Entregados · 4$/, 'C125BD, 0F4FEB, E31CE0 por estado de la web + AAAAAA por entrega publicada');
    const visibles = () => app.$$('.se-item').map((x) => x.textContent);
    assert.equal(visibles().length, 3);
    assert.ok(!visibles().some((t) => /#(C125BD|0F4FEB|E31CE0)/.test(t)));
    await app.click('[data-se-filtro="entregado"]', 100);
    const ent = visibles();
    assert.equal(ent.length, 4, 'la cifra del chip = las filas');
    assert.match(ent.find((t) => /#C125BD/.test(t)), /Entregado/);
    assert.match(ent.find((t) => /#C125BD/.test(t)), /Web: entregado · entregas publicadas 0\/1/, 'conciliación visible: estado guardado vs entregas');
    await app.click('[data-se-filtro="todos"]', 100);
    assert.match(visibles().find((t) => /#CANCEL/.test(t)), /Cancelado/);
    assert.match(visibles().find((t) => /#412862/.test(t)), /En proceso/);
    // S-03 · solo lectura: no se escribió nada ni se reenviaron accesos
    assert.ok(llamadas.every((b) => b.ruta === 'compras' && (b.metodo || 'GET') === 'GET'), JSON.stringify(llamadas.map((b) => b.ruta)));
  } finally { app.close(); }
});

test('H-02 · Inicio: módulos solo de los accesos que ya existen (no concede Finanzas a Geisell ni nada nuevo)', () => {
  const tiene = (r, u, id) => { const m = roleModules(r, u), c = roleCapabilities(r, u); return m.tabs.includes(id) || m.more.includes(id) || (id === 'control-maestro' && c.controlMaestro) || (id === 'finanzas' && c.finanzas); };
  assert.equal(tiene('geisell', 'geisell', 'finanzas'), false);
  assert.equal(tiene('vendedor', 'nuevo', 'finanzas'), false);
  assert.equal(tiene('vendedor', 'nuevo', 'sala-juntas'), false);
});

for (const [role, usuario, hola, esperado] of [
  // R196w · Kit 3D (PDF 16/11/2026): Herramientas = Sala · Control financiero · Control maestro · Recordatorios · Pelis,
  // solo las que el usuario ya tiene; Clientes y Tickets NO se repiten (están en la barra inferior).
  ['sublicuentas', 'sublicuentas', 'Sublicuentas', ['sala-juntas', 'finanzas', 'control-maestro', 'recordatorios', 'pelis']],
  ['relojes', 'relojes', 'Relojes', ['sala-juntas', 'finanzas', 'recordatorios', 'pelis']],
  ['geisell', 'geisell', 'Geisell', ['sala-juntas', 'control-maestro', 'recordatorios', 'pelis']],
  ['vendedor', 'nuevo.asesor', 'Nuevo', ['recordatorios', 'pelis']],
]) {
  test(`H-01/H-03 · Inicio ${usuario}: mismo diseño y Sublirobot, «Hola, ${hola}», módulos por permiso`, async () => {
    const app = await bootApp({ role, usuario });
    try {
      await app.sleep(300);
      assert.equal(app.$('.visual-home-brand h1').textContent, `Hola, ${hola}`);
      assert.equal(app.$('.visual-bot').getAttribute('src'), '/assets/inicio/3d/14_sublirobot.webp'); // R196w · Sublirobot del kit 3D para todos
      assert.ok(!app.$$('.home-v1-grid [data-open]').some((b) => ['clientes', 'tickets'].includes(b.dataset.open)), 'Clientes y Tickets no se duplican');
      assert.deepEqual(app.$$('.home-v1-grid [data-open]').map((b) => b.dataset.open), esperado);
      assert.doesNotMatch(app.w.document.body.textContent, /Naara|Libni/);
      assert.equal(app.$$('.visual-metrics .mcard').length, 3);
      const cards = app.$$('.home-v1-grid .hv-card');
      assert.equal(cards.filter((c) => c.classList.contains('wide')).length, esperado.length % 2, 'sin huecos: la última va ancha si son impares');
    } finally { app.close(); }
  });
}

test('H-04 · Inicio: tocar una tarjeta abre su módulo real', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(300);
    await app.click('.home-v1-grid [data-open="pelis"]', 300);
    assert.ok(app.$('.pl-hero'), 'abre Pelis (su ruta real)');
  } finally { app.close(); }
});

test('Inicio: si falla la carga no dice «Actualizado» (marca horaria solo de un éxito)', async () => {
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, b) => (b.resource === 'clientes' ? { ok: false, error: 'caído' } : undefined) });
  try { await app.sleep(400); assert.doesNotMatch(app.$('.visual-sync')?.textContent || '', /Actualizado \d/); } finally { app.close(); }
});
