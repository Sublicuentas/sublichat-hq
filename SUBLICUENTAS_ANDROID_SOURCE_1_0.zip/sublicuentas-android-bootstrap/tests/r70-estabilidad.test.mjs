import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';

test('R70 token rechazado (401): se renueva UNA vez y se repite la solicitud', async () => {
  const api = await import('../src/api.js?r70');
  api.__setSecureStoreForTests({ mode: 'test', get: async () => null, set: async () => {}, remove: async () => {} });
  api.setSession({ usuario: 'sublicuentas', role: 'sublicuentas', idToken: 'viejo', refreshToken: 'r', expiresAt: Date.now() + 3.6e6 });
  let calls = 0, refreshes = 0;
  globalThis.fetch = async (url, init) => {
    if (String(url).includes('securetoken')) { refreshes += 1; return { ok: true, status: 200, json: async () => ({ id_token: 'nuevo', expires_in: '3600' }), text: async () => JSON.stringify({ id_token: 'nuevo', expires_in: '3600' }) }; }
    calls += 1; const auth = init.headers.Authorization;
    if (auth === 'Bearer viejo') return { ok: false, status: 401, json: async () => ({ error: 'Sesión inválida o vencida.' }), text: async () => '{"error":"Sesión inválida o vencida."}' };
    return { ok: true, status: 200, json: async () => ({ ok: true, items: [] }), text: async () => '{"ok":true,"items":[]}' };
  };
  const r = await api.authPost('/api/mobile-core', { action: 'list', resource: 'clientes' });
  assert.equal(r.ok, true); assert.equal(refreshes, 1); assert.equal(calls, 2);
  delete globalThis.fetch;
});

test('R70 Inicio cuenta igual que Cobros y "Nuevo CRM" abre ficha limpia después de guardar', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(800);
    const home = Number(app.$('.mcard-today strong').textContent);
    await app.click('.mcard-today', 400);
    const cobrosHoy = Number(app.$('.cb-t3 [data-filter="hoy"] b')?.textContent);
    assert.equal(home, cobrosHoy, 'Vencen hoy (Inicio) = Hoy (Cobros)');
    await app.click('[data-tab="clientes"]', 300); await app.click('[data-tab-jump="nuevo-crm"]', 300);
    const set = (sel, v) => { const el = app.$(sel); el.value = v; el.dispatchEvent(new app.w.Event('input', { bubbles: true })); };
    set('#crmNombre', 'Juan Lion'); set('#crmTelefono', '94567168');
    const row = app.$('[data-crm-profile]');
    for (const [k, v] of [['[data-p-email]', 'a@b.c'], ['[data-p-password]', 'k'], ['[data-p-pin]', '1']]) { const el = row.querySelector(k); if (el) { el.value = v; el.dispatchEvent(new app.w.Event('input', { bubbles: true })); } }
    const dv = row.querySelector('[data-p-device]'); if (dv) { dv.value = 'tv'; dv.dispatchEvent(new app.w.Event('change', { bubbles: true })); }
    await app.click('#crmSubmit', 900);
    await app.click('#backMore', 300);
    await app.click('[data-tab-jump="nuevo-crm"]', 300);
    assert.equal(app.$('#crmNombre').value, '', 'la ficha guardada ya no queda pegada');
  } finally { app.close(); }
});
