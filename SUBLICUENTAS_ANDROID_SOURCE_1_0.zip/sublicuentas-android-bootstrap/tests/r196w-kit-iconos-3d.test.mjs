// R196w · Kit de iconos 3D de Inicio (PDF «SUBLICHAT_KIT_ICONOS_3D_PARA_CLAUDE», 16/11/2026). Pruebas 1–3, 5–9, 11–13.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ICONOS = ['01_sala_de_juntas', '02_control_financiero', '03_control_maestro', '04_recordatorios', '05_pelis_y_estrenos', '06_tickets_icono', '07_calendario_vencen_hoy', '08_reloj_proximos', '09_alerta_vencidos', '10_inicio_nav', '11_clientes_nav', '12_cobros_nav', '13_mas_nav', '14_sublirobot'];
const dimWebp = (b) => { // VP8L / VP8X: ancho y alto del encabezado WebP
  const t = b.toString('ascii', 12, 16);
  if (t === 'VP8X') return [1 + b.readUIntLE(24, 3), 1 + b.readUIntLE(27, 3)];
  if (t === 'VP8L') { const v = b.readUInt32LE(21); return [1 + (v & 0x3fff), 1 + ((v >> 14) & 0x3fff)]; }
  return [b.readUInt16LE(26) & 0x3fff, b.readUInt16LE(28) & 0x3fff];
};

test('2/12 · los 14 iconos están como archivos estáticos ligeros (WebP), cuadrados y sin deformar', () => {
  let total = 0;
  for (const n of ICONOS) {
    const f = new URL(`../public/assets/inicio/3d/${n}.webp`, import.meta.url); assert.ok(fs.existsSync(f), n);
    const b = fs.readFileSync(f); total += b.length;
    const [w, h] = dimWebp(b); assert.equal(w, h, `${n} cuadrado`); assert.ok(w === (n === '14_sublirobot' ? 512 : 256), `${n} ${w}px`);
  }
  assert.ok(total < 400 * 1024, `kit liviano: ${Math.round(total / 1024)} KB`);
  for (const f of ['src/app/inicio.js', 'src/app/icons.js', 'src/styles.css']) assert.doesNotMatch(src(f), /data:image\/(png|webp);base64/, `${f} sin base64`);
});

test('5/6 · Herramientas = solo 5 accesos reales; Clientes y Tickets solo en la barra; barra con iconos del kit', () => {
  const ini = src('src/app/inicio.js'), ico = src('src/app/icons.js');
  assert.match(ini, /HOME_ORDEN = Object\.freeze\(\['sala-juntas', 'finanzas', 'control-maestro', 'recordatorios', 'comercial', 'pelis'\]\)/);
  assert.doesNotMatch(ini.split('const HOME_CARDS')[1].split('};')[0], /clientes:|tickets:/);
  for (const n of ['10_inicio_nav', '11_clientes_nav', '12_cobros_nav', '06_tickets_icono', '13_mas_nav']) assert.match(ico, new RegExp(`inicio/3d/${n}\\.webp`));
  for (const n of ['07_calendario_vencen_hoy', '08_reloj_proximos', '09_alerta_vencidos']) assert.match(ico, new RegExp(n));
});

test('7/8/11 · Inicio real: cifras dinámicas (no las del diseño), barra de 5 pestañas, sin «Actualizando…» pegado', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(500);
    const nums = app.$$('.visual-metrics .mcard strong').map((e) => e.textContent.trim());
    assert.deepEqual(nums.length, 3); assert.notDeepEqual(nums, ['25', '24', '10'], 'no son los números de ejemplo del diseño');
    assert.equal(app.$$('.visual-metrics .mcard-3d').length, 3);
    assert.deepEqual(app.$$('.bottom-nav [data-tab]').map((b) => b.dataset.tab), ['inicio', 'clientes', 'cobros', 'tickets', 'mas']);
    assert.equal(app.$$('.bottom-nav img.bottom-nav-icon').length, 5);
    assert.doesNotMatch(app.$('.visual-sync')?.textContent || '', /Actualizando/);
    await app.click('.home-v1-grid [data-open="recordatorios"]', 300);
    assert.equal(app.$$('.home-v1-grid').length, 0, 'salió de Inicio a Recordatorios');
  } finally { app.close(); }
});

test('13 · Control Maestro sin cambios por este kit (solo el atajo de Inicio)', () => {
  assert.doesNotMatch(src('src/app/inicio.js').split('function dashboardView')[0], /ensureControlMaster|controlMaster\(/);
  for (const f of fs.readdirSync(new URL('../src/', import.meta.url)).filter((x) => /control-?maestro/i.test(x))) assert.doesNotMatch(src('src/' + f), /R196w/);
});
