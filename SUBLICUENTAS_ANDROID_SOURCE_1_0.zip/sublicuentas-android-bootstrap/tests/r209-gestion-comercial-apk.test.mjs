// R209 · APK: tarjeta «Gestión comercial» de ancho completo ANTES de Pelis y estrenos; abre la misma pantalla de la Web.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const R = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('Inicio: orden, permiso e icono 3D; los 3 indicadores originales intactos', () => {
  const ini = R('src/app/inicio.js');
  assert.match(ini, /'recordatorios', 'comercial', 'pelis'\]/);
  assert.match(ini, /id === 'comercial' && canComercial\(\)/);
  assert.match(ini, /comercial\/megafono\.webp/);
  assert.match(ini, /Vencen hoy[\s\S]*Próximos[\s\S]*Vencidos/);
  assert.ok(fs.existsSync(new URL('../public/assets/comercial/megafono.webp', import.meta.url)));
});
test('módulo: sesión de la APK, sin envío sin red, WhatsApp por intent y copia fiel de la Web', () => {
  const c = R('src/app/comercial.js');
  assert.match(c, /authPost\('\/api\/comercial'/); assert.match(c, /sinRed\(\)/); assert.match(c, /abrir: \(u\) => ui\.openLink\(u\)/);
  assert.match(c, /\['sublicuentas', 'relojes', 'geisell'\]/);
  const w = R('public/comercial-web.js'); assert.match(w, /window\.ComercialConfig/); assert.match(w, /«Abrir WhatsApp» no cuenta como enviado/);
  assert.ok(fs.existsSync(new URL('../public/comercial-web.css', import.meta.url)));
  const m = R('src/main.js'); assert.match(m, /state\.subview==='comercial'\) return comercialView\(\)/); assert.match(m, /bindComercial\(\)/);
});
