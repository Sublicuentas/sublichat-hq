import test from 'node:test';
import assert from 'node:assert/strict';
import { sopaCreate, sopaResolve, sopaHint, sopaPause, sopaResume, sopaElapsed, sopaSubmission, cellsBetween, snapEnd, normalizeWord, SOPA_LEVELS } from '../src/sopa.js';
import { bootApp } from './helpers/ui-harness.mjs';

const path = w => cellsBetween(w.start, w.end);

test('R61 generador con semilla: reproducible, dentro del grid y cada palabra en sus coordenadas', () => {
  for (const lvl of ['atencion', 'intermedio', 'pro']) {
    const a = sopaCreate(lvl, 'semilla-1', { now: 1000 }), b = sopaCreate(lvl, 'semilla-1', { now: 1000 });
    assert.deepEqual(a.grid, b.grid, 'misma semilla = mismo tablero');
    assert.equal(a.grid.length, SOPA_LEVELS[lvl].grid); assert.equal(a.words.length, SOPA_LEVELS[lvl].words);
    for (const w of a.words) assert.equal(path(w).map(c => a.grid[c.row][c.col]).join(''), w.text);
  }
  assert.equal(normalizeWord('Maracuyá'), 'MARACUYA'); assert.equal(normalizeWord('piña'), 'PIÑA');
});

test('R61 selección: horizontal, al revés, diagonal (nivel Pro), no alineada no vale; sin repetir', () => {
  let r = sopaCreate('atencion', 'abc', { now: 0 });
  const [w1, w2] = r.words;
  let out = sopaResolve(r, path(w1), 10); assert.equal(out.result.type, 'hit'); r = out.round;
  out = sopaResolve(r, path(w1), 11); assert.equal(out.result.type, 'miss', 'la misma palabra no suma dos veces');
  out = sopaResolve(r, cellsBetween(w2.end, w2.start), 12); assert.equal(out.result.type, 'hit', 'al revés');
  assert.deepEqual(cellsBetween({ row: 0, col: 0 }, { row: 2, col: 1 }), [], 'arrastre no alineado');
  assert.deepEqual(snapEnd({ row: 0, col: 0 }, { row: 3, col: 2 }, 6), { row: 3, col: 3 }, 'encaja a diagonal');
  const pro = sopaCreate('pro', 'diag', { now: 0 });
  assert.ok(SOPA_LEVELS.pro.dirs.includes('SE') && !SOPA_LEVELS.atencion.dirs.includes('SE'));
  for (const w of pro.words) assert.equal(sopaResolve(pro, path(w)).result.type, 'hit');
});

test('R61 pausa de 30 s no cuenta; pista cobra 10 una sola vez; completar calcula bono', () => {
  let r = sopaCreate('atencion', 'p', { now: 0 });
  r = sopaPause(r, 10000); r = sopaResume(r, 40000);
  assert.equal(sopaElapsed(r, 45000), 15000);
  r = sopaHint(r, 45000); assert.equal(r.hintCount, 1); assert.ok(r.hintCell);
  for (const w of r.words) r = sopaResolve(r, path(w), 50000).round;
  assert.equal(r.status, 'completed'); assert.equal(r.roundScore, 3 * 20 + 30 - 10 + Math.round(25 * (1 - 20000 / 60000)));
  const sub = sopaSubmission(r); assert.equal(sub.selections.length, 3); assert.equal(sub.hintsUsed, 1); assert.ok(!('roundScore' in sub));
});

test('R61 en la app: reanuda la ronda guardada (2/3) y al completar acredita con el MISMO roundId', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  const reg = [];
  const orig = app.w.fetch;
  app.w.fetch = async (url, init = {}) => { let b = {}; try { b = JSON.parse(init.body || '{}'); } catch (_) {} if (String(url).includes('/api/juegos') && b.accion === 'registrar') { reg.push(b); const d = { ok: true, awardedPoints: 120, totalPoints: 834 }; return { ok: true, status: 200, text: async () => JSON.stringify(d), json: async () => d }; } return orig(url, init); };
  try {
    await app.click('[data-tab="mas"]', 250); await app.click('[data-open="materia"]', 400);
    await app.click('.jg2-play[data-jg-play="WORD_SEARCH"]', 300);
    assert.ok(app.$('#sopaBoard') && app.$('.ws-chip'));
    const key = Object.keys(app.w.localStorage).find(k => k.startsWith('sublichat-sopa-v1'));
    let saved = JSON.parse(app.w.localStorage.getItem(key)).round;
    // encontrar 2 palabras "a mano" en el estado guardado y reabrir
    let r = saved; for (const w of r.words.slice(0, 2)) r = sopaResolve(r, path(w)).round;
    await app.click('#jgQuit', 250);
    app.w.localStorage.setItem(key, JSON.stringify({ schemaVersion: 1, round: r, lastSavedAt: Date.now() }));
    await app.click('.jg2-play[data-jg-play="WORD_SEARCH"]', 300);
    assert.match(app.$('.ws-progress b').textContent, /2\/3/, 'conserva 2/3 al reabrir');
    await app.click('#sopaPause', 100); assert.ok(app.$('.ws-board.paused')); await app.click('#sopaResume', 100);
    await app.click('#sopaHint', 100); assert.ok(app.$('.ws-cell.hint'));
    saved = JSON.parse(app.w.localStorage.getItem(key)).round;
    const last = saved.words.find(w => !w.found);
    const done = sopaResolve(saved, path(last)).round;
    await app.click('#jgQuit', 250);
    app.w.localStorage.setItem(key, JSON.stringify({ schemaVersion: 1, round: done, lastSavedAt: Date.now() }));
    await app.click('.jg2-play[data-jg-play="WORD_SEARCH"]', 900);
    assert.equal(reg.length, 1, 'ronda completa pendiente se envía al abrir');
    assert.equal(reg[0].roundId, done.roundId); assert.equal(reg[0].gameCode, 'WORD_SEARCH'); assert.equal(reg[0].metrics.selections.length, 3);
    await app.click('#jgQuit', 250); await app.click('.jg2-play[data-jg-play="WORD_SEARCH"]', 600);
    assert.equal(reg.length, 1, 'ya acreditada: no se vuelve a mandar');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
