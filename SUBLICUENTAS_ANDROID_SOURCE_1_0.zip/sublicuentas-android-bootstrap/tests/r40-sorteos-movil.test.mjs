import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import {
  sorteosScreenHtml, raffleMetrics, drawActions, prizeSheetHtml, readPrizeForm, drawSheetHtml, readDrawForm, ticketsSheetHtml, wheelSheetHtml,
  confirmSheetHtml, backfillPreviewText, auditText, localInput, defaultLocal, stockText, PRESETS,
} from '../src/sorteos.js';
import { moviesContentHtml } from '../src/screens.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const exists = p => fs.existsSync(new URL(`../public${p}`, import.meta.url));
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

const DATA = {
  ok: true, permisos: { alcance: 'todos' },
  premios: [
    { id: 'p1', nombre: '1 mes de Netflix', tipo: 'perfil', activo: true, stock: 3, reservados: 1, entregados: 0, entregaModo: 'manual', ownerVendor: 'sublicuentas', color: '#e2231a' },
    { id: 'p2', nombre: 'Boleto de cine', tipo: 'cine', activo: true, entregaModo: 'codigo', codigosDisponibles: 4, ownerVendor: 'relojes' },
  ],
  sorteos: [
    { id: 's1', titulo: 'Gran sorteo de septiembre', estado: 'activo', categoria: 'general', alcance: 'ambos', totalBoletos: 1636, fechaFin: '2026-09-30T23:59:00-06:00', premioIds: ['p1'] },
    { id: 's2', titulo: 'Cerrado', estado: 'cerrado', categoria: 'renovaciones', alcance: 'sublicuentas', totalBoletos: 10, premioIds: ['p1', 'p2'] },
    { id: 's3', titulo: 'Con ganador', estado: 'finalizado', categoria: 'general', alcance: 'sublicuentas', totalBoletos: 5, premioIds: ['p2'], ganador: { clienteNombre: 'Ana Paz', codigo: 'SB-0001', telefono: '9999' } },
  ],
  entregas: [{ id: 'e1', sorteoId: 's3', estado: 'pendiente', premioNombre: 'Boleto de cine' }],
  participantes: [{ id: 't1', sorteoId: 's2', codigo: 'SB-0002', clientId: 'c1', clienteNombre: 'Beto', tipo: 'renovacion' }, { id: 't2', sorteoId: 's2', codigo: 'SB-0003', clientId: 'c1', clienteNombre: 'Beto', tipo: 'compra' }],
};

test('Sorteos móvil: carga, métricas y pestañas como el panel web', () => {
  assert.ok(dom(sorteosScreenHtml({})).querySelector('.spinner'));
  assert.ok(dom(sorteosScreenHtml({ error: 'falló' })).querySelector('#rafflesRetry'));
  const d = dom(sorteosScreenHtml({ data: DATA }));
  assert.deepEqual([...d.querySelectorAll('.sr-metrics b')].map(b => b.textContent.replace(/[.,\s]/g, '')), ['1651', '1', '2', '1']);
  assert.deepEqual([...d.querySelectorAll('[data-sr-tab]')].map(b => b.dataset.srTab), ['sorteos', 'premios', 'ganadores']);
  assert.equal(d.querySelector('.sr-tabs .on').dataset.srTab, 'sorteos');
  assert.ok(d.querySelector('#srNewDraw'));
  assert.equal(d.querySelectorAll('.sr-card').length, 3);
  assert.deepEqual(raffleMetrics(DATA), { tickets: 1651, active: 1, prizes: 2, pending: 1 });
});

test('Sorteos móvil: cada sorteo muestra solo los botones que le corresponden (crear/editar/cerrar/girar/auditar/eliminar)', () => {
  const d = dom(sorteosScreenHtml({ data: DATA }));
  const [activo, cerrado, ganado] = [...d.querySelectorAll('.sr-card')];
  for (const attr of ['data-sr-close', 'data-sr-edit-draw', 'data-sr-backfill', 'data-sr-audit', 'data-sr-delete', 'data-sr-tickets']) assert.ok(activo.querySelector(`[${attr}]`), `activo: ${attr}`);
  assert.equal(activo.querySelector('[data-sr-spin]'), null);
  assert.ok(cerrado.querySelector('[data-sr-spin]'));
  assert.equal(cerrado.querySelector('[data-sr-close]'), null);
  assert.equal(cerrado.querySelector('[data-sr-edit-draw]'), null);
  assert.ok(cerrado.querySelector('[data-sr-audit]'));
  assert.deepEqual(Object.entries(drawActions(ganado ? DATA.sorteos[2] : {})).filter(([, v]) => v), []);
  assert.ok(ganado.querySelector('.sr-winner-mini'));
  assert.match(activo.textContent, /1[.,\s]?636boletos/);
  assert.match(activo.textContent, /Ambos negocios/);
  assert.match(activo.textContent, /1 mes de Netflix/);
  assert.equal(dom(sorteosScreenHtml({ data: DATA, busy: true })).querySelectorAll('.sr-card button:disabled').length > 0, true);
});

test('Sorteos móvil: premios (editar, eliminar, Club VIP) y ganadores (marcar entregado)', () => {
  const p = dom(sorteosScreenHtml({ data: DATA, tab: 'premios' }));
  assert.ok(p.querySelector('#srNewPrize') && p.querySelector('#srPrepareVip'));
  assert.equal(p.querySelectorAll('[data-sr-edit-prize]').length, 2);
  assert.equal(p.querySelectorAll('[data-sr-delete-prize]').length, 2);
  assert.equal(stockText(DATA.premios[0]), '2 disponible(s)');
  assert.equal(stockText(DATA.premios[1]), '4 código(s) disponible(s)');
  const g = dom(sorteosScreenHtml({ data: DATA, tab: 'ganadores' }));
  assert.match(g.querySelector('.sr-winner').textContent, /Ana Paz/);
  assert.equal(g.querySelector('[data-sr-deliver]').dataset.srDeliver, 'e1');
  assert.equal(dom(sorteosScreenHtml({ data: { ...DATA, entregas: [{ id: 'e1', sorteoId: 's3', estado: 'entregado' }] }, tab: 'ganadores' })).querySelector('[data-sr-deliver]'), null);
  assert.match(dom(sorteosScreenHtml({ data: { sorteos: [], premios: [], entregas: [] }, tab: 'ganadores' })).body.textContent, /Aún no hay ganadores/);
});

test('Formulario de premio: mismos campos que la web y el mismo payload', () => {
  const d = dom(prizeSheetHtml({ permisos: { alcance: 'todos' } }));
  const root = d.body;
  root.querySelector('#srPrizeName').value = '  Cine doble  ';
  root.querySelector('#srPrizeType').value = 'cine';
  root.querySelector('#srPrizeValue').value = '2';
  root.querySelector('#srPrizeDelivery').value = 'codigo';
  root.querySelector('#srPrizeCodes').value = 'A-1\n\n B-2 \n';
  root.querySelector('#srPrizeOwner').value = 'relojes';
  const payload = readPrizeForm(root);
  assert.equal(payload.nombre, 'Cine doble');
  assert.deepEqual(payload.codigos, ['A-1', 'B-2']);
  assert.equal(payload.tipo, 'cine'); assert.equal(payload.valor, 2); assert.equal(payload.entregaModo, 'codigo');
  assert.equal(payload.ownerVendor, 'relojes'); assert.equal(payload.activo, true);
  assert.deepEqual(PRESETS.cine, ['1', 'boleto', 'codigo']);
  // Relojes solo administra lo suyo: no se muestra el selector de dueño
  assert.equal(dom(prizeSheetHtml({ permisos: { alcance: 'relojes' } })).querySelector('#srPrizeOwner'), null);
  assert.match(dom(prizeSheetHtml({ prize: { ...DATA.premios[1], nombre: 'X' }, permisos: {} })).body.textContent, /Ya hay 4 código\(s\)/);
});

test('Formulario de sorteo: 1 a 5 premios, fechas y reglas', () => {
  const now = new Date(2026, 8, 20, 10, 0);
  const d = dom(drawSheetHtml({ premios: DATA.premios, permisos: { alcance: 'todos' }, now }));
  const root = d.body;
  assert.equal(root.querySelector('#srDrawStart').value, '2026-09-20T10:00');
  assert.equal(root.querySelector('#srDrawEnd').value, '2026-09-27T10:00');
  assert.throws(() => readDrawForm(root), /entre 1 y 5 premios/);
  root.querySelector('#srDrawTitle').value = 'Sorteo de prueba';
  root.querySelector('[data-sr-prize-choice][value="p1"]').checked = true;
  const payload = readDrawForm(root);
  assert.equal(payload.titulo, 'Sorteo de prueba');
  assert.deepEqual(payload.premioIds, ['p1']);
  assert.equal(payload.estado, 'activo'); assert.equal(payload.alcance, 'sublicuentas'); assert.equal(payload.categoria, 'general');
  assert.deepEqual(payload.reglas, { compra: 1, renovacion: 2, bonoNivel: false, limitePorCliente: 30 });
  assert.equal(new Date(payload.fechaFin).getTime() > new Date(payload.fechaInicio).getTime(), true);
  assert.equal(root.querySelector('#srVipConditions').hasAttribute('hidden'), true);
  assert.equal(dom(drawSheetHtml({ draw: { ...DATA.sorteos[0], categoria: 'oro' }, premios: DATA.premios })).querySelector('#srVipConditions').hasAttribute('hidden'), false);
  assert.equal(dom(drawSheetHtml({ premios: DATA.premios, permisos: { alcance: 'relojes' } })).querySelector('#srDrawScope').value, 'relojes');
  assert.equal(localInput('no es fecha'), '');
  assert.match(defaultLocal(1, now), /^2026-09-21T10:00$/);
});

test('Boletos, ruleta y confirmaciones', () => {
  const t = dom(ticketsSheetHtml({ draw: DATA.sorteos[1], tickets: DATA.participantes }));
  assert.equal(t.querySelectorAll('.sr-tickets article').length, 2);
  assert.match(t.body.textContent, /Renovación/);
  assert.match(dom(ticketsSheetHtml({ draw: { titulo: 'X', totalBoletos: 50 }, tickets: [] })).body.textContent, /No hay boletos emitidos todavía/);
  const w = dom(wheelSheetHtml({ draw: DATA.sorteos[1], tickets: DATA.participantes }));
  assert.equal(w.querySelector('#srWheel b').textContent, '2');
  assert.match(w.body.textContent, /1 clientes vigentes/);
  assert.ok(w.querySelector('#srWheelGo') && w.querySelector('#srWheelResult'));
  const c = dom(confirmSheetHtml({ title: 'Eliminar', body: 'línea 1\nlínea 2', ok: 'Eliminar', danger: true }));
  assert.ok(c.querySelector('[data-sr-yes]').className.includes('danger'));
  assert.ok(c.querySelector('[data-sr-no]'));
});

test('Auditoría y carga desde agosto: mismos textos y reglas que la web', () => {
  assert.match(backfillPreviewText({ clientesDetectados: 10, compras: 3, renovaciones: 7, boletosEstimados: 17, ambiguos: 1 }, 'Gran sorteo'), /Boletos estimados: 17[\s\S]*“Gran sorteo”/);
  const a = auditText({ resumen: { operacionesVerificadas: 8, boletosEsperados: 12, boletosGuardados: 10, faltantes: 2, sobrantesOSinRespaldo: 0, registrosAmbiguos: 1, clientesConDiferencias: 1 }, diferencias: [{ nombre: 'Ana', telefono: '99', faltantes: 2 }] });
  assert.equal(a.needsRepair, true);
  assert.match(a.text, /Faltantes: 2/); assert.match(a.text, /• Ana \(99\): faltan 2/);
  assert.equal(auditText({ resumen: { faltantes: 0, sobrantesOSinRespaldo: 0 } }).needsRepair, false);
});

test('main.js conecta todas las acciones de Sorteos con /api/sorteos', () => {
  assert.match(api, /export async function raffleAction\(payload=\{\}\) \{ return authPost\('\/api\/sorteos', payload\); \}/);
  for (const accion of ['guardar_premio', 'eliminar_premio', 'preparar_club_vip', 'guardar_sorteo', 'eliminar_sorteo', 'cerrar_sorteo', 'girar_ruleta', 'marcar_entregado', 'auditar_boletos', 'corregir_boletos', 'cargar_agosto_2026']) {
    assert.ok(main.includes(`accion:'${accion}'`), `falta ${accion}`);
  }
  assert.match(main, /return sorteosScreenHtml\(\{data:state\.raffles/);
  assert.match(main, /if\(id==='sorteos'\)await ensureRaffles\(true\)/);
  assert.match(main, /while\(last&&!last\.completado\)/);
  for (const attr of ['data-sr-spin', 'data-sr-close', 'data-sr-delete', 'data-sr-backfill', 'data-sr-audit', 'data-sr-deliver', 'data-sr-edit-draw', 'data-sr-edit-prize', 'data-sr-tickets']) assert.ok(main.includes(`[${attr}]`), attr);
  assert.match(css, /\.sr-host\{position:fixed;inset:0/);
  assert.match(css, /\.sr-wheel\.spinning\{animation:srSpin/);
});

test('Pelis: rediseño del mockup (héroe con palomitas, buscador con botón Buscar y estado vacío)', () => {
  const d = dom(moviesContentHtml({}));
  assert.equal(d.querySelector('h1').textContent, 'Pelis');
  assert.match(d.body.textContent, /Dónde verlas en Honduras/);
  assert.match(d.body.textContent, /Busca una película o serie y te mostramos la sinopsis/);
  assert.ok(d.querySelector('img.pl-art'));
  assert.equal(d.querySelector('#movieForm .pl-go').textContent, 'Buscar');
  assert.match(d.querySelector('.pl-note').textContent, /disponibilidad en Honduras \(TMDB\)/);
  assert.match(d.querySelector('.pl-empty').textContent, /Escribe un título/);
  assert.ok(d.querySelector('#backMore') && d.querySelector('#moviesMenuBtn'));
  assert.ok(dom(moviesContentHtml({ menuOpen: true })).querySelector('#movieClear'));
  assert.ok(dom(moviesContentHtml({ loading: true })).querySelector('.spinner'));
  assert.match(main, /return moviesContentHtml\(\{query:state\.movieQuery/);
  for (const f of ['pelis-hero.webp', 'robot-sentado.webp', 'robot-parado.webp']) assert.ok(exists(`/assets/mas/${f}`), f);
});

test('Robots: Más usa el sentado y Subli el parado (sin recortes)', async () => {
  const { masHomeHtml, subliContentHtml } = await import('../src/screens.js');
  assert.match(masHomeHtml({ modules: ['pelis'] }), /robot-sentado\.webp/);
  assert.match(subliContentHtml({}), /robot-parado\.webp/);
  assert.equal(exists('/assets/mas/mas-robot.png'), false, 'ya no queda el robot viejo');
});
