import test from 'node:test';
import assert from 'node:assert/strict';
import { buildTraditionalFicha, iptvDefaultUrl, iptvDefaultList, iptvProviderKey } from '../src/operations.js';
import { buildCrmUpsertPayload } from '../src/api.js';
import { bootApp } from './helpers/ui-harness.mjs';

const base = { nombrePerfil: 'Carlos', telefono: '32883602', plataforma: 'Nanotech', plataformaRaw: 'evoutouch1', fechaRenovacion: '24/10/2026', perfiles: [{ nombre: 'Carlos', correo: 'CarlosGomez25', clave: '5Ah7TNqM2Cbc' }], vendedor: 'Sublicuentas', mesesContratados: 1, iptvProveedor: 'Nanotech', iptvPantallas: 1, iptvLista: '', iptvHora: '04:37' };

test('R56 Nanotech usa SU url aunque el proveedor se escriba "Nanotech" (antes caía en LatinTV)', () => {
  assert.equal(iptvDefaultUrl('evoutouch1', 'Nanotech'), 'http://smarterstv99.dyndns.tv:25461/');
  assert.equal(iptvDefaultUrl('evoutouch2', ''), 'http://smarterstv99.dyndns.tv:25461/');
  assert.equal(iptvDefaultUrl('liontv3', 'cualquier cosa'), 'http://liontv.es:80');
  assert.equal(iptvDefaultUrl('latintv1', 'latintv2'), 'http://enlatv.com');
  assert.equal(iptvDefaultUrl('latintv1', ''), 'http://latgt.com:8080');
  assert.equal(iptvProviderKey('evoutouch1', 'LatinTV'), 'evoutouch', 'la plataforma manda');
  assert.equal(iptvDefaultList('evoutouch1', ''), 'Nanotech');
});

test('R57 ficha IPTV: Nombre, Lista, Usuario, Contraseña, Fecha y hora de renovación, URL (sin correo)', () => {
  const f = buildTraditionalFicha(base);
  const order = ['Nombre: Carlos', 'Lista: Nanotech', 'Usuario: CarlosGomez25', 'Contraseña: 5Ah7TNqM2Cbc', 'Renovación: 24/10/2026 · 04:37', 'URL: http://smarterstv99.dyndns.tv:25461/'];
  let last = -1; for (const s of order) { const i = f.indexOf(s); assert.ok(i > last, `falta o está fuera de orden: ${s}`); last = i; }
  assert.doesNotMatch(f, /Correo|latgt|Max Player/);
});

test('R57 Max Player: usuario y contraseña PROPIOS de Max Player, además de los de la lista', () => {
  const f = buildTraditionalFicha({ ...base, maxPlayer: true, maxPlayerUsuario: 'carlosmp', maxPlayerClave: 'mp123' });
  assert.match(f, /Usuario: CarlosGomez25/); assert.match(f, /Max Player\*\n\*👤 Usuario: carlosmp\*\n\*🔒 Contraseña: mp123/);
  const payload = buildCrmUpsertPayload({ ...base, plataforma: 'evoutouch1', precio: 80, maxPlayer: true, maxPlayerUsuario: 'carlosmp', maxPlayerClave: 'mp123', correo: 'CarlosGomez25', clave: 'x' });
  assert.equal(payload.servicio.maxPlayer, true); assert.equal(payload.servicio.maxPlayerUsuario, 'carlosmp'); assert.equal(payload.servicio.maxPlayerClave, 'mp123');
});

test('R56 CRM: Nanotech muestra Max Player, Lista, Hora y "Usuario" (no correo)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 300); await app.click('[data-tab-jump="nuevo-crm"]', 300);
    const plat = app.$('#crmPlataforma'); plat.value = 'evoutouch'; plat.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(200);
    assert.ok(app.$('#crmMaxPlayer')); assert.ok(app.$('#crmIptvLista')); assert.equal(app.$('#crmIptvHora').type, 'time');
    assert.equal(app.$('[data-p-email]').placeholder, 'Usuario');
    assert.match(app.$('.crm2-iptv-url').textContent, /smarterstv99/);
    assert.match(app.$('.crm2-iptv-url').textContent, /solo dispositivos y fecha/);
    const mp = app.$('#crmMaxPlayer'); mp.value = 'si'; mp.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(200);
    assert.ok(app.$('#crmMaxUser') && app.$('#crmMaxPass'), 'pide usuario y contraseña de Max Player');
    assert.match(app.$('.crm2-iptv-url').textContent, /usuario y contraseña de Max Player/);
    const u = app.$('#crmMaxUser'); u.value = 'carlosmp'; u.dispatchEvent(new app.w.Event('input', { bubbles: true }));
    const k = app.$('#crmMaxPass'); k.value = 'mp123'; k.dispatchEvent(new app.w.Event('input', { bubbles: true })); await app.sleep(100);
    assert.match(app.$('#crmFichaTexto').value, /Max Player[\s\S]*carlosmp[\s\S]*mp123/);
  } finally { app.close(); }
});
