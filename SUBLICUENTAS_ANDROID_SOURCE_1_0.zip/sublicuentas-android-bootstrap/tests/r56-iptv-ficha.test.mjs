import test from 'node:test';
import assert from 'node:assert/strict';
import { buildTraditionalFicha, iptvDefaultUrl, iptvDefaultList, iptvProviderKey } from '../src/operations.js';
import { buildCrmUpsertPayload } from '../src/api.js';
import { bootApp } from './helpers/ui-harness.mjs';

const base = { nombrePerfil: 'Carlos', telefono: '32883602', plataforma: 'Nanotech', plataformaRaw: 'evoutouch1', fechaRenovacion: '24/10/2026', perfiles: [{ nombre: 'Carlos', correo: 'CarlosGomez25', clave: '5Ah7TNqM2Cbc' }], vendedor: 'Sublicuentas', mesesContratados: 1, iptvProveedor: 'Nanotech', iptvPantallas: 1, iptvLista: '', iptvHora: '04:37' };

test('R56 Nanotech usa SU url aunque el proveedor se escriba "Nanotech" (antes caía en LatinTV)', () => {
  assert.equal(iptvDefaultUrl('evoutouch1', 'Nanotech'), 'http://smarterstv99.dyndns.tv:25461/');
  assert.equal(iptvDefaultUrl('evoutouch2', ''), 'http://smarterstv99.dyndns.tv:25461/');
  assert.equal(iptvDefaultUrl('liontv3', 'cualquier cosa'), 'http://liontv.es:80');
  assert.equal(iptvDefaultUrl('latintv1', 'latintv2'), 'http://enlatv.com');
  assert.equal(iptvDefaultUrl('latintv1', ''), 'http://latgt.com:8080');
  assert.equal(iptvProviderKey('evoutouch1', 'LatinTV'), 'evoutouch', 'la plataforma manda');
  assert.equal(iptvDefaultList('evoutouch1', ''), 'Nanotech');
});

test('R56 ficha IPTV: Nombre, Lista, Usuario, Clave, URL, Hora, Fecha y aviso de dispositivos; sin correo', () => {
  const f = buildTraditionalFicha(base);
  const order = ['Nombre: Carlos', 'Lista: Nanotech', 'Usuario: CarlosGomez25', 'Clave: 5Ah7TNqM2Cbc', 'URL: http://smarterstv99.dyndns.tv:25461/', 'Hora: 04:37', 'Fecha: 24/10/2026'];
  let last = -1; for (const s of order) { const i = f.indexOf(s); assert.ok(i > last, `falta o está fuera de orden: ${s}`); last = i; }
  assert.match(f, /Cuenta válida en 1 dispositivo/);
  assert.doesNotMatch(f, /Correo|latgt/);
});

test('R56 Max Player: la ficha lleva usuario y clave (sin lista ni URL)', () => {
  const f = buildTraditionalFicha({ ...base, maxPlayer: true });
  assert.match(f, /Usuario: CarlosGomez25/); assert.match(f, /Clave: 5Ah7TNqM2Cbc/); assert.match(f, /Max Player/);
  assert.doesNotMatch(f, /URL:|Lista:/);
  const payload = buildCrmUpsertPayload({ ...base, plataforma: 'evoutouch1', precio: 80, maxPlayer: true, correo: 'CarlosGomez25', clave: 'x' });
  assert.equal(payload.servicio.maxPlayer, true);
});

test('R56 CRM: Nanotech muestra Max Player, Lista, Hora y "Usuario" (no correo)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 300); await app.click('[data-tab-jump="nuevo-crm"]', 300);
    const plat = app.$('#crmPlataforma'); plat.value = 'evoutouch'; plat.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(200);
    assert.ok(app.$('#crmMaxPlayer')); assert.ok(app.$('#crmIptvLista')); assert.equal(app.$('#crmIptvHora').type, 'time');
    assert.equal(app.$('[data-p-email]').placeholder, 'Usuario');
    assert.match(app.$('.crm2-iptv-url').textContent, /smarterstv99/);
    const mp = app.$('#crmMaxPlayer'); mp.value = 'si'; mp.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(200);
    assert.match(app.$('.crm2-iptv-url').textContent, /Max Player/);
    assert.match(app.$('#crmFichaTexto').value, /App: Max Player/);
  } finally { app.close(); }
});
