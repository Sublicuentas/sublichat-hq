// R198 · PDF «Sublichat APK: modo offline completo» (18/11/2026) · P0: Baúl de APKs, Inicio y Clientes SIN internet.
// La app REAL en jsdom con un «dispositivo» cuyo almacenamiento sobrevive a cerrar y abrir (IndexedDB + almacén seguro +
// localStorage) y modo avión (ninguna llamada llega al servidor). Datos FICTICIOS.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { miniIndexedDB } from './helpers/mini-idb.mjs';

const MSG = '*Oleada TV · Fire TV*\n1. Abra Downloader\n2. Escriba el código *1290332*';
const BAUL = (editor = false) => ({
  ok: true, editor, version: 7, aviso: 'Instale solo apps autorizadas.',
  plataformas: ['icomplay', 'latintv', 'oleada', 'stellatv', 'evoutouch', 'liontv'].map((id) => ({ id, nombre: { icomplay: 'ICOMPLAY', latintv: 'Latin TV', oleada: 'Oleada TV', stellatv: 'Stella TV', evoutouch: 'Nanotech', liontv: 'Lion TV' }[id] })),
  vistas: [
    { plataforma: 'oleada', dispositivos: [{ id: 'fire_tv', nombre: 'Fire TV', enlaces: [{ id: 'oleada-fire', app: 'Oleada', appId: 'oleada', dispositivo: 'fire_tv', metodo: 'apk', metodoTxt: 'APK directo', url: 'https://descargas.prueba.test/oleada.apk', codigo: '1290332', activo: true, mensaje: MSG }] }] },
    { plataforma: 'liontv', dispositivos: [{ id: 'smart_tv', nombre: 'Smart TV', enlaces: [{ id: 'lion-tv', app: 'Lion TV', appId: 'liontv', dispositivo: 'smart_tv', metodo: 'tv_store', metodoTxt: 'Tienda del TV', activo: true, mensaje: '*Lion TV*\nBusque «Lion TV» en la tienda del televisor.' }] }] },
  ],
  enlaces: [{ id: 'oleada-fire', appId: 'oleada', dispositivo: 'fire_tv', url: 'https://descargas.prueba.test/oleada.apk', codigo: '1290332', activo: true }],
});
const extra = (editor) => async (path, body) => {
  if (path !== '/api/inventario') return undefined;
  if (body.accion === 'baulApks') return BAUL(editor);
  if (body.accion === 'tvUrlsHistorial') return { ok: true, urls: {}, historial: [] };
  return { ok: true };
};
const nuevoDispositivo = () => ({ idb: miniIndexedDB(), seguro: new Map(), local: new Map(), avion: false });
const copiado = (app) => { const out = []; Object.defineProperty(app.w.navigator, 'clipboard', { value: { writeText: async (t) => { out.push(t); } }, configurable: true }); return out; };
async function abrirBaul(app) { await app.click('[data-tab="mas"]', 300); await app.click('[data-open="baul-apks"]', 400); }

test('Baúl en modo avión tras CERRAR y ABRIR la APK, sin haber abierto nunca la pantalla (precarga): 6 plataformas, logos, copiar', async () => {
  const dev = nuevoDispositivo();
  const a = await bootApp({ role: 'geisell', usuario: 'geisell', dispositivo: dev, fetchExtra: extra(false) });
  try {
    assert.ok(await a.waitFor(() => a.bodies.some((b) => b?.accion === 'baulApks'), 6000), 'se precarga sin abrir el Baúl');
    await a.sleep(300); dev.guardarLocal();
  } finally { a.close(); }
  dev.avion = true; // modo avión + app cerrada por completo
  const b = await bootApp({ role: 'geisell', usuario: 'geisell', dispositivo: dev, fetchExtra: extra(false) });
  try {
    assert.ok(b.$('.bottom-nav'), 'Inicio abre sin conexión');
    assert.ok(await b.waitFor(() => /SIN CONEXIÓN/.test(b.$('.offline-band')?.textContent || ''), 9000), 'banda global visible');
    assert.equal(b.$$('.loading-card .spinner').length, 0, 'sin spinner infinito en Inicio');
    await abrirBaul(b);
    assert.ok(await b.waitFor(() => b.$$('[data-baul-plat]').length === 6), 'las seis plataformas desde la copia cifrada');
    assert.match(b.$('.baul-sync').textContent, /Sin conexión · Catálogo sincronizado: \d{2}\/\d{2}\/\d{4}, \d{2}:\d{2}/);
    assert.ok(b.$$('.baul-plat img').every((im) => /^\/assets\/plataformas\//.test(im.getAttribute('src'))), 'logos locales del paquete (no de internet)');
    await b.click('[data-baul-plat="oleada"]', 150); await b.click('[data-baul-disp="fire_tv"]', 150);
    const wrap = b.$('.se-wrap').textContent;
    assert.match(wrap, /1290332/); assert.match(wrap, /Instrucciones guardadas/); assert.match(wrap, /Código guardado/); assert.match(wrap, /Requiere internet para descargar/);
    assert.equal(b.$('[data-baul-abrir]'), null, 'no se ofrece abrir/descargar sin internet');
    const clip = copiado(b);
    await b.click('[data-baul-copiar-msg="oleada-fire"]', 100); await b.click('[data-baul-copiar="1290332"]', 100);
    assert.deepEqual(clip, [MSG, '1290332'], 'instrucciones y código se copian sin internet');
    await b.click('[data-baul-atras="disp"]', 100); await b.click('[data-baul-atras="plat"]', 100);
    await b.click('[data-baul-plat="liontv"]', 120); await b.click('[data-baul-disp="smart_tv"]', 120);
    assert.match(b.$('.se-wrap').textContent, /tienda del televisor/);
  } finally { b.close(); }
});

test('Editor sin señal: no puede editar ni activar (requiere internet) y «Actualizar» no finge nada', async () => {
  const dev = nuevoDispositivo();
  const a = await bootApp({ role: 'sublicuentas', dispositivo: dev, fetchExtra: extra(true) });
  try { await a.waitFor(() => a.bodies.some((x) => x?.accion === 'baulApks'), 6000); await a.sleep(300); dev.guardarLocal(); } finally { a.close(); }
  dev.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: dev, fetchExtra: extra(true) });
  try {
    await abrirBaul(b); await b.waitFor(() => b.$('[data-baul-plat="oleada"]'));
    await b.click('[data-baul-plat="oleada"]', 120); await b.click('[data-baul-disp="fire_tv"]', 120);
    assert.equal(b.$('[data-baul-editar]'), null); assert.equal(b.$('[data-baul-activar]'), null);
    assert.match(b.$('.se-wrap').textContent, /Editar, activar o desactivar requiere internet/);
    assert.equal(b.$('.baul-url'), null, 'la URL técnica no se muestra sin señal');
    await b.click('[data-baul-recargar]', 300);
    assert.ok(b.$$('[data-baul-enlace]').length, 'sigue mostrando la copia');
  } finally { b.close(); }
});

test('Primera instalación sin internet: aviso claro (no spinner); otro usuario en el mismo equipo NO ve la copia ajena', async () => {
  const dev = nuevoDispositivo(); dev.avion = true;
  const a = await bootApp({ role: 'geisell', usuario: 'geisell', dispositivo: dev, fetchExtra: extra(false) });
  try {
    await abrirBaul(a);
    assert.ok(await a.waitFor(() => /todavía no tiene el Baúl guardado/.test(a.$('.se-wrap')?.textContent || '')));
    assert.equal(a.$('.baul-wrap .spinner'), null);
  } finally { a.close(); }
  const dev2 = nuevoDispositivo();
  const s = await bootApp({ role: 'sublicuentas', dispositivo: dev2, fetchExtra: extra(true) });
  try { await s.waitFor(() => s.bodies.some((x) => x?.accion === 'baulApks'), 6000); await s.sleep(300); dev2.guardarLocal(); } finally { s.close(); }
  dev2.avion = true;
  const r = await bootApp({ role: 'relojes', usuario: 'relojes', dispositivo: dev2, fetchExtra: extra(true) });
  try {
    await abrirBaul(r);
    assert.ok(await r.waitFor(() => /todavía no tiene el Baúl guardado/.test(r.$('.se-wrap')?.textContent || '')), 'caja aislada por usuario');
  } finally { r.close(); }
});

test('Clientes sin internet tras reiniciar: búsqueda por nombre en la copia guardada, sin claves en localStorage', async () => {
  const dev = nuevoDispositivo();
  const a = await bootApp({ role: 'sublicuentas', dispositivo: dev, fetchExtra: extra(true) });
  try { await a.waitFor(() => a.bodies.some((x) => x?.accion === 'baulApks'), 6000); await a.sleep(1800); dev.guardarLocal(); } finally { a.close(); }
  const plano = [...dev.local.values()].join(' ');
  for (const secreto of ['subli2', '3300', 'p@x.lat']) assert.ok(!plano.includes(secreto), `localStorage sin ${secreto}`);
  dev.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: dev, fetchExtra: extra(true) });
  try {
    await b.click('[data-tab="clientes"]', 400);
    assert.ok(await b.waitFor(() => /Ana Multi/.test(b.$('.app-main')?.textContent || '')), 'fichas guardadas visibles sin conexión');
    assert.match(b.$('.offline-band').textContent, /Última sincronización: \d{2}\/\d{2}\/\d{4}/);
  } finally { b.close(); }
});

test('Código: precarga enganchada a la sincronización, caja cifrada con la llave del Keystore, main.js < 2000 líneas', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /if\(key==='clients'\)setTimeout\(baulPrecargar,1200\)/);
  assert.ok(main.split('\n').length < 2000);
  const off = fs.readFileSync(new URL('../src/app/offline.js', import.meta.url), 'utf8');
  assert.match(off, /export async function saveBox[\s\S]*seal\(/); assert.doesNotMatch(off, /localStorage\.setItem/);
  const baul = fs.readFileSync(new URL('../src/app/baul-apks.js', import.meta.url), 'utf8');
  assert.doesNotMatch(baul, /localStorage/, 'el Baúl no se guarda en texto plano');
});
