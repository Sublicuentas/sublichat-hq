// R152 · Fase 2 · Push en la APK: plugin, permiso, token después del login, baja al cerrar sesión,
// google-services.json solo desde el secreto del workflow, sin push si la APK no trae Firebase.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { pushDestino, pushHabilitado, pushActivo } from '../src/app/push.js';
import { bootApp } from './helpers/ui-harness.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const leer = (f) => fs.readFileSync(path.join(root, f), 'utf8');

test('plugin instalado una sola vez y sin llaves en el código', () => {
  const pkg = JSON.parse(leer('package.json'));
  assert.ok(pkg.dependencies['@capacitor/push-notifications'], 'plugin de push');
  assert.ok(pkg.dependencies['@capacitor/local-notifications'], 'los recordatorios locales siguen (no se duplica)');
  assert.ok(!fs.existsSync(path.join(root, 'google-services.json')), 'google-services.json no va en el ZIP');
  const src = leer('src/app/push.js');
  assert.doesNotMatch(src, /AIza[0-9A-Za-z_-]{20,}|private_key|BEGIN PRIVATE/);
  assert.match(src, /VITE_PUSH_ENABLED/);
  assert.match(src, /requestPermissions\(\)/);
});

test('sin Firebase en la compilación, push queda apagado (no se llama register y la app no se cierra)', () => {
  assert.equal(pushHabilitado(), false);
});

test('main.js: token después del login (loadRemoteConfig) y baja al cerrar sesión', () => {
  const main = leer('src/main.js');
  assert.match(main, /remoteCfgAt=Date\.now\(\); pushIniciar\(\{authPost/);
  assert.match(main, /function logoutNow\(reason=''\) \{pushBaja\(\{apiBase:API_BASE,session:state\.session\}\)/);
  assert.ok(main.split('\n').length < 2000);
});

test('al tocar la notificación abre donde corresponde', () => {
  assert.deepEqual(pushDestino({ ir: 'tickets', tab: 'tickets' }), { active: 'mas', subview: 'tickets', ticketsTab: 'tickets' });
  assert.deepEqual(pushDestino({ ir: 'tickets' }), { active: 'mas', subview: 'tickets', ticketsTab: 'avisos' });
  assert.deepEqual(pushDestino({ ir: 'clientes' }), { active: 'clientes', subview: null });
  assert.deepEqual(pushDestino({ ir: 'otra-cosa' }), { active: 'inicio', subview: null });
});

test('android-native.mjs: con el secreto escribe google-services.json, ícono y canal; sin él la APK compila sin push', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'push-'));
  fs.mkdirSync(path.join(tmp, 'scripts'));
  fs.copyFileSync(path.join(root, 'scripts/android-native.mjs'), path.join(tmp, 'scripts/android-native.mjs'));
  fs.cpSync(path.join(root, 'android-native'), path.join(tmp, 'android-native'), { recursive: true });
  const main = path.join(tmp, 'android/app/src/main');
  fs.mkdirSync(path.join(main, 'java/com/sublicuentas/app'), { recursive: true });
  fs.mkdirSync(path.join(main, 'res/values'), { recursive: true });
  fs.writeFileSync(path.join(main, 'java/com/sublicuentas/app/MainActivity.java'), 'package com.sublicuentas.app;\npublic class MainActivity {}\n');
  const manifest = '<manifest><application android:label="Sublichat">\n    </application></manifest>';
  fs.writeFileSync(path.join(main, 'AndroidManifest.xml'), manifest);
  const run = (env) => execFileSync(process.execPath, [path.join(tmp, 'scripts/android-native.mjs')], { env: { ...process.env, CAPACITOR_PLATFORM_NAME: 'android', ...env }, encoding: 'utf8' });
  assert.match(run({ GOOGLE_SERVICES_JSON: '' }), /push FCM apagado/);
  assert.ok(!fs.existsSync(path.join(tmp, 'android/app/google-services.json')));
  const gs = { project_info: { project_id: 'demo' }, client: [{ client_info: { android_client_info: { package_name: 'com.sublicuentas.app' } } }] };
  assert.match(run({ GOOGLE_SERVICES_JSON: Buffer.from(JSON.stringify(gs)).toString('base64') }), /push FCM activado/);
  assert.ok(fs.existsSync(path.join(tmp, 'android/app/google-services.json')));
  const m = fs.readFileSync(path.join(main, 'AndroidManifest.xml'), 'utf8');
  assert.match(m, /default_notification_icon" android:resource="@drawable\/ic_stat_sublicuentas"/);
  assert.match(m, /default_notification_channel_id" android:value="sublichat_avisos"/);
  // Correr dos veces no duplica (cap sync se puede repetir).
  run({ GOOGLE_SERVICES_JSON: JSON.stringify(gs) });
  assert.equal((fs.readFileSync(path.join(main, 'AndroidManifest.xml'), 'utf8').match(/default_notification_icon/g) || []).length, 1);
  // google-services.json de otra app → error claro, no compila con Firebase equivocado.
  const otro = { client: [{ client_info: { android_client_info: { package_name: 'com.otra.app' } } }] };
  assert.throws(() => run({ GOOGLE_SERVICES_JSON: JSON.stringify(otro) }));
  assert.ok(fs.existsSync(path.join(root, 'android-res/drawable/ic_stat_sublicuentas.xml')), 'ícono de notificación');
  fs.rmSync(tmp, { recursive: true, force: true });
});

test('Perfil muestra el estado de push y la app arranca sin errores sin Firebase', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(400);
    assert.deepEqual(app.logs.filter((l) => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('con push activo la APK no programa el aviso local de 7 AM / 7 PM (llega del servidor)', () => {
  const av = leer('src/app/avisos.js');
  assert.match(av, /if \(pushActivo\(\)\) \{ REMINDERS\.status='push'; pushPreferencias\(\{ cobros: !!cfg\.activo \}\)/);
  assert.ok(av.indexOf('if (pushActivo())') > av.indexOf('LN.cancel({ notifications:old })'), 'primero se borran los locales ya programados');
  assert.equal(pushActivo(), false, 'sin Firebase en la compilación sigue el aviso local');
  assert.deepEqual(pushDestino({ ir: 'renovar', tab: 'vencidos' }), { active: 'renovar', subview: null, renewFilter: 'vencidos' });
  assert.match(leer('src/main.js'), /onActivo:\(\)=>scheduleCobroReminders\(\{now:true\}\),preferencias:\(\)=>\(\{cobros:!!loadReminderConfig\(\)\.activo\}\)/);
});
