// R196v · APK: el Hogar se confirma EN VIVO con el servidor (misma consulta que Web y Telegram); sin datos viejos por caché.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { inventoryDetailHtml, hogarConsultaVista } from '../src/screens2.js';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');

test('01/14 · el detalle muestra la copia del teléfono como «confirmando…», no como dato definitivo', () => {
  const h = inventoryDetailHtml({ item: { id: 'm1', plataforma: 'netflix', correo: 'madre.demo@ejemplo.com', capacidad: 5, clientes: [] }, label: 'Netflix' });
  assert.match(h, /data-hogar-row/); assert.match(h, /<b data-hogar-texto>Hogar sin asignar<\/b><small data-hogar-nota>Confirmando con Sublichat…<\/small>/);
});

test('01 · la respuesta del servidor manda: titular + perfil; duplicada = incidencia; sin red = «sin confirmar»', () => {
  assert.deepEqual(hogarConsultaVista({ ok: true, aplica: true, hogar: { texto: 'Hogar: Cliente B · Perfil 2' }, incidencia: '' }), { texto: 'Hogar: Cliente B · Perfil 2', nota: 'Confirmado con Sublichat.', incidencia: false });
  const d = hogarConsultaVista({ ok: true, hogar: { texto: 'Hogar sin asignar' }, incidencia: 'Esta cuenta madre está 2 veces en Bodega (mismo correo). El Hogar está registrado en la otra copia (Hogar: Cliente B · Perfil 2).' });
  assert.equal(d.incidencia, true); assert.match(d.nota, /^⚠️ Esta cuenta madre está 2 veces/);
  assert.match(hogarConsultaVista(null, 'timeout').nota, /sin confirmar/);
});

test('02/14 · al confirmar se corrige la copia local (lista/cliente no vuelven al dato anterior) y se usa /api/mobile-core action hogar', () => {
  assert.match(src('src/main.js'), /if\(String\(d\.raw\.plataforma\|\|''\)\.toLowerCase\(\)==='netflix'\) refrescarHogarDetalle\(host,d,state\);/);
  assert.match(src('src/app/hogar-vivo.js'), /if \(it\) \{ if \(r\.hogarDoc\) it\.hogar = r\.hogarDoc; else delete it\.hogar; \}/);
  assert.match(src('src/api.js'), /export async function loadHogar\(inventarioId\) \{ return authPost\('\/api\/mobile-core', \{ action:'hogar', inventarioId:String\(inventarioId\|\|''\) \}\); \}/);
});
