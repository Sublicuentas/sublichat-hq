import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
// La pantalla Más/Clientes vive ahora en src/screens.js (rediseño R37): se revisa junto con main.js.
const main=appSource()+'\n'+fs.readFileSync(new URL('../src/screens.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.4 home keeps only renewal indicators and new Sublichat modules',()=>{
  const start=main.indexOf('function dashboardView()'); const block=main.slice(start,main.indexOf('\n}\n',start)+3); // R74: dashboardView vive en src/app/inicio.js
  assert.match(block,/Vencen hoy/); assert.match(block,/Próximos/); assert.match(block,/Vencidos/);
  assert.doesNotMatch(block,/Cobrado hoy|Disponibles|Acciones rápidas/);
  // R196s · Inicio variante 1: las tarjetas salen de homeModules (accesos existentes), con sus nombres reales.
  // R196w · Kit 3D (PDF 16/11/2026): solo cinco accesos; Clientes y Tickets quedan en la barra inferior.
  assert.match(main,/'sala-juntas', 'finanzas', 'control-maestro', 'recordatorios', 'comercial', 'pelis'/); assert.match(main,/t: 'Control financiero'/); assert.match(main,/t: 'Recordatorios'/); assert.match(main,/t: 'Pelis y estrenos'/);
});
test('R21.4 role footer follows Sublicuentas Relojes and Geisell contract',()=>{
  assert.match(main,/function navTabs\(\)/);
  // Las pestañas salen de roleModules (src/data.js): Geisell sin Cobros, todos con "Más"; Perfil vive dentro de Más.
  assert.match(main,/cobros:\['Cobros','renew'\]/); assert.match(main,/tickets:\['Tickets','ticket'\]/);
  assert.match(main,/mas:\['Más','more'\]/); assert.match(main,/roleModules\(state\.session/);
});
test('R21.4 more exposes media subli profile and operations without deleting them',()=>{
  assert.match(main,/Pelis/); assert.match(main,/Partidos/); assert.match(main,/Subli/); assert.match(main,/Perfil/);
  assert.match(main,/Herramientas operativas/);
});
test('R29 splash loader spins via a JS requestAnimationFrame loop, not CSS animation',()=>{ assert.match(main,/splash-loader/); assert.match(main,/spinSplashLoaderWithJS/); assert.match(main,/requestAnimationFrame/); });
