import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
// La pantalla Más/Clientes vive ahora en src/screens.js (rediseño R37): se revisa junto con main.js.
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8')+'\n'+fs.readFileSync(new URL('../src/screens.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.4 home keeps only renewal indicators and new Sublichat modules',()=>{
  const block=main.slice(main.indexOf('function dashboardView()'),main.indexOf('function currentOperationalRows()'));
  assert.match(block,/Vencen hoy/); assert.match(block,/Próximos/); assert.match(block,/Vencidos/);
  assert.doesNotMatch(block,/Cobrado hoy|Disponibles|Acciones rápidas/);
  assert.match(block,/Aula de clases/); assert.match(block,/Control financiero/); assert.match(block,/Materia cerebral/);
});
test('R21.4 role footer follows Sublicuentas Relojes and Geisell contract',()=>{
  assert.match(main,/function navTabs\(\)/);
  // Las pestañas salen de roleModules (src/data.js): Geisell sin Cobros, todos con "Más"; Perfil vive dentro de Más.
  assert.match(main,/cobros:\['Cobros','renew'\]/); assert.match(main,/tickets:\['Tickets','ticket'\]/);
  assert.match(main,/mas:\['Más','more'\]/); assert.match(main,/roleModules\(state\.session/);
});
test('R21.4 more exposes media subli profile and operations without deleting them',()=>{
  assert.match(main,/Pelis/); assert.match(main,/Partidos/); assert.match(main,/Subli/); assert.match(main,/Perfil/);
  assert.match(main,/Herramientas operativas/);
});
test('R29 splash loader spins via a JS requestAnimationFrame loop, not CSS animation',()=>{ assert.match(main,/splash-loader/); assert.match(main,/spinSplashLoaderWithJS/); assert.match(main,/requestAnimationFrame/); });
