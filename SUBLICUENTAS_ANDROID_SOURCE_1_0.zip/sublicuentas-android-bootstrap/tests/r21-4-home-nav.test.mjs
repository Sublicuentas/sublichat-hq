import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.4 home keeps only renewal indicators and new Sublichat modules',()=>{
  const block=main.slice(main.indexOf('function dashboardView()'),main.indexOf('function currentOperationalRows()'));
  assert.match(block,/Vencen hoy/); assert.match(block,/Próximos/); assert.match(block,/Vencidos/);
  assert.doesNotMatch(block,/Cobrado hoy|Disponibles|Acciones rápidas/);
  assert.match(block,/Aula de clases/); assert.match(block,/Control financiero/); assert.match(block,/Materia cerebral/);
});
test('R21.4 role footer follows Sublicuentas Relojes and Geisell contract',()=>{
  assert.match(main,/function navTabs\(\)/);
  assert.match(main,/\['cobros','Cobros'/); assert.match(main,/\['tickets','Tickets'/);
  assert.match(main,/identity==='geisell'/); assert.match(main,/\['perfil','Perfil'/);
});
test('R21.4 more exposes media subli profile and operations without deleting them',()=>{
  assert.match(main,/Pelis/); assert.match(main,/Partidos/); assert.match(main,/Subli/); assert.match(main,/Perfil/);
  assert.match(main,/Herramientas operativas/);
});
test('R21.4 splash has no overlay loader',()=>{ assert.doesNotMatch(main,/splash-loader/); assert.match(css,/\.splash-art/); });
