import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  crmBasePlatform, crmStoredDeviceCount, crmStoredPlatform, crmAllowedDevices, crmAllowedMonths, crmDefaultPrice,
  platformLabel, telegramSummary, telegramShouldAutoRetry, telegramToast, telegramDelivered,
} from '../src/operations.js';
import { buildCrmUpsertPayload } from '../src/api.js';

const main = appSource();

test('Nanotech: mismos dispositivos y planes que el bot y el servidor (evoutouch1/2/3 · 1/3/6/12 meses)', () => {
  assert.deepEqual(crmAllowedDevices('evoutouch'), [1, 2, 3]);
  assert.deepEqual(crmAllowedMonths('evoutouch'), [1, 3, 6, 12]);
  for (const n of [1, 2, 3]) {
    assert.equal(crmStoredPlatform('evoutouch', n), `evoutouch${n}`);
    assert.equal(crmBasePlatform(`evoutouch${n}`), 'evoutouch');
    assert.equal(crmStoredDeviceCount(`evoutouch${n}`), n);
  }
  // evoutouch4 = alias legado: se lee como Nanotech 1 (igual que el bot y api/renovar.js)
  assert.equal(crmBasePlatform('evoutouch4'), 'evoutouch');
  assert.equal(crmStoredDeviceCount('evoutouch4'), 1);
  assert.equal(crmStoredPlatform('evoutouch', 4), 'evoutouch1');
  assert.equal(crmDefaultPrice('evoutouch2', 'Relojes'), 0);
});

test('Nanotech: la venta viaja al servidor como evoutouch{n} con sus pantallas', () => {
  const payload = buildCrmUpsertPayload({
    nombrePerfil: 'Cliente', telefono: '99999999', plataforma: 'evoutouch2', iptvPantallas: 2,
    vendedor: 'Relojes', precio: 300, fechaRenovacion: '20/10/2026', mesesContratados: 6, correo: 'usuario1', clave: 'x',
  });
  assert.equal(payload.servicio.plataforma, 'evoutouch2');
  assert.equal(payload.servicio.iptvPantallas, 2);
  assert.equal(payload.servicio.mesesContratados, 6);
});

test('Nanotech: el selector usa la base "evoutouch" con nombre Nanotech (ya no EvouTouch 4)', () => {
  assert.match(main, /\['evoutouch','Nanotech'\]/);
  assert.doesNotMatch(main, /\['evoutouch4','EvouTouch'\]/);
  assert.match(main, /CRM_NO_PIN = new Set\([^)]*'evoutouch'/);
});

test('Nombres visibles de plataforma iguales a Sublichat HQ', () => {
  assert.equal(platformLabel('evoutouch2'), 'Nanotech (2 dispositivos)');
  assert.equal(platformLabel('EvouTouch'), 'Nanotech');
  assert.equal(platformLabel('disneyp'), 'Disney Premium');
  assert.equal(platformLabel('algo-nuevo'), 'algo-nuevo');
  assert.equal(platformLabel(''), '');
  assert.doesNotMatch(main, /esc\(row\.plataforma\)/);
});

test('Telegram: el resumen dice a quién llegó y por qué falló cada quien', () => {
  const info = {
    ok: false, partial: true, deliveredRoles: ['jimena'], failedRoles: ['heber'],
    results: [{ ok: true, roles: ['jimena'] }, { ok: false, reason: 'chat_no_encontrado', roles: ['heber'] }],
  };
  const text = telegramSummary(info);
  assert.match(text, /llegó a Jimena/);
  assert.match(text, /falló para Heber/);
  assert.match(text, /Heber: Telegram no encuentra ese chat/);
  assert.deepEqual(telegramDelivered(info), ['Jimena']);
  assert.match(telegramToast({ telegramOk: false, telegramInfo: info }, 'Aviso guardado'), /Aviso guardado · Telegram: llegó a Jimena/);
  assert.equal(telegramToast({ telegramOk: true, telegramInfo: { deliveredRoles: ['relojes', 'geisell'] } }, 'Ticket guardado'), 'Ticket guardado · llegó a Relojes, Geisell.');
  assert.equal(telegramToast({}, 'Ticket guardado'), 'Ticket guardado.');
});

test('Telegram: el motivo del puente de Render llega a pantalla', () => {
  const info = { ok: false, results: [{ ok: false, reason: 'telegram_bridge_error', error: 'ECONNREFUSED', roles: ['heber'] }], failedRoles: ['heber'], deliveredRoles: [] };
  assert.match(telegramSummary(info), /falló el puente con el bot de Render \(ECONNREFUSED\)/);
});

test('Telegram: reintento automático solo si nadie lo recibió y Render no quedó en duda', () => {
  assert.equal(telegramShouldAutoRetry({ deliveredRoles: [], results: [{ ok: false, reason: 'telegram_bridge_error', roles: ['a'] }] }), true);
  assert.equal(telegramShouldAutoRetry({ deliveredRoles: ['a'], results: [] }), false);
  assert.equal(telegramShouldAutoRetry({ deliveredRoles: [], results: [{ ok: false, reason: 'telegram_bridge_timeout', roles: ['a'] }] }), false);
  assert.equal(telegramShouldAutoRetry(null), false);
});

test('Tickets: la app ya no dice "enviado" a ciegas', () => {
  assert.doesNotMatch(main, /showToast\('Ticket enviado\.'\)/);
  assert.doesNotMatch(main, /showToast\('Aviso guardado y enviado\.'\)/);
  assert.match(main, /telegramToast\(result,'Ticket guardado'\)/);
});
