import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { readFileSync } from 'node:fs';

test('Películas: una sincronización que redibuja la pantalla no le quita el teclado al que escribe', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 200);
    const btn = app.$('[data-open="pelis"]') || app.$$('button').find(b => /Pel[ií]culas/.test(b.textContent || ''));
    if (btn) await app.click(btn, 200);
    const input = app.$('#movieQuery');
    assert.ok(input, 'abre Películas');
    input.focus(); input.value = 'Avatar'; input.setSelectionRange(6, 6);
    app.w.dispatchEvent(new app.w.Event('focus')); // simula volver a la app → refresco silencioso
    await app.sleep(300);
    const after = app.$('#movieQuery');
    assert.equal(after.value, 'Avatar', 'conserva lo escrito');
    assert.equal(app.w.document.activeElement, after, 'conserva el foco (no se baja el teclado)');
  } finally { app.close(); }
});

test('render() devuelve foco, texto y cursor al mismo campo; Códigos se borra a los 30 s', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /const ae=document\.activeElement, keep=/);
  assert.match(main, /el\.focus\(\{preventScroll:true\}\)/);
  const cod = readFileSync(new URL('../src/app/codigos.js', import.meta.url), 'utf8');
  assert.match(cod, /export const CODIGO_VISIBLE_MS = 30000;/);
  assert.match(cod, /programarBorrado\(s\);\n    s\.recientes/);
});
