// R189 · APK: Más › Sala de Juntas = la MISMA sala de Sublichat Web (mismo servidor y misma base). Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { roleModules } from '../src/data.js';
import { MAS_MODULES } from '../src/screens.js';

const AHORA = Date.UTC(2026, 9, 4, 18, 0, 0);
const PANEL = { ok: true, yo: { id: 'naara', nombre: 'Naara', anfitriona: true }, permisos: { crear: true, moderar: true }, tiempoReal: true,
  fundadoras: [{ id: 'naara', nombre: 'Naara' }, { id: 'libni', nombre: 'Libni' }, { id: 'geisell', nombre: 'Geisell' }],
  reuniones: [
    { id: 'reuPrueba01', titulo: 'Junta de prueba', agenda: ['Ventas'], inicioMs: AHORA + 3600e3, fecha: '04/10/2026', hora: '1:00 p. m.', duracionMin: 45, estado: 'programada', participantes: ['naara', 'libni', 'geisell'],
      invitaciones: { libni: { estado: 'aceptada' } }, avisos: { enviado: 2, pendiente: 0, fallido: 1, fallas: [{ usuario: 'geisell', tipo: 'h1', error: 'bot bloqueado' }] } },
    { id: 'reuPasada01', titulo: 'Cierre de septiembre', inicioMs: AHORA - 30 * 864e5, fecha: '04/09/2026', hora: '9:00 a. m.', estado: 'finalizada', participantes: ['naara', 'libni'], invitaciones: {} },
  ] };

test('Más: solo se AGREGA Sala de Juntas (fundadoras); un rol desconocido no la ve; navbar intacto', () => {
  assert.ok(MAS_MODULES['sala-juntas']?.svg);
  for (const [r, u] of [['sublicuentas', 'sublicuentas'], ['relojes', 'libni'], ['geisell', 'geisell']]) assert.ok(roleModules(r, u).more.includes('sala-juntas'), u);
  assert.equal(roleModules('otro', 'otro').more.includes('sala-juntas'), false);
  assert.deepEqual(roleModules('geisell', 'geisell').tabs, ['inicio', 'clientes', 'tickets', 'mas']);
});

test('sin tokens en la APK: R193 la sala se abre DENTRO de la APK con la sesión vigente (sin Chrome ni /?sala=)', () => {
  const src = fs.readFileSync(new URL('../src/app/sala-juntas.js', import.meta.url), 'utf8');
  const codigo = src.split('\n').filter((l) => !l.trim().startsWith('//')).join('\n');
  assert.doesNotMatch(codigo, /openLink|\?sala=|API_BASE|LIVEKIT|apiSecret/i);
  assert.match(src, /authPost\('\/api\/sala-juntas'/);
});
// R194 · La agenda/RSVP/entrada ya no tienen pantalla propia en la APK: se abre directo la sala completa de SubliStudio 3D
// (tests/r193-sala-interna.test.mjs). Las reglas de RSVP, avisos y permisos se prueban en el servidor (Sublichat HQ).
