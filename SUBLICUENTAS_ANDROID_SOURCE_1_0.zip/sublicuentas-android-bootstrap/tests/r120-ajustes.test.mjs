import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalizarWhatsapp, waAlertasHtml } from '../src/app/whatsapp-alertas.js';
test('R120: reglas con VPN y sin "2 faltas"/"sin reembolso"', () => {
  const ops = readFileSync(new URL('../src/operations.js', import.meta.url), 'utf8');
  assert.match(ops, /📌 Cuenta con garantía total activa\.\n🚫 Prohibido usar VPN\./);
  assert.match(ops, /⚠ Garantía válida al cumplir las reglas\. De lo contrario, el servicio se suspende\./);
  assert.doesNotMatch(ops, /2 faltas|sin reembolso/);
});
test('R120: número de WhatsApp para alertas (solo configuración)', () => {
  assert.equal(normalizarWhatsapp('9999-9999'), '+50499999999');
  assert.equal(normalizarWhatsapp('+1 305 555 0101'), '+13055550101');
  assert.equal(normalizarWhatsapp('123'), null);
  assert.match(waAlertasHtml({ profile: {} }), /No configurado/);
  assert.match(waAlertasHtml({ profile: { whatsapp_alert_number: '+50499999999' } }), /Configurado · \+50499999999/);
  const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
  assert.match(css, /\.app-main\{padding-bottom:calc\(142px/);
});
