import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildNoRenewalPayload } from '../src/api.js';
const main=appSource();

test('client WhatsApp uses direct whatsapp send URI with normalized phone',()=>{
  assert.match(main,/whatsapp:\/\/send\?phone=\$\{phone\}/);
  assert.match(main,/packageName,/);
});

test('Tickets remains a first-class navigation destination instead of generic WhatsApp',()=>{
  assert.match(main,/tickets:\['Tickets','ticket'\]/);
  const dash=main.slice(main.indexOf('function dashboardView'), main.indexOf('function currentOperationalRows'));
  assert.doesNotMatch(dash,/id="openWhatsApp"/);
});

test('no-renew payload explicitly requires preserving the client record',()=>{
  const payload=buildNoRenewalPayload({clienteId:'c1',servicioIndex:0});
  assert.equal(payload.preservarFicha,true);
  assert.match(main,/Core intentó eliminar la ficha completa/);
});
