import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildNoRenewalPayload } from '../src/api.js';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');

test('client WhatsApp uses direct whatsapp send URI with normalized phone',()=>{
  assert.match(main,/whatsapp:\/\/send\?phone=\$\{phone\}/);
  assert.match(main,/packageName,/);
});

test('dashboard quick action uses Tickets instead of generic WhatsApp',()=>{
  const dash=main.slice(main.indexOf('function dashboardView'), main.indexOf('function currentOperationalRows'));
  assert.match(dash,/data-open="tickets"/);
  assert.doesNotMatch(dash,/id="openWhatsApp"/);
});

test('no-renew payload explicitly requires preserving the client record',()=>{
  const payload=buildNoRenewalPayload({clienteId:'c1',servicioIndex:0});
  assert.equal(payload.preservarFicha,true);
  assert.match(main,/Core intentó eliminar la ficha completa/);
});
