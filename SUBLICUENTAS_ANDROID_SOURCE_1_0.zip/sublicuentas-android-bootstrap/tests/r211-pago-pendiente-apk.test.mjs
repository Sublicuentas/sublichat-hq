// R211 · Regresión: «Pago pendiente por vendedor» visible en renovación (un solo importe y por servicio) y compra nueva.
import test from 'node:test';
import assert from 'node:assert/strict';
import { renewPaySheetHtml, pagoLoteBody, deudaVendedorVista, validarLote } from '../src/app/finanzas-libro.js';
const rows = [{ key: 's0', nombre: 'Disney Premium', label: 'Disney Premium · vence 11/11', precio: 100 }];
test('renovación (un solo importe): 3 opciones; Pago pendiente sin banco, con vendedor por chips', () => {
  const s = { tipo: 'renovacion', unTotal: true, lote: true, rows, precios: {}, cobrado: null, dif: '', cliente: 'Hilda', label: '1 servicio', montos: {} };
  const h = renewPaySheetHtml(s, [{ id: 'bac', nombre: 'BAC' }]);
  assert.match(h, /💵 Con pago/); assert.match(h, /🕒 Pago pendiente/); assert.match(h, /🛠 Ajuste sin pago/);
  const p = { ...s, modo: 'pendiente', responsable: 'vendedor', vendedor: 'Geisell', cobrado: 0, dif: 'pendiente' };
  const hp = renewPaySheetHtml(p, [{ id: 'bac', nombre: 'BAC' }]);
  assert.match(hp, /data-rp-vend="Geisell"/); assert.match(hp, /No entra dinero ni suma a bancos/);
  assert.match(hp, /Geisell · 50 % para Sublicuentas/); assert.match(hp, /L50/);
  assert.doesNotMatch(hp, /¿Dónde entró el dinero\?/); assert.match(hp, /Renovar con pago pendiente/);
  const b = pagoLoteBody(p).pago;
  assert.equal(b.montoTotal, 100); assert.equal(b.recibido, 0); assert.equal(b.bancoId, ''); assert.equal(b.responsable, 'vendedor'); assert.equal(b.vendedorId, 'geisell');
  assert.equal(validarLote(p).ok, true, 'sin banco porque no entró dinero');
});
test('compra nueva: también tiene Pago pendiente; Con pago y Ajuste conservan su comportamiento', () => {
  const c = renewPaySheetHtml({ tipo: 'compra', rows, cliente: 'Ana', label: 'Netflix', montos: {} }, []);
  assert.match(c, /🕒 Pago pendiente/); assert.match(c, /🤝 Ya pagó por Socios/);
  const a = renewPaySheetHtml({ tipo: 'renovacion', modo: 'ajuste', rows, cliente: 'Ana', label: 'x', montos: {} }, []);
  assert.match(a, /Mueve la fecha sin registrar ingreso ni pendiente/);
  assert.deepEqual(deudaVendedorVista('Heber', 150), { deuda: 150, regla: '' });
  assert.equal(deudaVendedorVista('geissel', 150).deuda, 75);
});
