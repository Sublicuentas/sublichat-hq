export const StatusBar={hide:async()=>{},show:async()=>{},setStyle:async()=>{},setBackgroundColor:async()=>{},setOverlaysWebView:async()=>{}};
export const Style={Dark:'DARK',Light:'LIGHT'};
