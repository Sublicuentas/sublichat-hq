export const IntentLauncher={startActivityAsync:async()=>({}),openApplication:async()=>({})};
export const ActivityAction={VIEW:'android.intent.action.VIEW',SEND:'android.intent.action.SEND'};
