export const IntentLauncher={startActivityAsync:async(o)=>{ (globalThis.__intents ||= []).push(o); return {}; },openApplication:async()=>({})};
export const ActivityAction={VIEW:'android.intent.action.VIEW',SEND:'android.intent.action.SEND'};
