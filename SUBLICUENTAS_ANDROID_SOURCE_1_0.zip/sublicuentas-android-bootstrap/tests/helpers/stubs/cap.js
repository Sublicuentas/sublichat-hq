export const Filesystem={writeFile:async()=>({uri:'file:///x'})};export const Directory={Cache:'CACHE'};export const Encoding={UTF8:'utf8'};
export const Share={share:async()=>({}),canShare:async()=>({value:true})};
