// Arranca la app REAL (src/main.js empaquetada con esbuild) dentro de jsdom para probar pantallas y botones como en el teléfono:
// sesión de un rol, datos de clientes simulados y toques (click) sobre la interfaz.
import { JSDOM, VirtualConsole } from 'jsdom';
import { build } from 'esbuild';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const stub = name => path.join(root, 'tests/helpers/stubs', name);
let bundled;
async function bundle() {
  if (bundled) return bundled;
  const out = await build({
    entryPoints: [path.join(root, 'src/main.js')], bundle: true, write: false, format: 'iife', platform: 'browser', logLevel: 'silent',
    loader: { '.css': 'empty' },
    define: { 'import.meta.env': JSON.stringify({ VITE_API_BASE_URL: 'https://api.test', VITE_BUILD_NUMBER: '1', DEV: false, MODE: 'production' }) },
    alias: { '@capacitor/status-bar': stub('statusbar.js'), '@capgo/capacitor-intent-launcher': stub('intent.js'), '@capacitor/filesystem': stub('cap.js'), '@capacitor/share': stub('cap.js') },
  });
  bundled = out.outputFiles[0].text;
  return bundled;
}

export const SAMPLE_CLIENTS = Object.freeze([
  { id: 'c1', nombre: 'Prueba', telefono: '22554675', vendedor: 'Sublicuentas', updatedAt: '2026-09-20T10:00:00Z',
    servicios: [{ plataforma: 'netflix', precio: 130, fechaRenovacion: '20/10/2026', correo: 'p@x.lat', clave: 'subli2', pinPerfil: '3300', vendedor: 'Sublicuentas', compraId: 'k1' }] },
  { id: 'c2', nombre: 'Ana Multi', nombrePerfil: 'Ana Multi', telefono: '99887766', vendedor: 'Relojes', servicios: [
    { plataforma: 'disneyp', precio: 90, fechaRenovacion: '21/12/2026', vendedor: 'Relojes', compraId: 'k2', beneficiarioTipo: 'tercero', beneficiarioNombre: 'Beto',
      perfiles: [{ nombre: 'Ana', correo: 'a@a.com', clave: 'z', pinPerfil: '1111', dispositivo: 'TV', esRoku: false }, { nombre: 'Beto', correo: 'a@a.com', clave: 'z', pinPerfil: '2222', dispositivo: 'Celular' }] },
    { plataforma: 'evoutouch2', precio: 300, fechaRenovacion: '01/12/2026', vendedor: 'Relojes', iptvProveedor: 'evoutouch', iptvPantallas: 2, correo: 'usr1', clave: 'pw' }] },
  { id: 'c3', nombre: 'Sin Fecha', telefono: '', servicios: [{ plataforma: 'stellatv', precio: 0, correo: 'u', clave: 'p' }] },
]);

export const TEST_TICKETS = Object.freeze([
  { id: 't1', numero: 26, titulo: 'Prueba web', tipo: 'aviso', detalle: 'Aviso de prueba', estado: 'abierto', prioridad: 'normal', creadoPorRol: 'sublicuentas', destinosLabel: 'Sublicuentas' },
]);

// R104: Sublicuentas/Relojes confirman la renovación en la hoja de pago real (monto escrito + banco).
// R104/R106: Sublicuentas/Relojes confirman compra/renovación en la hoja de pago (total + recibido + banco).
export async function pagarHojaRenovacion(app, monto = '220', { confirmar = true, recibido = null } = {}) {
  await app.sleep(40);
  if (!app.$('#rpConfirm')) return false; // no hay hoja de pago abierta
  const paid = recibido == null ? Number(monto) : Number(recibido);
  const total = Number(monto);
  if (app.$('#rpCobrado')) { // R196n · renovación con UN solo importe (monto = precio por servicio)
    const n = app.$$('.rp-fila').length || 1;
    for (const input of app.$$('[data-rp-precio]')) { input.value = String(total); input.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(5); }
    const c = app.$('#rpCobrado'); c.value = String(paid * n); c.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(10);
    if (paid < total) { const d = app.$('[data-rp-dif="pendiente"]'); if (d) await app.click(d, 10); }
    const bk = app.$('[data-rp-banco]'); if (bk && paid > 0) await app.click(bk, 30);
    if (confirmar) await app.click('#rpConfirm', 0);
    return true;
  }
  if (paid <= 0) {
    for (const btn of app.$$('[data-rp-status="pendiente"]')) await app.click(btn, 10);
    for (const input of app.$$('[data-rp-pendiente]')) { input.value = String(total); input.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
  } else {
    for (const input of app.$$('[data-rp-pagado]')) { input.value = String(paid); input.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
    if (paid < total) {
      for (const btn of app.$$('[data-rp-toggle-pending]')) await app.click(btn, 10);
      for (const input of app.$$('[data-rp-pendiente]')) { input.value = String(total - paid); input.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
    }
  }
  const banco = app.$('[data-rp-banco]'); if (banco && paid > 0) await app.click(banco, 30);
  if (confirmar) await app.click('#rpConfirm', 0);
  return true;
}

export async function bootApp({ role = 'sublicuentas', usuario = '', clients = SAMPLE_CLIENTS, mobileCoreDelayMs = 0, fetchExtra = null } = {}) {
  const code = await bundle();
  const logs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => logs.push(`ERROR ${(e.detail?.message || e.message)}`));
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>', { url: 'https://localhost/', runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: vc });
  const w = dom.window;
  // Reloj fijo (4-oct-2026 12:00 Honduras) para que los clientes de prueba no se "venzan" con el paso de los días y rompan el build.
  w.eval(`(() => { const R = Date, off = R.UTC(2026, 9, 4, 18, 0, 0) - R.now(); class F extends R { constructor(...a) { if (a.length) super(...a); else super(R.now() + off); } static now() { return R.now() + off; } } window.Date = F; })();`);
  w.sessionStorage.setItem('sublicuentas-session-v1', JSON.stringify({ usuario: usuario || role, role, uid: 'u', idToken: 't', refreshToken: 'r', expiresAt: Date.now() + 3.6e6 }));
  const calls = [], bodies = [];
  w.fetch = async (url, init = {}) => {
    const u = new URL(url); let body = {}; try { body = JSON.parse(init.body || '{}'); } catch (_) {}
    calls.push({ path: u.pathname, action: body.action || body.accion || '', resource: body.resource || '' });
    bodies.push(body);
    let data = { ok: true };
    if (u.pathname === '/api/mobile-core') { if (mobileCoreDelayMs) await new Promise(r => setTimeout(r, mobileCoreDelayMs)); data = { ok: true, items: body.resource === 'clientes' ? clients : [], nextCursor: '' }; }
    if (u.pathname === '/api/tickets' && body.accion === 'eliminar') data = { ok: true, id: body.id };
    else if (u.pathname === '/api/tickets') data = { ok: true, items: TEST_TICKETS, recipients: [] };
    if (u.pathname === '/api/renovar' && body.accion === 'asegurar_enlaces') data = { ok: true, enlaces: [{ token: 'tok123', url: 'https://sublichat.capuchino.lat/c/tok123' }] };
    if (u.pathname === '/api/renovar' && body.accion === 'renovar') data = { ok: true, verified: true, fechaNueva: '22/12/2026' };
    if (u.pathname === '/api/renovar' && body.accion === 'ficha_upsert') data = { ok: true, guardadoEnFirebase: true, clienteId: 'nuevo1', compraId: 'compra1' };
    if (u.pathname === '/api/finanzas' && body.accion === 'registrar_cobro') data = { ok: true };
    if (u.pathname === '/api/finanzas' && body.accion === 'registrar_cobro_renovacion') data = { ok: true, movimientoId: 'mov1' }; // R104
    if (u.pathname === '/api/finanzas' && body.accion === 'registrar_operacion_pago') data = { ok: true, operacionId: 'op1', estado: Number(body.recibido) >= Number(body.montoTotal) ? 'pagado' : (Number(body.recibido) > 0 ? 'parcial' : 'pendiente'), saldo: Math.max(0, Number(body.montoTotal) - Number(body.recibido)) }; // R106
    if (u.pathname === '/api/finanzas' && body.accion === 'finanzas_resumen') data = { ok: true, hoy: '2026-10-04', metodos: [{ id: 'bac-credomatic', nombre: 'BAC Credomatic', logoKey: 'bac', activo: true }, { id: 'ficohsa', nombre: 'Ficohsa', logoKey: 'ficohsa', activo: true }], ciclo: { id: 'ciclo_2026-10-01', inicio: '2026-10-01', dias: 4, diasDesdeUltimoCierre: null }, totales: { ingresos: 0, egresosOperativos: 0, disponibleAntesPlanilla: 0, planilla: 0, resultado: 0 }, bancos: [], totalBancos: 0, planillaPagos: [], cierres: [] }; // R104
    if (u.pathname === '/api/codigos') data = { ok: true, modo: body.modo, resultado: { tipo: 'codigo', correo: body.correo, plataforma: 'netflix', plataformaNombre: 'Netflix', codigo: '4821', asunto: 'Tu código de inicio de sesión', fecha: '26/09/2026 07:10', ts: Date.now() - 120000 } }; // R77
    if (fetchExtra) { const x = await fetchExtra(u.pathname, body); if (x !== undefined) data = x; } // Oct-2026: respuestas propias por prueba
    return { ok: true, status: 200, text: async () => JSON.stringify(data), json: async () => data };
  };
  w.scrollTo = () => {}; w.HTMLElement.prototype.scrollIntoView = () => {};
  w.matchMedia = w.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} }));
  w.confirm = () => true; w.prompt = () => '1';
  Object.defineProperty(w.navigator, 'clipboard', { value: { writeText: async () => {} }, configurable: true });
  w.addEventListener('error', e => logs.push(`ERROR ${e.message}`));
  w.addEventListener('unhandledrejection', e => logs.push(`ERROR ${e.reason?.message}`));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = s => w.document.querySelector(s);
  const $$ = s => [...w.document.querySelectorAll(s)];
  const waitFor = async (fn, ms = 8000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (_) {} await sleep(60); } return null; };
  const click = async (target, wait = 200) => { const el = typeof target === 'string' ? $(target) : target; if (!el) throw new Error(`No existe ${target}`); el.click(); await sleep(wait); };
  w.eval(code);
  if (!await waitFor(() => $('.bottom-nav'))) throw new Error('La app no arrancó');
  return { w, $, $$, sleep, waitFor, click, logs, calls, bodies, tabs: () => $$('.bottom-nav [data-tab]').map(b => b.dataset.tab), close: () => w.close() };
}
