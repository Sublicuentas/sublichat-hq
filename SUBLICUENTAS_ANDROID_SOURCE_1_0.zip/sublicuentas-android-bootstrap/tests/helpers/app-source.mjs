// R74: main.js se dividió en módulos (src/app/*.js). Las pruebas que revisan el código fuente
// leen TODO el código de la app junto: main.js + src/app/*.js.
import fs from 'node:fs';
const dir = new URL('../../src/app/', import.meta.url);
export function appSource() {
  const main = fs.readFileSync(new URL('../../src/main.js', import.meta.url), 'utf8');
  const mods = fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.endsWith('.js')).sort().map(f => fs.readFileSync(new URL(f, dir), 'utf8')) : [];
  return [main, ...mods].join('\n');
}
