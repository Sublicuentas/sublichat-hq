// R198e · Carga UN módulo de src/ (con sus dependencias) dentro de jsdom, empaquetado con esbuild, para probar funciones
// internas con el mismo almacenamiento simulado del teléfono (IndexedDB + almacén seguro). Devuelve sus exports.
import { JSDOM } from 'jsdom';
import { build } from 'esbuild';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const stub = (n) => path.join(root, 'tests/helpers/stubs', n);
export async function cargarModulo(rel, { dispositivo, sesion } = {}) {
  const out = await build({ stdin: { contents: `import * as M from './${rel}'; import { state } from './app/core.js'; window.__M = M; window.__S = state;`, resolveDir: path.join(root, 'src'), loader: 'js' }, bundle: true, write: false, format: 'iife', platform: 'browser', logLevel: 'silent', loader: { '.css': 'empty' },
    define: { 'import.meta.env': JSON.stringify({ VITE_API_BASE_URL: 'https://api.test', VITE_BUILD_NUMBER: '1', DEV: false, MODE: 'production' }) },
    alias: { '@capacitor/status-bar': stub('statusbar.js'), '@capgo/capacitor-intent-launcher': stub('intent.js'), '@capacitor/filesystem': stub('cap.js'), '@capacitor/share': stub('cap.js') } });
  const dom = new JSDOM('<!doctype html><body></body>', { url: 'https://localhost/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  if (dispositivo) { w.indexedDB = dispositivo.idb; w.__SUBLI_PRUEBA_ALMACEN__ = dispositivo.seguro; Object.defineProperty(w.navigator, 'onLine', { get: () => !dispositivo.avion, configurable: true }); }
  if (!w.crypto?.subtle) Object.defineProperty(w, 'crypto', { value: globalThis.crypto, configurable: true });
  if (sesion) w.sessionStorage.setItem('sublicuentas-session-v1', JSON.stringify(sesion));
  w.eval(out.outputFiles[0].text);
  return { w, M: w.__M, S: w.__S, close: () => w.close() };
}
