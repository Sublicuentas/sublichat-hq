// R198 · IndexedDB mínimo EN MEMORIA para pruebas (jsdom no trae IndexedDB). Cubre lo que usa src/app/offline.js:
// open(nombre, versión) + onupgradeneeded, transaction(store, modo).objectStore().put/get, oncomplete y deleteDatabase.
// Las bases se guardan en el Map que se pasa: compartirlo entre dos arranques simula «cerrar y volver a abrir la APK».
export function miniIndexedDB(bases = new Map()) {
  const later = (fn) => setTimeout(fn, 0);
  function open(nombre) {
    const req = { result: null, error: null };
    later(() => {
      let db = bases.get(nombre); const nueva = !db;
      if (!db) { db = { stores: new Map() }; bases.set(nombre, db); }
      const api = {
        objectStoreNames: { contains: (n) => db.stores.has(n) },
        createObjectStore: (n) => { db.stores.set(n, new Map()); return {}; },
        transaction: (store) => {
          const tx = { oncomplete: null, onerror: null, onabort: null, error: null };
          tx.objectStore = () => ({
            put: (v, k) => { const r = { result: k }; db.stores.get(store).set(k, structuredClone(v)); later(() => tx.oncomplete && tx.oncomplete()); return r; },
            get: (k) => { const r = { result: structuredClone(db.stores.get(store).get(k)) }; later(() => tx.oncomplete && tx.oncomplete()); return r; },
          });
          return tx;
        },
        close: () => {},
      };
      req.result = api;
      if (nueva && req.onupgradeneeded) req.onupgradeneeded();
      req.onsuccess && req.onsuccess();
    });
    return req;
  }
  function deleteDatabase(nombre) { const r = {}; later(() => { bases.delete(nombre); r.onsuccess && r.onsuccess(); }); return r; }
  return { open, deleteDatabase, _bases: bases };
}
