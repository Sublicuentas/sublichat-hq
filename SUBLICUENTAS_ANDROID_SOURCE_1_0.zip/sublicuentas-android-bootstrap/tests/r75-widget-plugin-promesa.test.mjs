import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

// Igual que registerPlugin() de Capacitor: un Proxy que devuelve un "método nativo" para CUALQUIER propiedad (también .then).
const fakePlugin = () => new Proxy({}, { get: (_, prop) => (...args) => new Promise(() => {}) /* método nativo inexistente: nunca responde */ });
const withTimeout = (p, ms = 200) => Promise.race([p, new Promise(r => setTimeout(() => r('COLGADO'), ms))]);

test('R75 devolver el plugin suelto desde async se cuelga (causa del widget vacío)', async () => {
  const bare = async () => fakePlugin();
  assert.equal(await withTimeout(bare()), 'COLGADO');
});

test('R75 envuelto en un objeto sí llega', async () => {
  const wrapped = async () => ({ W: fakePlugin() });
  const r = await withTimeout(wrapped());
  assert.notEqual(r, 'COLGADO'); assert.equal(typeof r.W.update, 'function');
});

test('R75 avisos.js envuelve los plugins del widget y de las notificaciones', () => {
  const src = fs.readFileSync(new URL('../src/app/avisos.js', import.meta.url), 'utf8');
  assert.match(src, /return \{ W:widgetPlugin \}/);
  assert.match(src, /\{ LN:m\.LocalNotifications \}/);
  assert.match(src, /\(await homeWidgetPlugin\(\)\)\?\.W/);
  assert.match(src, /\(await notificationsPlugin\(\)\)\?\.LN/);
  assert.doesNotMatch(src, /return widgetPlugin;|return m\.LocalNotifications\|\|null/);
});
