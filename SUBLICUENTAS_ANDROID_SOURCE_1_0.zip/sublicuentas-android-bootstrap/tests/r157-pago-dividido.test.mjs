// Oct-2026 · Pago dividido: el cliente paga lo de la renovación en 2 bancos/métodos el mismo día.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp, pagarHojaRenovacion } from './helpers/ui-harness.mjs';
import { repartoPagos } from '../src/app/finanzas-reglas.js';
import { validarPartes, repartirFilas, operacionPagoBody } from '../src/app/finanzas-libro.js';

const M = [{ id: 'bac', nombre: 'BAC' }, { id: 'tigo', nombre: 'Tigo Money' }, { id: 'ficohsa', nombre: 'Ficohsa' }];

test('Reglas: suma exacta, bancos activos y sin repetir; un solo banco sigue igual', () => {
  assert.deepEqual(repartoPagos([], 220, M, 'bac').pagos, [{ bancoId: 'bac', banco: 'BAC', monto: 220 }]);
  assert.deepEqual(repartoPagos([{ bancoId: 'bac', monto: 120 }, { bancoId: 'tigo', monto: 100 }], 220, M).pagos.map((p) => p.monto), [120, 100]);
  assert.match(repartoPagos([{ bancoId: 'bac', monto: 120 }, { bancoId: 'tigo', monto: 90 }], 220, M).error, /suman L210.*L220/);
  assert.match(repartoPagos([{ bancoId: 'bac', monto: 120 }, { bancoId: 'bac', monto: 100 }], 220, M).error, /repetido/);
  assert.match(repartoPagos([{ bancoId: 'bac', monto: 120 }, { bancoId: 'x', monto: 100 }], 220, M).error, /banco o método/);
  assert.match(validarPartes([{ bancoId: 'bac', monto: 220 }, { bancoId: '', monto: '' }], 220, M).error, /al menos 2/);
  assert.deepEqual(repartirFilas([{ bancoId: 'bac', monto: 150 }, { bancoId: 'tigo', monto: 100 }], [{ key: 'a', recibido: 200 }, { key: 'b', recibido: 50 }]), { a: [{ bancoId: 'bac', monto: 150 }, { bancoId: 'tigo', monto: 50 }], b: [{ bancoId: 'tigo', monto: 50 }] });
  const s = { tipo: 'renovacion', montos: { r: { estadoCobro: 'pagado', pagado: '220' } }, rows: [{ key: 'r' }], pagosPorFila: { r: [{ bancoId: 'bac', monto: 120 }, { bancoId: 'tigo', monto: 100 }] } };
  const b = operacionPagoBody(s, 'r');
  assert.equal(b.bancoId, 'bac'); assert.deepEqual(b.pagos, [{ bancoId: 'bac', monto: 120 }, { bancoId: 'tigo', monto: 100 }]);
});

test('APK: renovar con "Pagó en 2 bancos" manda las dos partes al servidor', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 400);
    await app.click(app.$('.cli-card .cli-dots'), 200);
    await app.click(app.$('[data-client-action="renew"]') || app.$('[data-client-action="charge"]'), 250);
    await app.click(app.$('[data-renew-days="30"]') || app.$$('[data-renew-days]')[0], 60);
    await app.click('#renewApply', 80);
    await pagarHojaRenovacion(app, '220', { confirmar: false });
    await app.click('[data-rp-dividir]', 60);
    assert.ok(app.$('[data-rp-parte-banco="1"]'), 'dos líneas de banco');
    const opts = app.$$('[data-rp-parte-banco="0"] option').map((o) => o.value).filter(Boolean);
    assert.ok(opts.length >= 2, 'hay al menos 2 métodos');
    const set = (sel, v, ev = 'input') => { const el = app.$(sel); el.value = v; el.dispatchEvent(new app.w.Event(ev, { bubbles: true })); };
    set('[data-rp-parte-banco="0"]', opts[0], 'change'); set('[data-rp-parte-monto="0"]', '120');
    set('[data-rp-parte-banco="1"]', opts[1], 'change'); set('[data-rp-parte-monto="1"]', '90');
    assert.match(app.$('#rpPartesSuma').textContent, /faltan L10/);
    await app.click('#rpConfirm', 80);
    assert.match(app.$('#rpError').textContent, /suman L210/);
    set('[data-rp-parte-monto="1"]', '100');
    await app.click('#rpConfirm', 600);
    await app.waitFor(() => app.bodies.some((b) => b?.pago?.pagos || b?.pagos));
    const b = app.bodies.find((x) => x?.pago?.pagos || x?.pagos), pago = b.pago || b;
    assert.deepEqual(pago.pagos, [{ bancoId: opts[0], monto: 120 }, { bancoId: opts[1], monto: 100 }]);
    assert.equal(pago.bancoId, opts[0]); assert.equal(Number(pago.recibido), 220);
  } finally { app.close(); }
});
