import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { BASKET_CHARACTERS, simulateShot, generateNextHoopX, createBasketGame, resolveCurrentShot, setAngle, setPower, bqPause, bqResume, bqRemainingMs, calculateMatchSP, basketProSubmission, BQ } from '../src/basquet.js';
import { bootApp } from './helpers/ui-harness.mjs';

const find = (hx, swish) => { for (let a = 25; a <= 85; a++) for (let p = 10; p <= 100; p++) { const r = simulateShot(a, p, hx); if (r.scored && r.swish === swish) return [a, p]; } };

test('R67 personajes: 2 niños y 1 niña con imagen 3D local', () => {
  assert.deepEqual(BASKET_CHARACTERS.map(c => c.gender), ['BOY', 'BOY', 'GIRL']);
  for (const c of BASKET_CHARACTERS) assert.ok(existsSync(new URL(`../public${c.img}`, import.meta.url)), c.img);
});

test('R67 física determinista: mismo tiro = mismo resultado; en todo el rango del aro hay tiros que entran', () => {
  assert.deepEqual(simulateShot(55, 60, 0.74), simulateShot(55, 60, 0.74));
  for (const hx of [0.60, 0.70, 0.80, 0.88]) { assert.ok(find(hx, true), `limpia posible en ${hx}`); assert.ok(find(hx, false), `enceste posible en ${hx}`); }
  const h = generateNextHoopX(0.7, () => 0.36); assert.ok(h >= BQ.HOOP_MIN && h <= BQ.HOOP_MAX && Math.abs(h - 0.7) >= 0.08, 'el aro cambia de verdad');
});

test('R67 partida: 5 tiros, puntos 2/3, SP = puntos×10 + bonos; ángulo/fuerza con límites; pausa congela', () => {
  let g = createBasketGame('yo', 'girl_1', 0);
  assert.equal(setAngle(g, 10).currentAngle, 25); assert.equal(setPower(g, 500).currentPower, 100);
  for (let i = 0; i < 5; i++) { const [a, p] = find(g.currentHoopX, true); g = resolveCurrentShot(setPower(setAngle(g, a), p), 1000 * (i + 1)); }
  assert.equal(g.status, 'FINISHED'); assert.equal(g.shotsMade, 5); assert.equal(g.totalScore, 15);
  assert.equal(calculateMatchSP(g), 150 + 25 + 15);
  assert.equal(basketProSubmission(g).shots.length, 5); assert.ok(!('totalScore' in basketProSubmission(g)));
  let h = createBasketGame('yo', 'boy_1', 0); h = bqPause(h, 5000); const left = bqRemainingMs(h, 5000); assert.equal(bqRemainingMs(h, 60000), left); h = bqResume(h, 60000);
});

test('R67 en la app: selección de personaje → Comenzar → Lanzar', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250); await app.click('[data-open="materia"]', 400);
    await app.click('.jg2-play[data-jg-play="BASKETBALL"]', 300);
    assert.equal(app.$$('[data-bq-char]').length, 3);
    await app.click('[data-bq-char="girl_1"]', 120); assert.match(app.$('.bq-info').textContent, /Jugadora 3/);
    await app.click('#bqStart', 200);
    assert.ok(app.$('.bq-court') && app.$('#bqAngle') && app.$('#bqPower') && app.$('.bq-shooter[src*="jugadora3"]'));
    await app.click('#bqShoot', 300);
    assert.match(app.$('.bq-kpis').textContent, /1\/5/);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
