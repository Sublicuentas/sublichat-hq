import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { bootApp } from './helpers/ui-harness.mjs';
import { buildChargeMessage, CHARGE_MESSAGE_VARIETY } from '../src/operations.js';

const main = appSource();
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');

test('Mensajes de cobro: miles de combinaciones distintas (antes solo 8) y siempre con nombre, servicio y precio en negrita', () => {
  assert.ok(CHARGE_MESSAGE_VARIETY >= 5000, `variedad total: ${CHARGE_MESSAGE_VARIETY}`);
  const g = { nombre: 'Ana Paz', total: 150, fechaRenovacion: '21/10/2026', servicios: [{ plataforma: 'netflix', precio: 150 }] };
  const seen = new Set();
  for (let i = 0; i < 500; i += 1) seen.add(buildChargeMessage(g, i));
  assert.equal(seen.size, 500, 'sin ningún mensaje repetido en 500 llamadas seguidas');
  for (const msg of [buildChargeMessage(g, 0), buildChargeMessage(g, 1), buildChargeMessage(g, 137)]) {
    assert.match(msg, /\*Ana Paz\*/); assert.match(msg, /\*Netflix\*/); // R52: nombre bonito de la plataforma, no la clave interna assert.match(msg, /\*Lps 150\*/);
    assert.equal(msg.split('\n').length, 2, 'sigue siendo de 2 líneas');
    assert.ok((msg.match(/\p{Extended_Pictographic}/gu) || []).length >= 2, 'con emojis');
    assert.doesNotMatch(msg, /BAC|Ficohsa|Banpa[ií]s|transferencia|dep[oó]sito|cuenta\s+bancaria/i, 'sin datos de pago');
  }
});

test('Nuevo CRM: ahora tiene botón para cerrar y vuelve a donde se abrió', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    // Se abre desde Clientes (➕ Agregar cuenta) y el cierre debe volver a Clientes.
    await app.click('[data-tab="clientes"]', 500);
    await app.click('.cli-dots', 200);
    await app.click('[data-client-action="add-service"]', 300);
    assert.ok(app.$('#crmSubmit'), 'abrió Nuevo CRM');
    assert.ok(app.$('#backMore'), 'ahora SÍ hay botón para cerrar');
    await app.click('#backMore', 250);
    assert.equal(app.$('.bottom-nav .active').dataset.tab, 'clientes', 'vuelve a Clientes, no se queda atorado');
    assert.equal(app.$('#crmSubmit'), null);

    // Se abre desde Más y el cierre debe volver a Más.
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="nuevo-crm"]', 300);
    assert.ok(app.$('#crmSubmit'));
    await app.click('#backMore', 250);
    assert.equal(app.$('.bottom-nav .active').dataset.tab, 'mas');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Inicio: "Su espacio de trabajo" ya no queda pegado a las métricas', () => {
  assert.match(css, /\.visual-workspace\{margin-top:22px!important\}/);
});

test('Aula: la ruta de cursos es una sola columna (ya no hay burbujas zigzag encima de las tarjetas)', () => {
  assert.doesNotMatch(css, /nth-child\(odd\)\{justify-content:flex-start/);
  assert.doesNotMatch(css, /\.aula \.info\{position:absolute/);
  assert.match(css, /\.aula \.node\{position:relative;display:flex;align-items:flex-start;column-gap:14px/);
  const dom = new JSDOM('<body><div class="aula"><div class="path"><button class="node done"><div class="bubble">✅</div><div class="info"><b>Curso</b></div></button></div></div></body>').window.document;
  assert.ok(dom.querySelector('.node .bubble') && dom.querySelector('.node .info'), 'mismo marcado, solo cambió el CSS');
});

test('Calculadora: usa el robot con la calculadora física', () => {
  const calc = fs.readFileSync(new URL('../src/calculadora.js', import.meta.url), 'utf8');
  assert.match(calc, /robot-calc\.webp/);
  assert.ok(fs.existsSync(new URL('../public/assets/mas/robot-calc.webp', import.meta.url)));
});
