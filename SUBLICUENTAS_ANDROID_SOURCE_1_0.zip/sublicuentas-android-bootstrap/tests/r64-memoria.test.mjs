import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { createMemoryGame, openCard, evaluateOpenPair, closeMismatch, removeMatchedPair, checkTimeout, pauseGame, resumeGame, memoryRemainingMs, calculateFinalScore, memorySubmission, chooseAssets, MEMORY_POOL, MEMORY_MODE_CONFIG } from '../src/memoria.js';
import { bootApp } from './helpers/ui-harness.mjs';

const pairOf = (g, id) => g.cards.find(c => c.pairId === g.cards.find(x => x.id === id).pairId && c.id !== id).id;

test('R64 Memoria: 30 imágenes locales, modos del pack y set nuevo cada partida', () => {
  assert.equal(MEMORY_POOL.length, 30);
  for (const a of MEMORY_POOL) assert.ok(existsSync(new URL(`../public${a.src}`, import.meta.url)), a.src);
  assert.deepEqual([6, 8, 10].map((p, i) => MEMORY_MODE_CONFIG[['EASY', 'MEDIUM', 'HARD'][i]].pairs), [6, 8, 10]);
  const g = createMemoryGame('HARD', { now: 0 }); assert.equal(g.cards.length, 20); assert.equal(g.secondsInitial, 40);
  const prev = g.cards.map(c => c.assetId);
  const next = chooseAssets(MEMORY_POOL, 10, prev); assert.equal(next.filter(a => prev.includes(a.id)).length, 0, 'evita repetir el set anterior');
});

test('R64 Memoria: par correcto suma y se retira; error se voltea; pausa congela; tiempo agotado conserva pares', () => {
  let g = createMemoryGame('EASY', { now: 0 });
  const a = g.cards[0].id, b = pairOf(g, a);
  g = openCard(g, a, 1000); g = openCard(g, b, 1100);
  let r = evaluateOpenPair(g, 1200); assert.equal(r.result, 'MATCH'); g = removeMatchedPair(r.state, r.matchedPairId);
  assert.equal(g.pairsFound, 1); assert.equal(g.roundPoints, 10); assert.ok(g.cards.filter(c => c.state === 'REMOVED').length === 2);
  const [x, y] = g.cards.filter(c => c.state === 'HIDDEN'); const y2 = y.pairId === x.pairId ? g.cards.find(c => c.state === 'HIDDEN' && c.pairId !== x.pairId) : y;
  g = openCard(g, x.id, 1300); g = openCard(g, y2.id, 1400); r = evaluateOpenPair(g, 1500); assert.equal(r.result, 'MISMATCH');
  g = closeMismatch(r.state); assert.equal(g.cards.filter(c => c.state === 'OPEN').length, 0); assert.equal(g.mistakes, 1);
  g = pauseGame(g, 11000); const left = memoryRemainingMs(g, 11000); assert.equal(memoryRemainingMs(g, 60000), left, 'en pausa no corre');
  g = resumeGame(g, 60000); g = checkTimeout(g, 60000 + left + 10);
  assert.equal(g.status, 'TIMEOUT'); assert.deepEqual(calculateFinalScore(g), { pairs: 10, completion: 0, timeBonus: 0, total: 10 });
  assert.equal(memorySubmission(g).completed, false);
});

test('R64 en la app: el juego se llama Memoria, tiene modos y se voltean cartas', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250); await app.click('[data-open="materia"]', 400);
    assert.match(app.$('.jg2-page').textContent, /Memoria/);
    await app.click('.jg2-play[data-jg-play="MEMORY_PAIRS"]', 300);
    assert.equal(app.$$('[data-mc-card]').length, 12);
    await app.click('[data-mc-mode="MEDIUM"]', 250); assert.equal(app.$$('[data-mc-card]').length, 16);
    await app.click('[data-mc-mode="HARD"]', 250); assert.equal(app.$$('[data-mc-card]').length, 20);
    await app.click(app.$('[data-mc-card]'), 120);
    assert.ok(app.$('.mc-card.face.open'), 'la carta se voltea');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
