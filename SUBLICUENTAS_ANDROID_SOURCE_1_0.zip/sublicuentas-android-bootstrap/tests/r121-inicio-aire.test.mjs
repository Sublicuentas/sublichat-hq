import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { AIRE_INICIO, ZOOM_MIN_INICIO, zoomBaseInicio, apretarNecesario, ajustarInicio } from '../src/app/inicio-ajuste.js';

const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

// Pantalla simulada: el contenido mide "alto" px, de los cuales "flexible" son márgenes que se pueden acortar.
function pantalla({ navTop, alto, flexible }) {
  const estilo = { zoom: '', vars: {}, setProperty(k, v) { this.vars[k] = v; } };
  const z = () => Number(estilo.zoom) || 1, h = () => Number(estilo.vars['--inicio-apretar']) || 0;
  const shell = { style: estilo, isConnected: true, children: [{ getBoundingClientRect: () => ({ bottom: (alto - flexible * h()) * z() }) }], getBoundingClientRect: () => ({ top: 0 }), querySelectorAll: () => [] };
  const nav = { getBoundingClientRect: () => ({ top: navTop }) };
  const win = { scrollY: 0, innerHeight: navTop + 80, document: { querySelector: () => nav } };
  return { shell, nav, win, fondo: () => shell.children[0].getBoundingClientRect().bottom, z, h };
}

test('R121: el aire pedido está entre 24 y 32 dp', () => {
  assert.ok(AIRE_INICIO >= 24 && AIRE_INICIO <= 32);
});

test('R121: si ya hay aire de sobra, Inicio no cambia en nada', () => {
  const p = pantalla({ navTop: 840, alto: 700, flexible: 44 });
  const r = ajustarInicio(p.shell, p.nav, p.win);
  assert.deepEqual(r, { zoom: 1, apretar: 0 });
  assert.equal(p.shell.style.zoom, '');
  assert.equal(p.shell.style.vars['--inicio-apretar'], '0');
});

test('R121: "Tickets y avisos" pegado a la barra → sube solo con márgenes, sin cambiar tamaños', () => {
  const p = pantalla({ navTop: 704, alto: 704, flexible: 44 }); // justo pegado
  const r = ajustarInicio(p.shell, p.nav, p.win);
  assert.equal(r.zoom, 1, 'nada cambia de tamaño');
  assert.ok(r.apretar > 0 && r.apretar < 1);
  const aire = 704 - p.fondo();
  assert.ok(aire >= AIRE_INICIO && aire <= AIRE_INICIO + 0.1, `aire=${aire}`);
});

test('R121: si antes ya se reducía la escala, se conserva LA MISMA (nada crece ni se achica) y el aire sale de los márgenes', () => {
  const p = pantalla({ navTop: 704, alto: 720, flexible: 60 });
  const base = zoomBaseInicio(0, 704, 720);
  const r = ajustarInicio(p.shell, p.nav, p.win);
  assert.equal(r.zoom, base);
  assert.ok(Math.abs((704 - p.fondo()) - AIRE_INICIO) < 0.2);
});

test('R121: pantalla muy bajita → márgenes al mínimo y recién ahí se reduce un poco más, siempre dejando el aire', () => {
  const p = pantalla({ navTop: 560, alto: 760, flexible: 20 });
  const r = ajustarInicio(p.shell, p.nav, p.win);
  assert.equal(r.apretar, 1);
  assert.ok(r.zoom < zoomBaseInicio(0, 560, 760) && r.zoom >= ZOOM_MIN_INICIO);
  assert.ok(p.fondo() <= 560 - AIRE_INICIO + 0.6);
});

test('R121: cálculos puros', () => {
  assert.equal(zoomBaseInicio(0, 700, 690), 1);
  assert.equal(zoomBaseInicio(0, 700, 2000), ZOOM_MIN_INICIO);
  assert.equal(apretarNecesario(600, 560, 610), 0);
  assert.equal(apretarNecesario(600, 560, 580), 0.5);
  assert.equal(apretarNecesario(600, 560, 500), 1);
  assert.equal(apretarNecesario(600, 600, 590), 1);
  assert.equal(ajustarInicio(null), null);
});

test('R121: sin tocar el diseño — con --inicio-apretar:0 los márgenes son los de siempre', () => {
  assert.match(css, /\.app-main\.home-fixed\{--inicio-apretar:0\}/);
  assert.match(css, /\.app-main\.home-fixed \.visual-workspace\{margin-top:calc\(38px - 24px \* var\(--inicio-apretar\)\)!important\}/);
  assert.match(css, /\.app-main\.home-fixed \.visual-metrics\{margin:calc\(18px - 4px \* var\(--inicio-apretar\)\) 0 calc\(28px - 14px \* var\(--inicio-apretar\)\)!important\}/);
  assert.match(css, /\.app-main\.home-fixed \.visual-module-grid\{row-gap:calc\(14px - 5px \* var\(--inicio-apretar\)\)!important\}/);
  const ini = css.indexOf('R121 · Inicio'), fin = css.indexOf('/* ═', ini + 20); const bloque = css.slice(ini, fin > ini ? fin : undefined); // solo el bloque de Inicio
  assert.doesNotMatch(bloque, /aspect-ratio|font-size|\.mcard|\.visual-bot|\.visual-brand-logo|\.home-tool-card|[^-]width|height/, 'R121 no toca tamaños de cuadros, iconos, robot ni logo');
});

test('R121: main.js delega el ajuste y sigue bajo el límite de líneas', () => {
  assert.match(main, /import \{ ajustarInicio \} from '\.\/app\/inicio-ajuste\.js'/);
  assert.match(main, /shell\.classList\.add\('home-fixed'\);\s*ajustarInicio\(shell,document\.querySelector\('\.bottom-nav'\)\)/);
  assert.doesNotMatch(main, /shell\.style\.zoom=/);
  assert.ok(main.split('\n').length < 2000);
  const mod = readFileSync(new URL('../src/app/inicio-ajuste.js', import.meta.url), 'utf8');
  assert.doesNotMatch(mod, /^import /m, 'sin importaciones: se prueba sola');
});
