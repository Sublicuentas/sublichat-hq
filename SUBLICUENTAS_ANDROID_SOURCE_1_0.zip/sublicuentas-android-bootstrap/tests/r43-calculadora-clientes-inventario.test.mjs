import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { bootApp } from './helpers/ui-harness.mjs';
import {
  DEFAULT_CATALOG, effectiveCatalog, computeTotals, calcInitialState, calcAddCatalog, calcAddManual, calcStep, calcRemove, parseAmount, fmtL, fmtPct,
  sanitizePrices, loadCalcPrices, saveCalcPrices, quoteText, pushCalcHistory, calcScreenHtml, CALC_STORAGE_KEY, CALC_HISTORY_KEY, CALC_CATEGORIES,
} from '../src/calculadora.js';
import { groupClientsByFicha } from '../src/operations.js';

const main = appSource();
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;
const T = (st, prices = {}) => computeTotals(st, effectiveCatalog(prices));
const fresh = (...ids) => { const s = calcInitialState(); ids.forEach(i => calcAddCatalog(s, i)); return s; };

test('Calculadora · casos obligatorios A–F de la especificación', () => {
  assert.equal(T(fresh('netflix', 'prime', 'vix')).subtotal, 290, 'A');                       // Netflix 150 + Prime 80 + VIX 60
  const b = fresh('netflix', 'prime', 'vix'); b.discountValue = '10';
  assert.equal(T(b).total, 280, 'B');                                                          // L 290 - L 10
  const c = fresh('netflix', 'prime', 'vix'); c.discountMode = 'porcentaje'; c.discountValue = '10';
  assert.equal(T(c).total, 261, 'C'); assert.equal(T(c).discount, 29);                         // L 290 - 10 %
  const d = fresh('netflix', 'netflix', 'prime');
  assert.equal(T(d).subtotal, 380, 'D'); assert.equal(T(d).lines[0].amount, 300);              // (150 x 2) + 80
  const e = fresh('netflix'); assert.deepEqual(calcAddManual(e, 'Office 365', '120'), { ok: true });
  assert.equal(T(e).subtotal, 270, 'E');
  const f = fresh('netflix', 'prime', 'vix'); f.finalPrice = '250';
  assert.equal(T(f).discount, 40, 'F'); assert.equal(T(f).savingPct, 13.79); assert.equal(fmtPct(T(f).savingPct), '13.79%');
  assert.equal(T(f).total, 250);
});

test('Calculadora · descuentos, validaciones y "Quiero cobrar"', () => {
  const s = fresh('netflix', 'prime', 'vix');
  s.discountValue = '9999'; assert.equal(T(s).discount, 290); assert.equal(T(s).total, 0); assert.ok(T(s).errors.length, 'descuento mayor que el subtotal se limita y avisa');
  s.discountValue = '-5'; assert.equal(T(s).discount, 0); assert.ok(T(s).errors.length, 'negativo no se acepta');
  s.discountValue = 'abc'; assert.equal(T(s).discount, 0); assert.ok(T(s).errors.length, 'NaN no se acepta');
  s.discountMode = 'porcentaje'; s.discountValue = '150'; assert.equal(T(s).discount, 290); assert.ok(T(s).errors.some(x => /100/.test(x)), 'porcentaje mayor de 100 se limita');
  s.discountValue = '0'; assert.equal(T(s).total, 290);
  s.discountValue = ''; s.finalPrice = '400'; const inc = T(s);
  assert.equal(inc.discount, 0); assert.equal(inc.increase, 110); assert.equal(inc.total, 400, 'precio final mayor = incremento, no descuento');
  s.finalPrice = '-3'; assert.ok(T(s).errors.length); assert.equal(T(s).total, 290);
  const empty = T(calcInitialState()); assert.equal(empty.subtotal, 0); assert.equal(empty.total, 0); assert.equal(empty.savingPct, 0);
  const noneFinal = calcInitialState(); noneFinal.finalPrice = '100'; assert.equal(T(noneFinal).total, 0, 'sin productos no hay total');
  assert.deepEqual([parseAmount('').ok, parseAmount('-1').ok, parseAmount('x').ok, parseAmount('1,250.5').value], [true, false, false, 1250.5]);
  assert.equal(fmtL(150), 'L 150'); assert.equal(fmtL(150.5), 'L 150.50'); assert.equal(fmtL(1250), 'L 1,250'); assert.equal(fmtL(-10), '-L 10');
});

test('Calculadora · cantidades, eliminar y separación precio base vs producto manual', () => {
  const s = fresh('netflix'); calcStep(s, 'c-netflix', 1); assert.equal(s.items[0].qty, 2);
  calcStep(s, 'c-netflix', -1); calcStep(s, 'c-netflix', -1); assert.equal(s.items.length, 0, 'menos de 1 lo quita');
  calcAddCatalog(s, 'prime'); calcRemove(s, 'c-prime'); assert.equal(s.items.length, 0);
  assert.equal(calcAddManual(s, '', 10).ok, false); assert.equal(calcAddManual(s, 'X', -5).ok, false); assert.equal(calcAddManual(s, 'X', 'abc').ok, false); assert.equal(calcAddManual(s, 'X', 0).ok, false);
  const before = JSON.stringify(effectiveCatalog());
  calcAddManual(s, 'Office 365', 120); calcAddManual(s, 'Cotización especial', 99.5);
  assert.equal(T(s).subtotal, 219.5, 'varios manuales en una misma venta');
  assert.equal(JSON.stringify(effectiveCatalog()), before, 'un producto manual NO cambia el catálogo');
  const prices = { netflix: 200 }; const n = fresh('netflix'); assert.equal(T(n, prices).subtotal, 200, 'un precio editado se refleja en la venta');
  assert.equal(effectiveCatalog(prices).find(p => p.id === 'netflix').precioBase, 150);
  assert.equal(DEFAULT_CATALOG.filter(p => ['netflix', 'prime', 'vix'].includes(p.id)).map(p => p.precio).join(), '150,80,60');
});

test('Calculadora · los precios personalizados se guardan (localStorage) y se validan', () => {
  const mem = new Map(); const storage = { getItem: k => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v) };
  assert.equal(saveCalcPrices(storage, { netflix: 175, prime: 80, vix: -4, zzz: 10 }), true);
  assert.deepEqual(loadCalcPrices(storage), { netflix: 175 }, 'solo lo distinto del precio base y válido');
  assert.deepEqual(sanitizePrices({ netflix: 'abc', vix: '65' }), { vix: 65 });
  assert.deepEqual(loadCalcPrices({ getItem: () => '{roto' }), {});
  assert.equal(pushCalcHistory(storage, { at: 1, total: 280, text: 'x' }), 1); assert.equal(pushCalcHistory(storage, { at: 2, total: 1, text: 'y' }), 2);
  assert.equal(JSON.parse(mem.get(CALC_HISTORY_KEY))[0].at, 2);
  assert.equal(CALC_STORAGE_KEY, 'sublichat-calc-v1');
});

test('Calculadora · texto de la cotización', () => {
  const s = fresh('netflix', 'netflix', 'prime'); s.discountValue = '30';
  const q = quoteText(T(s));
  assert.match(q, /Cotización Sublicuentas/); assert.match(q, /Netflix x2 — L 300/); assert.match(q, /Prime Video — L 80/);
  assert.match(q, /Subtotal: L 380/); assert.match(q, /Descuento: -L 30/); assert.match(q, /Total a cobrar: L 350/);
});

test('Calculadora · pantalla como el mockup', () => {
  const st = fresh('netflix', 'prime', 'vix'); st.discountValue = '10';
  const d = dom(calcScreenHtml({ st, catalog: effectiveCatalog() }));
  assert.equal(d.querySelector('h1').textContent, 'Calculadora de venta');
  assert.match(d.body.textContent, /Calcula, combina y vende más/);
  assert.deepEqual([...d.querySelectorAll('[data-calc-mode]')].map(b => b.dataset.calcMode), ['catalog', 'manual']);
  assert.deepEqual([...d.querySelectorAll('[data-calc-cat]')].map(b => b.dataset.calcCat), CALC_CATEGORIES.map(c => c[0]));
  assert.ok(d.querySelector('#calcSearch') && d.querySelector('#calcEdit') && d.querySelector('img.pf-logo'));
  assert.ok(d.querySelectorAll('[data-calc-add]').length >= 9);
  assert.equal(d.querySelectorAll('.cc-line').length, 3);
  assert.match(d.querySelector('#calcSummary').textContent, /Subtotal\s*L 290/); assert.match(d.querySelector('#calcSummary').textContent, /Descuento\s*-L 10/);
  assert.match(d.querySelector('#calcSummary').textContent, /Total a cobrar\s*L 280/); assert.match(d.querySelector('#calcSummary').textContent, /Ahorras L 10/);
  assert.deepEqual([...d.querySelectorAll('[data-calc-quick]')].map(b => b.dataset.calcQuick), ['5', '10', '20', '30']);
  assert.deepEqual([...d.querySelectorAll('[data-calc-dmode]')].map(b => b.dataset.calcDmode), ['lempiras', 'porcentaje']);
  assert.ok(d.querySelector('#calcFinal') && d.querySelector('#calcManualName') && d.querySelector('#calcManualAdd') && d.querySelector('#calcClear') && d.querySelector('#calcSave'));
  const vacio = dom(calcScreenHtml({ st: calcInitialState(), catalog: effectiveCatalog() }));
  assert.equal(vacio.querySelector('#calcSave').disabled, true, 'sin productos no se puede guardar');
  assert.equal(vacio.querySelector('#calcDiscount').disabled, true);
  assert.equal(vacio.querySelector('#calcClear').disabled, true);
  const filtro = fresh('netflix'); filtro.cat = 'musica';
  const f = dom(calcScreenHtml({ st: filtro, catalog: effectiveCatalog() }));
  assert.ok([...f.querySelectorAll('[data-calc-add]')].every(b => ['spotify', 'deezer'].includes(b.dataset.calcAdd)), 'el filtro solo afecta el catálogo');
  assert.equal(f.querySelectorAll('.cc-line').length, 1, 'y no toca lo ya seleccionado');
  const manual = dom(calcScreenHtml({ st: { ...calcInitialState(), mode: 'manual' }, catalog: effectiveCatalog() }));
  assert.equal(manual.querySelector('.cc-grid'), null); assert.ok(manual.querySelector('#calcUseSaved'));
  const edit = dom(calcScreenHtml({ st: { ...calcInitialState(), editing: true }, catalog: effectiveCatalog({ netflix: 175 }) }));
  assert.equal(edit.querySelector('[data-calc-price="netflix"]').value, '175'); assert.match(edit.body.textContent, /Base: L 150/);
});

test('Calculadora · funciona de punta a punta en la app para Sublicuentas, Relojes y Geisell', async () => {
  for (const role of ['sublicuentas', 'relojes', 'geisell']) {
    const app = await bootApp({ role });
    try {
      await app.click('[data-tab="mas"]', 300);
      assert.ok(app.$('.mas-card[data-open="calculadora"]'), `${role}: tarjeta Calculadora de venta en Más`);
      assert.match(app.$('.mas-card[data-open="calculadora"]').textContent, /Calculadora de venta/);
      await app.click('[data-open="calculadora"]', 300);
      assert.ok(app.$('.cc-page'), `${role}: abre la calculadora`);
      assert.equal(app.$('.bottom-nav .active').dataset.tab, 'mas', 'el footer no cambia y Más sigue activo');
      const setVal = (sel, v, ev = 'input') => { const el = app.$(sel); el.value = v; el.dispatchEvent(new app.w.Event(ev, { bubbles: true })); };
      const sum = () => app.$('#calcSummary').textContent.replace(/\s+/g, ' ');
      for (const id of ['netflix', 'prime', 'vix']) await app.click(`[data-calc-add="${id}"]`, 120);
      assert.match(sum(), /Subtotal L 290/); assert.match(sum(), /Total a cobrar L 290/);
      await app.click('[data-calc-quick="10"]', 150);
      assert.match(sum(), /Total a cobrar L 280/);
      await app.click('[data-calc-dmode="porcentaje"]', 150); await app.click('[data-calc-quick="10"]', 150);
      assert.match(sum(), /Total a cobrar L 261/);
      setVal('#calcDiscount', '20'); assert.match(sum(), /Descuento -L 58/); assert.match(sum(), /Total a cobrar L 232/);   // 20 % de 290, en tiempo real sin botón calcular
      setVal('#calcFinal', '250'); await app.sleep(120);
      assert.match(sum(), /Descuento -L 40/); assert.match(sum(), /13\.79% menos/); assert.match(sum(), /Total a cobrar L 250/);
      setVal('#calcFinal', ''); await app.sleep(120);
      await app.click('[data-calc-dmode="lempiras"]', 120);
      await app.click('[data-calc-plus="c-netflix"]', 120);
      assert.match(sum(), /Subtotal L 440/);
      await app.click('[data-calc-minus="c-netflix"]', 120); await app.click('[data-calc-del="c-vix"]', 120);
      assert.match(sum(), /Subtotal L 230/);
      await app.click('[data-calc-mode="manual"]', 150);
      setVal('#calcManualName', 'Office 365'); setVal('#calcManualPrice', '120');
      await app.click('#calcManualAdd', 200);
      assert.match(app.$('#calcLines').textContent, /Office 365/); assert.match(sum(), /Subtotal L 350/);
      assert.match(app.w.localStorage.getItem(CALC_STORAGE_KEY) || '{}', /^\{/, 'nada del catálogo se guardó por agregar un manual');
      assert.equal(JSON.parse(app.w.localStorage.getItem(CALC_STORAGE_KEY) || '{"prices":{}}').prices.netflix, undefined);
      await app.click('#calcUseSaved', 150);
      await app.click('#calcEdit', 150);
      setVal('[data-calc-price="netflix"]', '200', 'change'); await app.sleep(150);
      assert.equal(JSON.parse(app.w.localStorage.getItem(CALC_STORAGE_KEY)).prices.netflix, 200, 'el precio base se guarda');
      await app.click('#calcEdit', 150);
      assert.match(app.$('[data-calc-add="netflix"]').textContent, /L 200/);
      assert.match(sum(), /Subtotal L 400/, 'lo ya seleccionado usa el precio nuevo (200 + 80 + 120)');
      await app.click('#calcSave', 200);
      assert.ok(JSON.parse(app.w.localStorage.getItem(CALC_HISTORY_KEY))[0].total > 0);
      await app.click('#calcClear', 150);
      assert.equal(app.$$('.cc-line').length, 0); assert.equal(app.$('#calcSave').disabled, true);
      await app.click('#backMore', 250);
      assert.ok(app.$('.mas-card[data-open="calculadora"]'), 'atrás vuelve a Más');
      assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), [], `${role}: sin errores`);
    } finally { app.close(); }
  }
});

test('Inventario en Más para Geisell y Relojes (y sigue en Sublicuentas)', async () => {
  for (const role of ['sublicuentas', 'relojes', 'geisell']) {
    const app = await bootApp({ role });
    try {
      await app.click('[data-tab="mas"]', 300);
      assert.ok(app.$('.mas-card[data-open="inventario"]'), `${role}: tarjeta Inventario`);
      await app.click('[data-open="inventario"]', 500);
      assert.ok(app.$('.inv-page'), `${role}: abre Inventario`);
      assert.ok(app.calls.some(c => c.path === '/api/mobile-core' && c.resource === 'inventario'), `${role}: pide el inventario al servidor`);
      assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
    } finally { app.close(); }
  }
});

test('Clientes: 1 ficha = 1 tarjeta aunque tenga cuentas con fechas distintas (como en la web)', async () => {
  const rows = [
    { clienteId: 'a', nombre: 'Olvin Padilla', telefono: '8795', vendedor: 'Sublicuentas', plataforma: 'evoutouch2', fechaRenovacion: '19/10/2026', precio: 80 },
    { clienteId: 'a', nombre: 'Olvin Padilla', telefono: '8795', vendedor: 'Sublicuentas', plataforma: 'vipnetflix', fechaRenovacion: '21/10/2026', precio: 150 },
    { clienteId: 'a', nombre: 'Olvin Padilla', telefono: '8795', vendedor: 'Sublicuentas', plataforma: 'disneyp', fechaRenovacion: '21/10/2026', precio: 140 },
    { clienteId: 'b', nombre: 'Nicolle', telefono: '9687', vendedor: 'Relojes', plataforma: 'hbomax', fechaRenovacion: '28/09/2026', precio: 70 },
  ];
  const g = groupClientsByFicha(rows);
  assert.equal(g.length, 2);
  const olvin = g.find(x => x.clienteId === 'a');
  assert.equal(olvin.servicios.length, 3); assert.equal(olvin.fechaRenovacion, '19/10/2026', 'muestra la fecha más próxima');
  assert.equal(olvin.total, 80, 'se cobra por cuenta, en su fecha'); assert.deepEqual(olvin.vendedores, ['Sublicuentas']);
  assert.equal(groupClientsByFicha([{ nombre: 'X', telefono: '1', plataforma: 'a' }, { nombre: 'x', telefono: '1', plataforma: 'b' }]).length, 1, 'fichas antiguas sin id se unen por nombre y teléfono');

  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 500);
    const cards = app.$$('.cli-card');
    assert.equal(cards.length, 2, 'Ana Multi tiene 2 cuentas y sale UNA sola vez');
    assert.equal(cards.filter(c => c.textContent.includes('Ana Multi')).length, 1);
    const ana = cards.find(c => c.textContent.includes('Ana Multi'));
    assert.match(ana.textContent, /evoutouch2/); assert.match(ana.textContent, /disneyp/); assert.match(ana.textContent, /01\/12\/2026/); assert.match(ana.textContent, /L\s*300\.00/);
    assert.match(app.$('.cli-meta').textContent, /Mostrando 2 de 2 clientes · 3 cuentas/);
    // ⋮ con selector de cuenta: cada acción funciona sobre la cuenta elegida
    for (let pick = 0; pick < 2; pick++) {
      for (const action of ['renew', 'charge', 'edit', 'ficha', 'url', 'no-renew']) {
        await app.click('[data-tab="clientes"]', 120);
        for (const b of app.$$('#closeClientActionsBtn')) b.click();
        const i = app.$$('.cli-card').findIndex(c => c.textContent.includes('Ana Multi'));
        await app.click(app.$$('.cli-dots')[i], 150);
        const picks = app.$$('[data-client-svc]'); assert.equal(picks.length, 2, 'selector con las 2 cuentas');
        await app.click(picks[pick], 150);
        assert.equal(app.$('.client-svc-picker .on').dataset.clientSvc, picks[pick].dataset.clientSvc);
        const btn = app.$(`[data-client-action="${action}"]`); assert.ok(btn, `falta ${action}`);
        btn.click(); await app.sleep(350);
        if (action === 'renew' || action === 'charge') assert.ok(app.$('.renew-backdrop'), `cuenta ${pick}: ${action} abre la renovación`);
        if (action === 'edit') assert.ok(app.$('#crmSubmit'), `cuenta ${pick}: editar abre la ficha`);
        if (action === 'url') assert.ok(app.$('#clientCopyUrlMessage'), `cuenta ${pick}: url muestra variantes`);
        if (action === 'no-renew') assert.ok(app.calls.some(c => c.action === 'no_renovo'));
      }
    }
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), [], 'ninguna acción lanza errores');
  } finally { app.close(); }
});

test('Inicio: el robot queda libre (la frase no lo tapa) y todo baja un poco', () => {
  assert.match(css, /\.visual-home-brand\{max-width:57%!important\}/);
  assert.match(css, /\.app-main\.home-fixed\{padding-top:calc\(env\(safe-area-inset-top,0px\) \+ 34px\)!important\}/);
  assert.match(main, /calc:calcInitialState\(\), calcPrices:loadCalcPrices\(localStorage\)/);
  assert.match(main, /if \(state\.subview==='calculadora'\) return calculatorView\(\);/);
});
