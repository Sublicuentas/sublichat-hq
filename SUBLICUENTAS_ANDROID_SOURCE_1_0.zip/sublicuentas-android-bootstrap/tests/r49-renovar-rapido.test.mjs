import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('main.js: renovar ya NO espera la recarga completa del CRM antes de avisar (esa espera era la lentitud real)', () => {
  assert.match(main, /for\(const \[row,fecha\] of renewedRows\)\{if\(row\?\.raw\)row\.raw\.fechaRenovacion=fecha;\}/);
  assert.match(main, /state\.mutating=false;state\.renewGroupKey=''[^\n]*render\(\);\n\s*showToast\(/, 'el aviso sale justo después de aplicar los cambios locales');
  const tail = main.slice(main.indexOf("showToast(`${ok} renovación"));
  assert.ok(tail.startsWith("showToast(`${ok} renovación") && tail.slice(0, 400).includes("\n  loadCoreData({force:true});\n}"), 'la recarga completa se dispara DESPUÉS del aviso, sin esperarla (sin await)');
  assert.doesNotMatch(main, /await loadCoreData\(\{force:true\}\);showToast\(`\$\{ok\}/, 'ya no bloquea el aviso esperando la recarga completa');
});

test('Renovar: el cliente ve la fecha nueva y el aviso de inmediato, aunque la recarga completa del CRM tarde', async () => {
  const app = await bootApp({ role: 'sublicuentas', mobileCoreDelayMs: 400 }); // simula un CRM grande y lento de recargar
  try {
    await app.click('[data-tab="clientes"]', 400);
    const card = app.$$('.cli-card').find(c => c.textContent.includes('Ana Multi')) || app.$('.cli-card');
    const dots = card.querySelector('.cli-dots');
    await app.click(dots, 200);
    const renewBtn = app.$('[data-client-action="renew"]') || app.$('[data-client-action="charge"]');
    await app.click(renewBtn, 250);
    const days30 = app.$('[data-renew-days="30"]') || app.$$('[data-renew-days]')[0];
    assert.ok(days30, 'hay un botón de renovación disponible');
    await app.click(days30, 60); // R52: primero se elige la opción…
    const t0 = Date.now();
    await app.click('#renewApply', 60); // …y se confirma con "Renovar a fecha elegida" (solo un respiro corto)
    const elapsed = Date.now() - t0;
    assert.ok(app.$('.toast') || app.w.document.body.textContent.includes('renovación confirmada'), 'el aviso ya apareció');
    assert.ok(elapsed < 350, `el aviso debe llegar antes de que termine la recarga lenta simulada (tardó ${elapsed}ms)`);
    await app.sleep(500); // dejar que la recarga en segundo plano termine, sin que rompa nada
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
