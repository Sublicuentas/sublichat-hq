import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import ExcelJS from 'exceljs';
import {
  finParse, finMoney, mergeFinanceSources, parseAllFinance, periodRange, filterMovs, totalsOf, byBankOf, lastMonthsOf,
  weekRange, financeContentHtml, buildFinanceWorkbook, financeFileName,
} from '../src/finanzas.js';
import { bufferToBase64 } from '../src/finanzas-file.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

const docs = [
  { id: 'a1', tipo: 'ingreso', monto: '150', fecha: '20/09/2026', metodoPago: 'BAC', plataforma: 'netflix', clienteNombre: 'Ana' },
  { id: 'a2', tipo: 'egreso', monto: 40, fechaPago: '2026-09-19', motivo: 'Compra cuentas', banco: 'Ficohsa' },
  { id: 'h1', tipo: 'Cobro', monto: 'L 1,200.50', createdAt: '2026-08-15T18:00:00Z', banco: '' },
  { id: 'h2', type: 'gasto', amount: 300, date: '05/07/2026', descripcion: 'Internet' },
  { id: 'x', tipo: 'ingreso', monto: 10 }, // sin fecha: se descarta igual que en la web
];

test('Finanzas: normaliza igual que la web (fechas DMY/ISO/timestamp, montos, banco, egreso/ingreso)', () => {
  assert.equal(finMoney('L 1,200.50'), 1200.5);
  assert.equal(finMoney(-30), 30);
  const [a1, a2, h1, h2] = docs.map(finParse);
  assert.equal(a1.tipo, 'ingreso'); assert.equal(a1.banco, 'BAC'); assert.equal(a1.concepto, 'Netflix'); assert.equal(a1.fecha.getDate(), 20);
  assert.equal(a2.tipo, 'egreso'); assert.equal(a2.concepto, 'Compra cuentas'); assert.equal(a2.fecha.getMonth(), 8);
  assert.equal(h1.monto, 1200.5); assert.equal(h1.banco, 'Sin banco'); assert.equal(h1.fecha.getMonth(), 7);
  assert.equal(h2.tipo, 'egreso'); assert.equal(h2.fecha.getMonth(), 6);
  assert.equal(parseAllFinance(docs).length, 4, 'el movimiento sin fecha no cuenta');
});

test('Finanzas: histórico + actual se unen por id y lo actual manda', () => {
  const merged = mergeFinanceSources([{ id: 'k', monto: 1 }, { id: 'solo-h', monto: 5 }], [{ id: 'k', monto: 2 }]);
  assert.equal(merged.length, 2);
  const k = merged.find(x => x.id === 'k');
  assert.equal(k.monto, 2); assert.equal(k._source, 'finanzas_movimientos');
  assert.equal(merged.find(x => x.id === 'solo-h')._source, 'finanzas');
});

test('Finanzas: períodos, totales, bancos, meses y semana', () => {
  const movs = parseAllFinance(docs);
  const today = new Date(2026, 8, 20, 10);
  const mes = periodRange('mes', today); assert.equal(mes.desde.getDate(), 1); assert.equal(mes.hasta.getDate(), 30);
  assert.equal(periodRange('hoy', today).desde.getDate(), 20);
  assert.equal(periodRange('todo', today).desde, null);
  const rango = periodRange('rango', today, { desde: '2026-09-19', hasta: '2026-09-20' });
  const t = totalsOf(filterMovs(movs, rango)); assert.equal(t.ing, 150); assert.equal(t.egr, 40); assert.equal(t.neto, 110);
  assert.equal(totalsOf(movs).n, 4);
  const bancos = byBankOf(movs); assert.equal(bancos[0].banco, 'Sin banco'); assert.equal(bancos[0].ing, 1200.5);
  const meses = lastMonthsOf(movs, today, 6); assert.equal(meses.length, 6); assert.equal(meses[5].ing, 150);
  const w = weekRange(today); assert.equal(w.start.getDay(), 1); assert.equal(w.end.getDay(), 0);
  assert.match(financeFileName('todo', today), /^Finanzas_Sublichat_todo_2026-09-20\.xlsx$/);
});

test('Finanzas: la pantalla trae resumen, bancos, meses, movimientos, egresos, cierre y Excel', () => {
  const movs = parseAllFinance(docs);
  const today = new Date(2026, 8, 20, 10);
  const d = dom(financeContentHtml({ movs, period: 'todo', today, canWrite: true }));
  assert.equal(d.querySelectorAll('[data-fin-period]').length, 5);
  assert.equal(d.querySelectorAll('.fin-kpis article').length >= 3, true);
  assert.equal(d.querySelectorAll('.fin-mov').length, 4);
  assert.ok(d.querySelector('#finXlsAll') && d.querySelector('#finXlsPeriod'));
  assert.ok(d.querySelector('#finEgSave') && d.querySelector('#finCierreSave'));
  assert.equal(d.querySelectorAll('.fin-bank').length, 3);
  assert.equal(d.querySelectorAll('.fin-month').length, 6);
  const ro = dom(financeContentHtml({ movs, period: 'todo', today, canWrite: false }));
  assert.ok(!ro.querySelector('#finEgSave') && !ro.querySelector('#finCierreSave'), 'sin permiso no hay formularios');
  const rango = dom(financeContentHtml({ movs, period: 'rango', desde: '2026-09-19', hasta: '2026-09-20', today }));
  assert.ok(rango.querySelector('#finDesde') && rango.querySelector('#finApplyRange'));
  assert.equal(rango.querySelectorAll('.fin-mov').length, 2);
  const solo = dom(financeContentHtml({ movs, period: 'todo', tipo: 'egreso', today }));
  assert.equal(solo.querySelectorAll('.fin-mov').length, 2);
  assert.match(financeContentHtml({ movs: [], period: 'hoy', today }), /Sin movimientos/);
});

test('Excel: se genera un .xlsx real con 4 hojas y todos los movimientos (se relee con ExcelJS)', async () => {
  const movs = parseAllFinance(mergeFinanceSources(docs.slice(2), docs.slice(0, 2)));
  const wb = buildFinanceWorkbook(ExcelJS, movs, { label: 'Todo', now: new Date(2026, 8, 20) });
  const buf = await wb.xlsx.writeBuffer();
  assert.ok(buf.byteLength > 4000);
  const back = new ExcelJS.Workbook(); await back.xlsx.load(buf);
  assert.deepEqual(back.worksheets.map(w => w.name), ['Resumen', 'Por Mes', 'Por Banco', 'Movimientos']);
  const det = back.getWorksheet('Movimientos');
  assert.equal(det.rowCount, 1 + movs.length);
  assert.equal(det.getRow(1).getCell(10).value, 'Origen');
  const filas = []; det.eachRow((r, i) => { if (i > 1) filas.push([r.getCell(2).value, r.getCell(5).value, r.getCell(10).value]); });
  assert.equal(filas.filter(f => f[0] === 'Ingreso').length, 2); assert.equal(filas.filter(f => f[0] === 'Egreso').length, 2);
  assert.ok(filas.some(f => f[1] === 1200.5 && f[2] === 'Histórico'));
  assert.ok(filas.some(f => f[1] === 150 && f[2] === 'Actual'));
  const res = back.getWorksheet('Resumen');
  assert.equal(res.getCell('A6').value, 'INGRESOS'); assert.equal(res.getCell('A7').value, 1350.5);
  assert.equal(res.getCell('B7').value, 340); assert.equal(res.getCell('C7').value, 1010.5);
  assert.throws(() => buildFinanceWorkbook(ExcelJS, [], {}), /No hay movimientos/);
  assert.equal(Buffer.from(bufferToBase64(buf), 'base64').equals(Buffer.from(buf)), true, 'base64 sin pérdida');
});

test('Control financiero conectado en la app: histórico + actual, Excel, egreso y cierre', () => {
  assert.match(main, /loadMobileResource\('finanzas', \{pageSize:250,maxPages:24\}\)/);
  assert.match(main, /mergeFinanceSources\(historico, actual\)/);
  assert.match(main, /import\('exceljs\/dist\/exceljs\.min\.js'\)/);
  assert.match(main, /saveAndShareXlsx\(financeFileName\(scope,new Date\(\)\),buffer\)/);
  for (const id of ['finXlsAll', 'finXlsPeriod', 'finEgSave', 'finCierreSave', 'finApplyRange', 'finMore']) assert.match(main, new RegExp(`#${id}`));
  assert.match(main, /registerFinanceExpense\(\{motivo,monto,banco,fecha\}\)/);
  assert.match(main, /saveFinanceClosing\(\{fechaInicio:isoDay\(week\.start\)/);
  assert.match(css, /\.fin-kpis\{/);
  assert.doesNotMatch(main, /Resumen de hoy/);
});

test('Avisos: el hilo muestra el rol (no "naara") y a quién va la respuesta', () => {
  assert.match(main, /function ticketMsgWho\(m,thread,index\)/);
  assert.match(main, /<b>\$\{esc\(ticketMsgWho\(m,thread,mi\)\)\}<\/b>/);
  assert.match(main, /telegramRoleLabel\(m\.porRol\)/);
  assert.match(main, /\$\{who\} · \$\{tg\?'Telegram':'Sublichat'\}\$\{para\?` → \$\{para\}`:''\}/);
});
