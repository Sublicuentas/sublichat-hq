import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { cobrosScreenHtml } from '../src/screens2.js';
import { fitSize, compressToLimit, prepareAvatarImage, AVATAR_MAX_CHARS, AVATAR_STEPS } from '../src/image.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('Cobros: Hoy, Próximo y Vencidos en UNA línea con el número abajo, igual que Clientes', () => {
  const d = dom(cobrosScreenHtml({ counts: { hoy: 13, proximo: 19, vencidos: 46 }, filter: 'proximo' }));
  const nav = d.querySelector('nav');
  assert.ok(nav.classList.contains('cli-tabs') && nav.classList.contains('cb-t3'));
  const tiles = [...nav.querySelectorAll('button')];
  assert.deepEqual(tiles.map(b => b.dataset.filter), ['hoy', 'proximo', 'vencidos']);
  assert.deepEqual(tiles.map(b => b.querySelector('span').textContent), ['Hoy', 'Próximo', 'Vencidos']);
  assert.deepEqual(tiles.map(b => b.querySelector('b').textContent), ['13', '19', '46']);
  for (const b of tiles) { assert.ok(b.querySelector('i.ico svg'), 'icono'); assert.ok(b.querySelector('em'), 'barrita'); }
  assert.equal(nav.querySelector('.active').dataset.filter, 'proximo');
  assert.match(css, /\.cli-tabs\.cb-t3\{grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
  assert.match(css, /\.cli-tabs\{display:grid;grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(main, /\[data-filter\]'\)\.forEach\(btn=>btn\.addEventListener\('click',\(\)=>\{state\.renewFilter=btn\.dataset\.filter;render\(\);\}\)\)/);
});

test('Inicio: saludo en Bold y frase del día simpática (con emoji y palabra resaltada)', () => {
  assert.match(css, /\.visual-home-brand h1\{font-weight:900!important/);
  assert.match(main, /<h1>Hola, \$\{esc\(firstName\)\}<\/h1>\$\{mottoHtml\(dailyPhrase\(\)\)\}/);
  const block = main.slice(main.indexOf('const FRASES=['), main.indexOf('function mottoHtml'));
  const frases = new Function(`${block}\nreturn FRASES;`)();
  assert.ok(frases.length >= 40, 'suficientes frases para no repetir en más de un mes');
  assert.equal(new Set(frases.map(f => f[1])).size, frases.length, 'sin repetidas');
  for (const [emoji, text] of frases) {
    assert.ok(emoji && !/[a-z]/i.test(emoji), `emoji: ${emoji}`);
    assert.ok(text.length <= 62, `cabe en 3 líneas: ${text}`);
    assert.match(text, /\*[^*]+\*/, `tiene una parte resaltada: ${text}`);
  }
  assert.doesNotMatch(main, /Tu actitud de hoy define tus resultados/);
  const html = new Function('esc', `${main.slice(main.indexOf('function mottoHtml'), main.indexOf('function dailyPhrase'))}\nreturn mottoHtml;`)(v => String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])))(['🚀', 'Hoy se vende y *se celebra*.']);
  assert.match(html, /<div class="visual-motto"><i>🚀<\/i><span>Hoy se vende y <em>se celebra<\/em>\.<\/span><\/div>/);
  assert.match(css, /\.visual-motto em\{font-style:normal;color:#e2231a\}/);
});

test('Foto de perfil: se reduce y comprime sola (ya no dice "pesa mucho")', async () => {
  assert.deepEqual(fitSize(4000, 3000, 640), { w: 640, h: 480 });
  assert.deepEqual(fitSize(300, 200, 640), { w: 300, h: 200 }, 'no agranda');
  assert.deepEqual(fitSize(0, 0, 640), { w: 0, h: 0 });
  // un dibujo que solo cabe cuando el lado baja: se detiene en el primer tamaño que cabe
  const tried = [];
  const out = compressToLimit((side, q) => { tried.push([side, q]); return 'x'.repeat(side * 900); }, { maxChars: 480 * 900 });
  assert.equal(out.length, 480 * 900);
  assert.deepEqual(tried.map(t => t[0]), [640, 560, 480]);
  assert.throws(() => compressToLimit(() => 'x'.repeat(AVATAR_MAX_CHARS + 1)), /demasiado grande/);
  assert.ok(AVATAR_MAX_CHARS < 850000, 'margen bajo el límite del servidor (api/perfil.js)');
  assert.ok(AVATAR_STEPS.every(([side, q]) => side >= 256 && q > 0.5 && q < 0.9));
  await assert.rejects(() => prepareAvatarImage({ type: 'application/pdf', size: 10 }), /imagen válida/);
  await assert.rejects(() => prepareAvatarImage({ type: 'image/jpeg', size: 50 * 1024 * 1024 }), /enorme/);
  assert.doesNotMatch(main, /f\.size>620000/);
  assert.doesNotMatch(main, /La foto pesa mucho/);
  assert.match(main, /import \{ prepareAvatarImage \} from '\.\/image\.js'/);
  assert.match(main, /state\.profileAvatarDraft=await prepareAvatarImage\(f\)/);
  assert.match(main, /changes\.avatar=state\.profileAvatarDraft/, 'el guardado del perfil no cambió');
});
