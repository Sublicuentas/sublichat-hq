// R198c · Fase 3 del PDF «Sublichat APK: modo offline completo»: cola robusta, idempotente y con conflictos explicables.
// App REAL en jsdom; «dispositivo» que sobrevive a cerrar/abrir; modo avión a mitad de la operación. Datos FICTICIOS.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp, pagarHojaRenovacion } from './helpers/ui-harness.mjs';
import { miniIndexedDB } from './helpers/mini-idb.mjs';

const dev = () => ({ idb: miniIndexedDB(), seguro: new Map(), local: new Map(), avion: false });
const renovaciones = (app) => app.bodies.filter((b) => b?.accion === 'renovar');
// Abre la hoja de pago CON señal (bancos cargados), se cae el internet y se confirma: la renovación queda en la cola.
async function renovarSinSenal(d) {
  const a = await bootApp({ role: 'sublicuentas', dispositivo: d });
  try {
    await a.sleep(1200);
    await a.click('[data-tab="clientes"]', 400);
    await a.click(a.$('.cli-card .cli-dots'), 200);
    await a.click(a.$('[data-client-action="renew"]') || a.$('[data-client-action="charge"]'), 250);
    await a.click(a.$('[data-renew-days="30"]') || a.$$('[data-renew-days]')[0], 60);
    await a.click('#renewApply', 400); await a.waitFor(() => a.$('[data-rp-banco]'), 3000);
    d.avion = true; a.w.dispatchEvent(new a.w.Event('offline')); await a.sleep(150);
    await pagarHojaRenovacion(a, '130'); await a.sleep(700);
    assert.equal(renovaciones(a).length, 0, 'sin señal no sale nada al servidor');
    assert.match(a.$('.offline-band').textContent, /Pendientes de sincronizar: 1 \(no confirmados por el servidor\)/);
    assert.match(a.$('.offline-pend').textContent, /Pendiente · Renovar/);
    assert.match(a.$('.toast')?.textContent || '', /en cola/); assert.doesNotMatch(a.$('.toast')?.textContent || '', /1 renovación confirmada/);
    d.guardarLocal();
  } finally { a.close(); }
}

test('08/17 · renovación sin señal + reinicio del teléfono: queda pendiente, al reconectar se envía UNA vez con su versión y se confirma con ID', async () => {
  const d = dev(); await renovarSinSenal(d);
  d.avion = false;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d });
  try {
    assert.ok(await b.waitFor(() => renovaciones(b).length >= 1, 8000), 'la cola se envía sola al reconectar');
    await b.sleep(500);
    const r = renovaciones(b); assert.equal(r.length, 1, 'una sola renovación');
    assert.equal(r[0].colaOffline, true); assert.ok(r[0].fechaEsperada && r[0].fechaEsperada === r[0].fechaActual, 'manda la fecha que vio el teléfono');
    assert.match(r[0].operationId || '', /\S{8,}/);
    await b.waitFor(() => /Confirmado/.test(b.$('.offline-pend')?.textContent || '') || !b.$('.offline-band'), 3000);
    const hist = JSON.stringify(b.w.document.body.textContent);
    assert.doesNotMatch(hist, /Pendientes de sincronizar/);
  } finally { b.close(); }
});

test('09/11 · el servidor detecta conflicto (la fecha cambió desde Web/TG): «Requiere revisión», no se reintenta ni se duplica', async () => {
  const d = dev(); await renovarSinSenal(d);
  d.avion = false;
  const conflicto = async (path, body) => (path === '/api/renovar' && body.accion === 'renovar' ? { ok: false, error: 'La fecha de netflix cambió mientras usted estaba sin conexión. No se renovó para no duplicar.', conflicto: { codigo: 'fecha_cambio', fechaServidor: '20/11/2026' } } : undefined);
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: conflicto });
  try {
    assert.ok(await b.waitFor(() => /Requiere revisión/.test(b.$('.offline-banner.failed')?.textContent || ''), 8000), 'aviso claro del conflicto');
    assert.match(b.$('.offline-banner.failed').textContent, /No se renovó para no duplicar/);
    b.w.dispatchEvent(new b.w.Event('online')); await b.sleep(2200);
    assert.equal(renovaciones(b).length, 1, 'un conflicto no se reintenta solo');
  } finally { b.close(); }
  const c = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: conflicto }); // el historial sobrevive al reinicio
  try { await c.sleep(1500); assert.equal(renovaciones(c).length, 0, 'ya no está en la cola'); } finally { c.close(); }
});

test('18 · se corta la red a mitad del envío: sigue pendiente con el MISMO operationId y se confirma al volver (sin duplicar)', async () => {
  const d = dev(); await renovarSinSenal(d);
  d.avion = false;
  let cortes = 1;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: async (path, body) => { if (path === '/api/renovar' && body.accion === 'renovar' && cortes-- > 0) throw new TypeError('Failed to fetch'); return undefined; } });
  try {
    assert.ok(await b.waitFor(() => renovaciones(b).length >= 2, 9000), 'tras el corte se reintenta solo');
    await b.sleep(600);
    assert.equal(renovaciones(b).length, 2, 'un intento cortado + uno confirmado; nada más');
    assert.equal(b.$('.offline-band'), null, 'la cola quedó vacía (sin «Subiendo…» eterno)');
    assert.equal(b.$('.offline-banner.failed'), null, 'un corte de red no es un rechazo');
    const ids = new Set(renovaciones(b).map((x) => x.operationId)); assert.equal(ids.size, 1, 'mismo operationId: el servidor no lo aplica dos veces');
  } finally { b.close(); }
});

test('Geisell (sin cola) sin señal: renovar avisa «requiere internet» y no cambia nada', async () => {
  const d = dev();
  const clientes = [{ id: 'g1', nombre: 'Gloria Prueba', telefono: '50411110000', vendedor: 'Geisell', servicios: [{ plataforma: 'netflix', precio: 130, fechaRenovacion: '20/10/2026', vendedor: 'Geisell', compraId: 'kg1' }] }];
  const a = await bootApp({ role: 'geisell', usuario: 'geisell', clients: clientes, dispositivo: d });
  try {
    await a.sleep(1000); d.avion = true; a.w.dispatchEvent(new a.w.Event('offline'));
    await a.click('[data-tab="clientes"]', 400); await a.click(a.$('.cli-card .cli-dots'), 200);
    await a.click(a.$('[data-client-action="renew"]') || a.$('[data-client-action="charge"]'), 250);
    await a.click(a.$('[data-renew-days="30"]') || a.$$('[data-renew-days]')[0], 60);
    await a.click('#renewApply', 400);
    assert.match(a.$('.toast')?.textContent || '', /renovar requiere internet\. No se cambió nada/);
    assert.equal(renovaciones(a).length, 0);
  } finally { a.close(); }
});

test('Código: venta en cola no entrega accesos por WhatsApp; cola con estados y versión esperada', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /if\(delivery==='tradicional'\)\{showToast\('📴 Venta en cola: los datos de acceso se envían al cliente cuando el servidor la confirme/);
  assert.ok(main.split('\n').length < 2000);
  const q = fs.readFileSync(new URL('../src/app/offline-queue.js', import.meta.url), 'utf8');
  for (const e of ['pendiente', 'enviando', 'confirmado', 'rechazado', 'revision']) assert.match(q, new RegExp(`${e}:'`));
  assert.match(q, /body\.colaOffline=true/); assert.match(q, /body\.fechaEsperada=String\(body\.fechaActual\|\|''\)/);
  assert.match(q, /o\.estado==='enviando'\?\{\.\.\.o,estado:'pendiente'\}/, 'tras un reinicio, «enviando» vuelve a pendiente');
});
