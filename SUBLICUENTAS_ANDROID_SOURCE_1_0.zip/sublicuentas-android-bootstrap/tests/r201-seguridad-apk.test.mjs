// R201 · Protocolo de seguridad en la APK: R8, SSL pinning, sin http, 12 h sin uso y Turnstile.
import test from 'node:test'; import assert from 'node:assert/strict';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { execFileSync } from 'node:child_process';
const raiz = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
test('android-native.mjs: activa R8, pinning de *.capuchino.lat con vencimiento y sin tráfico http', () => {
  const t = fs.mkdtempSync(path.join(os.tmpdir(), 'r201-'));
  fs.cpSync(path.join(raiz, 'scripts'), path.join(t, 'scripts'), { recursive: true });
  fs.cpSync(path.join(raiz, 'android-native'), path.join(t, 'android-native'), { recursive: true });
  const main = path.join(t, 'android/app/src/main'); fs.mkdirSync(path.join(main, 'java/com/sublicuentas/app'), { recursive: true }); fs.mkdirSync(path.join(main, 'res/values'), { recursive: true });
  fs.writeFileSync(path.join(main, 'java/com/sublicuentas/app/MainActivity.java'), 'package com.sublicuentas.app;\npublic class MainActivity {}\n');
  fs.writeFileSync(path.join(main, 'AndroidManifest.xml'), '<manifest>\n    <application android:label="x">\n    </application>\n</manifest>\n');
  fs.writeFileSync(path.join(t, 'android/app/build.gradle'), "android { buildTypes { release {\n minifyEnabled false\n proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'\n} } }\n");
  const env = { ...process.env, GOOGLE_SERVICES_JSON: '' };
  execFileSync(process.execPath, [path.join(t, 'scripts/android-native.mjs')], { env }); execFileSync(process.execPath, [path.join(t, 'scripts/android-native.mjs')], { env });
  const g = fs.readFileSync(path.join(t, 'android/app/build.gradle'), 'utf8');
  assert.match(g, /minifyEnabled true/); assert.match(g, /shrinkResources true/); assert.match(g, /proguard-android-optimize\.txt/);
  const reglas = fs.readFileSync(path.join(t, 'android/app/proguard-rules.pro'), 'utf8');
  assert.match(reglas, /-keep class com\.getcapacitor\.\*\* \{ \*; \}/); assert.equal(reglas.split('R201 · Sublichat').length, 2, 'las reglas no se duplican'); assert.match(reglas, /-dontwarn com\.google\.firebase\.ktx\.\*\*/, 'E1: R8 no exige com.google.firebase.ktx.Firebase (BoM 34)');
  const nsc = fs.readFileSync(path.join(main, 'res/xml/network_security_config.xml'), 'utf8');
  assert.match(nsc, /<domain includeSubdomains="true">capuchino\.lat<\/domain>/); assert.match(nsc, /<pin-set expiration="\d{4}-\d{2}-\d{2}">/);
  assert.ok((nsc.match(/<pin digest="SHA-256">/g) || []).length >= 6, 'varias raíces de respaldo');
  assert.match(nsc, /C5\+lpZ7tcVwmwQIMcRtPbsQtWLABXhQzejna0wHFr8M=/, 'Let\'s Encrypt ISRG Root X1');
  assert.match(nsc, /cleartextTrafficPermitted="false"/); assert.doesNotMatch(nsc, /src="user"/, 'no confía en certificados instalados por el usuario');
  const m = fs.readFileSync(path.join(main, 'AndroidManifest.xml'), 'utf8');
  assert.equal((m.match(/networkSecurityConfig/g) || []).length, 1);
});
test('Sesión 12 h y Turnstile: el token viaja al servidor y la APK no tiene clave secreta', async () => {
  const api = fs.readFileSync(path.join(raiz, 'src/api.js'), 'utf8');
  assert.match(api, /SESSION_IDLE_MS = 12 \* 60 \* 60 \* 1000/);
  const { buildLoginPayload } = await import('../src/api.js?r201');
  assert.deepEqual(buildLoginPayload(' Relojes ', 'x', 'tok'), { usuario: 'relojes', clave: 'x', turnstileToken: 'tok' });
  assert.deepEqual(buildLoginPayload('relojes', 'x'), { usuario: 'relojes', clave: 'x' });
  const ts = fs.readFileSync(path.join(raiz, 'src/turnstile-login.js'), 'utf8');
  assert.match(ts, /ev\.origin !== TURNSTILE_ORIGIN/);
  for (const f of ['src/api.js', 'src/main.js', 'src/turnstile-login.js']) assert.doesNotMatch(fs.readFileSync(path.join(raiz, f), 'utf8'), /TURNSTILE_SECRET|0x4AAAAAAA/);
});
