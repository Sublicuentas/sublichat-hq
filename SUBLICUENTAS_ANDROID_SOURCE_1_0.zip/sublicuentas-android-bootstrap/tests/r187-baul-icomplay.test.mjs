// R187 · APK: ICOMPLAY oficial (1/2/3/5/7 pantallas, tarifas del catálogo central) y Más › Baúl de APKs (datos ficticios del servidor).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { crmPlanPrice, crmAllowedDevices, crmStoredPlatform, crmStoredDeviceCount, setPlanesTv, ICOMPLAY_PRECIOS } from '../src/operations.js';
import { roleModules } from '../src/data.js';
import { MAS_MODULES } from '../src/screens.js';

test('ICOMPLAY: 2 pantallas existe (L219 / L599), regex [12357], catálogo central válido y nada de 0 silencioso', () => {
  assert.deepEqual(crmAllowedDevices('icomplay'), [1, 2, 3, 5, 7]);
  assert.equal(crmStoredPlatform('icomplay', 2), 'icomplay2');
  assert.equal(crmStoredDeviceCount('icomplay2'), 2);
  assert.equal(crmPlanPrice('icomplay2', 1), 219); assert.equal(crmPlanPrice('icomplay2', 3), 599); assert.equal(crmPlanPrice('icomplay7', 12), 4199);
  assert.equal(setPlanesTv({ icomplay: { 2: { 3: 649, 6: 0 }, 4: { 1: 1 } } }), true);
  assert.equal(ICOMPLAY_PRECIOS[2][3], 649); assert.equal(ICOMPLAY_PRECIOS[2][6], 1149, 'un 0 no pisa la tarifa'); assert.equal(ICOMPLAY_PRECIOS[4], undefined, 'no inventa 4 pantallas');
  setPlanesTv({ icomplay: { 2: { 3: 599 } } });
  for (const f of ['../src/operations.js', '../src/app/core.js']) assert.doesNotMatch(fs.readFileSync(new URL(f, import.meta.url), 'utf8'), /ICOMPLAY MAX/);
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /'planesTv'/); assert.match(main, /setPlanesTv\(cfg\.planesTv\)/);
  assert.ok(main.split('\n').length < 2000, 'main.js < 2000 líneas');
});

test('Más: solo se AGREGA Baúl de APKs (Sublicuentas, Relojes, Geisell); un rol desconocido no lo ve', () => {
  assert.ok(MAS_MODULES['baul-apks']?.svg);
  for (const [r, u] of [['sublicuentas', 'sublicuentas'], ['relojes', 'relojes'], ['geisell', 'geisell']]) assert.ok(roleModules(r, u).more.includes('baul-apks'), r);
  assert.equal(roleModules('otro', 'otro').more.includes('baul-apks'), false);
  assert.deepEqual(roleModules('relojes', 'relojes').tabs, ['inicio', 'clientes', 'cobros', 'tickets', 'mas'], 'navbar intacto');
});

test('enlace: «Abrir» solo https; el código por confirmar solo para el editor; sin URL inventada en tienda del TV', () => {
  const src = fs.readFileSync(new URL('../src/app/baul-apks.js', import.meta.url), 'utf8');
  assert.match(src, /const http = \/\^https:\\\/\\\/\/i\.test/);
  assert.match(src, /editor && e\.codigoPendiente \?/);
  assert.match(src, /e\.metodo === 'tv_store' \? '<small>Buscar en la tienda del TV \(sin enlace\)\.<\/small>'/);
  assert.doesNotMatch(src, /aftv\.news|dldsrvs|bit\.ly/, 'la APK no trae una lista fija: la sirve el servidor');
});

const BAUL = {
  ok: true, editor: true, version: 3, aviso: 'Para APK externas…',
  plataformas: [{ id: 'oleada', nombre: 'Oleada TV' }, { id: 'stellatv', nombre: 'Stella TV' }],
  vistas: [
    { plataforma: 'oleada', dispositivos: [{ id: 'fire_tv', nombre: 'Fire TV', enlaces: [{ id: 'oleada-fire', app: 'Oleada', appId: 'oleada', metodo: 'apk', metodoTxt: 'APK directo', url: 'https://dldsrvs.com/apks/firestick/mgs_pro.apk', codigo: '1290332', activo: true }] }] },
    { plataforma: 'stellatv', dispositivos: [] },
  ],
  enlaces: [{ id: 'oleada-fire', appId: 'oleada', plataformas: ['oleada'], dispositivo: 'fire_tv', metodo: 'apk', url: 'https://dldsrvs.com/apks/firestick/mgs_pro.apk', codigo: '1290332', activo: true, revision: 1 }],
};

test('Más › Baúl: carga del servidor, muestra 1290332, editor guarda y desactiva por /api/inventario', async () => {
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/inventario') return undefined;
    if (body.accion === 'baulApks') return BAUL;
    if (body.accion === 'tvUrlsHistorial') return { ok: true, urls: { icomplay: { nombre: 'ICOMPLAY', url: 'http://latinostream.xyz:80', activo: true } }, historial: [] };
    return { ok: true };
  } });
  try {
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="baul-apks"]', 400);
    await app.waitFor(() => /1290332/.test(app.$('.se-wrap')?.textContent || ''));
    assert.match(app.$('.se-wrap').textContent, /mgs_pro\.apk/);
    assert.ok(app.$('[data-baul-abrir="https://dldsrvs.com/apks/firestick/mgs_pro.apk"]') && app.$('[data-baul-copiar="1290332"]'));
    await app.click('[data-baul-editar="oleada-fire"]', 150);
    app.$('#baulNota').value = 'Probado en Fire TV Stick';
    await app.click('[data-baul-guardar="oleada-fire"]', 300);
    const g = app.bodies.find((b) => b?.accion === 'baulGuardarEnlace');
    assert.equal(g.enlace.id, 'oleada-fire'); assert.equal(g.enlace.nota, 'Probado en Fire TV Stick'); assert.equal(g.enlace.codigo, '1290332');
    await app.click('[data-baul-activar="oleada-fire"]', 300);
    assert.deepEqual((({ id, activo }) => ({ id, activo }))(app.bodies.find((b) => b?.accion === 'baulActivarEnlace')), { id: 'oleada-fire', activo: false });
    await app.click('[data-baul-tab="urls"]', 150);
    assert.match(app.$('.se-wrap').textContent, /latinostream\.xyz/);
    assert.match(app.$('.se-wrap').textContent, /clientes que ya la tienen no se tocan/);
  } finally { app.close(); }
});
