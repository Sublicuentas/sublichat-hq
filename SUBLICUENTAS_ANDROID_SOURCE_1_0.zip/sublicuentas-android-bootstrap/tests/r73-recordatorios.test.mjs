import test from 'node:test';
import assert from 'node:assert/strict';
import { serviceRowsFromClients } from '../src/data.js';
import { groupRenewalsByClientDate } from '../src/operations.js';
import { planReminders, reminderSellerOf, cobrosDelDia } from '../src/recordatorios.js';

const f = d => `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
const now = new Date(2026, 8, 26, 5, 0, 0);            // 26/09/2026 5:00 AM
const hoy = new Date(2026, 8, 26), manana = new Date(2026, 8, 27);
const cli = (id, vendedor, fecha, precio, extra = {}) => ({ id, nombrePerfil: `Cliente ${id}`, vendedor, servicios: [{ plataforma: 'netflix', vendedor, precio, fechaRenovacion: f(fecha), ...extra }] });
const clients = [
  cli('a', 'Sublicuentas', hoy, 100), cli('b', 'Sublicuentas', hoy, 150), cli('c', 'Relojes', hoy, 90),
  cli('d', 'Sublicuentas', manana, 120), cli('e', 'Relojes', manana, 80), cli('f', 'Geissel', manana, 70),
  cli('g', 'Relojes', hoy, 80, { beneficiarioTipo: 'tercero', beneficiarioNombre: 'Aracely Mendes' }),
];
const groups = groupRenewalsByClientDate(serviceRowsFromClients(clients));

test('R73 cada usuario recibe SOLO sus cobros', () => {
  assert.equal(reminderSellerOf('admin', 'naara'), 'sublicuentas');
  assert.equal(reminderSellerOf('asesor', 'libni'), 'relojes');
  assert.equal(reminderSellerOf('', 'geisell'), 'geisell');
  assert.equal(cobrosDelDia(groups, hoy, 'sublicuentas').count, 2);
  assert.equal(cobrosDelDia(groups, hoy, 'relojes').count, 2, 'Relojes: su cliente + el tercero');
  assert.equal(cobrosDelDia(groups, manana, 'geisell').count, 1, 'Geissel viejo cuenta como Geisell');
});

test('R73 7 AM "Hoy toca cobrar a N" y 7 PM "Mañana vencen N"', () => {
  const plan = planReminders({ groups, seller: 'sublicuentas', now });
  const am = plan.find(n => n.extra.filtro === 'hoy' && n.schedule.at.getDate() === 26);
  const pm = plan.find(n => n.extra.filtro === 'proximo' && n.schedule.at.getDate() === 26);
  assert.equal(am.schedule.at.getHours(), 7);
  assert.match(am.title, /Hoy toca cobrar a 2 clientes/);
  assert.equal(pm.schedule.at.getHours(), 19);
  assert.match(pm.title, /Mañana vencen 1/);
  assert.ok(!plan.some(n => /Relojes|Aracely/.test(n.title + n.body)));
});

test('R73 no programa horas pasadas, días sin cobros ni si está apagado', () => {
  const late = new Date(2026, 8, 26, 20, 0, 0);
  const plan = planReminders({ groups, seller: 'sublicuentas', now: late });
  assert.ok(plan.every(n => n.schedule.at > late));
  assert.equal(planReminders({ groups, seller: 'sublicuentas', now, cfg: { activo: false } }).length, 0);
  assert.equal(planReminders({ groups, seller: 'heber', now }).length, 0);
  const ids = plan.map(n => n.id); assert.equal(new Set(ids).size, ids.length);
});
