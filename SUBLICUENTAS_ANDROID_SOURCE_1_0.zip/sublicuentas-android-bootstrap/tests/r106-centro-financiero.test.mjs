import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { libroViewHtml, renewPaySheetHtml, operacionPagoBody } from '../src/app/finanzas-libro.js';
import { publicMethods, bankBalances } from '../src/app/finanzas-reglas.js';

const methods = publicMethods([{ id: 'bac', nombre: 'BAC', logoKey: 'bac' }, { id: 'ficohsa', nombre: 'Ficohsa', logoKey: 'ficohsa' }]);
const bancos = bankBalances([], { bases: { bac: { saldo: 4000, desde: '2026-10-01' }, ficohsa: { saldo: 1000, desde: '2026-10-01' } } }, methods).bancos;
const st = (tab, extra = {}) => ({ libro: { tab, data: { hoy: '2026-10-04', metodos: methods, ciclo: { inicio: '2026-10-01', dias: 4 }, totales: { ingresos: 100, egresosOperativos: 0, disponibleAntesPlanilla: 100, planilla: 0, resultado: 100, ventasGeneradas: 1020 }, bancos, totalBancos: 5000, planillaPagos: [], cierres: [], cartera: { pendienteClientes: 420, pendienteVendedores: 500, pendienteTotal: 920 } }, movFiltro: {}, ...extra } });

test('Resumen muestra ventas generadas y cartera separada del dinero real', () => {
  const h = libroViewHtml(st('resumen'));
  assert.match(h, /Ventas generadas/); assert.match(h, /Pendiente clientes/); assert.match(h, /Pendiente vendedores/); assert.match(h, /NO es dinero disponible/);
});

test('Pendientes: filtros Cliente/Vendedor y abono con banco', () => {
  const h = libroViewHtml(st('pendientes', { pend: { rows: [{ id: 'c1', deudorTipo: 'cliente', deudorNombre: 'Ana', clienteNombre: 'Ana', tipoOrigen: 'compra', plataforma: 'Disney', montoTotalOperacion: 300, montoRecibidoInicial: 100, montoRecibidoPosterior: 0, saldoPendiente: 200, estado: 'parcial' }, { id: 'c2', deudorTipo: 'vendedor', deudorNombre: 'Heber', clienteNombre: 'Carlos', saldoPendiente: 500, montoTotalOperacion: 500, estado: 'pendiente' }] }, abono: { cuentaId: 'c1', bancoId: '' } }));
  assert.match(h, /data-fl-pf="cliente"/); assert.match(h, /data-fl-pf="vendedor"/);
  assert.match(h, /Ana/); assert.match(h, /Heber/); assert.match(h, /id="flAbOk"/); assert.match(h, /data-fl-abb="bac"/);
});

test('Bancos: transferencia interna; Movimientos: corregir/anular solo en movimientos activos', () => {
  assert.match(libroViewHtml(st('bancos')), /Transferencia entre bancos/);
  const h = libroViewHtml(st('movimientos', { movs: { rows: [{ id: 'm1', kind: 'ingreso', monto: 220, fecha: '2026-10-02', banco: 'BAC', bancoId: 'bac' }, { id: 'm2', kind: 'egreso', monto: 50, fecha: '2026-10-02', banco: 'BAC', estadoFinanciero: 'anulado' }] } }));
  assert.match(h, /data-fl-co="m1"/); assert.match(h, /data-fl-fe="m1"/); assert.match(h, /data-fl-an="m1"/); assert.doesNotMatch(h, /data-fl-an="m2"/);
});

test('Hoja de pago: total y recibido vacíos; operación con estado y responsable', () => {
  const s = { tipo: 'compra', cliente: 'Ana', label: 'Disney', rows: [{ key: 'compra', label: 'Disney' }], montos: {}, bancoId: '', responsable: 'cliente', modo: 'pago' };
  const h = renewPaySheetHtml(s, methods);
  assert.match(h, /data-rp-total="compra" value=""/); assert.match(h, /data-rp-recibido="compra" value=""/); assert.doesNotMatch(h, /Ajuste sin pago/, 'compra nueva no tiene ajuste sin pago');
  s.montos.compra = { total: '300', recibido: '100' }; s.bancoId = 'ficohsa';
  assert.deepEqual(operacionPagoBody(s, 'compra', { clienteNombre: 'Ana' }), { accion: 'registrar_operacion_pago', tipoOrigen: 'compra', montoTotal: 300, recibido: 100, bancoId: 'ficohsa', responsable: 'cliente', vendedorNombre: '', origen: 'apk', clienteNombre: 'Ana' });
});

test('APK: compra nueva exige hoja de pago (Sublicuentas/Relojes) e intro sin líneas', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /if\(libroUser\(\)&&\(!d\.compraId\|\|perfilesNuevos>0\)&&!state\.crmPago\)/); // compra nueva o perfil adicional
  assert.match(main, /await registrarPagoCompra\(pay,/);
  assert.match(main, /Pago de la compra/); assert.match(main, /crmConfigurePayment/); assert.match(main, /returnOnly:true/);
  assert.ok(main.split('\n').length < 2050);
});

test('R106: añadir perfil a una compra existente pide pago en la APK', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /_perfilesOriginales:profiles\.length/);
  assert.match(main, /if\(libroUser\(\)&&\(!d\.compraId\|\|perfilesNuevos>0\)&&!state\.crmPago\)/);
});


test('R109: Movimientos nunca muestra la fila comercial venta como Sin banco', () => {
  const libro = readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  const legacy = readFileSync(new URL('../src/finanzas.js', import.meta.url), 'utf8');
  assert.match(libro, /kind !== 'venta'/);
  assert.match(legacy, /tipo=venta/);
});


test('R110: fecha del dinero se ajusta manualmente y usuarios financieros se normalizan', () => {
  const libro = readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  const legacy = readFileSync(new URL('../src/finanzas.js', import.meta.url), 'utf8');
  assert.match(libro, /accion: 'ajustar_fecha_movimiento'/);
  assert.match(libro, /Fecha REAL del pago/);
  assert.match(libro, /'naara', 'sublicuentas'/);
  assert.match(libro, /'libni', 'daniela', 'relojes', 'finanzas'/);
  assert.match(legacy, /finActorLabel/);
});
