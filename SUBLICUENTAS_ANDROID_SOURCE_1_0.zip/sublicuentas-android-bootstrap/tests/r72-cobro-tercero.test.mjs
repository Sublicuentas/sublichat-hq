import test from 'node:test';
import assert from 'node:assert/strict';
import { serviceRowsFromClients } from '../src/data.js';
import { groupRenewalsByClientDate, renewalGroupKeyOf, buildChargeMessage } from '../src/operations.js';

const clients = [{
  id: 'k1', nombrePerfil: 'Kassandra Molina', telefono: '89613761', vendedor: 'Relojes',
  servicios: [
    { plataforma: 'netflix', precio: 150, fechaRenovacion: '11/10/2026', vendedor: 'Relojes', beneficiarioTipo: 'titular' },
    { plataforma: 'hbomax', precio: 80, fechaRenovacion: '24/09/2026', vendedor: 'Relojes', beneficiarioTipo: 'tercero', beneficiarioNombre: 'Aracely Mendes' },
  ],
}];

test('R72 el cobro del servicio de un tercero sale a nombre del tercero, no del titular', () => {
  const rows = serviceRowsFromClients(clients);
  const groups = groupRenewalsByClientDate(rows);
  const hbo = groups.find(g => g.fechaRenovacion === '24/09/2026');
  assert.equal(hbo.nombre, 'Aracely Mendes');
  assert.equal(hbo.esTercero, true);
  assert.equal(hbo.titularNombre, 'Kassandra Molina');
  assert.equal(hbo.total, 80);
  assert.equal(hbo.serviciosCliente.length, 1, 'solo cuenta los servicios del tercero');
  assert.match(buildChargeMessage(hbo, 0), /Aracely Mendes/);
  assert.doesNotMatch(buildChargeMessage(hbo, 0), /Kassandra/);
  const net = groups.find(g => g.fechaRenovacion === '11/10/2026');
  assert.equal(net.nombre, 'Kassandra Molina');
  assert.equal(net.esTercero, false);
  assert.equal(renewalGroupKeyOf(rows[1]), hbo.key);
});

test('R72 titular y tercero con la MISMA fecha salen como dos cobros separados', () => {
  const c = structuredClone(clients); c[0].servicios[0].fechaRenovacion = '24/09/2026';
  const groups = groupRenewalsByClientDate(serviceRowsFromClients(c));
  assert.deepEqual(groups.map(g => g.nombre).sort(), ['Aracely Mendes', 'Kassandra Molina']);
});
