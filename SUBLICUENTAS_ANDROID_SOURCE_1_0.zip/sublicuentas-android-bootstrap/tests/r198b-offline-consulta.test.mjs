// R198b · Fase 2 del PDF «Sublichat APK: modo offline completo»: Clientes/CRM, inventario, Control Maestro y tickets en
// LECTURA sin internet para todos los usuarios con permiso (incluida Geisell), cifrado por usuario, cupos «por confirmar».
// App REAL en jsdom; «dispositivo» que sobrevive a cerrar/abrir y modo avión. Datos FICTICIOS.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { miniIndexedDB } from './helpers/mini-idb.mjs';

const CLIENTES = [
  { id: 'g1', nombre: 'Gloria Prueba', telefono: '50411110000', vendedor: 'Geisell', servicios: [{ plataforma: 'hbomax', planHbo: 'platinum', precio: 90, fechaRenovacion: '20/10/2026', vendedor: 'Geisell', compraId: 'kg1', correo: 'madre@prueba.test', clave: 'ClaveSecreta1', pinPerfil: '7788' }] },
  { id: 'g2', nombre: 'Gerardo Ficticio', telefono: '50422220000', vendedor: 'Geisell', servicios: [{ plataforma: 'netflix', precio: 140, fechaRenovacion: '25/10/2026', vendedor: 'Geisell', compraId: 'kg2', correo: 'nf@prueba.test', clave: 'OtraClave2' }] },
];
const INV = [
  { id: 'inv1', plataforma: 'hbomax', planHbo: 'platinum', correo: 'madre@prueba.test', clave: 'ClaveMadre9', capacidad: 5, ocupados: 3, clientes: [{ compraId: 'kg1', nombre: 'Gloria Prueba', slot: 1 }] },
  { id: 'inv2', plataforma: 'netflix', correo: 'nf@prueba.test', clave: 'ClaveMadre8', capacidad: 5, ocupados: 5, clientes: [] },
];
const extra = async (path, body) => {
  if (path === '/api/mobile-core' && body.resource === 'inventario') return { ok: true, items: INV, nextCursor: '' };
  if (path === '/api/inventario') return { ok: true, plataformas: [], vistas: [], urls: {} };
  return undefined;
};
const dev = () => ({ idb: miniIndexedDB(), seguro: new Map(), local: new Map(), avion: false });
const textoIdb = (d) => JSON.stringify([...d.idb._bases.values()].map((b) => [...b.stores.values()].map((m) => [...m.values()])));
async function sincronizarYcerrar(d, opts) {
  const a = await bootApp({ ...opts, dispositivo: d, fetchExtra: extra });
  try {
    await a.waitFor(() => a.calls.some((c) => c.resource === 'inventario'), 6000);
    await a.click('[data-tab="mas"]', 300); await a.click('[data-open="control-maestro"]', 900); // Control Maestro visto con señal
    await a.sleep(1800); d.guardarLocal();
  } finally { a.close(); }
}

test('Geisell en modo avión tras cerrar y abrir: Clientes, búsqueda, Control Maestro e Inventario como foto «por confirmar»', async () => {
  const d = dev();
  await sincronizarYcerrar(d, { role: 'geisell', usuario: 'geisell', clients: CLIENTES });
  d.avion = true;
  const b = await bootApp({ role: 'geisell', usuario: 'geisell', clients: CLIENTES, dispositivo: d, fetchExtra: extra });
  try {
    await b.click('[data-tab="clientes"]', 400);
    assert.ok(await b.waitFor(() => /Gloria Prueba/.test(b.$('.app-main')?.textContent || '') && /Gerardo Ficticio/.test(b.$('.app-main').textContent)), 'fichas de Geisell sin internet');
    const q = b.$('#clientSearch'); assert.ok(q, 'buscador presente');
    { q.value = 'gerardo'; q.dispatchEvent(new b.w.Event('input', { bubbles: true })); await b.sleep(400); assert.doesNotMatch(b.$('.app-main').textContent, /Gloria Prueba/, 'busca en la copia local'); }
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="control-maestro"]', 600);
    const cm = b.$('.app-main').textContent;
    assert.match(cm, /ma\*\*\*@prueba\.test/, 'correo de cuenta madre enmascarado');
    assert.doesNotMatch(cm, /madre@prueba\.test|ClaveMadre9/);
    assert.match(b.$('.offline-band').textContent, /disponibilidad por confirmar/);
    assert.match(b.$('.offline-band').textContent, /Correos enmascarados y claves no guardadas/);
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="inventario"]', 500);
    assert.match(b.$('.app-main').textContent, /HBO|Netflix/i, 'inventario desde la foto guardada');
    assert.match(b.$('.offline-band').textContent, /foto del \d{2}\/\d{2}\/\d{4}/);
  } finally { b.close(); }
});

test('Privacidad: nada en texto plano (ni localStorage ni IndexedDB); sin claves, PIN ni correos de acceso en la copia', async () => {
  const d = dev();
  await sincronizarYcerrar(d, { role: 'geisell', usuario: 'geisell', clients: CLIENTES });
  const local = [...d.local.values()].join(' ');
  for (const x of ['Gloria Prueba', 'Gerardo Ficticio', 'ClaveSecreta1', '7788', 'madre@prueba.test']) assert.ok(!local.includes(x), `localStorage sin «${x}»`);
  const idb = textoIdb(d);
  assert.ok(idb.includes('"ct"'), 'la copia existe y está cifrada');
  for (const x of ['Gloria Prueba', 'ClaveSecreta1', 'madre@prueba.test', 'ClaveMadre9']) assert.ok(!idb.includes(x), `IndexedDB sin «${x}» legible`);
});

test('Otro usuario en el mismo teléfono no ve la copia de Geisell', async () => {
  const d = dev();
  await sincronizarYcerrar(d, { role: 'geisell', usuario: 'geisell', clients: CLIENTES });
  d.avion = true;
  const r = await bootApp({ role: 'relojes', usuario: 'relojes', clients: CLIENTES, dispositivo: d, fetchExtra: extra });
  try {
    await r.click('[data-tab="clientes"]', 600);
    assert.doesNotMatch(r.$('.app-main').textContent, /Gloria Prueba|Gerardo Ficticio/);
  } finally { r.close(); }
});

test('Tickets guardados se leen sin internet tras reiniciar (Sublicuentas)', async () => {
  const d = dev();
  const a = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try { await a.click('[data-tab="tickets"]', 900); await a.waitFor(() => /Prueba web/.test(a.$('.app-main')?.textContent || '')); await a.sleep(1600); d.guardarLocal(); } finally { a.close(); }
  assert.ok(![...d.local.values()].join(' ').includes('Aviso de prueba'), 'tickets ya no van en texto plano');
  d.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try {
    await b.click('[data-tab="tickets"]', 700);
    assert.ok(await b.waitFor(() => /Prueba web/.test(b.$('.app-main')?.textContent || '')), 'tickets guardados visibles');
    assert.equal(b.$('.app-main .error-box'), null);
  } finally { b.close(); }
});

test('Código: vigencia 7 días, la copia nunca pisa datos del servidor y Control Maestro sigue consultando con señal', () => {
  const m = fs.readFileSync(new URL('../src/app/offline-consulta.js', import.meta.url), 'utf8');
  assert.match(m, /VIGENCIA_MS = 7 \* 86400000/);
  assert.match(m, /if \(!\(state\.clients \|\| \[\]\)\.length && Array\.isArray\(d\.clients\)\)/);
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /if \(\(state\.controlInventory&&!state\.controlDesdeCopia\) \|\| !cap\(\)\.controlMaestro\) return;/);
  assert.match(main, /SENSITIVE_KEY_RE=\/\^\(clave\|claves\|password/);
  const re1 = main.match(/SENSITIVE_KEY_RE=(\/[^\n]*\/i);/)[1], re2 = m.match(/SECRETO_RE = (\/[^\n]*\/i);/)[1];
  assert.equal(re1, re2, 'misma lista de campos secretos que R69');
  assert.ok(main.split('\n').length < 2000);
});
