import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { basketballCreate, basketballShoot, basketballSubmission, dartsCreate, dartsThrow, dartsPoints, dartsSubmission, colorCreate, colorFill, colorPick, colorSubmission, COLOR_DESIGNS } from '../src/juegos-engine.js';

test('R55 Básquet: tiro parabólico real, el aro cambia y al 10º tiro termina', () => {
  let s = basketballCreate(10, () => 0.5);
  const first = s.hoop;
  let madeAt = -1; for (let p = 0; p <= 100; p++) if (basketballShoot(s, 55, p).lastResult.made) { madeAt = p; break; }
  assert.ok(madeAt > 0, 'existe una fuerza que encesta');
  s = basketballShoot(s, 55, madeAt);
  assert.equal(s.made, 1); assert.ok(s.lastPath.length > 5);
  assert.ok(basketballShoot(basketballCreate(10, () => 0.5), 55, 0).lastResult.feedback.length > 3, 'da una pista cuando falla');
  for (let i = 1; i < 10; i++) s = basketballShoot(s, 55, 10);
  assert.ok(s.finishedAt); assert.equal(basketballSubmission(s).attempts, 10);
  assert.deepEqual(first, { dx: 230, dy: 85 });
});

test('R55 Dardos: diana 50, anillos, 10 dardos y fin', () => {
  assert.equal(dartsPoints(0, 0), 50); assert.equal(dartsPoints(0.12, 0), 25); assert.equal(dartsPoints(1.1, 0), 0);
  let s = dartsCreate(10);
  for (let i = 0; i < 10; i++) s = dartsThrow(s, 0, 0);
  assert.equal(s.score, 500); assert.equal(s.bulls, 10); assert.ok(s.finishedAt);
  assert.equal(dartsSubmission(s).darts, 10);
});

test('R55 Colorear: 3 dibujos, pintar todo termina la partida', () => {
  assert.equal(COLOR_DESIGNS.length, 3);
  let s = colorCreate(1); s = colorPick(s, '#1f7cf2');
  for (let i = 0; i < s.regions.length; i++) s = colorFill(s, i);
  assert.ok(s.finishedAt); assert.equal(colorSubmission(s).regionsColored, s.regions.length);
});

test('R55 En la app: Básquet, Dardos y Colorear se abren y sus botones funcionan', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    await app.click('[data-jg-play="BASKETBALL"]', 250);
    assert.ok(app.$('.jg-bk-court'));
    await app.click('#jgShoot', 150);
    assert.match(app.$('.jg-page').textContent, /1\/10/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="DARTS"]', 250);
    assert.ok(app.$('.jg-dt-board'));
    await app.click('#jgThrow', 150);
    assert.match(app.$('.jg-page').textContent, /1\/10/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="COLOR_CHALLENGE"]', 250);
    assert.ok(app.$('.jg-co-art'));
    await app.click('[data-jg-color="#1f7cf2"]', 80);
    app.$('[data-jg-region="0"]').dispatchEvent(new app.w.MouseEvent('click', { bubbles: true })); await app.sleep(120); // en jsdom los <path> SVG no tienen .click()
    assert.equal(app.$('[data-jg-region="0"]').getAttribute('fill'), '#1f7cf2');
    await app.click('#jgNextDesign', 150);
    assert.match(app.$('.jg-page').textContent, /Vitral/);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R55 Sesión: queda guardada (localStorage) y solo vence tras 1 día sin actividad', async () => {
  const store = new Map(); const ls = { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) };
  globalThis.localStorage = ls; globalThis.sessionStorage = { getItem: () => JSON.stringify({ usuario: 'relojes', idToken: 't', refreshToken: 'r' }), removeItem() {} };
  const api = await import('../src/api.js?r55');
  const s = api.getSession();
  assert.equal(s.usuario, 'relojes', 'migra la sesión vieja sin pedir login');
  assert.ok(store.get('sublicuentas-session-v1'), 'ahora vive en localStorage');
  const v = JSON.parse(store.get('sublicuentas-session-v1'));
  v.lastActiveAt = Date.now() - (23 * 3600 * 1000); store.set('sublicuentas-session-v1', JSON.stringify(v));
  assert.ok(api.getSession(), 'con 23 h sigue abierta');
  v.lastActiveAt = Date.now() - (25 * 3600 * 1000); store.set('sublicuentas-session-v1', JSON.stringify(v));
  globalThis.sessionStorage = { getItem: () => null, removeItem() {} };
  assert.equal(api.getSession(), null, 'con más de 1 día sin actividad se cierra');
  delete globalThis.localStorage; delete globalThis.sessionStorage;
});
