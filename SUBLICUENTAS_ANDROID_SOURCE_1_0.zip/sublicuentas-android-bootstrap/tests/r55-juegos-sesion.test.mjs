import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { basketballCreate, basketballShoot, basketballSubmission, dartsCreate, dartsThrow, dartsPoints, dartsSubmission, colorCreate, colorFill, colorPick, colorSubmission, COLOR_DESIGNS } from '../src/juegos-engine.js';

test('R58 Básquet: 5 tiros con métricas del servidor (made, swish, bestStreak, avgAccuracy)', () => {
  let s = basketballCreate(5, () => 0.5);
  let madeAt = -1; for (let p = 0; p <= 100; p++) if (basketballShoot(s, 55, p).lastResult.made) { madeAt = p; break; }
  assert.ok(madeAt > 0);
  s = basketballShoot(s, 55, madeAt);
  for (let i = 1; i < 5; i++) s = basketballShoot(s, 55, 10);
  assert.ok(s.finishedAt);
  const m = basketballSubmission(s);
  assert.deepEqual(Object.keys(m).sort(), ['avgAccuracy', 'bestStreak', 'made', 'swish']);
  assert.equal(m.made, 1);
});

test('R58 Dardos: cuenta regresiva 150 → 0 exacto, "se pasó" no resta, métricas del servidor', () => {
  assert.equal(dartsPoints(0, 0), 50); assert.equal(dartsPoints(0.12, 0), 25); assert.equal(dartsPoints(1.1, 0), 0);
  let s = dartsCreate();
  s = dartsThrow(s, 0, 0); s = dartsThrow(s, 0, 0); assert.equal(s.remaining, 50);
  s = dartsThrow(s, 0.12, 0); assert.equal(s.remaining, 25);
  s = dartsThrow(s, 0, 0); assert.equal(s.remaining, 25); assert.ok(s.lastBust, 'se pasó: no resta');
  s = dartsThrow(s, 0.12, 0); assert.ok(s.finished && s.finishedAt);
  assert.deepEqual(dartsSubmission(s), { finished: true, dartsUsed: 5, avgAccuracy: dartsSubmission(s).avgAccuracy, bonusHits: 2 });
});

test('R58 Colorear modo reto: copiar el modelo da 100% y premio fino', () => {
  assert.equal(COLOR_DESIGNS.length, 3);
  let s = colorCreate(1);
  for (let i = 0; i < s.regions.length; i++) { s = colorPick(s, s.model[i]); s = colorFill(s, i); }
  assert.ok(s.finishedAt);
  assert.deepEqual(colorSubmission(s), { completed: true, precisionPct: 100, wrongChanges: 0, finePremium: true });
});

test('R55 En la app: Básquet, Dardos y Colorear se abren y sus botones funcionan', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    await app.click('[data-jg-play="BASKETBALL"]', 250);
    assert.ok(app.$('.jg-bk-court'));
    await app.click('#jgShoot', 150);
    assert.match(app.$('.jg-page').textContent, /1\/5/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="DARTS"]', 250);
    assert.ok(app.$('.jg-dt-board'));
    await app.click('#jgThrow', 150);
    assert.match(app.$('.jg-page').textContent, /1\/30/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="COLOR_CHALLENGE"]', 250);
    assert.ok(app.$('.jg-co-art'));
    await app.click('[data-jg-color="#1f7cf2"]', 80); assert.ok(app.$('.jg-co-model'), 'muestra el modelo a copiar');
    app.$('[data-jg-region="0"]').dispatchEvent(new app.w.MouseEvent('click', { bubbles: true })); await app.sleep(120); // en jsdom los <path> SVG no tienen .click()
    assert.equal(app.$('[data-jg-region="0"]').getAttribute('fill'), '#1f7cf2');
    await app.click('#jgNextDesign', 150);
    assert.match(app.$('.jg-page').textContent, /Vitral/);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R55 Sesión: queda guardada (localStorage) y solo vence tras 1 día sin actividad', async () => {
  const store = new Map(); const ls = { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) };
  globalThis.localStorage = ls; globalThis.sessionStorage = { getItem: () => JSON.stringify({ usuario: 'relojes', idToken: 't', refreshToken: 'r' }), removeItem() {} };
  const api = await import('../src/api.js?r55');
  const s = api.getSession();
  assert.equal(s.usuario, 'relojes', 'migra la sesión vieja sin pedir login');
  assert.ok(store.get('sublicuentas-session-v1'), 'ahora vive en localStorage');
  const v = JSON.parse(store.get('sublicuentas-session-v1'));
  v.lastActiveAt = Date.now() - (23 * 3600 * 1000); store.set('sublicuentas-session-v1', JSON.stringify(v));
  assert.ok(api.getSession(), 'con 23 h sigue abierta');
  v.lastActiveAt = Date.now() - (25 * 3600 * 1000); store.set('sublicuentas-session-v1', JSON.stringify(v));
  globalThis.sessionStorage = { getItem: () => null, removeItem() {} };
  assert.equal(api.getSession(), null, 'con más de 1 día sin actividad se cierra');
  delete globalThis.localStorage; delete globalThis.sessionStorage;
});
