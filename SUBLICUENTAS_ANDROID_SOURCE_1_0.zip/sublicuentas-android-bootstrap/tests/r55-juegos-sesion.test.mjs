import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { basketballCreate, basketballShoot, basketballSubmission, dartsCreate, dartsThrow, dartsPoints, dartsSubmission, colorCreate, colorFill, colorPick, colorSubmission, COLOR_DESIGNS } from '../src/juegos-engine.js';

test('R58 Básquet: 5 tiros con métricas del servidor (made, swish, bestStreak, avgAccuracy)', () => {
  let s = basketballCreate(5, () => 0.5);
  let madeAt = -1; for (let p = 0; p <= 100; p++) if (basketballShoot(s, 55, p).lastResult.made) { madeAt = p; break; }
  assert.ok(madeAt > 0);
  s = basketballShoot(s, 55, madeAt);
  for (let i = 1; i < 5; i++) s = basketballShoot(s, 55, 10);
  assert.ok(s.finishedAt);
  const m = basketballSubmission(s);
  assert.deepEqual(Object.keys(m).sort(), ['avgAccuracy', 'bestStreak', 'made', 'swish']);
  assert.equal(m.made, 1);
});

test('R58 Colorear modo reto: copiar el modelo da 100% y premio fino', () => {
  assert.equal(COLOR_DESIGNS.length, 3);
  let s = colorCreate(1);
  for (let i = 0; i < s.regions.length; i++) { s = colorPick(s, s.model[i]); s = colorFill(s, i); }
  assert.ok(s.finishedAt);
  assert.deepEqual(colorSubmission(s), { completed: true, precisionPct: 100, wrongChanges: 0, finePremium: true });
});

test('R55 En la app: Básquet, Dardos y Colorear se abren y sus botones funcionan', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    await app.click('[data-jg-play="BASKETBALL"]', 250);
    assert.ok(app.$('[data-bq-char]'), 'R67: primero se elige personaje'); await app.click('#bqStart', 150);
    assert.ok(app.$('.bq-court'));
    await app.click('#bqShoot', 250);
    assert.match(app.$('.jg-page').textContent, /1\/5/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="DARTS"]', 250);
    assert.ok(app.$('#dtActive') && app.$('#dtBoard'), 'Dardos PRO: tablero y dardo arrastrable');
    assert.match(app.$('.dt-score').textContent, /301/);
    await app.click('#jgQuit', 200);
    await app.click('[data-jg-play="COLOR_CHALLENGE"]', 250);
    assert.ok(app.$('.jg-co-art'));
    await app.click('[data-jg-color="#1f7cf2"]', 80); assert.ok(app.$('.jg-co-model'), 'muestra el modelo a copiar');
    app.$('[data-jg-region="0"]').dispatchEvent(new app.w.MouseEvent('click', { bubbles: true })); await app.sleep(120); // en jsdom los <path> SVG no tienen .click()
    assert.equal(app.$('[data-jg-region="0"]').getAttribute('fill'), '#1f7cf2');
    await app.click('#jgNextDesign', 150);
    assert.match(app.$('.jg-page').textContent, /Vitral/);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R69 Sesión: migra al almacén seguro, borra localStorage, idToken solo en memoria y vence tras 12 h sin actividad (R201)', async () => {
  const store = new Map(); const ls = { getItem: k => store.has(k) ? store.get(k) : null, setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) };
  store.set('sublicuentas-session-v1', JSON.stringify({ usuario: 'relojes', role: 'relojes', idToken: 'SECRETO-ID', refreshToken: 'r' }));
  globalThis.localStorage = ls; globalThis.sessionStorage = { getItem: () => null, removeItem() {} };
  const api = await import('../src/api.js?r69');
  const secure = new Map();
  api.__setSecureStoreForTests({ mode: 'test', get: async k => secure.has(k) ? JSON.parse(secure.get(k)) : null, set: async (k, v) => { secure.set(k, JSON.stringify(v)); }, remove: async k => { secure.delete(k); } });
  const s = await api.hydrateSession();
  assert.equal(s.usuario, 'relojes', 'migra la sesión vieja sin pedir login');
  assert.equal(store.get('sublicuentas-session-v1'), undefined, 'ya no queda en localStorage');
  await new Promise(r => setTimeout(r, 20));
  const saved = JSON.parse(secure.get('session'));
  assert.equal(saved.refreshToken, 'r'); assert.ok(!('idToken' in saved), 'el idToken no se guarda en disco');
  api.getSession().lastActiveAt = Date.now() - 11 * 3600 * 1000; assert.ok(api.getSession(), 'con 11 h sigue abierta');
  api.getSession().lastActiveAt = Date.now() - 13 * 3600 * 1000; assert.equal(api.getSession(), null, 'más de 12 h sin actividad: se cierra');
  delete globalThis.localStorage; delete globalThis.sessionStorage;
});
