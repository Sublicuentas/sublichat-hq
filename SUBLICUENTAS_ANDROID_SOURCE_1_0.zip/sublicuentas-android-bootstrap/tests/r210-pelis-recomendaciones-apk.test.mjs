// R210 · Pelis y estrenos (APK): Recomendaciones del día con el mismo módulo de la Web.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const R = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('recomendaciones del día: módulo compartido, sesión de la APK y sin bloquear el buscador', async () => {
  const { moviesContentHtml } = await import('../src/screens.js');
  const vacio = moviesContentHtml({});
  assert.match(vacio, /id="plRec"/); assert.match(vacio, /id="plUpd"/);
  const busq = moviesContentHtml({ results: [{ titulo: 'X', proveedores: ['Netflix'] }] });
  assert.ok(busq.indexOf('mv-card') < busq.indexOf('id="plRec"'), 'los resultados de búsqueda van arriba de las recomendaciones');
  assert.match(moviesContentHtml({ error: 'falla' }), /error-box/);
  const m = R('src/app/pelis-rec.js');
  assert.match(m, /authPost\('\/api\/tmdb', body\)/);
  assert.match(m, /pelis-rec\.js\?v=\$\{PELIS_REC_VERSION\}/);
  assert.match(R('src/main.js'), /bindComercial\(\); bindPelisRec\(\);/); assert.match(R('src/main.js'), /^import .*import \{ bindPelisRec \} from '\.\/app\/pelis-rec\.js';/m, 'import real (no dentro de un comentario)'); assert.doesNotMatch(R('src/main.js'), /\/\/[^\n]*import \{ bindPelisRec/);
  assert.ok((R('src/main.js').match(/\n/g) || []).length <= 1998);
  const pub = R('public/pelis-rec.js');
  for (const t of ['Recomendaciones del día', 'Selección diaria', 'Dónde verla:', 'Cartelera y estrenos', 'Reintentar']) assert.ok(pub.includes(t), t);
  assert.doesNotMatch(pub + R('public/pelis-rec.css'), /api_key|gradient/);
  for (const f of ['estrella', 'selec_cal', 'claqueta', 'tipo_peli', 'tipo_serie', 'mini_cal']) assert.ok(fs.existsSync(new URL(`../public/assets/pelis/${f}.webp`, import.meta.url)), f);
});
