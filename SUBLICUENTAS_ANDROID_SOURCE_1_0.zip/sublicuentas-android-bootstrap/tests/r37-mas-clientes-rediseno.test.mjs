import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import {
  masHomeHtml, MAS_MODULES, clientsScreenHtml, clientCardHtml, clientTone, clientInitials, dueStatus, recentMs, sortClientGroups, CLIENT_SORTS,
} from '../src/screens.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const exists = p => fs.existsSync(new URL(`../public${p}`, import.meta.url));
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;
const parse = s => { const m = String(s).match(/^(\d{2})\/(\d{2})\/(\d{4})$/); return m ? new Date(+m[3], +m[2] - 1, +m[1], 12) : null; };

test('Más: iconos 3D recortados (con transparencia) y todas las tarjetas del mockup', () => {
  const all = Object.keys(MAS_MODULES);
  const d = dom(masHomeHtml({ modules: all, sessionLabel: 'Sublicuentas', online: true, syncText: 'En línea' }));
  const cards = [...d.querySelectorAll('.mas-card[data-open]')];
  assert.deepEqual(cards.map(c => c.dataset.open), all);
  assert.equal(cards.length, 11);
  for (const m of Object.values(MAS_MODULES)) assert.ok(exists(`/assets/mas/${m.img}.png`), `falta ${m.img}.png`);
  assert.ok(exists('/assets/mas/mas-resultados.png') && exists('/assets/mas/mas-robot.png') && exists('/assets/clientes-hero.png'));
  assert.match(d.body.textContent, /Películas y series/);
  assert.match(d.body.textContent, /Ingresos y egresos/);
  assert.match(d.body.textContent, /MISMAS HERRAMIENTAS/);
  assert.match(d.body.textContent, /Más resultados/);
  assert.match(d.body.textContent, /Más\s*que una app,\s*tu centro de control\./);
  assert.match(d.body.textContent, /Versión 1\.0/);
  assert.equal(d.querySelectorAll('.mas-ico img').length, 12);
});

test('Más: solo se muestran los módulos permitidos para el rol', () => {
  const d = dom(masHomeHtml({ modules: ['pelis', 'partidos', 'subli', 'perfil', 'aula', 'materia'] }));
  assert.equal(d.querySelectorAll('.mas-card[data-open]').length, 6);
  assert.equal(d.querySelector('[data-open="finanzas"]'), null);
  assert.match(main, /masHomeHtml\(\{modules:items\.map\(x=>x\[0\]\)/);
});

test('Los PNG de iconos tienen transparencia real (sin fondo blanco)', () => {
  const png = fs.readFileSync(new URL('../public/assets/mas/mas-pelis.png', import.meta.url));
  assert.equal(png.readUInt8(25), 6, 'PNG RGBA (color type 6)');
  const hero = fs.readFileSync(new URL('../public/assets/clientes-hero.png', import.meta.url));
  assert.equal(hero.readUInt8(25), 6);
});

test('Clientes: buscador (cliente, teléfono, plataforma), filtros, Cobros de hoy y orden como el mockup', () => {
  const d = dom(clientsScreenHtml({
    counts: { vigentes: 646, hoy: 17, proximos: 631, vencidos: 39 }, statusFilter: 'hoy', platforms: ['netflix'], sellers: ['Relojes'],
    limit: 100, sort: 'vence', shown: 1, total: 749, uniqueClients: 646, canNewCrm: true,
    cards: [{ clienteId: 'c1', actionKey: 'k1', nombre: 'Amy Pastrana', telefono: '31652323', plataformas: ['vipnetflix', 'disneyp'], fecha: '02/10/2026', total: 'L 210.00', vendedor: 'Relojes', statusTone: 'ok', statusLabel: 'Vigente', tone: 'r', initials: 'AP' }],
  }));
  assert.match(d.querySelector('#clientSearch').placeholder, /Buscar cliente, teléfono o plataforma/);
  assert.ok(d.querySelector('#clientFiltersToggle'));
  assert.deepEqual([...d.querySelectorAll('.cli-tabs button')].map(b => b.dataset.clientStatus), ['vigentes', 'hoy', 'proximos', 'vencidos']);
  assert.equal(d.querySelector('.cli-tabs .active').dataset.clientStatus, 'hoy');
  assert.equal(d.querySelector('.cli-tabs .t-vigentes b').textContent, '646');
  assert.ok(d.querySelector('#clientPlatformFilter') && d.querySelector('#clientSellerFilter') && d.querySelector('#clientLimit'));
  assert.ok(d.querySelector('#clientCobrosHoy'));
  assert.equal(d.querySelectorAll('#clientSort option').length, CLIENT_SORTS.length);
  assert.equal(d.querySelector('#clientSort').value, 'vence');
  assert.match(d.querySelector('.cli-cta').textContent, /Nuevo CRM · Registrar venta/);
  assert.match(d.querySelector('.cli-meta').textContent, /Mostrando 1 de 749 registros · 646 clientes/);
  assert.ok(d.querySelector('.cli-hero-img'));
  const card = d.querySelector('.cli-card');
  assert.equal(card.querySelector('[data-client-id]').dataset.clientId, 'c1');
  assert.equal(card.querySelector('[data-client-actions]').dataset.clientActions, 'k1');
  assert.match(card.textContent, /L 210\.00/);
  assert.equal(card.querySelectorAll('.chip').length, 2);
  // sin permiso para vender no aparece "Nuevo CRM"; con filtros ocultos el panel queda hidden
  const hidden = dom(clientsScreenHtml({ canNewCrm: false, filtersOpen: false }));
  assert.equal(hidden.querySelector('.cli-cta'), null);
  assert.equal(hidden.querySelector('.cli-filters').hasAttribute('hidden'), true);
});

test('Clientes: estado por fecha, iniciales, colores y orden', () => {
  const hoy = new Date(2026, 8, 20);
  assert.equal(dueStatus('19/09/2026', parse, hoy).label, 'Vencido');
  assert.equal(dueStatus('20/09/2026', parse, hoy).label, 'Hoy');
  assert.equal(dueStatus('21/09/2026', parse, hoy).label, 'Vigente');
  assert.equal(dueStatus('', parse, hoy).label, 'Sin fecha');
  assert.equal(clientInitials('Amy Pastrana'), 'AP');
  assert.equal(clientInitials('lucy'), 'LU');
  assert.equal(clientInitials(''), 'C');
  assert.equal(clientTone('Amy Pastrana'), clientTone('Amy Pastrana'));
  assert.equal(recentMs({ updatedAt: '2026-09-20T10:00:00.000Z' }), Date.parse('2026-09-20T10:00:00.000Z'));
  assert.equal(recentMs({ updatedAt: { _seconds: 1000 } }), 1_000_000);
  assert.equal(recentMs({}), 0);
  const groups = [
    { nombre: 'Zoe', clienteId: 'z', fechaRenovacion: '05/10/2026', total: 100 },
    { nombre: 'Ana', clienteId: 'a', fechaRenovacion: '01/10/2026', total: 300 },
    { nombre: 'Mia', clienteId: 'm', fechaRenovacion: '03/10/2026', total: 200 },
  ];
  const byId = { z: { updatedAt: '2026-09-01T00:00:00Z' }, a: { updatedAt: '2026-09-10T00:00:00Z' }, m: { updatedAt: '2026-09-05T00:00:00Z' } };
  const opts = { clientById: id => byId[id], parse };
  assert.deepEqual(sortClientGroups(groups, 'recientes', opts).map(g => g.nombre), ['Ana', 'Mia', 'Zoe']);
  assert.deepEqual(sortClientGroups(groups, 'vence', opts).map(g => g.nombre), ['Ana', 'Mia', 'Zoe']);
  assert.deepEqual(sortClientGroups(groups, 'nombre', opts).map(g => g.nombre), ['Ana', 'Mia', 'Zoe']);
  assert.deepEqual(sortClientGroups(groups, 'monto', opts).map(g => g.nombre), ['Ana', 'Mia', 'Zoe']);
});

test('Clientes: main.js conecta el rediseño y las acciones siguen en el menú ⋮', () => {
  assert.match(main, /import \{ masHomeHtml, clientsScreenHtml,/);
  assert.match(main, /return clientsScreenHtml\(\{counts:clientFilterCounts\(\)/);
  assert.match(main, /#clientFiltersToggle'\)\?\.addEventListener\('click'/);
  assert.match(main, /#clientSort'\)\?\.addEventListener\('change'/);
  assert.match(main, /data-client-action="renew"/);
  assert.match(main, /data-client-action="charge"/);
  assert.match(css, /\.cli-tabs\{display:grid;grid-template-columns:repeat\(4/);
  assert.match(css, /\.mas-grid\{display:grid;grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
});
