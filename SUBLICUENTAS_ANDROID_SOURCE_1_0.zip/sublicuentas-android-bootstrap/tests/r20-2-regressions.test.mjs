import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { servicesForRenewalDate } from '../src/operations.js';

const main=appSource();
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');

test('renewal detail keeps only services for the selected renewal date',()=>{
  const rows=[
    {clienteId:'aura',plataforma:'Disney+',fechaRenovacion:'17/09/2026',precio:100},
    {clienteId:'aura',plataforma:'Paramount+',fechaRenovacion:'28/09/2026',precio:60},
  ];
  const due=servicesForRenewalDate(rows,'17/09/2026');
  assert.deepEqual(due.map(x=>x.plataforma),['Disney+']);
});

test('login uses approved visual with only username password and submit',()=>{
  assert.match(main,/login-clean-bg\.png/);
  assert.match(main,/id="loginUser"/);
  assert.match(main,/id="loginPassword"/);
  assert.match(main,/Iniciar sesión/);
  assert.doesNotMatch(main,/Recuperar contraseña|Continuar con Google|Crear cuenta/);
});

test('startup includes the approved static intro artwork before login',()=>{
  assert.match(main,/intro-clean-loader\.png/);
  assert.match(main,/splash-screen/);
  assert.match(css,/\.splash-screen/);
});

test('R29 splash keeps artwork static and spins only the loading ring (via JS)',()=>{
  assert.doesNotMatch(css,/splashZoomIn|splashBreath/);
  assert.match(main,/spinSplashLoaderWithJS/);
  assert.match(css,/splash-loader/);
});

test('R20.3 login uses clean background without baked duplicate form',()=>{
  assert.match(main,/login-clean-bg\.png/);
  assert.doesNotMatch(main,/class="visual-login-bg" src="\/assets\/login-reference\.png"/);
});
