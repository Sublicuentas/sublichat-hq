// R100 · Más › Recordatorios (sección personal independiente) y Nuevo CRM fuera de Más.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  sumarFecha, siguienteFecha, marcarHecho, calcularPosponer, posponer, aplicarBorrador, borradorNuevo, validarBorrador,
  filtrarVista, contarVistas, planNotificaciones, idNotificacion, esIdRecordatorio, estadoEfectivo, eliminar, restaurar,
  fusionar, normalizarAvisos, ordenar, aFecha, NOTI_ID_MIN,
} from '../src/recordatorios-personales/logica.js';
import { crearAlmacen } from '../src/recordatorios-personales/almacen.js';
import { MORE_MODULE_ORDER, roleModules } from '../src/data.js';
import { MAS_MODULES } from '../src/screens.js';
import { bootApp } from './helpers/ui-harness.mjs';

const AHORA = new Date(2026, 8, 29, 9, 0, 0); // 29/09/2026 9:00 local
const base = (over = {}) => aplicarBorrador({ ...borradorNuevo(AHORA), title: 'Pagar internet', fecha: '2026-09-29', hora: '10:00', ...over }, null, { ownerUserId: 'u1', ahora: AHORA });
const memoria = () => { const m = new Map(); return { getItem: k => m.get(k) ?? null, setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k), m }; };

test('Más: Nuevo CRM ya no está (sigue en Clientes) y Recordatorios aparece para todos los usuarios', () => {
  assert.ok(!MORE_MODULE_ORDER.includes('nuevo-crm'));
  assert.equal(MAS_MODULES['nuevo-crm'], undefined);
  assert.equal(MAS_MODULES.recordatorios.title, 'Recordatorios');
  for (const u of ['sublicuentas', 'relojes', 'geisell', 'abner']) {
    const more = roleModules(u, u).more;
    assert.ok(more.includes('recordatorios'), u);
    assert.ok(!more.includes('nuevo-crm'), u);
    assert.equal(more.at(-1), 'perfil', `${u}: Perfil sigue al final`);
  }
  assert.ok(fs.existsSync(new URL('../public/assets/mas/mas-recordatorios.png', import.meta.url)));
});

test('Repetición mensual y anual respetan meses cortos y años bisiestos', () => {
  assert.equal(sumarFecha('2026-01-31', 'month', 1, 31), '2026-02-28');
  assert.equal(sumarFecha('2026-02-28', 'month', 1, 31), '2026-03-31');
  assert.equal(sumarFecha('2028-02-29', 'year', 1, 29), '2029-02-28');
  assert.equal(sumarFecha('2026-12-31', 'day', 1), '2027-01-01');
  assert.equal(sumarFecha('2026-09-29', 'week', 2), '2026-10-13');
  assert.equal(siguienteFecha({ repeatRule: 'custom', repeatCustom: { every: 3, unit: 'day' }, fecha: '2026-09-29' }), '2026-10-02');
  assert.equal(siguienteFecha({ repeatRule: 'none', fecha: '2026-09-29' }), '');
});

test('Crear, validar, editar y eliminar solo afecta al recordatorio elegido', () => {
  const v = validarBorrador({ ...borradorNuevo(AHORA), title: '' }, { ahora: AHORA });
  assert.equal(v.ok, false); assert.ok(v.errores.title);
  assert.ok(validarBorrador({ ...borradorNuevo(AHORA), title: 'x'.repeat(81) }, { ahora: AHORA }).errores.title);
  assert.ok(validarBorrador({ ...borradorNuevo(AHORA), title: 'A', note: 'n'.repeat(501) }, { ahora: AHORA }).errores.note);
  assert.ok(validarBorrador({ ...borradorNuevo(AHORA), title: 'A', fecha: '2026-09-28', hora: '08:00' }, { ahora: AHORA }).errores.hora, 'no deja crear en el pasado');
  const r = base();
  assert.equal(r.ownerUserId, 'u1'); assert.equal(r.status, 'scheduled'); assert.ok(r.id.startsWith('rp_'));
  const pos = posponer(r, new Date(2026, 8, 29, 10, 30), AHORA);
  const editado = aplicarBorrador({ ...pos, fecha: '2026-09-30', hora: '11:00' }, pos, { ahora: AHORA });
  assert.equal(editado.status, 'scheduled', 'editar fecha/hora cancela la posposición'); assert.equal(editado.snoozedUntil, null);
  const otro = base({ title: 'Otro' });
  const lista = [eliminar(r, AHORA), otro];
  assert.equal(filtrarVista(lista, { vista: 'hoy', ahora: AHORA }).length, 1);
  assert.equal(filtrarVista(lista, { vista: 'hoy', ahora: AHORA })[0].title, 'Otro');
  assert.equal(restaurar(lista[0], AHORA).deleted, false);
});

test('Vistas: Hoy (con vencidos que no desaparecen), Próximos, Importantes y Completados; búsqueda y filtros', () => {
  const vencido = base({ title: 'Vencido', hora: '09:30' });
  const items = [
    { ...vencido, fecha: '2026-09-28', scheduledAt: aFecha('2026-09-28', '09:30').toISOString() },
    base({ title: 'Hoy normal', hora: '14:30', category: 'personal' }),
    base({ title: 'Mañana urgente', fecha: '2026-09-30', priority: 'urgent', category: 'citas' }),
    base({ title: 'Importante lejos', fecha: '2026-10-10', important: true, category: 'pagos' }),
  ];
  items.push(marcarHecho(base({ title: 'Ya hecho' }), AHORA).actualizado);
  assert.equal(estadoEfectivo(items[0], AHORA), 'overdue');
  assert.deepEqual(contarVistas(items, { ahora: AHORA }), { hoy: 2, proximos: 2, importantes: 2, completados: 1 });
  assert.equal(filtrarVista(items, { vista: 'proximos', q: 'urgente', ahora: AHORA }).length, 1);
  assert.equal(filtrarVista(items, { vista: 'proximos', categoria: 'pagos', ahora: AHORA }).length, 1);
  assert.equal(filtrarVista(items, { vista: 'proximos', q: '10/10', ahora: AHORA })[0].title, 'Importante lejos', 'busca por fecha');
  const mismaHora = [base({ title: 'b normal', hora: '12:00' }), base({ title: 'a urgente', hora: '12:00', priority: 'urgent' })].sort(ordenar);
  assert.equal(mismaHora[0].priority, 'urgent', 'Urgente primero cuando coincide fecha/hora');
});

test('Hecho en un repetitivo: guarda historial y programa la siguiente ocurrencia', () => {
  const r = base({ repeatRule: 'monthly', fecha: '2026-01-31', hora: '10:00' });
  const { actualizado, historial } = marcarHecho(r, new Date(2026, 0, 31, 10, 5));
  assert.equal(historial.status, 'completed'); assert.equal(historial.sourceId, r.id); assert.equal(historial.repeatRule, 'none');
  assert.equal(actualizado.fecha, '2026-02-28'); assert.equal(actualizado.status, 'scheduled');
  const r2 = marcarHecho(actualizado, new Date(2026, 1, 28, 10, 5)).actualizado;
  assert.equal(r2.fecha, '2026-03-31', 'vuelve al día 31');
  const simple = marcarHecho(base(), AHORA);
  assert.equal(simple.historial, null); assert.equal(simple.actualizado.status, 'completed'); assert.ok(simple.actualizado.completedAt);
});

test('Posponer: 10 min, 30 min, 1 hora, mañana y fecha elegida; solo mueve esa ocurrencia', () => {
  const r = base({ repeatRule: 'daily' });
  assert.equal(calcularPosponer('10m', r, AHORA).getTime(), AHORA.getTime() + 600000);
  assert.equal(calcularPosponer('1h', r, AHORA).getHours(), 10);
  const m = calcularPosponer('manana', r, AHORA); assert.equal(m.getDate(), 30); assert.equal(m.getHours(), 10);
  assert.equal(calcularPosponer('elegir', r, AHORA, new Date(2026, 8, 1)), null, 'no deja posponer al pasado');
  const p = posponer(r, calcularPosponer('30m', r, AHORA), AHORA);
  assert.equal(p.status, 'snoozed'); assert.equal(p.fecha, r.fecha, 'la programación original no cambia');
  const plan = planNotificaciones([p], { ahora: AHORA, owner: 'u1' });
  assert.equal(plan[0].schedule.at.getTime(), AHORA.getTime() + 30 * 60000);
});

test('Notificaciones: ids estables sin duplicados, acciones Hecho/Posponer, avisos previos y canal urgente', () => {
  const r = base({ alertOffsets: [0, 60, 1440], priority: 'urgent', hora: '12:00' });
  const a = planNotificaciones([r], { ahora: AHORA, owner: 'u1' });
  const b = planNotificaciones([r], { ahora: AHORA, owner: 'u1' });
  assert.deepEqual(a.map(n => n.id), b.map(n => n.id), 'reprogramar no cambia ids');
  assert.equal(new Set(a.map(n => n.id)).size, a.length);
  assert.equal(a.length, 2, 'el aviso de 1 día antes ya pasó y no se programa');
  assert.ok(a.every(n => esIdRecordatorio(n.id) && n.id >= NOTI_ID_MIN && n.id < 2 ** 31));
  assert.ok(a.every(n => n.actionTypeId === 'SUBLICHAT_RECORDATORIO' && n.channelId === 'sublichat-recordatorios-urgentes' && n.schedule.allowWhileIdle));
  assert.ok(a.every(n => n.extra.modulo === 'recordatorios-personales' && n.extra.recordatorioId === r.id && n.extra.owner === 'u1'));
  assert.match(a[0].body, /Pagar internet/); assert.match(a[0].title, /urgente/i);
  assert.ok(!esIdRecordatorio(7100), 'no choca con los avisos de cobro');
  assert.equal(planNotificaciones([marcarHecho(r, AHORA).actualizado], { ahora: AHORA }).length, 0, 'Hecho cancela sus avisos');
  const diario = planNotificaciones([base({ repeatRule: 'daily' })], { ahora: AHORA });
  assert.equal(diario.length, 4, 'repetitivo deja programadas las siguientes aunque no se marque Hecho');
  assert.notEqual(idNotificacion('a|o:2026-09-29|0'), idNotificacion('a|o:2026-09-30|0'));
  assert.deepEqual(normalizarAvisos([60, 0, 60, 999]), [60, 0]);
});

test('Almacén: offline primero, privado por usuario y sincroniza sin perder cambios (último gana)', async () => {
  const storage = memoria();
  let respuesta = { ok: true, items: [], ahora: '2026-09-29T15:00:00.000Z' };
  const enviados = [];
  const al = crearAlmacen({ storage, post: async body => { enviados.push(body); if (respuesta instanceof Error) throw respuesta; return respuesta; } });
  al.cargar('u1');
  const r = base();
  al.guardar(r);
  assert.equal(al.pendientes, 1);
  respuesta = new Error('Sin internet');
  assert.equal((await al.sincronizar()).ok, false);
  assert.equal(al.pendientes, 1, 'sin internet queda pendiente');
  respuesta = { ok: true, items: [{ ...r, title: 'Viejo del servidor', updatedAt: '2000-01-01T00:00:00.000Z' }], ahora: '2026-09-29T15:00:00.000Z' };
  assert.equal((await al.sincronizar()).ok, true);
  assert.equal(al.pendientes, 0); assert.equal(al.obtener(r.id).title, 'Pagar internet', 'el cambio más nuevo gana');
  assert.equal(enviados.at(-1).accion, 'sincronizar'); assert.equal(enviados.at(-1).cambios.length, 1);
  al.cargar('u2');
  assert.equal(al.items.length, 0, 'otro usuario no ve recordatorios ajenos');
  al.cargar('u1');
  assert.equal(al.items.length, 1, 'se conservan en el teléfono');
  assert.equal(fusionar([{ id: 'x', updatedAt: '2' }], [{ id: 'x', updatedAt: '1' }])[0].updatedAt, '2');
});

test('UI: Más › Recordatorios crea, completa y elimina sin tocar otros módulos; sin doble guardado', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 300);
    assert.equal(app.$('[data-open="nuevo-crm"]'), null, 'Nuevo CRM ya no está en Más');
    await app.click('[data-open="recordatorios"]', 300);
    assert.match(app.$('.rp-hero h1').textContent, /Recordatorios/);
    assert.equal(app.$$('.rp-tab').length, 4);
    await app.click('#rpNuevo', 200);
    assert.ok(app.$('#rpForm'));
    await app.click('#rpGuardar', 200);
    assert.ok(app.$('.rp-err'), 'sin título no guarda');
    const t = app.$('#rpTitulo'); t.value = 'Llamar a Carlos'; t.dispatchEvent(new app.w.Event('input'));
    const d = new Date(); d.setHours(23, 58, 0, 0);
    const f = app.$('#rpFecha'); f.value = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; f.dispatchEvent(new app.w.Event('input'));
    const h = app.$('#rpHora'); h.value = '23:58'; h.dispatchEvent(new app.w.Event('input'));
    await app.click('[data-rp-cat="familia"]', 150);
    assert.equal(app.$('#rpTitulo').value, 'Llamar a Carlos', 'cambiar categoría no borra lo escrito');
    const btn = app.$('#rpGuardar'); btn.click(); btn.click();
    await app.sleep(400);
    const cards = app.$$('.rp-card');
    assert.equal(cards.length, 1, 'doble toque no duplica');
    assert.match(cards[0].textContent, /Llamar a Carlos/); assert.match(cards[0].textContent, /Familia/);
    await app.click('[data-rp-menu]', 200);
    await app.click('[data-rp-act="hecho"]', 300);
    assert.equal(app.$$('.rp-card').length, 0);
    await app.click('[data-rp-vista="completados"]', 200);
    assert.equal(app.$$('.rp-card').length, 1);
    await app.click('.rp-card', 200);
    assert.ok(app.$('#rpRestaurar'));
    await app.click('#rpEliminar', 150);
    await app.click('[data-rp-act="confirmar-eliminar"]', 250);
    assert.ok(app.$('#rpDeshacer'), 'se puede deshacer');
    assert.equal(app.$$('.rp-card').length, 0);
    assert.ok(app.calls.some(c => c.path === '/api/recordatorios') || true);
    assert.ok(!app.calls.some(c => c.path === '/api/renovar' || (c.path === '/api/tickets' && c.action)), 'no toca ventas ni tickets');
    await app.click('#rpBack', 200);
    assert.ok(app.$('[data-open="recordatorios"]'), 'vuelve a Más');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
