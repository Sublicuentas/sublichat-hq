import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { mdToHtml, mdToPlain } from '../src/markdown.js';
import { subliContentHtml, SUBLI_CATS, SUBLI_DEFAULT_SUGGESTIONS, subliSuggestions } from '../src/screens.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

const muestra = [
  'Como hoy es **domingo 20 de septiembre de 2026**, el total es **Lps. 5,094.00**.',
  '',
  '### **Lunes 21 de septiembre**',
  '* **Gisselle Fajardo** (8900-0958) - ViX: **Lps. 120.00**',
  '* **Isabella Orellana** (9905-4237) - Prime Video: **Lps. 90.00**',
].join('\n');

test('Markdown: negritas, encabezados y viñetas ordenadas (adiós asteriscos)', () => {
  const d = dom(mdToHtml(muestra));
  assert.equal(d.querySelector('p strong').textContent, 'domingo 20 de septiembre de 2026');
  assert.equal(d.querySelector('h4.md-h').textContent, 'Lunes 21 de septiembre');
  const items = [...d.querySelectorAll('ul li')];
  assert.equal(items.length, 2);
  assert.equal(items[0].querySelectorAll('strong').length, 2);
  assert.match(items[0].textContent, /Gisselle Fajardo \(8900-0958\) - ViX: Lps\. 120\.00/);
  assert.doesNotMatch(d.body.textContent, /\*/);
  assert.doesNotMatch(mdToPlain(muestra), /[*#]/);
  assert.match(mdToPlain(muestra), /• Gisselle Fajardo/);
});

test('Markdown: seguro (escapa HTML), colapsa listas largas y dibuja tablas', () => {
  const d = dom(mdToHtml('<img src=x onerror=alert(1)> **ok**'));
  assert.equal(d.querySelector('img'), null);
  assert.equal(d.querySelector('strong').textContent, 'ok');
  const largo = dom(mdToHtml(Array.from({ length: 30 }, (_, i) => `- Cliente ${i + 1}`).join('\n')));
  assert.equal(largo.querySelectorAll('li').length, 30);
  assert.match(largo.querySelector('details.md-more summary').textContent, /Ver 15 más/);
  const corta = dom(mdToHtml(Array.from({ length: 17 }, (_, i) => `- Cliente ${i + 1}`).join('\n')));
  assert.equal(corta.querySelector('details'), null, 'con pocos elementos sobrantes no se esconde nada');
  const t = dom(mdToHtml('| A | B |\n|---|---|\n| 1 | 2 |'));
  assert.equal(t.querySelectorAll('th').length, 2);
  assert.equal(t.querySelectorAll('td').length, 2);
  const ol = dom(mdToHtml('1. uno\n2. dos'));
  assert.equal(ol.querySelectorAll('ol li').length, 2);
  assert.equal(mdToHtml('   '), '');
});

test('Subli (bienvenida): héroe con robot, categorías, preguntas sugeridas y compositor como el mockup', () => {
  const d = dom(subliContentHtml({}));
  assert.equal(d.querySelector('h1').textContent, 'Subli');
  assert.match(d.body.textContent, /Asistente de Sublicuentas/);
  assert.ok(d.querySelector('img.sb-robot'));
  assert.match(d.querySelector('.sb-hello').textContent, /¡Hola! 👋/);
  assert.match(d.querySelector('.sb-hello').textContent, /Uso los datos reales de tu cartera/);
  assert.match(d.querySelector('.sb-q').textContent, /¿Qué deseas consultar\?/);
  assert.deepEqual([...d.querySelectorAll('[data-subli-cat]')].map(b => b.dataset.subliCat), ['clientes', 'vencimientos', 'cobros', 'reportes']);
  assert.equal(d.querySelectorAll('.sb-cats svg').length, 4);
  assert.deepEqual([...d.querySelectorAll('[data-subli-suggest]')].map(b => b.dataset.subliSuggest), [...SUBLI_DEFAULT_SUGGESTIONS]);
  assert.ok(d.querySelector('#subliRefresh'));
  assert.ok(d.querySelector('#backMore') && d.querySelector('#subliMenuBtn'));
  assert.match(d.querySelector('#subliInput').placeholder, /Escribe tu pregunta/);
  assert.ok(d.querySelector('#subliForm button[type=submit]'));
  assert.equal(d.querySelector('.subli-msgs'), null);
});

test('Subli (chat): la respuesta se ve con formato y el menú ⋮ ofrece nueva conversación y copiar', () => {
  const d = dom(subliContentHtml({ messages: [{ role: 'user', text: '¿Qué vence hoy?' }, { role: 'bot', text: muestra }], menuOpen: true }));
  assert.ok(d.querySelector('.sb-page.chatting'));
  assert.equal(d.querySelector('.sb-msg.me').textContent, '¿Qué vence hoy?');
  const bot = d.querySelector('.sb-msg.bot.md');
  assert.equal(bot.querySelectorAll('li').length, 2);
  assert.equal(bot.querySelectorAll('strong').length >= 5, true);
  assert.doesNotMatch(bot.textContent, /\*\*/);
  assert.equal(d.querySelector('[data-subli-cat]'), null, 'en el chat no se repiten las categorías');
  assert.ok(d.querySelector('#subliNewChat') && d.querySelector('#subliCopyLast') && d.querySelector('#subliMenuClose'));
  const err = dom(subliContentHtml({ messages: [{ role: 'bot', text: '⚠️ falló <b>x</b>', error: true }] }));
  assert.equal(err.querySelector('b'), null);
  assert.ok(err.querySelector('.sb-msg.err'));
  assert.ok(dom(subliContentHtml({ loading: true })).querySelector('.typing'));
});

test('Subli: preguntas sugeridas por categoría y el botón ↻ rota', () => {
  assert.deepEqual(subliSuggestions('', 0), [...SUBLI_DEFAULT_SUGGESTIONS]);
  const cobros = subliSuggestions('cobros', 0);
  for (const q of cobros) assert.ok(SUBLI_CATS.cobros.questions.includes(q));
  assert.notDeepEqual(subliSuggestions('cobros', 1), cobros);
  assert.equal(subliSuggestions('', 99).length, 3);
});

test('Subli: main.js conecta menú, categorías, copiar (texto limpio) y Enter para enviar', () => {
  assert.match(main, /import \{ mdToPlain \} from '\.\/markdown\.js'/);
  assert.match(main, /return subliContentHtml\(\{messages:state\.subliMessages/);
  assert.match(main, /\[data-subli-cat\]'\)\.forEach/);
  assert.match(main, /#subliRefresh'\)\?\.addEventListener/);
  assert.match(main, /navigator\.clipboard\.writeText\(mdToPlain\(last\.text\)\)/);
  assert.match(main, /e\.key==='Enter'&&!e\.shiftKey/);
  assert.match(css, /\.md \.md-h\{/);
  assert.match(css, /\.md ul li:before/);
  assert.match(css, /\.sb-composer\{position:sticky;bottom:calc\(96px/);
});

test('Subli: la caja de escribir queda pegada abajo también en la pantalla de bienvenida', () => {
  assert.match(css, /\.sb-page\{display:flex;flex-direction:column;min-height:calc\(100dvh - 150px/);
  assert.match(css, /\.sb-page>\.sb-composer\{margin-top:auto\}/);
  assert.match(css, /\.sb-page>\*\{flex:none\}/);
});
