import test from 'node:test';
import assert from 'node:assert/strict';
import { clasificarServicio, puedeSerCuentaCompleta, ORDEN_CATEGORIAS } from '../src/app/catalogo-categorias.js';
test('R112 APK: mismo contrato de categorías que el servidor', () => {
  assert.deepEqual(ORDEN_CATEGORIAS, ['perfiles', 'tv_digital', 'musica', 'software', 'cuentas_completas']);
  assert.equal(clasificarServicio({ plataforma: 'viki' }).tipoVenta, 'cuenta_completa');
  assert.equal(clasificarServicio({ plataforma: 'netflix', tipoVenta: 'cuenta_completa' }).categoria, 'cuentas_completas');
  assert.ok(puedeSerCuentaCompleta('crunchyroll'));
});

import { bootApp } from './helpers/ui-harness.mjs';
test('R112 APK: compra nueva muestra 5 categorías; Cuentas completas filtra plataformas y oculta PIN/perfil', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 300);
    await app.click('[data-tab-jump="nuevo-crm"]', 400);
    const chips = app.$$('[data-crm-cat]');
    assert.equal(chips.length, 5, 'las 5 categorías antes de la plataforma');
    await app.click('[data-crm-cat="cuentas_completas"]', 250);
    const opts = app.$$('#crmPlataforma option').filter((o) => !o.hidden).map((o) => o.value).sort();
    assert.deepEqual(opts, ['crunchyroll', 'disneys', 'hbomax', 'netflix', 'viki']);
    const pin = app.$('[data-p-pin]'); assert.ok(!pin || pin.closest('.crm-field')?.hidden, 'sin PIN');
    await app.click('[data-crm-cat="perfiles"]', 250);
    assert.ok(!app.$$('#crmPlataforma option').some((o) => !o.hidden && o.value === 'viki'), 'Viki ya no está en Perfiles');
  } finally { app.close(); }
});
