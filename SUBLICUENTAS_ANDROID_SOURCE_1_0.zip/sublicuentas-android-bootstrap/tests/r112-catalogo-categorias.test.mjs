import test from 'node:test';
import assert from 'node:assert/strict';
import { clasificarServicio, puedeSerCuentaCompleta, ORDEN_CATEGORIAS } from '../src/app/catalogo-categorias.js';
test('R112 APK: mismo contrato de categorías que el servidor', () => {
  assert.deepEqual(ORDEN_CATEGORIAS, ['perfiles', 'tv_digital', 'musica', 'software', 'cuentas_completas']);
  assert.equal(clasificarServicio({ plataforma: 'viki' }).tipoVenta, 'cuenta_completa');
  assert.equal(clasificarServicio({ plataforma: 'netflix', tipoVenta: 'cuenta_completa' }).categoria, 'cuentas_completas');
  assert.ok(puedeSerCuentaCompleta('crunchyroll'));
});
