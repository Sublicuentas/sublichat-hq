// R193 · Finanzas APK: filas por PRODUCTO canónico (las calcula el servidor), «Pendiente de clasificar» fuera del ranking
// pero dentro del total, revisión de alias con evidencia, y Excel con la MISMA respuesta. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { mesHtml, productosHtml } from '../src/app/finanzas-libro.js';

const MES = { periodo: '2026-11', desde: '2026-11-01', hasta: '2026-11-30', ingresos: 9645.05, ingresosCentavos: 964505, egresos: 0, planilla: 0, resultado: 9645.05, ventasGeneradas: 0, pagosUnicos: 7,
  cobrosPorProducto: [{ productoId: 'netflix', plataforma: 'Netflix Premium', monto: 4000, centavos: 400000, pagos: 3, alias: ['netflix', 'Netflix Premium'] },
    { productoId: 'vipnetflix', plataforma: 'Netflix VIP', monto: 3000, centavos: 300000, pagos: 2, alias: ['vipnetflix'] },
    { productoId: 'disneyp', plataforma: 'Disney Premium', monto: 1881.95, centavos: 188195, pagos: 2, alias: ['disneyp', 'Disney Premium'] }],
  pendienteClasificar: { monto: 763.1, centavos: 76310, pagos: 2, detalle: [{ pagoId: 'p1', fecha: '2026-11-04', cliente: 'Cliente ficticio', original: 'Netflix Premium VIP', motivo: 'alias_ambiguo_netflix_vip', monto: 113.1 }, { pagoId: 'p2', fecha: '2026-11-05', cliente: 'Otro', original: '', motivo: 'sin_plataforma', monto: 650 }] },
  aliasRevisados: [{ original: 'Netflix Premium VIP', motivo: 'alias_ambiguo_netflix_vip', pagos: 1, monto: 113.1, centavos: 11310 }],
  productosCatalogo: { netflix: 'Netflix Premium', vipnetflix: 'Netflix VIP', disneyp: 'Disney Premium' },
  conciliacion: { productosMasPendienteIgualIngresos: true } };

test('F02/F05/F07: una fila por producto; Premium y VIP separados; sin «Pago combinado» ni «Sin plataforma» en el ranking', () => {
  const h = mesHtml(MES, false, null, {});
  assert.match(h, /Ingresos cobrados por producto/);
  const ranking = h.slice(h.indexOf('Ingresos cobrados por producto'));
  const filas = [...ranking.matchAll(/<li class="fl-plat"><span>([^<]+)/g)].map((m) => m[1].trim());
  assert.deepEqual(filas, ['Netflix Premium', 'Netflix VIP', 'Disney Premium']);
  assert.doesNotMatch(h, /Pago combinado|Sin plataforma<\/span>/);
  assert.match(h, /Pendiente de clasificar/); assert.match(h, /fuera del ranking, sí en el total/);
  assert.match(h, /✔ Productos \+ pendiente = ingresos cobrados/);
});

test('F04/F08: el pendiente se abre con su detalle; la etiqueta ambigua se revisa con evidencia obligatoria (no se asigna sola)', () => {
  const h = productosHtml(MES, { abierto: true, revisar: true });
  assert.match(h, /«Netflix Premium VIP»: ¿Premium o VIP\? \(revisar\)/); assert.match(h, /Sin plataforma registrada/);
  assert.match(h, /Evidencia \(obligatorio\)/); assert.match(h, /no cambia montos ni movimientos/);
  const src = fs.readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  assert.match(src, /accion: 'finanzas_alias_confirmar'/);
  assert.match(productosHtml({ ...MES, conciliacion: { productosMasPendienteIgualIngresos: false } }), /No cuadra/);
});

test('F09: el Excel usa la MISMA respuesta del servidor (hoja «Cobros por producto» + pendiente)', () => {
  const src = fs.readFileSync(new URL('../src/app/excel-saiyajin.js', import.meta.url), 'utf8');
  assert.match(src, /export function hojaProductos\(wb, mes\)/); assert.match(src, /hojaProductos\(wb, mes\);/);
  assert.match(fs.readFileSync(new URL('../src/app/renovar-lote.js', import.meta.url), 'utf8'), /range:\{desde,hasta\},mes\}\)/);
});
