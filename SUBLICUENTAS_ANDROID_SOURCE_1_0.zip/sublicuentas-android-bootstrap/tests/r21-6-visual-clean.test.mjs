import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
test('R21.6 login preserves artwork aspect ratio instead of stretching',()=>{
  assert.match(css,/\.visual-login-bg\{[^}]*object-fit:cover/);
  assert.doesNotMatch(css,/\.visual-login-bg\{[^}]*object-fit:fill/);
});
test('R21.6 home cards have no black borders',()=>{
  assert.match(css,/\.visual-module-card\{[^}]*border:0/);
  assert.match(css,/\.visual-metric\{[^}]*border:0/);
});
test('R21.6 home uses supplied brand and robot assets',()=>{
  assert.match(main,/01_logo_sublicuentas\.png/);
  assert.match(main,/06_mascota_sublibot\.png/);
});
