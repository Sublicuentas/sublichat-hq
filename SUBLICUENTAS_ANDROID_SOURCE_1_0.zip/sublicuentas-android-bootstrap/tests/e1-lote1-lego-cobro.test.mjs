// E1 · Entrega parcial 1: tema LEGO 3D (solo visual) + correcciones de Cobro y Renovación.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const read = (p) => fs.readFileSync(new URL(`../src/${p}`, import.meta.url), 'utf8');
const lego = read('lego.css');

test('E1 · Más: subtítulo solo «Herramientas operativas» y se conservan los 16 módulos', async () => {
  assert.doesNotMatch(read('screens.js'), /nada se elimina/);
  const app = await bootApp();
  try {
    await app.click('.bottom-nav [data-tab="mas"]', 300);
    assert.equal(app.$('.mas-sub')?.textContent.trim(), 'Herramientas operativas');
    assert.equal(app.$$('.mas-grid .mas-card').length, 16); // 15 módulos + «Más resultados»
  } finally { app.close(); }
});

test('E1 · Tema LEGO 3D: opción en Perfil, clase en <html>, sin tocar el tema claro por defecto', async () => {
  assert.match(read('main.js'), /<option value="lego">LEGO 3D<\/option>/);
  assert.match(read('app/core.js'), /\['light','dark','system','lego'\]/);
  assert.match(read('app/core.js'), /classList\.toggle\('theme-lego', state\.theme==='lego'\)/);
  // todo lo visual del tema queda bajo .theme-lego (salvo los componentes funcionales nuevos)
  const reglas = lego.split('/* ---------- Tema LEGO 3D ---------- */')[1];
  for (const sel of reglas.match(/^[^@/{}\s][^{]*\{/gm) || []) assert.match(sel, /theme-lego/, `regla fuera del tema: ${sel}`);
  assert.doesNotMatch(lego, /linear-gradient/); // sin degradados de color
  const app = await bootApp();
  try { assert.equal(app.w.document.documentElement.classList.contains('theme-lego'), false); } finally { app.close(); }
});

test('E1 · Selector de vendedor: lista única desde el <select> real; Seleccionar aplica y ✕ cancela', async () => {
  const app = await bootApp();
  try {
    await app.click('.bottom-nav [data-tab="cobros"]', 300);
    const sel = app.$('#renewSellerFilter'); assert.ok(sel, 'sigue existiendo el select real');
    await app.click('[data-seller-picker="renewSellerFilter"]', 50);
    const filas = app.$$('.sp-row'); assert.equal(filas[0].textContent.trim().endsWith('Todos'), true);
    assert.deepEqual(filas.map((f) => f.dataset.spV), [...sel.options].map((o) => o.value));
    assert.equal(app.$$('.sp-row.on').length, 1);
    // ✕ cancela sin cambios
    await app.click(filas[1], 10); await app.click('[data-sp-cerrar]', 50);
    assert.equal(app.$('.sp-back'), null); assert.equal(app.$('#renewSellerFilter').value, '');
    // Seleccionar aplica
    await app.click('[data-seller-picker="renewSellerFilter"]', 50);
    const v = app.$$('.sp-row')[1].dataset.spV; await app.click(app.$$('.sp-row')[1], 10); await app.click('[data-sp-ok]', 300);
    assert.equal(app.$('#renewSellerFilter').value, v);
    assert.match(app.$('.cb-seller-pick').textContent, new RegExp(v));
  } finally { app.close(); }
});

test('E1 · Plantillas de cobro: posición real, estilo activo, Copiar confirma y WhatsApp lleva el texto visible', async () => {
  const src = read('app/renovar-mensajes.js');
  assert.match(src, /Plantilla \$\{pos\} de \$\{total\}/);
  assert.match(src, /document\.execCommand\('copy'\)/); // respaldo si el WebView no deja usar el portapapeles
  assert.match(src, /lbl\.textContent = '¡Copiado!'/);
  assert.match(src, /no tiene teléfono: copie el mensaje/);
});

test('E1 · Renovación: «Confirmar» bloquea el doble toque y la hoja muestra vence → nuevo', () => {
  const src = read('app/finanzas-libro.js');
  assert.match(src, /btn\.dataset\.enviando === '1'\) return;/);
  assert.match(src, /vence \$\{esc\(f\.anterior \|\| '—'\)\} → nuevo/);
  assert.match(read('main.js'), /fechas:rows\.map\(r=>\(\{plataforma:/);
  // «Con pago» y «Ajuste sin pago» siguen siendo operaciones distintas; «Ya pagó por Socios» solo en compras
  assert.match(src, /data-rp-modo="pago">💵 Con pago<\/button><button class="\$\{ajuste \? 'on' : ''\}" data-rp-modo="ajuste">🛠 Ajuste sin pago/);
});
