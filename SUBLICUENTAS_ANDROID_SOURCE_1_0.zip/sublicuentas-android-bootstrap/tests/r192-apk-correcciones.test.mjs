// R192 · PDF «Sublichat APK correcciones»: Sala 3D, Baúl en 3 niveles con mensaje/compartir, Resumen del mes,
// conciliación del ciclo, edición sin saltos y tarjetas de Más. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { libroViewHtml, mesHtml, conciliacionCiclo } from '../src/app/finanzas-libro.js';
import { MAS_MODULES } from '../src/screens.js';
import { roleModules } from '../src/data.js';

const src = (f) => fs.readFileSync(new URL(`../src/${f}`, import.meta.url), 'utf8');

const BAUL = { ok: true, editor: false, version: 4, aviso: 'Para APK externas…',
  plataformas: [{ id: 'oleada', nombre: 'Oleada TV' }, { id: 'liontv', nombre: 'Lion TV' }],
  vistas: [
    { plataforma: 'oleada', dispositivos: [{ id: 'android_tv', nombre: 'Android TV / TV Box', enlaces: [{ id: 'oleada-atv', app: 'Oleada', dispositivo: 'android_tv', metodo: 'apk', metodoTxt: 'Con Downloader', url: 'https://ejemplo.invalid/o.apk', codigo: '9387291', activo: true, mensaje: 'SUBLICUENTAS | Instalación de Oleada TV\nCódigo Downloader: 9387291' }] }] },
    { plataforma: 'liontv', dispositivos: [{ id: 'smart_tv', nombre: 'Smart TV Samsung o LG', enlaces: [
      { id: 'maxplayer-tv', app: 'Max Player', dispositivo: 'smart_tv', metodo: 'tv_store', metodoTxt: 'Tienda del TV', activo: true, mensaje: 'SUBLICUENTAS | Instalación de Lion TV\nAplicación: Max Player' },
      { id: 'smartone-tv', app: 'SmartOne', dispositivo: 'smart_tv', metodo: 'tv_store', metodoTxt: 'Tienda del TV', activo: true, costoExterno: { texto: 'L85 para activar 12 meses POR DISPOSITIVO' }, mensaje: 'SUBLICUENTAS | SmartOne\nImportante: L85' }] },
      { id: 'iphone', nombre: 'iPhone / iPad', enlaces: [{ id: 'purple-ios', app: 'Purple IPTV Lite', dispositivo: 'iphone', metodo: 'app_store', metodoTxt: 'App Store', url: 'https://apps.apple.com/x', activo: true, mensaje: 'App Store' }] }] },
  ], enlaces: [] };

test('P2 Baúl: logo → dispositivo → app; mensaje del servidor; Enviar abre Compartir (no envía solo); URL oculta al no editor', async () => {
  const app = await bootApp({ role: 'geisell', fetchExtra: async (path, body) => {
    if (path !== '/api/inventario') return undefined;
    if (body.accion === 'baulApks') return BAUL;
    return { ok: true, urls: {} };
  } });
  try {
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="baul-apks"]', 400);
    await app.waitFor(() => app.$('[data-baul-plat="oleada"]'));
    assert.match(app.$('.se-wrap').textContent, /Paso 1 de 3/);
    assert.ok(app.$('[data-baul-plat="oleada"] img[src="/assets/plataformas/oleada-tv.webp"]'));
    await app.click('[data-baul-plat="oleada"]', 150);
    assert.match(app.$('.se-wrap').textContent, /Paso 2 de 3/);
    await app.click('[data-baul-disp="android_tv"]', 150);
    const t = app.$('.se-wrap').textContent;
    assert.match(t, /Paso 3 de 3/); assert.match(t, /Código Downloader: 9387291/);
    assert.doesNotMatch(t, /ejemplo\.invalid/, 'la URL técnica no se muestra al personal sin permiso de edición');
    assert.ok(app.$('[data-baul-copiar-msg="oleada-atv"]') && app.$('[data-baul-enviar="oleada-atv"]'));
    await app.click('[data-baul-atras="disp"]', 150); await app.click('[data-baul-atras="plat"]', 150);
    await app.click('[data-baul-plat="liontv"]', 150); await app.click('[data-baul-disp="smart_tv"]', 150);
    const tv = app.$('.se-wrap').textContent;
    assert.match(tv, /Opción 1/); assert.match(tv, /Opción 2/); assert.match(tv, /L85 para activar 12 meses/);
    await app.click('[data-baul-atras="disp"]', 150); await app.click('[data-baul-disp="iphone"]', 150);
    assert.match(app.$('.se-wrap').textContent, /No instalar archivos APK en iPhone/);
  } finally { app.close(); }
  const s = src('app/baul-apks.js');
  assert.match(s, /Share\.share\(\{ title: 'Instalación', text: texto/);
  assert.doesNotMatch(s, /wa\.me|api\.whatsapp|sendMessage/, 'nunca envía automáticamente');
});

test('P3 Resumen: solo el mes; cobrado/egreso/generado/pendiente separados; cobros por plataforma legibles', () => {
  const mes = { periodo: '2026-11', ingresos: 220, egresos: 50, planilla: 0, ventasGeneradas: 900, pagosUnicos: 2,
    cobrosPorPlataforma: [{ plataforma: 'netflix', monto: 150, centavos: 15000 }, { plataforma: 'Pago combinado (varios servicios)', monto: 70, centavos: 7000 }] };
  const h = mesHtml(mes, false, { pendienteTotal: 120 });
  assert.match(h, /Noviembre 2026/); assert.match(h, /01 nov – 30 nov 2026/);
  assert.match(h, /Ingresos cobrados por plataforma/); assert.match(h, /Pago combinado/);
  assert.match(h, /Ventas generadas/); assert.match(h, /class="fl-plat/);
  const st = { libro: { tab: 'resumen', mes, movFiltro: {}, data: { hoy: '2026-11-07', metodos: [], ciclo: { inicio: '2026-10-01' }, totales: {}, bancos: [], totalBancos: 0, cierres: [], cartera: { pendienteTotal: 120 } } } };
  const r = libroViewHtml(st);
  assert.match(r, /NO es dinero disponible/); assert.doesNotMatch(r, /Ciclo abierto desde/);
  const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
  assert.match(css, /\.fl-plat\{[^}]*grid-template-columns/);
});

test('P3 Cierre: ciclo abierto desde 01/10 sin cierre al 31/10 → alerta y cierre guiado (no automático); con cierre, nada', () => {
  const d = { hoy: '2026-11-07', ciclo: { inicio: '2026-10-01' }, cierres: [] };
  assert.deepEqual(conciliacionCiclo(d), { fechaSugerida: '2026-10-31', mesAnteriorAbierto: true, ultimoDiaMesAnterior: '2026-10-31', ultimo: null });
  assert.equal(conciliacionCiclo({ ...d, ciclo: { inicio: '2026-11-01' }, cierres: [{ fechaFin: '2026-10-31', estado: 'cerrado', origenCanal: 'tg' }] }).mesAnteriorAbierto, false);
  const h = libroViewHtml({ libro: { tab: 'cierre', movFiltro: {}, data: { ...d, metodos: [], totales: { ingresos: 0, egresosOperativos: 0, disponibleAntesPlanilla: 0, planilla: 0, resultado: 0 }, bancos: [], totalBancos: 0 } } });
  assert.match(h, /No hay cierre registrado al 31\/10\/2026/); assert.match(h, /data-fl-cierre-sug="2026-10-31"/);
  const s = src('app/finanzas-libro.js');
  assert.doesNotMatch(s, /setTimeout\([^)]*guardar_cierre_ciclo/, 'no cierra solo');
});

test('P4 Movimientos: editar conserva ancla, filtros y fila; P5 Más con relieve; navbar y categorías intactos', () => {
  const s = src('app/finanzas-libro.js');
  assert.match(s, /export function anclaMov\(id\)/); assert.match(s, /export function restaurarAncla\(a\)/);
  assert.match(s, /data-fl-row="/); assert.match(s, /fl-editando/);
  assert.match(s, /loadMovs\(ctx, \{ ?silent/);
  assert.ok(MAS_MODULES['baul-apks']?.svg && MAS_MODULES['sala-juntas']?.svg);
  assert.match(src('screens.js'), /mas-ico-svg/);
  assert.match(fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8'), /\.mas-ico\.mas-ico-svg/);
  assert.deepEqual(roleModules('sublicuentas', 'sublicuentas').tabs.length, roleModules('sublicuentas', 'sublicuentas').tabs.length);
});
