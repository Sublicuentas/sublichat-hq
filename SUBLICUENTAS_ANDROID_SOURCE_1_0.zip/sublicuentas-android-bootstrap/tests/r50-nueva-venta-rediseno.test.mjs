import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');

async function openCrm() {
  const app = await bootApp({ role: 'sublicuentas' });
  const bodies = [];
  const orig = app.w.fetch;
  app.w.fetch = async (url, init = {}) => {
    let b = {}; try { b = JSON.parse(init.body || '{}'); bodies.push(b); } catch (_) {}
    if ((b.accion || b.action) === 'asegurar_enlaces') { const data = { ok: true, linkPublico: '/c/tok123' }; return { ok: true, status: 200, text: async () => JSON.stringify(data), json: async () => data }; }
    return orig(url, init);
  };
  await app.click('[data-tab="clientes"]', 300);
  await app.click('[data-tab-jump="nuevo-crm"]', 400);
  const setVal = (sel, v, ev = 'input') => { const el = typeof sel === 'string' ? app.$(sel) : sel; el.value = v; el.dispatchEvent(new app.w.Event(ev, { bubbles: true })); };
  return { app, bodies, setVal };
}
const upserts = bodies => bodies.filter(b => (b.accion || b.action) === 'ficha_upsert');

test('R50 Nueva Venta: estructura igual a la referencia (5 tarjetas, ficha URL siempre visible, 6 variantes)', async () => {
  const { app } = await openCrm();
  try {
    assert.match(app.$('.crm2-title h1').textContent, /Nueva\s+Venta/);
    const titles = app.$$('.crm2-card-title b').map(b => b.textContent.trim());
    assert.deepEqual(titles, ['Datos del cliente', 'Servicio', 'Detalles de la compra', 'Perfiles incluidos', 'Guardar y entregar']);
    assert.ok(app.$('#crmLinkInput'), 'la ficha URL se ve aunque aún no se haya guardado');
    assert.equal(app.$$('[data-crm-url-variant]').length, 6);
    for (const id of ['#crmSearchClient', '#crmOpenCatalog', '#crmCopyLink', '#crmCopyUrlVariant', '#crmOpenUrlVariant', '#crmNewFicha', '#crmAddService', '#crmSubmit', '#crmCopyFicha', '#crmDeliverTraditional', '#crmDeliverUrl', '#crmAddProfile']) assert.ok(app.$(id), id);
    assert.equal(app.$('#crmSubmit').type, 'button', 'Guardar CRM ya no dispara dos guardados (click + submit)');
  } finally { app.close(); }
});

test('R50 Ver catálogo abre la lista con logos y al tocar cambia la plataforma y el precio', async () => {
  const { app, setVal } = await openCrm();
  try {
    setVal('#crmNombre', 'Darwin Villatoro');
    await app.click('#crmOpenCatalog', 250);
    assert.ok(app.$('#crmCatalogGrid'), 'se abre el catálogo');
    assert.equal(app.$('#crmNombre').value, 'Darwin Villatoro', 'abrir el catálogo no borra lo escrito');
    setVal('#crmCatalogQuery', 'disney');
    const visibles = app.$$('#crmCatalogGrid [data-crm-pick-platform]').filter(b => !b.hidden);
    assert.ok(visibles.length >= 1 && visibles.every(b => /disney/.test(b.dataset.q)));
    await app.click('[data-crm-pick-platform="disneyp"]', 250);
    assert.equal(app.$('#crmCatalogGrid'), null, 'se cierra al elegir');
    assert.equal(app.$('#crmPlataforma').value, 'disneyp');
    assert.equal(app.$('#crmNombre').value, 'Darwin Villatoro');
  } finally { app.close(); }
});

test('R50 Buscar cliente: hoja con resultados en vivo y precarga el cliente elegido', async () => {
  const { app, setVal } = await openCrm();
  try {
    await app.click('#crmSearchClient', 250);
    assert.ok(app.$('#crmClientQuery'));
    setVal('#crmClientQuery', 'ana');
    const hit = app.$('[data-crm-pick-client="c2"]');
    assert.ok(hit, 'aparece Ana Multi');
    await app.click(hit, 250);
    assert.equal(app.$('#crmClientQuery'), null);
    assert.equal(app.$('#crmNombre').value, 'Ana Multi');
    assert.equal(app.$('#crmTelefono').value, '99887766');
  } finally { app.close(); }
});

test('R50 Disney 2x1: dos perfiles en una sola compra se guardan juntos', async () => {
  const { app, bodies, setVal } = await openCrm();
  try {
    setVal('#crmNombre', 'Cliente 2x1'); setVal('#crmTelefono', '99990000');
    const plat = app.$('#crmPlataforma'); plat.value = 'disneyp'; plat.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(200);
    await app.click('#crmAddProfile', 250);
    const rows = app.$$('[data-crm-profile]');
    assert.equal(rows.length, 2);
    assert.match(app.$('.crm2-badge').textContent, /2 perfiles/);
    rows.forEach((row, i) => {
      setVal(row.querySelector('[data-p-name]'), i ? 'Hijo' : 'Papá');
      setVal(row.querySelector('[data-p-email]'), 'cuenta@disney.com');
      setVal(row.querySelector('[data-p-password]'), 'clave1');
      setVal(row.querySelector('[data-p-pin]'), i ? '2222' : '1111');
      setVal(row.querySelector('[data-p-device]'), i ? 'cel' : 'tv', 'change');
    });
    assert.equal(rows[0].querySelector('[data-p-roku]').closest('.crm-field').hidden, false, 'Roku solo se pregunta si es TV');
    assert.equal(rows[1].querySelector('[data-p-roku]').closest('.crm-field').hidden, true);
    await app.click('#crmSubmit', 500);
    const saved = upserts(bodies);
    assert.equal(saved.length, 1, 'un solo guardado');
    assert.match(JSON.stringify(saved[0]), /Papá[\s\S]*Hijo/);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R50 Ficha URL: Copiar / Abrir WhatsApp guardan primero si no hay enlace; cambiar de variante no borra lo escrito', async () => {
  const { app, bodies, setVal } = await openCrm();
  try {
    setVal('#crmNombre', 'Darwin Villatoro'); setVal('#crmTelefono', '98404016');
    const row = app.$('[data-crm-profile]');
    setVal(row.querySelector('[data-p-email]'), 'x@y.com'); setVal(row.querySelector('[data-p-password]'), 'casa33');
    setVal(row.querySelector('[data-p-pin]'), '1234'); setVal(row.querySelector('[data-p-device]'), 'tv', 'change');
    await app.click('[data-crm-url-variant="2"]', 200);
    assert.equal(app.$('#crmNombre').value, 'Darwin Villatoro');
    assert.ok(app.$('[data-crm-url-variant="2"]').classList.contains('active'));
    assert.match(app.$('#crmUrlVariantPreview').textContent, /Darwin Villatoro/);
    await app.click('#crmCopyLink', 700);
    assert.equal(upserts(bodies).length, 1, 'guardó una vez para generar el enlace');
    assert.match(app.$('#crmLinkInput').value, /^https:\/\//);
    await app.click('#crmOpenUrlVariant', 300);
    assert.equal(upserts(bodies).length, 1, 'con enlace ya no vuelve a guardar');
    assert.ok(app.$('#closeWhatsAppChooser') || app.$('.whatsapp-sheet'), 'abre selector de WhatsApp');
  } finally { app.close(); }
});

test('R50 estilos: tarjetas con color, botones de entrega verde/rojo y responsive para teléfono', () => {
  assert.match(css, /\.crm-form\.crm-v2 \.crm2-card\{--tone:#e5322d/);
  assert.match(css, /\.crm2-deliver \.wa-green\{background:#1faa4f/);
  assert.match(css, /\.crm2-deliver \.crm2-deliver-url\{background:#e3261d/);
  assert.match(css, /@media\(max-width:480px\)/);
  assert.match(main, /if\(state\.crmSaving\)return null;/);
  assert.match(main, /requestWhatsApp\(crmUrlMessage\(d,link\),d\.telefono\)/);
});

test('R50 Agregar otra cuenta guarda la actual y deja lista otra cuenta del mismo cliente; Ficha nueva limpia; Entregar ficha abre WhatsApp', async () => {
  const { app, bodies, setVal } = await openCrm();
  try {
    setVal('#crmNombre', 'Darwin Villatoro'); setVal('#crmTelefono', '98404016');
    const row = app.$('[data-crm-profile]');
    setVal(row.querySelector('[data-p-email]'), 'x@y.com'); setVal(row.querySelector('[data-p-password]'), 'casa33');
    setVal(row.querySelector('[data-p-pin]'), '1234'); setVal(row.querySelector('[data-p-device]'), 'tv', 'change');
    await app.click('#crmAddService', 700);
    assert.equal(upserts(bodies).length, 1);
    assert.equal(app.$('#crmNombre').value, 'Darwin Villatoro', 'mismo cliente');
    assert.equal(app.$('[data-crm-profile] [data-p-email]').value, '', 'cuenta nueva en blanco');
    await app.click('#crmNewFicha', 250);
    assert.equal(app.$('#crmNombre').value, '');
    setVal('#crmNombre', 'Otro'); setVal('#crmTelefono', '99991111');
    const r2 = app.$('[data-crm-profile]');
    setVal(r2.querySelector('[data-p-email]'), 'o@y.com'); setVal(r2.querySelector('[data-p-password]'), 'k');
    setVal(r2.querySelector('[data-p-pin]'), '1'); setVal(r2.querySelector('[data-p-device]'), 'cel', 'change');
    await app.click('#crmDeliverTraditional', 700);
    assert.equal(upserts(bodies).length, 2);
    assert.ok(app.$('#closeWhatsAppChooser') || app.$('.whatsapp-sheet'));
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
