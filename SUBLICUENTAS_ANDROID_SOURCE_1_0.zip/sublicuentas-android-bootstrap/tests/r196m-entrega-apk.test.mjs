// R196m · PDF «Correcciones Spotify y entrega APK», Fase 2: instrucciones cortas de UN dispositivo, «Copiar instrucciones»
// con el texto final (*negritas* de WhatsApp), «No configurado» bloquea la copia, logo o aviso visible. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import fs from 'node:fs';

const MSG_TV = '*Instalación en Android TV - Oleada TV*\n\n1. Abra *Downloader* en su televisor.\n2. Permita que Downloader instale aplicaciones si el sistema lo solicita.\n3. Introduzca el código *9387291* en la casilla principal.\n4. Presione *Go*.\n5. Cuando termine la descarga, pulse *Instalar* y luego *Abrir*.\n6. Ingrese los datos de acceso proporcionados.';
const BAUL = { ok: true, editor: false, version: 5, aviso: '',
  plataformas: [{ id: 'oleada', nombre: 'Oleada TV' }, { id: 'icomplay', nombre: 'Icomplay' }, { id: 'nuevaplat', nombre: 'Nueva Plat' }],
  vistas: [
    { plataforma: 'oleada', dispositivos: [
      { id: 'android_tv', nombre: 'Android TV / TV Box', enlaces: [{ id: 'oleada-atv', app: 'Oleada', dispositivo: 'android_tv', metodo: 'apk', codigo: '9387291', activo: true, mensaje: MSG_TV, faltante: '' }] },
      { id: 'android_movil', nombre: 'Celular / tableta Android', enlaces: [{ id: 'oleada-mov', app: 'Oleada', dispositivo: 'android_movil', metodo: 'apk', activo: true, mensaje: '', faltante: 'Enlace no configurado' }] }] },
    { plataforma: 'icomplay', dispositivos: [] }, { plataforma: 'nuevaplat', dispositivos: [] }],
  enlaces: [] };

test('R196m · Baúl APK: vista previa corta, Copiar instrucciones = texto final; No configurado bloquea; logos o aviso', async () => {
  const app = await bootApp({ role: 'geisell', fetchExtra: async (path, body) => (path === '/api/inventario' ? (body.accion === 'baulApks' ? BAUL : { ok: true, urls: {} }) : undefined) });
  try {
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="baul-apks"]', 400);
    await app.waitFor(() => app.$('[data-baul-plat="oleada"]'));
    assert.match(app.$('[data-baul-plat="icomplay"]').textContent, /^Icomplay/, 'nombre exacto «Icomplay»');
    assert.doesNotMatch(app.$('.baul-grid').textContent, /Icomplay Max/i);
    assert.ok(app.$('[data-baul-plat="icomplay"] img[src="/assets/plataformas/icomplay.webp"]'));
    assert.match(app.$('[data-baul-plat="nuevaplat"]').textContent, /Falta logo/, 'sin logo: aviso explícito, no recuadro vacío');
    await app.click('[data-baul-plat="oleada"]', 150);
    await app.click('[data-baul-disp="android_tv"]', 150);
    const prev = app.$('.baul-prev');
    assert.ok(prev, 'vista previa');
    assert.equal(prev.querySelectorAll('b').length >= 5, true, 'negritas visibles');
    assert.doesNotMatch(prev.textContent, /\*/, 'la vista previa no muestra asteriscos');
    assert.equal(app.$('[data-baul-copiar-msg="oleada-atv"]').textContent.trim(), 'Copiar instrucciones');
    let copiado = null;
    Object.defineProperty(app.w.navigator, 'clipboard', { value: { writeText: async (x) => { copiado = x; } }, configurable: true });
    await app.click('[data-baul-copiar-msg="oleada-atv"]', 120);
    assert.equal(copiado, MSG_TV, 'el portapapeles lleva el mensaje final con *negritas*, sin encabezados internos');
    await app.click('[data-baul-atras="disp"]', 150); await app.click('[data-baul-disp="android_movil"]', 150);
    assert.match(app.$('.baul-falta').textContent, /No configurado.*Enlace no configurado/s);
    assert.equal(app.$('[data-baul-copiar-msg="oleada-mov"]'), null, 'sin copiar instrucciones incompletas');
    assert.equal(app.$('[data-baul-enviar="oleada-mov"]'), null);
  } finally { app.close(); }
});

test('R196m · vista WhatsApp: escapa primero (sin HTML inyectado) y solo convierte *negrita*', () => {
  const s = fs.readFileSync(new URL('../src/app/baul-apks.js', import.meta.url), 'utf8');
  assert.match(s, /vistaWhatsApp = \(txt\) => esc\(txt\)\.replace\(/);
});
