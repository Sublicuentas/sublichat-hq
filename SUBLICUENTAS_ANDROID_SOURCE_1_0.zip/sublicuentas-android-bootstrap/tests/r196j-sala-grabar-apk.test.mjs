// R196j · V1.2 Fase 4: «Grabar» en la APK ya no es un botón muerto. Graba en el teléfono (igual que la web) y guarda el
// video por partes en Documentos/Sublichat. Datos ficticios; los plugins de Capacitor son simulados.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { guardarGrabacion } from '../src/app/sala-grabacion-apk.js';

const salaWeb = fs.readFileSync(new URL('../public/sala-juntas.js', import.meta.url), 'utf8');

test('R196j: la sala web ya no bloquea la grabación en la APK cuando la APK sabe guardar', () => {
  assert.doesNotMatch(salaWeb, /En la APK no se graba en el teléfono/);
  assert.match(salaWeb, /typeof CFG\.guardarGrabacion === 'function'/);
  assert.match(salaWeb, /await CFG\.guardarGrabacion\(r, base\)/);
  assert.doesNotMatch(salaWeb, /Falta configurar el bot en Vercel/);
  const grabar = fs.readFileSync(new URL('../public/sala-grabar.js', import.meta.url), 'utf8');
  assert.match(grabar, /ctx\.resume/, 'el audio suspendido ya no deja el video vacío');
  assert.match(salaWeb, /sala-grabar\.js\?v=20261111-r196j/);
  const apk = fs.readFileSync(new URL('../src/app/sala-juntas.js', import.meta.url), 'utf8');
  assert.match(apk, /guardarGrabacion: \(r, base\) => guardarGrabacion\(r, base\)/);
  assert.match(apk, /SALA_WEB_VERSION = '20261111-r196j'/);
});

test('R196j: guarda el video por partes, en Documentos/Sublichat, y abre Compartir', async () => {
  const bytes = new Uint8Array(7 * 1024 * 1024 + 5); for (let i = 0; i < bytes.length; i++) bytes[i] = i % 251;
  const blob = new Blob([bytes], { type: 'video/webm' });
  const ops = []; const archivo = [];
  const Filesystem = {
    writeFile: async (o) => { ops.push(['write', o.path, o.directory]); archivo.length = 0; archivo.push(o.data); },
    appendFile: async (o) => { ops.push(['append', o.path]); archivo.push(o.data); },
    getUri: async (o) => ({ uri: `file:///docs/${o.path}` }),
  };
  let compartido = null;
  const donde = await guardarGrabacion({ blob, extension: 'webm' }, 'Junta semanal 11-11-2026', {
    Capacitor: { isNativePlatform: () => true }, Filesystem, Directory: { Documents: 'DOCUMENTS', Data: 'DATA' },
    Share: { share: async (o) => { compartido = o; } } });
  assert.equal(donde, 'Documentos/Sublichat/Junta_semanal_11-11-2026.webm');
  assert.deepEqual(ops.map((o) => o[0]), ['write', 'append', 'append']);
  assert.equal(ops[0][2], 'DOCUMENTS');
  const unido = Buffer.concat(archivo.map((b) => Buffer.from(b, 'base64')));
  assert.equal(unido.length, bytes.length); assert.ok(unido.equals(Buffer.from(bytes)), 'el archivo armado por partes es idéntico');
  assert.deepEqual(compartido.files, ['file:///docs/Sublichat/Junta_semanal_11-11-2026.webm']);
});

test('R196j: si Documentos no deja escribir, queda en la carpeta de la app; vacía da error claro', async () => {
  const blob = new Blob([new Uint8Array(10)], { type: 'video/mp4' });
  const Filesystem = {
    writeFile: async (o) => { if (o.directory === 'DOCUMENTS') throw new Error('sin permiso'); },
    appendFile: async () => {}, getUri: async (o) => ({ uri: 'file:///app/' + o.path }) };
  const donde = await guardarGrabacion({ blob, extension: 'mp4' }, 'Reunión', { Capacitor: { isNativePlatform: () => true }, Filesystem, Directory: { Documents: 'DOCUMENTS', Data: 'DATA' }, Share: { share: async () => { throw new Error('cancelado'); } } });
  assert.match(donde, /carpeta de la app/);
  await assert.rejects(guardarGrabacion({ blob: new Blob([]), extension: 'webm' }, 'x', {}), /vacía/);
});
