// R196n · PDF «Correcciones puntuales» Fase 1: renovar varios servicios con UN solo importe (R-01 a R-03). Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';

async function abrirHoja(precios) {
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/renovar' || body.accion !== 'renovar_lote') return undefined;
    const lineas = (body.lineas || []).map((l, i) => ({ compraId: l.compraId, servicioIndex: l.servicioIndex ?? i, plataforma: l.plataforma, fechaAnterior: '04/11/2026', fechaNueva: '04/12/2026', periodos: 1, sigueVencida: false, monto: l.monto, precioRegistrado: precios[i] ?? null }));
    if (body.soloVista) return { ok: true, vista: true, lineas };
    return { ok: true, verified: true, accion: 'renovar_lote', lineas, total: body.pago?.recibido, pagoOperacion: { estado: 'pagado' } };
  } });
  await app.click('[data-tab="clientes"]', 400);
  await app.click(app.$('.cli-card .cli-dots'), 200);
  await app.click(app.$('[data-client-action="renew"]') || app.$('[data-client-action="charge"]'), 250);
  await app.click(app.$('[data-renew-days="30"]') || app.$$('[data-renew-days]')[0], 60);
  await app.click('#renewApply', 300);
  await app.waitFor(() => app.$('#rpCobrado'));
  return app;
}
const real = (app) => app.bodies.filter((b) => b?.accion === 'renovar_lote' && !b.soloVista);
const cambiar = async (app, sel, v) => { const i = app.$(sel); i.value = String(v); i.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(20); };

test('R-01/R-02 · un solo importe con el precio REGISTRADO de cada servicio; sin campos por plataforma; una sola operación', async () => {
  const app = await abrirHoja([150, 100, 90, 80, 70]);
  try {
    const n = app.$$('.rp-fila').length;
    assert.ok(n >= 1);
    assert.equal(app.$$('[data-rp-pagado]').length + app.$$('[data-rp-precio]').length, 0, 'no pide cuánto pagó por cada plataforma');
    const esperado = [150, 100, 90, 80, 70].slice(0, n).reduce((a, b) => a + b, 0);
    assert.equal(Number(app.$('#rpCobrado').value), esperado, 'precarga la suma');
    assert.match(app.$('.rp-total').textContent, new RegExp(`L${esperado}`));
    await app.click('[data-rp-banco]', 30); await app.click('#rpConfirm', 0);
    await app.waitFor(() => real(app).length);
    const b = real(app)[0];
    assert.deepEqual(b.lineas.map((l) => l.monto), [150, 100, 90, 80, 70].slice(0, n), 'Finanzas recibe L150 + L100 … (desglose interno)');
    assert.deepEqual([b.pago.montoTotal, b.pago.recibido, b.pago.ajuste], [esperado, esperado, undefined]);
    assert.equal(real(app).length, 1, 'una sola transacción');
    assert.equal(app.bodies.filter((x) => x?.accion === 'registrar_operacion_pago').length, 0);
  } finally { app.close(); }
});

test('R-03 · cobra menos: obliga a elegir Descuento / Cortesía / Otro ajuste / Queda pendiente; el ajuste viaja con su motivo', async () => {
  const app = await abrirHoja([150, 100, 90, 80, 70]);
  try {
    const n = app.$$('.rp-fila').length; const esp = [150, 100, 90, 80, 70].slice(0, n).reduce((a, b) => a + b, 0);
    await cambiar(app, '#rpCobrado', esp - 30);
    assert.equal(app.$$('[data-rp-dif]').length, 4);
    await app.click('[data-rp-banco]', 30); await app.click('#rpConfirm', 30);
    assert.match(app.$('#rpError').textContent, /por qué cobra menos/i);
    await app.click('[data-rp-dif="otro"]', 30); await app.click('[data-rp-banco]', 30); await app.click('#rpConfirm', 30);
    assert.match(app.$('#rpError').textContent, /motivo/);
    await app.click('[data-rp-dif="descuento"]', 30);
    const m = app.$('#rpAjMotivo'); m.value = 'Cliente frecuente'; m.dispatchEvent(new app.w.Event('input', { bubbles: true }));
    await app.click('[data-rp-banco]', 30); await app.click('#rpConfirm', 0);
    await app.waitFor(() => real(app).length);
    const b = real(app)[0];
    assert.deepEqual([b.pago.montoTotal, b.pago.recibido], [esp, esp - 30]);
    assert.deepEqual(b.pago.ajuste, { tipo: 'descuento', motivo: 'Cliente frecuente' });
  } finally { app.close(); }
});

test('R-03 · cortesía completa (L0) no se registra como venta: pide «Ajuste sin pago»; precio faltante se escribe solo en ese servicio', async () => {
  const app = await abrirHoja([null, 100, 90, 80, 70]);
  try {
    assert.equal(app.$$('[data-rp-precio]').length, 1, 'solo el servicio sin precio registrado pide su precio');
    await app.click('[data-rp-banco]', 30); await app.click('#rpConfirm', 30);
    assert.match(app.$('#rpError').textContent, /Escriba el precio/);
    await cambiar(app, '[data-rp-precio]', 150);
    await cambiar(app, '#rpCobrado', 0);
    await app.click('[data-rp-dif="cortesia"]', 30); await app.click('#rpConfirm', 30);
    assert.match(app.$('#rpError').textContent, /Ajuste sin pago/);
    assert.equal(real(app).length, 0, 'no se mandó nada');
  } finally { app.close(); }
});
