// R155 · Oct-2026 · Al cambiar correo/clave/PIN o renovar en la APK, la ficha de la cuenta sale con los datos nuevos
// (antes se mostraba la ficha guardada el día de la entrega, con el correo viejo). Crunchyroll sin "solo Honduras".
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { buildTraditionalFicha } from '../src/operations.js';

import { crmFichaVigente, fichaAlDia } from '../src/app/ficha-al-dia.js';
const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

const vieja = '*📧 Correo: viejo@imitatiko.lat*\n*🔑 Clave: sublia1*\n*📅 Renovación: 28/10/2026*';
const draft = (x = {}) => ({ fechaRenovacion: '28/10/2026', fichaTexto: vieja, perfiles: [{ correo: 'viejo@imitatiko.lat', clave: 'sublia1', pinPerfil: '' }], ...x });

test('ficha guardada con los mismos datos: se respeta (incluye textos editados a mano)', () => {
  assert.equal(crmFichaVigente(draft()), true);
});
test('cambió el correo, la clave, el PIN o la fecha: la ficha vieja se descarta', () => {
  assert.equal(crmFichaVigente(draft({ perfiles: [{ correo: 'nuevo@imitatiko.lat', clave: 'sublia1' }] })), false);
  assert.equal(crmFichaVigente(draft({ perfiles: [{ correo: 'viejo@imitatiko.lat', clave: 'subli44' }] })), false);
  assert.equal(crmFichaVigente(draft({ perfiles: [{ correo: 'viejo@imitatiko.lat', clave: 'sublia1', pinPerfil: '2810' }] })), false);
  assert.equal(crmFichaVigente(draft({ fechaRenovacion: '28/11/2026' })), false);
  assert.equal(crmFichaVigente(draft({ fichaTexto: '' })), false);
});
test('cableado: abrir la cuenta, ver ficha, copiar y entregar usan la ficha al día', () => {
  assert.equal(fichaAlDia(draft({ perfiles: [{ correo: 'nuevo@imitatiko.lat', clave: 'sublia1' }] })).fichaTexto, '');
  assert.equal(fichaAlDia(draft()).fichaTexto, vieja);
  assert.match(main, /function crmDraftFromRow\(row\) \{ return fichaAlDia\(crmDraftFromRowBase\(row\)\); \}/);
  assert.match(main, /  return fichaAlDia\(d\); \/\/ R155\n\}/);
  assert.match(main, /if\(previewEl\.dataset\.auto!=='1'&&d\.fichaTexto\)return;previewEl\.dataset\.auto='1';previewEl\.value=crmFichaFromDraft\(d\);/);
});
test('Crunchyroll: condiciones de perfil R200f (1 dispositivo, perfil, Honduras, garantía)', () => {
  const t = buildTraditionalFicha({ plataforma: 'crunchyroll', nombrePerfil: 'Carlos Cruz', perfiles: [{ nombre: 'Carlos Cruz', correo: 'a@b.com', clave: 'x1', pinPerfil: '2810' }], fechaRenovacion: '28/11/2026', vendedor: 'Relojes' });
  // R200f (22/11/2026): el dueño pidió las mismas 4 condiciones para Crunchyroll, incluida Honduras.
  assert.match(t, /📌 Cuenta solo para 1 dispositivo, no se permite acceder en otro\.\n📌 No se modifica perfil\.\n📌 Conexión válida en Honduras\.\n📌 Garantía vigente al cumplir indicaciones\./);
  assert.match(t, /a@b\.com/);
});
