import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = appSource();
const data = fs.readFileSync(new URL('../src/academia-data.js', import.meta.url), 'utf8');

test('R30 academia-data.js exports the full 60-lesson course catalog', () => {
  assert.match(data, /export const COURSES = \[/);
  const m = data.match(/"title":"([^"]+)"/g) || [];
  assert.ok(m.length >= 60, `expected at least 60 lesson titles, found ${m.length}`);
});

test('R30 Aula de clases is wired to the shared Firestore progress endpoint', () => {
  assert.match(main, /loadAcademiaProgress/);
  assert.match(main, /completeAcademiaLesson/);
  assert.match(main, /function ensureAcademia/);
  assert.match(main, /function academiaListView/);
  assert.match(main, /function academiaLessonView/);
});

test('R30 api.js calls the shared /api/academia endpoint (same collection as the web Academia)', () => {
  const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
  assert.match(api, /'\/api\/academia'.*accion:\s*'obtener'/);
  assert.match(api, /'\/api\/academia'.*accion:\s*'completar'/);
});

test('R47 Materia cerebral ahora abre Juegos PRO (ya no es un simple aviso de "módulo conservado"); Objetivos sigue como estaba', () => {
  assert.match(main, /if \(state\.subview==='objetivos'\) return preservedModuleView\(state\.subview\);/);
  assert.match(main, /if \(state\.subview==='materia'\) return juegosView\(\);/);
  assert.doesNotMatch(main, /state\.subview==='aula' \|\| state\.subview==='materia'/);
  assert.match(main, /state\.subview==='aula'\) return state\.academiaLesson!=null \? academiaLessonView/);
});

test('R30 opening Tickets, Perfil or Clientes from anywhere routes directly (no false "Más" tab)', () => {
  assert.match(main, /directRoutes=\['tickets','perfil','clientes'\]/);
  assert.match(main, /if\(directRoutes\.includes\(id\)\)\{state\.active=id;state\.subview=null/);
});

test('R30 back button inside a lesson returns to the lesson list, not out of Aula', () => {
  assert.match(main, /state\.subview==='aula'&&state\.academiaLesson!=null\)\{state\.academiaLesson=null;render\(\);return;\}/);
});
