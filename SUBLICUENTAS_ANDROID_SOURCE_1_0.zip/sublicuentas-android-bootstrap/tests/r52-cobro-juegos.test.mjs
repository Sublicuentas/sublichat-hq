import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { bootApp } from './helpers/ui-harness.mjs';
import { buildChargeMessage, CHARGE_MESSAGE_VARIETY, randomChargeVariant, splitChargeAiLines, normalizeChargeAiMessage } from '../src/operations.js';
import { leaderboardHtml, playerAccessName } from '../src/juegos.js';

const dom = html => new JSDOM(`<body>${html}</body>`).window.document;
const fakeJson = data => ({ ok: true, status: 200, text: async () => JSON.stringify(data), json: async () => data });

async function openRenewal({ chatReply = null } = {}) {
  const app = await bootApp({ role: 'sublicuentas' });
  const bodies = [];
  const orig = app.w.fetch;
  app.w.fetch = async (url, init = {}) => {
    let b = {}; try { b = JSON.parse(init.body || '{}'); bodies.push({ url: String(url), ...b }); } catch (_) {}
    if (String(url).includes('/api/chat') && chatReply !== null) return fakeJson(chatReply);
    return orig(url, init);
  };
  await app.click('[data-tab="clientes"]', 400);
  const card = app.$$('.cli-card').find(c => c.textContent.includes('Ana Multi')) || app.$('.cli-card');
  await app.click(card.querySelector('.cli-dots'), 200);
  await app.click(app.$('[data-client-action="renew"]') || app.$('[data-client-action="charge"]'), 250);
  return { app, bodies };
}

test('R52 mensajes de cobro: 36 mil combinaciones, seguidas nunca se parecen y cada cliente arranca al azar', () => {
  assert.ok(CHARGE_MESSAGE_VARIETY > 30000);
  const g = { nombre: 'Carolina Roque', total: 130, fechaRenovacion: '22/09/2026', servicios: [{ plataforma: 'vipnetflix', precio: 130 }] };
  const a = buildChargeMessage(g, 10).split('\n'), b = buildChargeMessage(g, 11).split('\n');
  assert.notEqual(a[0], b[0], 'la apertura cambia');
  assert.notEqual(a[1].slice(0, 6), b[1].slice(0, 6), 'el cuerpo también cambia');
  assert.match(buildChargeMessage(g, 0), /\*Netflix Premium VIP\*/, 'nombre bonito, no "vipnetflix"');
  assert.doesNotMatch(buildChargeMessage(g, 0), /vipnetflix/);
  const starts = new Set(Array.from({ length: 30 }, () => randomChargeVariant()));
  assert.ok(starts.size > 25, 'arranques distintos');
});

test('R52 IA: respuesta en una sola línea o con 3 líneas ya no se descarta', () => {
  const g = { nombre: 'Amy', servicios: [{ plataforma: 'netflix' }], total: 130 };
  const one = normalizeChargeAiMessage(splitChargeAiLines('🎬 Hola Amy, su Netflix está por renovarse. ¿Renovamos por Lps 130? ✅'), g);
  assert.equal(one.split('\n').length, 2);
  const three = normalizeChargeAiMessage('🎬 Hola Amy\nsu Netflix vence hoy\n¿Renovamos? ✅', g);
  assert.equal(three.split('\n').length, 2);
});

test('R52 Cobro y Renovación: diseño nuevo y todos los botones hacen lo suyo', async () => {
  const { app, bodies } = await openRenewal();
  try {
    assert.match(app.$('.rn-top h2').textContent, /Cobro y Renovación/);
    assert.ok(app.$('.rn-cal b') && app.$('.rn-client-txt h3'));
    const first = app.$('#renewChargeText').value;
    await app.click('#renewAnotherStyle', 150);
    assert.notEqual(app.$('#renewChargeText').value, first, 'Otro estilo cambia el mensaje');
    await app.click('#renewAiMessage', 400); // el servidor de prueba no responde texto → se aplica otro estilo y se avisa el motivo
    assert.match(app.w.document.body.textContent, /IA no disponible/);
    await app.click('#renewMenuBtn', 120);
    assert.ok(app.$('#renewOpenCrm') && app.$('#toggleRenewManage') && app.$('#renewEditService'));
    await app.click('#toggleRenewManage', 150);
    assert.ok(app.$('.rn-manage'));
    await app.click('[data-renew-months="2"]', 120);
    assert.ok(app.$('[data-renew-months="2"]').classList.contains('on'), 'el preset queda marcado, no renueva solo');
    assert.equal(bodies.filter(b => b.accion === 'renovar').length, 0);
    assert.match(app.$('.rn-preview').textContent, /\+2 meses/);
    await app.click('[data-renew-days="30"]', 120);
    await app.click('#renewApply', 400);
    assert.ok(bodies.some(b => b.accion === 'renovar' && Number(b.dias) === 30), 'Renovar a fecha elegida usa la opción marcada');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R52 IA responde: se usa su mensaje; "No renovó" da de baja lo seleccionado; Cerrar cierra', async () => {
  const { app, bodies } = await openRenewal({ chatReply: { respuesta: '🎬 Hola Ana, su servicio sigue listo. ¿Renovamos por Lps 100? ✅' } });
  try {
    await app.click('#renewAiMessage', 300);
    assert.match(app.$('#renewChargeText').value, /Renovamos por/);
    assert.match(app.w.document.body.textContent, /Mensaje IA actualizado/);
    await app.click('#renewNoRenewAll', 500);
    assert.ok(bodies.some(b => /no_renov|baja|eliminar_servicio/i.test(String(b.accion || b.action || ''))), 'pidió la baja');
    assert.equal(app.$('.rn-sheet'), null);
  } finally { app.close(); }
  const { app: app2 } = await openRenewal();
  try { await app2.click('#cancelRenew', 150); assert.equal(app2.$('.rn-sheet'), null); } finally { app2.close(); }
});

test('R52 Juegos: el jugador se muestra con el nombre del acceso (nunca Naara) y Jugar abre el juego', async () => {
  assert.equal(playerAccessName('naara', 'Naara'), 'Sublicuentas');
  assert.equal(playerAccessName('uid123', 'Daniela'), 'Relojes');
  assert.equal(playerAccessName('uid9', 'Geissel'), 'Geisell');
  const data = { entries: [{ userId: 'naara', displayName: 'Naara', score: 714, streak: 1, badge: 'Explorador' }, { userId: 'libni', displayName: 'Libni', score: 300, streak: 2, badge: 'Explorador' }] };
  const d = dom(leaderboardHtml({ scope: 'general', data, me: 'naara', meLabel: 'Sublicuentas', myTotals: { totalPoints: 714, byGame: { HANGMAN: 714 }, streak: { current: 1 }, badge: { code: 'EXPLORADOR', name: 'Explorador' } } }));
  const names = [...d.querySelectorAll('.jg2-name')].map(t => t.textContent);
  assert.deepEqual(names, ['Sublicuentas', 'Relojes']);
  assert.doesNotMatch(d.body.textContent, /Naara|Libni/);
  assert.match(d.querySelector('tr.me').textContent, /Sublicuentas/);
  assert.match(d.querySelector('.jg2-mecard').textContent, /#1/);
  assert.equal(d.querySelectorAll('.jg2-play[data-jg-play]').length, 6);
  assert.ok(d.querySelector('.jg2-game.hot [data-jg-play="HANGMAN"]'), 'el juego con más puntos se destaca');

  const app = await bootApp({ role: 'relojes' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    assert.ok(app.$('.jg2-page'), 'R53: entra directo al tablero Juegos');
    await app.click('[data-jg-scope="porJuego"]', 300);
    assert.ok(app.$('[data-jg-rankgame]'), 'Por juego permite elegir el juego');
    await app.click('[data-jg-rankgame="HANGMAN"]', 300);
    assert.ok(app.$('[data-jg-rankgame="HANGMAN"]').classList.contains('on'));
    await app.click('[data-jg-scope="general"]', 300);
    if (app.$('#jgGoHub')) { await app.click('#jgGoHub', 200); assert.ok(app.$('.jg-grid')); await app.click('#jgOpenRanking', 300); }
    const play = app.$('[data-jg-play="MEMORY_PAIRS"]');
    if (play) { await app.click(play, 250); assert.ok(app.$('[data-mc-card]'), 'R64: Jugar abre Memoria'); }
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('R53 Juegos: solo aparecen Sublicuentas, Relojes y Geisell (ningún otro nombre)', () => {
  const data = { entries: [{ userId: 'naara', displayName: 'Naara', score: 714 }, { userId: 'x1', displayName: 'Luna', score: 900 }, { userId: 'geissel', displayName: 'Geissel', score: 50 }, { userId: 'daniela', displayName: 'Daniela', score: 10 }] };
  const d = dom(leaderboardHtml({ scope: 'general', data, me: 'naara', meLabel: 'Sublicuentas' }));
  assert.deepEqual([...d.querySelectorAll('.jg2-name')].map(t => t.textContent), ['Sublicuentas', 'Geisell', 'Relojes']);
  assert.doesNotMatch(d.body.textContent, /Luna|Naara|Daniela|Geissel\b/);
  assert.equal(d.querySelectorAll('.jg2-play[data-jg-play]').length, 6, 'los botones Jugar salen aunque aún no carguen los puntos');
});

test('R53 Tema: arranca en Claro aunque antes estuviera en "sistema"; Oscuro se respeta', async () => {
  const main = (await import('node:fs')).readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /localStorage\.setItem\('sublicuentas-theme', prev==='dark'\?'dark':'light'\)/);
  assert.match(main, /<option value="light">Claro<\/option><option value="dark">Oscuro<\/option><option value="system">Predeterminado del sistema<\/option>/);
  const app = await bootApp({ role: 'sublicuentas' });
  try { assert.equal(app.w.document.documentElement.dataset.theme, 'light'); assert.ok(!app.w.document.documentElement.classList.contains('theme-dark')); } finally { app.close(); }
});
