import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { renewPaySheetHtml, operacionPagoBody, pagoSocioTexto } from '../src/app/finanzas-libro.js';
import { sellerPhone, sellerPhoneFor } from '../src/operations.js';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const libro = readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
const pagos = [{ movimientoId: 'socio_compra_ped1_cobro', socio: 'Jimena', clienteNombre: 'Jhoseline Navas', monto: 110, banco: 'BAC Credomatic', fecha: '2026-10-05', productos: [{ idx: 0, servicio: 'Netflix Vip', perfil: 'Jhoseline Navas', restantes: 1 }] }];
const hoja = (extra = {}) => ({ tipo: 'compra', cliente: 'Jhoseline Navas', label: 'Netflix · nueva compra', rows: [{ key: 'compra', label: 'Netflix' }], montos: {}, bancoId: '', responsable: 'cliente', modo: 'pago', ...extra });

test('R121: la hoja de pago de una COMPRA ofrece "Ya pagó por Socios"; la de renovación no', () => {
  assert.match(renewPaySheetHtml(hoja(), []), /data-rp-modo="socio">🤝 Ya pagó por Socios/);
  assert.doesNotMatch(renewPaySheetHtml(hoja({ tipo: 'renovacion' }), []), /Ya pagó por Socios/);
});

test('R121: modo Socios lista las compras de socios sin ficha, sin montos, bancos ni fecha que llenar', () => {
  const html = renewPaySheetHtml(hoja({ modo: 'socio', socios: pagos, socioSel: 'socio_compra_ped1_cobro|0' }), [{ id: 'bac', nombre: 'BAC' }]);
  assert.match(html, /data-rp-socio="socio_compra_ped1_cobro\|0"/);
  assert.match(html, /Jimena · Netflix Vip · Jhoseline Navas · .*110.* · BAC Credomatic · 05\/10/);
  assert.match(html, /no se registra otro ingreso/);
  assert.match(html, /Guardar ficha sin otro ingreso/);
  assert.match(html, /data-rp-socio-lista="socio_compra_ped1_cobro"/);
  assert.doesNotMatch(html, /data-rp-pagado|data-rp-banco|rpFechaOtra/);
  assert.match(renewPaySheetHtml(hoja({ modo: 'socio' }), []), /Buscando compras de socios/);
  assert.match(renewPaySheetHtml(hoja({ modo: 'socio', socios: [] }), []), /No hay compras de socios pendientes de ficha/);
  assert.match(renewPaySheetHtml(hoja({ modo: 'socio', socios: [], sociosError: '⚠️ Sin conexión' }), []), /Sin conexión[\s\S]*Reintentar/);
  assert.equal(pagoSocioTexto(pagos[0], pagos[0].productos[0]).startsWith('Jimena · Netflix Vip · Jhoseline Navas'), true);
});

test('R121: el pago viaja con la ficha como pagoSocio (sin monto ni banco: no hay ingreso nuevo)', () => {
  const body = operacionPagoBody(hoja({ modo: 'socio', pagoSocio: { movimientoId: 'socio_compra_ped1_cobro', productoIdx: 0 } }), 'compra', {});
  assert.deepEqual(body, { pagoSocio: { movimientoId: 'socio_compra_ped1_cobro', productoIdx: 0 }, origen: 'apk' });
  const normal = operacionPagoBody(hoja({ montos: { compra: { pagado: '110' } }, bancoId: 'bac' }), 'compra', {});
  assert.equal(normal.recibido, 110); assert.equal(normal.pagoSocio, undefined);
  assert.match(libro, /accion: 'listar_pagos_socios_sin_ficha'/);
  assert.match(libro, /accion: 'socio_ficha_lista'/);
  assert.match(libro, /Elija cuál compra de socio corresponde a esta ficha\./);
  assert.match(main, /if\(state\.crmPago\.modo==='socio'\)return/);
  assert.match(main, /const pagoAtomico=state\.crmPago\?\{\.\.\.operacionPagoBody\(state\.crmPago,'compra',\{\}\),operationId:state\.crmPago\.opId\}:null;/, 'sigue viajando en la MISMA petición que la ficha');
});

test('R121: al elegir vendedor sale su número y queda a la vista; nunca hereda el de otro vendedor', () => {
  assert.equal(sellerPhoneFor('Jimena', ''), sellerPhone('Jimena'));
  assert.equal(sellerPhoneFor('Jimena', '99999999'), '88501036', 'vendedor con número: siempre el suyo');
  assert.equal(sellerPhoneFor('Geisell', '32126332'), '', 'sin número propio: no se queda con el de Relojes');
  assert.equal(sellerPhoneFor('Geisell', '+504 3212-6332'), '', 'aunque venga en otro formato');
  assert.equal(sellerPhoneFor('Geisell', '9988-7766'), '9988-7766', 'un número escrito a mano se conserva');
  assert.match(main, /if\(tel\)tel\.value=sellerPhoneFor\(v,tel\.value\);if\(telBox\)telBox\.hidden=false;/);
  assert.match(main, /const showSellerPhone=true;/);
});

test('R121: la ficha URL abre WhatsApp directo en el número del cliente; la tradicional va al grupo (sin número)', () => {
  assert.match(main, /#clientOpenUrlWhatsApp'\)\?\.addEventListener\('click',\(\)=>\{const row=findRowByKey\(state\.clientActionKey\);requestWhatsApp\(String\(document\.querySelector\('#clientUrlMessage'\)\?\.value\|\|''\),String\(clientById\(row\?\.clienteId\)\?\.telefono\|\|row\?\.telefono\|\|''\)\);\}\);/);
  assert.match(main, /if\(delivery==='url'\)\{[\s\S]{0,160}requestWhatsApp\(crmUrlMessage\(d,link\),d\.telefono\);return result;\}/);
  assert.match(main, /#crmOpenUrlVariant'\)[\s\S]{0,160}requestWhatsApp\(crmUrlMessage\(d,link\),d\.telefono\)/);
  assert.match(main, /if\(delivery==='tradicional'\)\{requestWhatsApp\(d\.fichaTexto\|\|crmFichaFromDraft\(d\)\);return result;\}/);
  assert.ok(main.split('\n').length < 2000);
});
