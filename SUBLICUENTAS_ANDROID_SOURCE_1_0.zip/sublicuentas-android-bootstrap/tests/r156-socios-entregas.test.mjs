// Oct-2026 · APK "Pedidos de socios": entregas por servicio igual que la web, y la ficha amarrada al pago del socio
// ("Ya pagó por Socios") llega sugerida. Datos ficticios; respuestas del puente /api/revendedores-admin simuladas.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { roleModules } from '../src/data.js';

function puenteFalso() {
  const st = { guardados: [], vistas: 0, entrega: null };
  const compra = { id: 'web_juan2026A1', socio: 'Jimena', socio_norm: 'jimena', estado: 'pendiente', clientePrincipal: { nombre: 'Juan', apellido: 'Pérez' }, productos: [{ renglonId: 'r1', servicio: 'Netflix · 1 perfil' }, { renglonId: 'r2', servicio: 'Prime Video' }], monto: 190, banco: 'BAC', entregaResumen: { estado: 'pendiente', publicados: 0, requeridos: 2 } };
  const detalle = () => ({ ok: true, compraId: compra.id, ref: '2026A1', socio: 'jimena', socioVerificado: true, telegram: 'vinculado', estadoPedido: 'pendiente', cliente: 'Juan Pérez', pago: { monto: 190, banco: 'BAC', comprobante: true, revision: null },
    resumen: st.entrega ? { estado: 'parcial', texto: 'Entrega parcial · 1 de 2 servicios' } : { estado: 'pendiente', texto: 'Pendiente de entrega' },
    renglones: [
      { renglonId: 'r1', servicio: 'Netflix · 1 perfil', clienteNombre: 'Juan Pérez', datos: { dispositivo: '📺 TV' }, fichaPagada: null, entrega: null },
      { renglonId: 'r2', servicio: 'Prime Video', clienteNombre: 'Juan Pérez', datos: {}, fichaPagada: { clienteId: 'cli_apk', servicioCompraId: 'svc_pv', clienteNombre: 'Juan Pérez', plataforma: 'Prime Video' }, entrega: st.entrega },
    ] });
  const fetchExtra = async (path, b) => {
    if (path !== '/api/revendedores-admin') return undefined;
    assert.equal(b.apk, true);
    if (b.ruta === 'compras') return [compra];
    if (b.ruta === 'entregas') return detalle();
    if (b.ruta === 'entregas/vista-previa') { st.vistas++; return { ok: true, socio: { nombre: 'Jimena', telegram: 'vinculado' }, verSocio: { pedido: '#2026A1', cliente: 'Juan Pérez', servicio: 'Prime Video', vence: '30/11/2026', portal: 'Botón “Abrir portal del cliente”', codigo: 'Sin código' }, telegram: '✅ <b>Pedido #2026A1 disponible.</b>' }; }
    if (b.ruta === 'entregas/guardar') { st.guardados.push(b); st.entrega = { id: 'ent_web_juan2026A1_r2', estado: 'publicada', version: 1, fichaResumen: { cliente: 'Juan Pérez', plataforma: 'Prime Video' }, avisos: [{ version: 1, estado: 'pendiente' }], publicadaAt: Date.now() }; return { ok: true, id: 'ent_web_juan2026A1_r2', version: 1, aviso: 'pendiente' }; }
    return { ok: false, error: 'no_simulado' };
  };
  return { st, fetchExtra };
}

test('Pedidos de socios: solo Sublicuentas lo ve en Más', () => {
  assert.ok(roleModules('sublicuentas', 'sublicuentas').more.includes('socios-entregas'));
  assert.ok(!roleModules('relojes', 'libni').more.includes('socios-entregas'));
  assert.ok(!roleModules('geisell_admin', 'geisell').more.includes('socios-entregas'));
});

test('APK: abrir pedido → la ficha amarrada al pago del socio viene sugerida → revisar → publicar (un solo envío con opId)', async () => {
  const { st, fetchExtra } = puenteFalso();
  const app = await bootApp({ role: 'sublicuentas', fetchExtra });
  try {
    await app.sleep(400);
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="socios-entregas"]', 400);
    await app.waitFor(() => app.$('[data-se-abrir]'));
    assert.match(app.$('.se-item').textContent, /#2026A1 · Juan Pérez/);
    assert.match(app.$('.se-item').textContent, /Por entregar/);
    await app.click('[data-se-abrir]', 400);
    await app.waitFor(() => app.$('[data-se-rid="r2"]'));
    assert.match(app.$('[data-se-rid="r2"]').textContent, /Ficha amarrada al pago del socio: Juan Pérez · Prime Video/);
    await app.click('[data-se-rid="r2"] [data-se-form]', 300);
    assert.match(app.$('[data-se-rid="r2"] .se-sel').textContent, /Amarrada al pago del socio/);
    assert.equal(app.$('[data-se-rid="r2"] [data-se-f="portalAutorizado"]').checked, true);
    assert.equal(app.$('[data-se-rid="r2"] [data-se-guardar="publicar"]').disabled, true, 'publicar exige revisar');
    await app.click('[data-se-rid="r2"] [data-se-revisar]', 400);
    await app.waitFor(() => app.$('[data-se-rid="r2"] .se-preview'));
    assert.match(app.$('[data-se-rid="r2"] .se-preview').textContent, /Pedido #2026A1 disponible/);
    const pub = app.$('[data-se-rid="r2"] [data-se-guardar="publicar"]'); pub.click(); pub.click();
    await app.waitFor(() => /Publicada v1/.test(app.$('[data-se-rid="r2"]')?.textContent || ''));
    assert.equal(st.guardados.length, 1, 'doble toque = un envío');
    assert.deepEqual(st.guardados[0].datos.ficha, { clienteId: 'cli_apk', servicioCompraId: 'svc_pv' });
    assert.ok(st.guardados[0].datos.opId);
    assert.match(app.$('.se-card').textContent, /Entrega parcial · 1 de 2/);
    assert.deepEqual(app.logs.filter((l) => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Cableado: CRM "Ya pagó por Socios" ofrece publicar la entrega de ese servicio; main.js < 2000 líneas', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /if\(pagoAtomico\?\.pagoSocio&&result\?\.pagoOperacion\?\.pagoSocio\)setTimeout\(\(\)=>sociosOfrecerEntrega\(pagoAtomico\.pagoSocio\)/);
  assert.match(main, /resetSociosEntregas\(\)/, 'al cerrar sesión no queda nada del módulo');
  assert.ok(main.split('\n').length < 2000);
  const mod = fs.readFileSync(new URL('../src/app/socios-entregas.js', import.meta.url), 'utf8');
  assert.match(mod, /replace\(\/\^socio_compra_\/, ''\)\.replace\(\/_cobro\$\/, ''\)/, 'movimiento del pago → pedido');
  assert.doesNotMatch(mod, /localStorage/, 'nada de entregas ni códigos en el teléfono');
});
