import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validatePlanilla, bankBalances, cycleTotals, publicMethods } from '../src/app/finanzas-reglas.js';
import { libroViewHtml, renewPaySheetHtml, newDraft, isLibroUser, inicioSugerido } from '../src/app/finanzas-libro.js';

const methods = publicMethods([{ id: 'bac', nombre: 'BAC', logoKey: 'bac' }, { id: 'ficohsa', nombre: 'Ficohsa', logoKey: 'ficohsa' }, { id: 'atl', nombre: 'Atlántida', logoKey: 'atlantida' }, { id: 'tigo', nombre: 'Tigo Money', logoKey: 'tigo' }]);
const libro = { bases: { bac: { saldo: 4000, desde: '2026-10-01' }, ficohsa: { saldo: 1000, desde: '2026-10-01' }, atl: { saldo: 600, desde: '2026-10-01' }, tigo: { saldo: 400, desde: '2026-10-01' } } };
const bal = bankBalances([], libro, methods);

test('solo Sublicuentas y Relojes usan Finanzas nueva', () => {
  assert.equal(isLibroUser('sublicuentas'), true); assert.equal(isLibroUser('relojes'), true);
  assert.equal(isLibroUser('geisell'), false); assert.equal(isLibroUser('limited'), false);
});

test('reglas (copia del servidor): casos B, D, E y ciclo 5 del PDF', () => {
  const b = validatePlanilla({ montoTotal: 2000, asignaciones: [{ bancoId: 'bac', monto: 1000 }, { bancoId: 'ficohsa', monto: 1000 }], bancos: bal.bancos });
  assert.equal(b.ok, true); assert.deepEqual(b.asignaciones.map(a => a.saldoDespues), [3000, 0]);
  assert.match(validatePlanilla({ montoTotal: 2000, asignaciones: [{ bancoId: 'bac', monto: 1700 }], bancos: bal.bancos }).errors.join(' '), /Faltan Lps\. 300/);
  assert.match(validatePlanilla({ montoTotal: 700, asignaciones: [{ bancoId: 'atl', monto: 700 }], bancos: bal.bancos }).errors.join(' '), /Saldo insuficiente en Atlántida/);
  const t = cycleTotals([{ tipo: 'ingreso', monto: 20000, fechaPago: '2026-10-02' }, { tipo: 'egreso', monto: 12000, fechaPago: '2026-10-03' }, { tipo: 'egreso', subtipo: 'pago_planilla', monto: 5500, fechaPago: '2026-10-09' }], '2026-10-01', '2026-10-10');
  assert.equal(t.disponibleAntesPlanilla, 8000); assert.equal(t.resultado, 2500);
});

function stateWith(tab, extra = {}) {
  return { libro: { tab, loading: false, error: '', movs: null, movFiltro: { tipo: '', bancoId: '', texto: '', desde: '', hasta: '' }, draft: null, ajuste: null, sending: false,
    data: { ok: true, hoy: '2026-10-04', metodos: methods, ciclo: { id: 'ciclo_2026-10-01', inicio: '2026-10-01', dias: 4, diasDesdeUltimoCierre: null }, totales: { ingresos: 7000, egresosOperativos: 1000, disponibleAntesPlanilla: 6000, planilla: 0, resultado: 6000 }, bancos: bal.bancos, totalBancos: 6000, planillaPagos: [], cierres: [], conceptos: {} }, ...extra } };
}

test('Control financiero: pestañas Resumen/Bancos/Planilla/Movimientos/Cierre/Reportes y la vista anterior en Reportes', () => {
  const html = libroViewHtml(stateWith('resumen'), '<div id="old">viejo</div>');
  for (const t of ['Resumen', 'Bancos', 'Planilla', 'Movimientos', 'Cierre', 'Reportes']) assert.match(html, new RegExp(`>${t}<`));
  assert.match(html, /Disponible antes de planilla/); assert.match(html, /Resultado después de planilla/);
  assert.match(libroViewHtml(stateWith('reportes'), '<div id="old">viejo</div>'), /id="old"/);
});

test('planilla: borrador sin montos predeterminados y con antes → después por banco', () => {
  const st = stateWith('planilla'); st.libro.draft = newDraft('2026-10-04');
  const html = libroViewHtml(st);
  assert.match(html, /id="flMonto"[^>]*value=""/);
  assert.equal((html.match(/data-fl-take=/g) || []).length, 4);
  assert.doesNotMatch(html, /data-fl-take="[^"]+" value="[1-9]/);
  st.libro.draft.monto = '2000'; st.libro.draft.asignaciones = { bac: '1000', ficohsa: '700' };
  assert.match(libroViewHtml(st), /Faltan Lps\. 300 por asignar/);
  st.libro.draft.asignaciones.ficohsa = '1000';
  const ok = libroViewHtml(st);
  assert.match(ok, /Distribución completa/); assert.match(ok, /id="flConfirm" >/);
});

test('renovación: hoja de pago simple Pagó/Pendiente, con saldo pendiente opcional y ajuste', () => {
  const sheet = { cliente: 'Juan', label: '1 servicio +30 días', rows: [{ key: 'k1', label: 'Netflix' }], montos: {}, bancoId: '', modo: 'pago', motivo: '' };
  const html = renewPaySheetHtml(sheet, methods);
  assert.match(html, /Estado del cobro/); assert.match(html, /✅ Pagó/); assert.match(html, /🕒 Pendiente/);
  assert.match(html, /Monto pagado/); assert.match(html, /data-rp-pagado="k1" value=""/); assert.match(html, /Agregar saldo pendiente/);
  assert.doesNotMatch(html, /Monto total/); assert.doesNotMatch(html, /Recibido ahora/); assert.match(html, /¿Dónde entró el dinero\?/);
  assert.equal((html.match(/data-rp-banco=/g) || []).length, 4);
  const pend = renewPaySheetHtml({ ...sheet, montos: { k1: { estadoCobro: 'pendiente' } } }, methods);
  assert.match(pend, /Monto pendiente/); assert.match(pend, /¿Quién debe el pendiente\?/);
  const partial = renewPaySheetHtml({ ...sheet, montos: { k1: { estadoCobro: 'pagado', tienePendiente: true, pagado: '100', pendiente: '30' } } }, methods);
  assert.match(partial, /Saldo pendiente/); assert.match(partial, /Pagó Lps\. 100/); assert.match(partial, /pendiente Lps\. 30/);
  assert.match(renewPaySheetHtml({ ...sheet, modo: 'ajuste' }, methods), /Motivo/);
});



test('R110 renovación múltiple: la hoja cobra una sola vez aunque incluya varios servicios', () => {
  const sheet = { cliente: 'Andrea Motiño', label: '2 servicios +31 días', rows: [{ key: 'renovacion', label: 'Disney Premium + Netflix Premium' }], montos: {}, bancoId: '', modo: 'pago', motivo: '' };
  const html = renewPaySheetHtml(sheet, methods);
  assert.equal((html.match(/data-rp-pagado=/g) || []).length, 1, 'un solo campo de monto pagado');
  assert.equal((html.match(/data-rp-pendiente=/g) || []).length, 0, 'sin pendiente mientras no se active');
  assert.match(html, /Disney Premium \+ Netflix Premium/);
  assert.doesNotMatch(html, /data-rp-pagado="netflix"|data-rp-pagado="disney"/i);
});

test('main.js: el flujo de renovación usa pago real solo para Sublicuentas/Relojes y sigue bajo 2000 líneas', () => {
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /operacionPagoBody\(pago,'renovacion'/);
  assert.match(main, /el cobro se registra UNA sola vez para todo el grupo/);
  assert.match(main, /ajusteAdministrativo:true,motivoAjuste/);
  assert.match(main, /if\(libroUser\(\)&&!pago\)/);
  assert.ok(main.split('\n').length < 2000);
});

test('R113 Bancos: solo resumen por banco (ingresos y egresos), sin formulario de saldo inicial', () => {
  const st = stateWith('bancos'); st.libro.data.bancos = st.libro.data.bancos.map((b, i) => (i ? b : { ...b, sinSaldoInicial: true, ingresos: 150, egresosOperativos: 50, saldo: 100 }));
  const html = libroViewHtml(st);
  assert.doesNotMatch(html, /data-fl-ini|Registrar saldo inicial/);
  assert.match(html, /Ingresos/); assert.match(html, /Egresos/);
});
