import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import ExcelJS from 'exceljs';
import { cierreDelMes, financeContentHtml, buildFinanceWorkbook, parseAllFinance } from '../src/finanzas.js';

const main = appSource();
const today = new Date(2026, 8, 20, 10, 0, 0); // 20/09/2026

const rows = [
  { fechaRenovacion: '05/09/2026', precio: 150 },  // este mes, ya vencido (pendiente)
  { fechaRenovacion: '20/09/2026', precio: 100 },  // este mes, hoy (no pendiente)
  { fechaRenovacion: '28/09/2026', precio: 250 },  // este mes, por venir
  { fechaRenovacion: '10/08/2026', precio: 200 },  // mes pasado
  { fechaRenovacion: '15/10/2026', precio: 999 },  // otro mes: no cuenta
  { fechaRenovacion: 'sin fecha', precio: 50 },     // sin fecha: no cuenta
];

test('Cierre del mes: mismo cálculo que la web (esperado, pendiente/vencido, vs mes pasado)', () => {
  const c = cierreDelMes(rows, today);
  assert.equal(c.esperado, 500);
  assert.equal(c.pendiente, 150);
  assert.equal(c.anterior, 200);
  assert.equal(c.deltaPct, 150); // (500-200)/200
  assert.equal(c.servicios, 3);
  assert.match(c.mes, /septiembre/i);
  assert.equal(cierreDelMes(rows.filter(r => r.fechaRenovacion !== '10/08/2026'), today).deltaPct, null, 'sin mes pasado: "—"');
  assert.deepEqual(cierreDelMes([], today).esperado, 0);
});

test('Control financiero muestra el Cierre del mes arriba de todo', () => {
  const html = financeContentHtml({ movs: [], today, cierreMes: cierreDelMes(rows, today) });
  const doc = new JSDOM(`<body>${html}</body>`).window.document;
  const sec = doc.querySelector('.fin-cierre-mes');
  assert.ok(sec);
  assert.match(sec.textContent, /Esperado este mes/);
  assert.match(sec.textContent, /Pendiente \/ vencido/);
  assert.match(sec.textContent, /\+150%/);
  assert.match(sec.textContent, /No incluye marca de pago/);
  assert.equal(doc.body.firstElementChild, sec, 'va primero, como en la web');
  assert.equal(new JSDOM(`<body>${financeContentHtml({ movs: [], today })}</body>`).window.document.querySelector('.fin-cierre-mes'), null);
});

test('Excel: las 4 hojas de la web + "Cierre del mes"', async () => {
  const movs = parseAllFinance([
    { id: 'a', tipo: 'ingreso', monto: 1000, fecha: '01/09/2026', banco: 'BAC', plataforma: 'netflix' },
    { id: 'b', tipo: 'egreso', monto: 300, fecha: '02/09/2026', banco: 'BAC', motivo: 'Compra' },
  ]);
  const cierre = cierreDelMes(rows, today);
  const wb = buildFinanceWorkbook(ExcelJS, movs, { label: 'Todo', now: today, cierre });
  const back = new ExcelJS.Workbook(); await back.xlsx.load(await wb.xlsx.writeBuffer());
  assert.deepEqual(back.worksheets.map(w => w.name), ['Resumen', 'Por Mes', 'Por Banco', 'Movimientos', 'Cierre del mes']);
  const ws = back.getWorksheet('Cierre del mes');
  assert.equal(ws.getCell('B2').value, 500);
  assert.equal(ws.getCell('B3').value, 150);
  assert.equal(ws.getCell('B5').value, 1.5);
  // sin cierre queda como antes (4 hojas)
  const solo = buildFinanceWorkbook(ExcelJS, movs, { label: 'Todo', now: today });
  assert.equal(solo.worksheets.length, 4);
});

test('main.js pasa el cierre del mes a la pantalla y al Excel', () => {
  assert.match(main, /cierreMes:cierreDelMes\(allRows\(\),new Date\(\)\)/);
  assert.match(main, /cierre:cierreDelMes\(allRows\(\),new Date\(\)\)/);
});
