import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

// La pantalla Más/Clientes vive ahora en src/screens.js (rediseño R37): se revisa junto con main.js.
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8') + '\n' + fs.readFileSync(new URL('../src/screens.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const cap = JSON.parse(fs.readFileSync(new URL('../capacitor.config.json', import.meta.url), 'utf8'));

test('mobile UI removes bootstrap/debug placeholder copy', () => {
  for (const banned of ['Shell Android listo', 'CRM móvil por clienteId', 'La escritura autoritativa seguirá en Core', 'Debug interno']) {
    assert.equal(main.includes(banned), false, `found banned copy: ${banned}`);
  }
});

test('top content respects Android safe area', () => {
  assert.match(css, /safe-area-inset-top/);
});

test('navigation uses vector icons instead of people emoji', () => {
  assert.equal(main.includes('👥'), false);
  assert.match(main, /icon\(/);
});

test('Capacitor native HTTP patch is enabled for cross-origin Core calls', () => {
  assert.equal(cap.plugins?.CapacitorHttp?.enabled, true);
});

test('login and real data views are present', () => {
  for (const word of ['Iniciar sesión','Buscar cliente','Vencen hoy','Actualizar datos']) assert.match(main, new RegExp(word));
});


test('debug build number is injected by GitHub Actions instead of being hard-coded', () => {
  assert.match(main, /VITE_BUILD_NUMBER/);
  assert.equal(main.includes('1.0 · build 1</b>'), false);
});


test('Sorteos and Control Maestro are real read views, not coming-soon placeholders', () => {
  assert.match(main, /loadRaffles/);
  assert.match(main, /ensureControlMaster/);
  assert.equal(main.includes("simpleComing('Sorteos'"), false);
  assert.equal(main.includes("simpleComing('Control Maestro'"), false);
});

test('Nuevo CRM is a real mobile sale form and Catalog is not a bottom-nav destination', () => {
  for (const field of ['Cliente titular','Teléfono','Plataforma','Correo / usuario','Clave / serial','Precio','Fecha de renovación']) assert.match(main, new RegExp(field.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')));
  assert.match(main, /Registrar venta/);
  assert.match(main, /'nuevo-crm'/); assert.match(main, /title: 'Nuevo CRM'/);
  assert.equal(/\['catalogo','Catálogo','catalog'\]/.test(main), false);
});

test('Clientes keeps Sublichat operational filters and actions on mobile', () => {
  for (const text of ['Vigentes','Hoy','Próximos','Vencidos','Plataformas','Vendedores','Mostrar','Cobros de hoy','Editar cliente / ficha CRM','Acceso URL y 6 variantes','No renovó']) {
    assert.match(main, new RegExp(text.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')));
  }
  assert.equal(/data-client-whatsapp/.test(main), false);
  assert.match(main,/data-client-charge/);
  assert.match(main,/data-client-actions/);
});

test('WhatsApp uses a native Android intent launcher instead of window.location intent URLs', () => {
  assert.match(main, /capacitor-intent-launcher/);
  assert.match(main, /ActivityAction\.VIEW/);
  assert.match(main, /packageName/);
  assert.equal(main.includes('window.location.href=`intent://send'), false);
});


test('Clientes cards use Mensaje de cobro instead of a direct WhatsApp button', () => {
  assert.equal(/data-client-whatsapp/.test(main), false);
  assert.match(main, /data-client-charge/);
  assert.match(main, /data-client-charge.*openRenewForRow/);
  assert.match(main, /Mensaje de cobro/);
});

test('WhatsApp package launch uses wa.me chat link with selected client phone', () => {
  assert.match(main, /https:\/\/wa\.me\/\$\{phone\}/);
});

test('client status counters count unique clients, not service rows', () => {
  assert.match(main, /function uniqueClientCount\(/);
  assert.match(main, /vigentes:uniqueClientCount\(filterOperationalRows/);
});

test('renewal charge WhatsApp carries the active client phone', () => {
  assert.match(main, /renewOpenWhatsApp[\s\S]{0,500}requestWhatsApp\([\s\S]*g\?\.telefono/);
});

test('WhatsApp package launch uses wa.me chat URL as Android VIEW target', () => {
  assert.match(main, /data:phone\?`https:\/\/wa\.me\/\$\{phone\}/);
});

test('No renovó never presents client deletion as a successful outcome', () => {
  assert.doesNotMatch(main, /Cliente eliminado: no renovó/);
  assert.match(main, /La ficha del cliente debe conservarse/);
});

test('Perfil Android edits the shared Sublichat profile instead of a local-only profile', () => {
  assert.match(main, /Editar perfil/);
  assert.match(main, /profileName/);
  assert.match(main, /profileAvatar/);
  assert.match(main, /saveProfile/);
  assert.match(main, /loadProfile\(state\.session\.usuario\)/);
});

test('operational identity does not expose Naara or Daniela in Android role labels', () => {
  assert.equal(main.includes('Sublicuentas · Naara'), false);
  assert.equal(main.includes('Relojes · Libni'), false);
});
