import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp, SAMPLE_CLIENTS } from './helpers/ui-harness.mjs';

// Geisell solo ve las fichas cuyo vendedor es Geisell.
const CLIENTES_GEISELL = [...SAMPLE_CLIENTS, { id: 'c4', nombre: 'Cliente Geisell', telefono: '3111', vendedor: 'Geisell', servicios: [{ plataforma: 'hbomax', precio: 70, fechaRenovacion: '01/12/2026', vendedor: 'Geisell', compraId: 'k4' }] }];
import { MORE_MODULE_ORDER, roleModules } from '../src/data.js';

const STAFF = ['pelis', 'partidos', 'subli', 'inventario', 'calculadora', 'aula', 'materia', 'perfil'];
const RELOJES = ['pelis', 'partidos', 'subli', 'codigos', 'inventario', 'calculadora', 'aula', 'materia', 'perfil']; // R77: Relojes también ve Códigos
const masModules = app => app.$$('.mas-card[data-open]').map(b => b.dataset.open);
const homeTools = app => app.$$('.visual-module-grid [data-open]').map(b => b.dataset.open);

test('roleModules: lo que ve cada usuario (Perfil siempre al final)', () => {
  assert.deepEqual(roleModules('sublicuentas', 'sublicuentas').tabs, ['inicio', 'clientes', 'cobros', 'tickets', 'mas']);
  assert.deepEqual(roleModules('sublicuentas', 'sublicuentas').more, [...MORE_MODULE_ORDER]);
  assert.equal(MORE_MODULE_ORDER.at(-1), 'perfil');
  assert.deepEqual(roleModules('relojes', 'relojes').tabs, ['inicio', 'clientes', 'cobros', 'tickets', 'mas']);
  assert.deepEqual(roleModules('relojes', 'relojes').more, RELOJES);
  assert.deepEqual(roleModules('geisell', 'geisell').tabs, ['inicio', 'clientes', 'tickets', 'mas']);
  assert.deepEqual(roleModules('geisell', 'geisell').more, [...RELOJES.filter(m => m !== 'perfil'), 'control-maestro', 'perfil'], 'R69/R79: Geisell ve Códigos y Control Maestro, Perfil al final');
  assert.equal(roleModules('otro', 'otro').more.includes('finanzas'), false, 'un rol desconocido nunca escala');
});

test('Sublicuentas: pestañas, todas las tarjetas de Más (Perfil al final) y herramientas del Inicio', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    assert.deepEqual(app.tabs(), ['inicio', 'clientes', 'cobros', 'tickets', 'mas']);
    assert.deepEqual(homeTools(app), ['aula', 'finanzas', 'materia', 'clientes', 'tickets']);
    await app.click('[data-tab="mas"]', 300);
    assert.deepEqual(masModules(app), [...MORE_MODULE_ORDER]);
    assert.equal(masModules(app).at(-1), 'perfil');
    assert.equal(app.$('.mas-info').classList.contains('wide'), masModules(app).length % 2 === 0, 'R77: "Más resultados" ocupa el ancho solo si las tarjetas son pares; si son impares completa la fila');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Relojes: Inicio, Clientes, Cobros, Tickets, Más → Pelis, Partidos, Subli, Aula, Materia cerebral y Perfil', async () => {
  const app = await bootApp({ role: 'relojes' });
  try {
    assert.deepEqual(app.tabs(), ['inicio', 'clientes', 'cobros', 'tickets', 'mas']);
    assert.deepEqual(homeTools(app), ['aula', 'materia', 'clientes', 'tickets'], 'sin Control financiero en el Inicio');
    await app.click('[data-tab="mas"]', 300);
    assert.deepEqual(masModules(app), RELOJES);
    assert.equal(app.$('.mas-info').classList.contains('wide'), masModules(app).length % 2 === 0, 'R77: "Más resultados" completa la fila');
    for (const gone of ['nuevo-crm', 'control-maestro', 'finanzas', 'sorteos']) assert.equal(app.$(`[data-open="${gone}"]`), null, gone);
    assert.ok(app.$('[data-open="inventario"]') && app.$('[data-open="calculadora"]'), 'Relojes ve Inventario y Calculadora');
    await app.click('[data-open="perfil"]', 300);
    assert.ok(app.$('.profile-card, #profileForm, [data-profile-edit], .settings-list'), 'Perfil abre');
    await app.click('#backMore', 300);
    assert.equal(app.$('.bottom-nav .active').dataset.tab, 'mas', 'atrás desde Perfil vuelve a Más');
  } finally { app.close(); }
});

test('Geisell: Inicio, Clientes, Tickets, Más (sin Cobros) → mismas tarjetas; las tarjetas de vencimientos abren Clientes', async () => {
  const app = await bootApp({ role: 'geisell', clients: CLIENTES_GEISELL });
  try {
    assert.deepEqual(app.tabs(), ['inicio', 'clientes', 'tickets', 'mas']);
    assert.deepEqual(homeTools(app), ['aula', 'materia', 'clientes', 'tickets']);
    await app.click('.mcard-today', 400); // "Vencen hoy" no tiene pestaña Cobros: abre Clientes filtrado por Hoy
    assert.equal(app.$('.bottom-nav .active').dataset.tab, 'clientes');
    assert.equal(app.$('.cli-tabs .active').dataset.clientStatus, 'hoy');
    await app.click('[data-tab="mas"]', 300);
    assert.deepEqual(masModules(app), [...RELOJES.filter(m => m !== 'perfil'), 'control-maestro', 'perfil']); // R69/R79: Códigos y Control Maestro para Geisell
    // sin permiso de CRM: el menú del cliente no ofrece "Agregar otra cuenta" ni "Editar ficha CRM"
    await app.click('[data-tab="clientes"]', 300);
    await app.click('[data-client-status="vigentes"]', 300);
    assert.equal(app.$$('.cli-card').length, 1, 'Geisell solo ve su ficha');
    await app.click('.cli-dots', 300);
    assert.ok(app.$('[data-client-action="renew"]'));
    assert.equal(app.$('[data-client-action="add-service"]'), null);
    assert.equal(app.$('[data-client-action="edit"]'), null);
  } finally { app.close(); }
});

test('Clientes ⋮: los 7 botones de acciones funcionan (antes Editar y Agregar cuenta fallaban con "perfiles is not defined")', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 500);
    const n = app.$$('.cli-card').length;
    assert.ok(n >= 2, 'hay tarjetas');
    for (let i = 0; i < n; i++) {
      for (const action of ['renew', 'charge', 'add-service', 'edit', 'ficha', 'url', 'no-renew']) {
        await app.click('[data-tab="clientes"]', 120);
        for (const b of app.$$('#closeClientActionsBtn')) b.click();
        await app.click(app.$$('.cli-dots')[i], 120);
        const btn = app.$(`[data-client-action="${action}"]`);
        assert.ok(btn, `tarjeta ${i}: falta el botón ${action}`);
        btn.click(); await app.sleep(350);
        if (action === 'renew' || action === 'charge') assert.ok(app.$('.renew-backdrop'), `tarjeta ${i}: ${action} abre la hoja de renovación`);
        if (action === 'add-service' || action === 'edit') assert.ok(app.$('#crmSubmit'), `tarjeta ${i}: ${action} abre la ficha CRM`);
        if (action === 'url') assert.ok(app.$('#clientCopyUrlMessage'), `tarjeta ${i}: url muestra las variantes`);
        if (action === 'no-renew') assert.ok(app.calls.some(c => c.action === 'no_renovo'), 'no-renew llama al servidor');
      }
    }
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), [], 'ninguna acción lanza errores');
  } finally { app.close(); }
});
