import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('R51 CRM rápido: no espera la recarga completa y usa el enlace que ya devuelve el guardado', () => {
  const start = main.indexOf('async function saveCrm(');
  const block = main.slice(start, main.indexOf('\n}\n', start));
  assert.doesNotMatch(block, /await loadCoreData/);
  assert.match(block, /let link=String\(result\?\.linkPublico\|\|''\)/);
  assert.match(block, /setTimeout\(\(\)=>loadCoreData\(\{force:true,only:\['clients'\]\}\)/);
});

test('R51 WhatsApp abre al instante (no redibuja antes del intent) y la ficha de grupo no lleva número', () => {
  const start = main.indexOf('async function launchWhatsApp(');
  const block = main.slice(start, main.indexOf('IntentLauncher.startActivityAsync', start));
  assert.match(block, /if \(hadSheet\) render\(\);/);
  assert.match(main, /if\(delivery==='tradicional'\)\{requestWhatsApp\(d\.fichaTexto\|\|crmFichaFromDraft\(d\)\);/);
  assert.match(main, /requestWhatsApp\(crmUrlMessage\(d,link\),d\.telefono\)/);
});

test('R51 Inicio: "Sincronizado" en cuanto llegan los clientes; lo demás sigue en segundo plano', () => {
  // R69: cada recurso marca su propio estado; clientes solos ya permiten pintar Inicio
  assert.match(main, /function syncResource\(key\)/);
  assert.match(main, /loadMobileResource\('clientes',\{pageSize:1000,maxPages:24\}\)/);
});

test('R51 Perfil: "Cambiar" abre el selector de WhatsApp y guarda la elección', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="perfil"]', 300);
    await app.click('#whatsappAppReset', 250);
    assert.ok(app.$('.whatsapp-sheet'), 'se abre el selector');
    assert.ok(app.$('[data-whatsapp-package="ask"]'), 'incluye "Preguntar cada vez"');
    await app.click('[data-whatsapp-package="com.whatsapp.w4b"]', 250);
    assert.equal(app.w.localStorage.getItem('sublicuentas-whatsapp-app'), 'com.whatsapp.w4b');
    assert.equal(app.$('.whatsapp-sheet'), null);
    assert.match(app.$('.settings-panel').textContent, /WhatsApp Business/);
  } finally { app.close(); }
});

test('R51 Tema oscuro: al elegir Oscuro se activa theme-dark; Claro lo quita', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="perfil"]', 300);
    const sel = app.$('#themeSelect');
    sel.value = 'dark'; sel.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(150);
    assert.ok(app.w.document.documentElement.classList.contains('theme-dark'));
    const sel2 = app.$('#themeSelect');
    sel2.value = 'light'; sel2.dispatchEvent(new app.w.Event('change', { bubbles: true })); await app.sleep(150);
    assert.equal(app.w.document.documentElement.classList.contains('theme-dark'), false);
  } finally { app.close(); }
  assert.match(css, /html\.theme-dark\{filter:invert\(1\) hue-rotate\(180deg\)/);
  assert.doesNotMatch(css, /--crm2-navy:#f3f5ff/, 'el texto de la ficha ya no se vuelve blanco sobre fondo claro');
});

test('R51 Ícono de Sublichat: recursos incluidos y se aplican al sincronizar Capacitor', () => {
  assert.equal(pkg.scripts['capacitor:sync:after'], 'node scripts/android-icons.mjs');
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    for (const f of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) assert.ok(existsSync(new URL(`../android-res/mipmap-${d}/${f}`, import.meta.url)), `${d}/${f}`);
  }
  assert.ok(existsSync(new URL('../android-res/mipmap-anydpi-v26/ic_launcher.xml', import.meta.url)));
});
