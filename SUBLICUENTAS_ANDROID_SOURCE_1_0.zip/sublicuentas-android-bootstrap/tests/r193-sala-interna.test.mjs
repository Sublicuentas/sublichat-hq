// R193 · PDF «Corrección urgente Sala 3D y Finanzas APK»: la sala 3D se abre DENTRO de la APK (J01/J02/J10/J11).
// Es la MISMA sala web (copia fiel en public/), con la sesión de la APK. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const AHORA = Date.now();
const PANEL = { ok: true, yo: { id: 'naara', nombre: 'Naara', anfitriona: true }, permisos: { crear: true, moderar: true }, tiempoReal: true, grabacionServidor: false,
  fundadoras: [{ id: 'naara', nombre: 'Naara' }, { id: 'libni', nombre: 'Libni' }, { id: 'geisell', nombre: 'Geisell' }], avatares: {},
  reuniones: [{ id: 'reuEnCurso01', titulo: 'Junta semanal', inicioMs: AHORA - 6e5, fecha: '07/11/2026', hora: '10:00 a. m.', duracionMin: 45, estado: 'en_curso', anfitrion: 'naara', participantes: ['naara', 'libni', 'geisell'], invitaciones: {} },
    { id: 'reuPasada01', titulo: 'Cierre de octubre', inicioMs: AHORA - 9e8, fecha: '31/10/2026', hora: '9:00 a. m.', estado: 'finalizada', participantes: ['naara', 'libni'], invitaciones: {} }] };

async function abrirSala(extra = {}) {
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/sala-juntas') return undefined;
    if (body.accion === 'panel') return { ...PANEL, ...extra };
    if (body.accion === 'actas') return { ok: true, actas: [] };
    return { ok: true, eco: body };
  } });
  const llamadas = [];
  // La sala web real se carga desde public/sala-juntas.js; aquí se observa la API que la APK le pide.
  app.w.SublichatSala = { abrir: async (v, id) => { llamadas.push(['abrir', v, id]); app.w.document.getElementById('rbac-sala-juntas').innerHTML = `<div class="sj-card">Vista ${v}</div>`; }, cerrar: () => llamadas.push(['cerrar']) };
  const abiertos = []; app.w.open = (u) => abiertos.push(u);
  await app.click('[data-tab="mas"]', 300);
  await app.click('[data-open="sala-juntas"]', 400);
  await app.waitFor(() => /Junta semanal/.test(app.$('.se-wrap')?.textContent || ''));
  return { app, llamadas, abiertos };
}

test('J01/J02: «Entrar en la APK» abre la antesala y la sala 3D en una vista INTERNA (sin Chrome ni URL externa)', async () => {
  const { app, llamadas, abiertos } = await abrirSala();
  try {
    const t = app.$('.se-wrap').textContent;
    assert.match(t, /Mi avatar · Escenarios/); assert.match(t, /Acciones según permisos/); assert.match(t, /Programar reunión/);
    await app.click('[data-sj-ver="reuEnCurso01"]', 150);
    await app.click('[data-sj-interna="antesala"][data-id="reuEnCurso01"]', 200);
    assert.ok(app.$('#sjApk #screen-sala-juntas.active #rbac-sala-juntas'), 'contenedor interno de la sala');
    assert.deepEqual(llamadas[0], ['abrir', 'antesala', 'reuEnCurso01']);
    assert.ok(app.w.document.documentElement.classList.contains('sj-apk-on'));
    assert.equal(abiertos.length, 0); assert.equal((app.w.__intents || []).length, 0, 'no ACTION_VIEW');
    // la sala usa la sesión de la APK (sin segundo login) y se identifica como android
    const r = await app.w.SalaJuntasConfig.post({ accion: 'antesala', id: 'reuEnCurso01' });
    assert.equal(r.eco.origen, 'android'); assert.equal(r.eco.accion, 'antesala');
    assert.equal(app.w.SalaJuntasConfig.embebida, true);
    // J11: al volver se libera la sala (micrófono/LiveKit/3D) y se quita la vista
    await app.click('[data-sj-apk-cerrar]', 150);
    assert.deepEqual(llamadas.at(-1), ['cerrar']); assert.equal(app.$('#sjApk'), null);
    assert.equal(app.w.document.documentElement.classList.contains('sj-apk-on'), false);
  } finally { app.close(); }
});

test('J10: Mi avatar y Ver salas funcionan sin reunión, dentro de la APK; historial/actas/grabaciones también', async () => {
  const { app, llamadas, abiertos } = await abrirSala();
  try {
    for (const v of ['personaje', 'escenarios', 'historial', 'nueva']) { await app.click(`[data-sj-interna="${v}"]`, 120); await app.click('[data-sj-apk-cerrar]', 80); }
    assert.deepEqual(llamadas.filter((x) => x[0] === 'abrir').map((x) => x[1]), ['personaje', 'escenarios', 'historial', 'nueva']);
    assert.equal(abiertos.length, 0);
  } finally { app.close(); }
});

test('J05: solo la anfitriona ve «Programar reunión»; una invitada no', async () => {
  const { app } = await abrirSala({ yo: { id: 'libni', nombre: 'Libni' }, permisos: { crear: false, moderar: false } });
  try { assert.equal(app.$('[data-sj-interna="nueva"]'), null); assert.match(app.$('.se-wrap').textContent, /la anfitriona aprueba su ingreso/); }
  finally { app.close(); }
});

test('copia fiel de la sala web en la APK + permisos de Android; sin claves de LiveKit ni de grabación', () => {
  const HQ = new URL('../../../hq-gh/', import.meta.url);
  const archivos = ['sala-juntas.js', 'sala-3d.js', 'sala-vivo.js', 'sala-grabar.js', 'sala-presentar.js', 'escenarios.js', 'avatar-glb.js', 'vendor/three-gltf-0.160.0.js', 'assets/avatares/mujer.glb', 'assets/avatares/hombre.glb'];
  for (const f of archivos) {
    const apk = fs.readFileSync(new URL(`../public/${f}`, import.meta.url));
    if (fs.existsSync(new URL(f, HQ))) assert.ok(apk.equals(fs.readFileSync(new URL(f, HQ))), `copia fiel: ${f}`);
    if (f.endsWith('.js')) assert.doesNotMatch(apk.toString(), /LIVEKIT_API_SECRET|SALA_GRAB_GCP_CREDENTIALS|private_key/);
  }
  const web = fs.readFileSync(new URL('../public/sala-juntas.js', import.meta.url), 'utf8');
  assert.match(web, /window\.SalaJuntasConfig/); assert.match(web, /window\.SublichatSala = \{ open, abrir, cerrar/);
  const nat = fs.readFileSync(new URL('../scripts/android-native.mjs', import.meta.url), 'utf8');
  for (const p of ['RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'CAMERA']) assert.match(nat, new RegExp(`android\\.permission\\.${p}`));
  assert.match(nat, /android\.hardware\.camera', 'android\.hardware\.microphone'\]/);
});
