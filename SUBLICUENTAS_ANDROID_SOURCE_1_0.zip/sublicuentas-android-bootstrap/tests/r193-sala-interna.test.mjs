// R193 · PDF «Corrección urgente Sala 3D y Finanzas APK»: la sala 3D se abre DENTRO de la APK (J01/J02/J10/J11).
// Es la MISMA sala web (copia fiel en public/), con la sesión de la APK. Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const AHORA = Date.now();
const PANEL = { ok: true, yo: { id: 'naara', nombre: 'Naara', anfitriona: true }, permisos: { crear: true, moderar: true }, tiempoReal: true, grabacionServidor: false,
  fundadoras: [{ id: 'naara', nombre: 'Naara' }, { id: 'libni', nombre: 'Libni' }, { id: 'geisell', nombre: 'Geisell' }], avatares: {},
  reuniones: [{ id: 'reuEnCurso01', titulo: 'Junta semanal', inicioMs: AHORA - 6e5, fecha: '07/11/2026', hora: '10:00 a. m.', duracionMin: 45, estado: 'en_curso', anfitrion: 'naara', participantes: ['naara', 'libni', 'geisell'], invitaciones: {} },
    { id: 'reuPasada01', titulo: 'Cierre de octubre', inicioMs: AHORA - 9e8, fecha: '31/10/2026', hora: '9:00 a. m.', estado: 'finalizada', participantes: ['naara', 'libni'], invitaciones: {} }] };

async function abrirSala(extra = {}, role = 'sublicuentas') {
  const app = await bootApp({ role, fetchExtra: async (path, body) => {
    if (path !== '/api/sala-juntas') return undefined;
    if (body.accion === 'panel') return { ...PANEL, ...extra };
    return { ok: true, eco: body };
  } });
  const llamadas = [];
  // La sala web real (public/sala-juntas.js) se observa por la API que la APK le pide.
  app.w.SublichatSala = { abrir: async (v, id) => { llamadas.push(['abrir', v, id]); const h = app.w.document.getElementById('rbac-sala-juntas'); if (h) h.innerHTML = `<div class="sj-card">SubliStudio 3D · ${v}</div>`; }, cerrar: () => llamadas.push(['cerrar']) };
  const abiertos = []; app.w.open = (u) => abiertos.push(u);
  await app.click('[data-tab="mas"]', 300);
  return { app, llamadas, abiertos };
}

test('R194 · Más › Sala de Juntas abre DIRECTO la interfaz completa de SubliStudio 3D (sin pantalla preliminar, sin Chrome)', async () => {
  const { app, llamadas, abiertos } = await abrirSala();
  try {
    await app.click('[data-open="sala-juntas"]', 400);
    await app.waitFor(() => llamadas.length);
    assert.deepEqual(llamadas, [['abrir', 'inicio', '']], 'una sola apertura, directo a la sala completa');
    assert.ok(app.$('#sjApk #screen-sala-juntas.active #rbac-sala-juntas'));
    assert.match(app.$('#rbac-sala-juntas').textContent, /SubliStudio 3D · inicio/);
    assert.equal(app.$('.sj-m-reu, .sj-m-mi, [data-sj-interna]'), null, 'ya no existe la pantalla preliminar de la APK');
    assert.equal(abiertos.length, 0); assert.equal((app.w.__intents || []).length, 0, 'no ACTION_VIEW');
    // la sala usa la sesión de la APK (sin segundo login) y se identifica como android
    const r = await app.w.SalaJuntasConfig.post({ accion: 'antesala', id: 'reuEnCurso01' });
    assert.equal(r.eco.origen, 'android'); assert.equal(r.eco.accion, 'antesala');
    assert.equal(app.w.SalaJuntasConfig.embebida, true);
    // re-render de la APK no vuelve a abrir ni duplica la sala
    app.w.document.querySelector('#app') && await app.wait?.(100);
    assert.equal(app.w.document.querySelectorAll('#sjApk').length, 1);
    // J11: «‹ Más» libera la sala (micrófono/LiveKit/3D) y vuelve a Más
    await app.click('[data-sj-apk-cerrar]', 200);
    assert.deepEqual(llamadas.at(-1), ['cerrar']); assert.equal(app.$('#sjApk'), null);
    assert.equal(app.w.document.documentElement.classList.contains('sj-apk-on'), false);
    assert.ok(app.$('[data-open="sala-juntas"]'), 'quedó en Más');
    await app.click('[data-open="sala-juntas"]', 300);
    assert.deepEqual(llamadas.filter((x) => x[0] === 'abrir').length, 2);
  } finally { app.close(); }
});

test('R194 · si la sala no carga, se ve el error con Reintentar (no una pantalla a medias)', async () => {
  const { app } = await abrirSala();
  try {
    let n = 0;
    app.w.SublichatSala = { abrir: async () => { n++; if (n === 1) throw new Error('Sin conexión'); }, cerrar() {} };
    await app.click('[data-open="sala-juntas"]', 400);
    await app.waitFor(() => app.$('[data-sj-reintentar]'));
    assert.match(app.$('#rbac-sala-juntas').textContent, /Sin conexión/);
    await app.click('[data-sj-reintentar]', 200);
    assert.equal(n, 2);
  } finally { app.close(); }
});

test('copia fiel de la sala web en la APK + permisos de Android; sin claves de LiveKit ni de grabación', () => {
  const HQ = new URL('../../../hq-gh/', import.meta.url);
  const archivos = ['sala-juntas.js', 'sala-3d.js', 'sala-vivo.js', 'sala-grabar.js', 'sala-presentar.js', 'escenarios.js', 'avatar-glb.js', 'vendor/three-gltf-0.160.0.js', 'assets/avatares/mujer.glb', 'assets/avatares/hombre.glb'];
  for (const f of archivos) {
    const apk = fs.readFileSync(new URL(`../public/${f}`, import.meta.url));
    if (fs.existsSync(new URL(f, HQ))) assert.ok(apk.equals(fs.readFileSync(new URL(f, HQ))), `copia fiel: ${f}`);
    if (f.endsWith('.js')) assert.doesNotMatch(apk.toString(), /LIVEKIT_API_SECRET|SALA_GRAB_GCP_CREDENTIALS|private_key/);
  }
  const web = fs.readFileSync(new URL('../public/sala-juntas.js', import.meta.url), 'utf8');
  assert.match(web, /window\.SalaJuntasConfig/); assert.match(web, /window\.SublichatSala = \{ open, abrir, cerrar/);
  const nat = fs.readFileSync(new URL('../scripts/android-native.mjs', import.meta.url), 'utf8');
  for (const p of ['RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS', 'CAMERA']) assert.match(nat, new RegExp(`android\\.permission\\.${p}`));
  assert.match(nat, /android\.hardware\.camera', 'android\.hardware\.microphone'\]/);
});
