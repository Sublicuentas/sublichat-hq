import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { juegosHubHtml, leaderboardHtml, memoryScreenHtml, hangmanScreenHtml, wordSearchScreenHtml, resultSheetHtml, fmtClock, GAME_META } from '../src/juegos.js';
import { memoryCreate, hangmanCreate, wordSearchCreate } from '../src/juegos-engine.js';
import { bootApp } from './helpers/ui-harness.mjs';

const main = appSource();
const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('fmtClock: da formato mm:ss', () => {
  assert.equal(fmtClock(0), '00:00'); assert.equal(fmtClock(65), '01:05'); assert.equal(fmtClock(3661), '61:01'); assert.equal(fmtClock(-5), '00:00');
});

test('Hub de Juegos PRO: puntos, botón de ranking y las 6 tarjetas (3 jugables, 3 "Próximamente")', () => {
  const d = dom(juegosHubHtml({ resumen: { totalPoints: 1280 } }));
  assert.match(d.body.textContent, /Puntos: 1,280/);
  assert.ok(d.querySelector('#jgOpenRanking'));
  const cards = [...d.querySelectorAll('.jg-card')];
  assert.equal(cards.length, 6);
  const ready = cards.filter(c => !c.disabled);
  assert.deepEqual(ready.map(c => c.dataset.jgOpen).sort(), ['BASKETBALL', 'COLOR_CHALLENGE', 'DARTS', 'HANGMAN', 'MEMORY_PAIRS', 'WORD_SEARCH'].sort()); // R55: los 6 ya se juegan
  for (const c of cards.filter(c => c.disabled)) assert.match(c.textContent, /Próximamente/);
  assert.ok(d.querySelector('#jgRankBack'), 'R53: el hub vuelve al tablero de Juegos');
  const err = dom(juegosHubHtml({ error: 'sin red' }));
  assert.ok(err.querySelector('#jgRetry')); assert.match(err.body.textContent, /sin red/);
});

test('Tablero de puntajes: pestañas, mi tarjeta y la tabla (general trae racha e insignia; semanal y por juego no)', () => {
  const data = { me: { rank: 3, score: 1280 }, entries: [{ userId: 'libni', displayName: 'Libni', score: 2450, streak: 25, badge: 'Leyenda' }, { userId: 'naara', displayName: 'Naara', score: 1280, streak: 12, badge: 'Explorador' }] };
  const d = dom(leaderboardHtml({ scope: 'general', data, me: 'naara', myTotals: { totalPoints: 1280, streak: { current: 12 }, badge: { code: 'EXPLORADOR', name: 'Explorador' }, byGame: { MEMORY_PAIRS: 220, HANGMAN: 310, WORD_SEARCH: 420 } } }));
  assert.deepEqual([...d.querySelectorAll('[data-jg-scope]')].map(b => b.dataset.jgScope), ['general', 'semanal', 'porJuego']);
  assert.equal(d.querySelector('.jg-tabs .on').dataset.jgScope, 'general');
  assert.match(d.querySelector('.jg-mecard').textContent, /1,280/);
  assert.equal(d.querySelectorAll('.jg-table tbody tr').length, 2);
  assert.ok(d.querySelector('.jg-table tr.me'), 'la fila del usuario actual se resalta');
  assert.equal(d.querySelectorAll('.jg-bygame-card').length, 6);
  const loading = dom(leaderboardHtml({ loading: true })); assert.ok(loading.querySelector('.spinner'));
  const err = dom(leaderboardHtml({ error: 'falló' })); assert.match(err.body.textContent, /falló/);
  const semanal = dom(leaderboardHtml({ scope: 'semanal', data: { entries: [] } }));
  assert.match(semanal.body.textContent, /Todavía no hay resultados/);
});

test('Pares de cartas: pantalla muestra progreso, combo, movimientos y bloquea "Finalizar" hasta terminar', () => {
  const s = memoryCreate(12, () => 0.4);
  const d = dom(memoryScreenHtml({ state: s, timeLeftSec: 95, finished: false }));
  assert.equal(d.querySelectorAll('[data-jg-flip]').length, 24);
  assert.match(d.body.textContent, /01:35/);
  assert.equal(d.querySelector('#jgFinish').disabled, true);
  const done = dom(memoryScreenHtml({ state: { ...s, pairsFound: 12 }, timeLeftSec: 10, finished: true }));
  assert.equal(done.querySelector('#jgFinish').disabled, false);
});

test('El ahorcado: muestra la categoría, la pista, corazones de vidas y bloquea letras ya usadas', () => {
  let s = hangmanCreate(1, 7, 2, () => 0);
  const letter = s.rounds[0].word[0];
  const before = dom(hangmanScreenHtml({ state: s, timeLeftSec: 120 }));
  assert.equal(before.querySelectorAll('.jg-heart:not(.off)').length, 7);
  assert.match(before.body.textContent, new RegExp(s.rounds[0].clue.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  const key = before.querySelector(`[data-jg-letter="${letter}"]`); assert.ok(key && !key.disabled);
});

test('Sopa de letras: dibuja la rejilla del tamaño correcto y la lista de palabras con su progreso', () => {
  const s = wordSearchCreate(12, 0, () => 0.6);
  const d = dom(wordSearchScreenHtml({ state: s, timeLeftSec: 200 }));
  assert.equal(d.querySelectorAll('[data-jg-cell]').length, 144);
  assert.equal(d.querySelectorAll('.jg-ws-list li').length, s.words.length);
  assert.ok(d.body.textContent.includes(`0/${s.words.length}`));
});

test('Hoja de resultado: carga → listo (con racha/insignia) → error, y todas cierran con data-sr-cancel', () => {
  assert.ok(dom(resultSheetHtml({ status: 'loading' })).querySelector('.spinner'));
  const done = dom(resultSheetHtml({ status: 'done', awardedPoints: 750, totalPoints: 2030, streak: { current: 4 }, badge: { code: 'AVANZADO', name: 'Avanzado' } }));
  assert.match(done.body.textContent, /\+750 SP/); assert.match(done.body.textContent, /2,030/); assert.match(done.body.textContent, /Avanzado/);
  assert.ok(done.querySelector('[data-sr-cancel]'));
  const rep = dom(resultSheetHtml({ status: 'done', awardedPoints: 750, totalPoints: 2030, repetido: true }));
  assert.match(rep.body.textContent, /ya se había guardado/);
  const err = dom(resultSheetHtml({ status: 'error', error: 'sin red' }));
  assert.match(err.body.textContent, /sin red/); assert.ok(err.querySelector('[data-sr-cancel]'));
});

test('main.js: Materia cerebral abre Juegos PRO real (backend con puntos oficiales), no un aviso', () => {
  assert.match(api, /export async function juegosResumen\(\) \{ return authPost\('\/api\/juegos', \{ accion: 'resumen' \}\); \}/);
  assert.match(api, /export async function juegosRegistrar\(gameCode, roundId, metrics\)/);
  assert.match(api, /export async function juegosRanking\(scope, extra = \{\}\)/);
  assert.match(main, /function juegosStart\(code\)/);
  assert.match(main, /function juegosFinish\(\)/);
  assert.match(main, /juegosRegistrar\(j\.gameCode, j\.gameCode==='WORD_SEARCH'\?j\.engine\.roundId:\(j\.gameCode==='MEMORY_PAIRS'\|\|j\.gameCode==='HANGMAN'\|\|j\.gameCode==='BASKETBALL'\)\?j\.engine\.gameId:genRoundId\(\), sub\)/); // Sopa y Memoria: id fijo por partida (idempotente) // R61: Sopa usa su roundId fijo (idempotente)
  assert.match(main, /setInterval\(\(\)=>\{ if \(state\.session && state\.subview==='materia'\) juegosTick\(\); \},1000\)/);
  assert.match(main, /if\(id==='materia'\)\{state\.juegos\.screen='ranking';state\.juegos\.engine=null;ensureJuegosResumen\(\);await juegosLoadRanking/); // R53: entra directo al tablero Juegos
});

test('Juegos PRO de punta a punta en la app: navegar, jugar Sopa de letras tocando el tablero real y guardar puntos oficiales', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    assert.ok(app.$('.jg2-page'), 'R53: abre directo el tablero Juegos (no el aviso de "módulo conservado")');
    assert.doesNotMatch(app.$('.jg-page').textContent, /La reestructuración conserva este módulo/);
    assert.match(app.$('.jg-page').textContent, /Mis puntos por juego/);

    await app.click('.jg2-play[data-jg-play="WORD_SEARCH"]', 250);
    assert.ok(app.$('#sopaBoard'), 'R61: entra a Sopa de Letras PRO (tablero nuevo)');
    assert.equal(app.$$('.ws-cell').length, 36, 'nivel Atención: 6×6');
    assert.equal(app.$$('.ws-chip').length, 3);
    await app.click('#sopaHint', 80);
    assert.ok(app.$('.ws-cell.hint'), 'la pista marca la primera letra de una palabra');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Juegos PRO: El ahorcado y el Tablero de puntajes también se pueden abrir sin errores', async () => {
  const app = await bootApp({ role: 'relojes' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    await app.click('[data-jg-play="HANGMAN"]', 250);
    assert.ok(app.$('.hg-kb'), 'R66: Ahorcado PRO con teclado nuevo');
    await app.click('#jgQuit', 200);
    assert.ok(app.$('.jg2-page'), 'R53: salir de una partida regresa al tablero Juegos');
    await app.click('#jgGoHub', 200);
    assert.ok(app.$('.jg-grid'), 'desde el tablero se llega a la lista de juegos');
    await app.click('#jgOpenRanking', 300);
    assert.ok(app.$('.jg-table') || app.$('.spinner') || app.$('.jg-empty'), 'abre el tablero de puntajes');
    await app.click('[data-jg-scope="semanal"]', 300);
    assert.equal(app.$('.jg-tabs .on')?.dataset.jgScope, 'semanal');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
