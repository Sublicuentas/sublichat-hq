import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { juegosHubHtml, leaderboardHtml, memoryScreenHtml, hangmanScreenHtml, wordSearchScreenHtml, resultSheetHtml, fmtClock, GAME_META } from '../src/juegos.js';
import { memoryCreate, hangmanCreate, wordSearchCreate } from '../src/juegos-engine.js';
import { bootApp } from './helpers/ui-harness.mjs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('fmtClock: da formato mm:ss', () => {
  assert.equal(fmtClock(0), '00:00'); assert.equal(fmtClock(65), '01:05'); assert.equal(fmtClock(3661), '61:01'); assert.equal(fmtClock(-5), '00:00');
});

test('Hub de Juegos PRO: puntos, botón de ranking y las 6 tarjetas (3 jugables, 3 "Próximamente")', () => {
  const d = dom(juegosHubHtml({ resumen: { totalPoints: 1280 } }));
  assert.match(d.body.textContent, /Puntos: 1,280/);
  assert.ok(d.querySelector('#jgOpenRanking'));
  const cards = [...d.querySelectorAll('.jg-card')];
  assert.equal(cards.length, 6);
  const ready = cards.filter(c => !c.disabled);
  assert.deepEqual(ready.map(c => c.dataset.jgOpen).sort(), ['BASKETBALL', 'COLOR_CHALLENGE', 'DARTS', 'HANGMAN', 'MEMORY_PAIRS', 'WORD_SEARCH'].sort()); // R55: los 6 ya se juegan
  for (const c of cards.filter(c => c.disabled)) assert.match(c.textContent, /Próximamente/);
  assert.ok(d.querySelector('#jgRankBack'), 'R53: el hub vuelve al tablero de Juegos');
  const err = dom(juegosHubHtml({ error: 'sin red' }));
  assert.ok(err.querySelector('#jgRetry')); assert.match(err.body.textContent, /sin red/);
});

test('Tablero de puntajes: pestañas, mi tarjeta y la tabla (general trae racha e insignia; semanal y por juego no)', () => {
  const data = { me: { rank: 3, score: 1280 }, entries: [{ userId: 'libni', displayName: 'Libni', score: 2450, streak: 25, badge: 'Leyenda' }, { userId: 'naara', displayName: 'Naara', score: 1280, streak: 12, badge: 'Explorador' }] };
  const d = dom(leaderboardHtml({ scope: 'general', data, me: 'naara', myTotals: { totalPoints: 1280, streak: { current: 12 }, badge: { code: 'EXPLORADOR', name: 'Explorador' }, byGame: { MEMORY_PAIRS: 220, HANGMAN: 310, WORD_SEARCH: 420 } } }));
  assert.deepEqual([...d.querySelectorAll('[data-jg-scope]')].map(b => b.dataset.jgScope), ['general', 'semanal', 'porJuego']);
  assert.equal(d.querySelector('.jg-tabs .on').dataset.jgScope, 'general');
  assert.match(d.querySelector('.jg-mecard').textContent, /1,280/);
  assert.equal(d.querySelectorAll('.jg-table tbody tr').length, 2);
  assert.ok(d.querySelector('.jg-table tr.me'), 'la fila del usuario actual se resalta');
  assert.equal(d.querySelectorAll('.jg-bygame-card').length, 6);
  const loading = dom(leaderboardHtml({ loading: true })); assert.ok(loading.querySelector('.spinner'));
  const err = dom(leaderboardHtml({ error: 'falló' })); assert.match(err.body.textContent, /falló/);
  const semanal = dom(leaderboardHtml({ scope: 'semanal', data: { entries: [] } }));
  assert.match(semanal.body.textContent, /Todavía no hay resultados/);
});

test('Pares de cartas: pantalla muestra progreso, combo, movimientos y bloquea "Finalizar" hasta terminar', () => {
  const s = memoryCreate(12, () => 0.4);
  const d = dom(memoryScreenHtml({ state: s, timeLeftSec: 95, finished: false }));
  assert.equal(d.querySelectorAll('[data-jg-flip]').length, 24);
  assert.match(d.body.textContent, /01:35/);
  assert.equal(d.querySelector('#jgFinish').disabled, true);
  const done = dom(memoryScreenHtml({ state: { ...s, pairsFound: 12 }, timeLeftSec: 10, finished: true }));
  assert.equal(done.querySelector('#jgFinish').disabled, false);
});

test('El ahorcado: muestra la categoría, la pista, corazones de vidas y bloquea letras ya usadas', () => {
  let s = hangmanCreate(1, 7, 2, () => 0);
  const letter = s.rounds[0].word[0];
  const before = dom(hangmanScreenHtml({ state: s, timeLeftSec: 120 }));
  assert.equal(before.querySelectorAll('.jg-heart:not(.off)').length, 7);
  assert.match(before.body.textContent, new RegExp(s.rounds[0].clue.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  const key = before.querySelector(`[data-jg-letter="${letter}"]`); assert.ok(key && !key.disabled);
});

test('Sopa de letras: dibuja la rejilla del tamaño correcto y la lista de palabras con su progreso', () => {
  const s = wordSearchCreate(12, 0, () => 0.6);
  const d = dom(wordSearchScreenHtml({ state: s, timeLeftSec: 200 }));
  assert.equal(d.querySelectorAll('[data-jg-cell]').length, 144);
  assert.equal(d.querySelectorAll('.jg-ws-list li').length, s.words.length);
  assert.ok(d.body.textContent.includes(`0/${s.words.length}`));
});

test('Hoja de resultado: carga → listo (con racha/insignia) → error, y todas cierran con data-sr-cancel', () => {
  assert.ok(dom(resultSheetHtml({ status: 'loading' })).querySelector('.spinner'));
  const done = dom(resultSheetHtml({ status: 'done', awardedPoints: 750, totalPoints: 2030, streak: { current: 4 }, badge: { code: 'AVANZADO', name: 'Avanzado' } }));
  assert.match(done.body.textContent, /\+750 SP/); assert.match(done.body.textContent, /2,030/); assert.match(done.body.textContent, /Avanzado/);
  assert.ok(done.querySelector('[data-sr-cancel]'));
  const rep = dom(resultSheetHtml({ status: 'done', awardedPoints: 750, totalPoints: 2030, repetido: true }));
  assert.match(rep.body.textContent, /ya se había guardado/);
  const err = dom(resultSheetHtml({ status: 'error', error: 'sin red' }));
  assert.match(err.body.textContent, /sin red/); assert.ok(err.querySelector('[data-sr-cancel]'));
});

test('main.js: Materia cerebral abre Juegos PRO real (backend con puntos oficiales), no un aviso', () => {
  assert.match(api, /export async function juegosResumen\(\) \{ return authPost\('\/api\/juegos', \{ accion: 'resumen' \}\); \}/);
  assert.match(api, /export async function juegosRegistrar\(gameCode, roundId, metrics\)/);
  assert.match(api, /export async function juegosRanking\(scope, extra = \{\}\)/);
  assert.match(main, /function juegosStart\(code\)/);
  assert.match(main, /function juegosFinish\(\)/);
  assert.match(main, /juegosRegistrar\(j\.gameCode, genRoundId\(\), sub\)/);
  assert.match(main, /setInterval\(\(\)=>\{ if \(state\.session && state\.subview==='materia'\) juegosTick\(\); \},1000\)/);
  assert.match(main, /if\(id==='materia'\)\{state\.juegos\.screen='ranking';state\.juegos\.engine=null;ensureJuegosResumen\(\);await juegosLoadRanking/); // R53: entra directo al tablero Juegos
});

test('Juegos PRO de punta a punta en la app: navegar, jugar Sopa de letras tocando el tablero real y guardar puntos oficiales', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    assert.ok(app.$('.jg2-page'), 'R53: abre directo el tablero Juegos (no el aviso de "módulo conservado")');
    assert.doesNotMatch(app.$('.jg-page').textContent, /La reestructuración conserva este módulo/);
    assert.match(app.$('.jg-page').textContent, /Mis puntos por juego/);

    await app.click('[data-jg-play="WORD_SEARCH"]', 250);
    assert.ok(app.$('.jg-ws-grid'), 'entra a Sopa de letras');
    // Leemos el tablero y la lista de palabras EXACTAMENTE como las vería un jugador (nada de estado interno).
    const size = Math.sqrt(app.$$('[data-jg-cell]').length);
    const grid = []; app.$$('[data-jg-cell]').forEach(b => { const [r, c] = b.dataset.jgCell.split(',').map(Number); (grid[r] ||= [])[c] = b.textContent.trim(); });
    const words = app.$$('.jg-ws-list li').map(li => li.textContent.replace(/^[✓•]\s*/, '').trim());
    const DIRS = [[0, 1], [1, 0], [1, 1], [1, -1], [0, -1], [-1, 0], [-1, -1], [-1, 1]];
    const locate = word => {
      for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) for (const [dr, dc] of DIRS) {
        const r1 = r + dr * (word.length - 1), c1 = c + dc * (word.length - 1);
        if (r1 < 0 || r1 >= size || c1 < 0 || c1 >= size) continue;
        let ok = true; for (let i = 0; i < word.length; i++) if (grid[r + dr * i][c + dc * i] !== word[i]) { ok = false; break; }
        if (ok) return [[r, c], [r1, c1]];
      }
      return null;
    };
    const [start, end] = locate(words[0]);
    await app.click(`[data-jg-cell="${start[0]},${start[1]}"]`, 120);
    await app.click(`[data-jg-cell="${end[0]},${end[1]}"]`, 150);
    assert.match(app.$('.jg-ws-list li').textContent, /^✓/, 'la primera palabra quedó marcada como encontrada tocando el tablero real');
    // El resto se completa con pistas (acción real y visible) para llegar al final sin adivinar a ciegas.
    for (let i = 1; i < words.length; i++) { await app.click('#jgHint', 80); }
    assert.equal(app.$('#jgFinish').disabled, false, 'con las 12 palabras encontradas, Finalizar ya no está bloqueado');
    await app.click('#jgFinish', 300);
    assert.ok(app.calls.some(c => c.path === '/api/juegos' && c.action === 'registrar' && c.resource === ''), 'se llamó a /api/juegos a registrar la partida');
    await app.click('[data-sr-cancel]', 250);
    assert.ok(app.$('.jg-page'), 'vuelve al hub tras cerrar el resultado');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), [], 'ninguna acción lanzó errores');
  } finally { app.close(); }
});

test('Juegos PRO: El ahorcado y el Tablero de puntajes también se pueden abrir sin errores', async () => {
  const app = await bootApp({ role: 'relojes' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="materia"]', 400);
    await app.click('[data-jg-play="HANGMAN"]', 250);
    assert.ok(app.$('.jg-keyboard'));
    await app.click('#jgQuit', 200);
    assert.ok(app.$('.jg2-page'), 'R53: salir de una partida regresa al tablero Juegos');
    await app.click('#jgGoHub', 200);
    assert.ok(app.$('.jg-grid'), 'desde el tablero se llega a la lista de juegos');
    await app.click('#jgOpenRanking', 300);
    assert.ok(app.$('.jg-table') || app.$('.spinner') || app.$('.jg-empty'), 'abre el tablero de puntajes');
    await app.click('[data-jg-scope="semanal"]', 300);
    assert.equal(app.$('.jg-tabs .on')?.dataset.jgScope, 'semanal');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
