import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');

test('R63 Clientes: Vigentes = Hoy + Próximos (un cliente con servicio hoy y otro después cuenta una sola vez)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 400);
    const n = s => Number((app.$(`[data-client-status="${s}"]`)?.textContent.match(/\d+/) || [0])[0]);
    assert.equal(n('vigentes'), n('hoy') + n('proximos'));
    await app.click('[data-client-status="proximos"]', 250);
    await app.click('[data-client-status="hoy"]', 250);
  } finally { app.close(); }
});
test('R63 Sopa: botón Nueva ronda compacto', () => {
  assert.match(css, /\.ws-new\{width:auto!important;min-width:160px;margin:2px auto 0;display:flex!important;min-height:36px!important/);
});
