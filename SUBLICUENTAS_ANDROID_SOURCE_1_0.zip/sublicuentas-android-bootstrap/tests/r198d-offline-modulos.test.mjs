// R198d · Fase 4 del PDF «Sublichat APK: modo offline completo»: Finanzas, Panel de Socios, Sala de Juntas, Partidos y Pelis
// muestran lo último guardado con sello («dato histórico», «NO en vivo») y nunca fingen pago, mensaje, reunión ni resultado.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { miniIndexedDB } from './helpers/mini-idb.mjs';

const dev = () => ({ idb: miniIndexedDB(), seguro: new Map(), local: new Map(), avion: false });
const PARTIDOS = { ok: true, hoy: '2026-10-04', partidos: [
  { liga: 'Liga Nacional', local: 'Equipo Azul', visita: 'Equipo Rojo', golesLocal: 1, golesVisita: 0, estado: '2H', horaHN: 'sáb, 4 oct, 07:00 p. m.', fechaISO: '2026-10-04T19:00:00-06:00' },
  { liga: 'Liga Nacional', local: 'Equipo Verde', visita: 'Equipo Gris', estado: 'NS', horaHN: 'sáb, 4 oct, 09:00 p. m.', fechaISO: '2026-10-04T21:00:00-06:00' }] };
const COMPRA = { id: 'web_prueba01', socio: 'Socio Uno', socio_norm: 'socio uno', estado: 'pendiente', clientePrincipal: { nombre: 'Cliente', apellido: 'Ficticio' }, productos: [{ renglonId: 'r1', servicio: 'Prime Video' }], monto: 120, banco: 'BAC', entregaResumen: { estado: 'pendiente', publicados: 0, requeridos: 1 } };
const extra = async (path, b) => {
  if (path === '/api/partidos') return PARTIDOS;
  if (path === '/api/revendedores-admin' && b.ruta === 'compras') return [COMPRA];
  return undefined;
};
async function verYcerrar(d, abrir) {
  const a = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try { await a.sleep(800); for (const id of abrir) { await a.click('[data-tab="mas"]', 300); await a.click(`[data-open="${id}"]`, 1500); } await a.sleep(1200); d.guardarLocal(); } finally { a.close(); }
}

test('14 · Partidos sin señal: última programación guardada con sello y el partido que estaba en juego NO sale «EN VIVO»', async () => {
  const d = dev(); await verYcerrar(d, ['partidos']); d.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try {
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="partidos"]', 300);
    await b.waitFor(() => /Equipo Azul/.test(b.$('.app-main')?.textContent || ''), 5000);
    const t = b.$('.app-main').textContent;
    assert.match(t, /Equipo Azul/); assert.match(t, /Equipo Verde/);
    assert.equal(b.$('.mt-live'), null, 'una copia nunca dice «EN VIVO»');
    assert.match(t, /marcador guardado, NO en vivo/);
    assert.match(b.$('.offline-band').textContent, /programación guardada del \d{2}\/\d{2}\/\d{4}.*los marcadores NO son en vivo/);
  } finally { b.close(); }
});

test('Finanzas sin señal: último resumen como «dato histórico»; Panel de Socios: pedidos guardados y entregar requiere internet', async () => {
  const d = dev(); await verYcerrar(d, ['finanzas', 'socios-entregas']); d.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try {
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="finanzas"]', 300);
    await b.waitFor(() => /dato histórico/.test(b.$('.offline-band')?.textContent || ''), 5000);
    assert.match(b.$('.offline-band').textContent, /Finanzas: resumen guardado del .*dato histórico.*no se registra ni se contabiliza nada/);
    assert.doesNotMatch(b.$('.app-main').textContent, /Failed to fetch/);
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="socios-entregas"]', 900);
    assert.ok(await b.waitFor(() => /Cliente Ficticio/.test(b.$('.app-main')?.textContent || '')), 'pedidos guardados visibles');
    assert.match(b.$('.offline-band').textContent, /Pedidos de socios guardados del .*requiere internet/);
  } finally { b.close(); }
});

test('Pantalla nunca abierta con señal: aviso claro, sin inventar datos ni spinner eterno', async () => {
  const d = dev(); await verYcerrar(d, []); d.avion = true;
  const b = await bootApp({ role: 'sublicuentas', dispositivo: d, fetchExtra: extra });
  try {
    await b.click('[data-tab="mas"]', 300); await b.click('[data-open="partidos"]', 300);
    assert.ok(await b.waitFor(() => /no se había descargado/.test(b.$('.app-main')?.textContent || ''), 5000));
    assert.doesNotMatch(b.$('.app-main').textContent, /Equipo Azul/);
  } finally { b.close(); }
});

test('Código: Sala, Socios y Finanzas leen con copia y bloquean escrituras sin señal; mensajes nunca «enviados»', () => {
  const sala = fs.readFileSync(new URL('../src/app/sala-juntas.js', import.meta.url), 'utf8');
  assert.match(sala, /if \(escribe && sinRed\(\)\) throw new Error\('Sin conexión: esta acción de la Sala \(reunión, invitación, grabación o cambio\) requiere internet\. No se envió nada\.'\)/);
  assert.match(sala, /leerConCopia\('sala'/); assert.match(sala, /Entrar a la reunión, grabar e invitar requieren internet/);
  const so = fs.readFileSync(new URL('../src/app/socios-entregas.js', import.meta.url), 'utf8');
  assert.match(so, /if \(metodo !== 'GET' && sinRed\(\)\)/); assert.match(so, /leerConCopia\('socios'/);
  const fl = fs.readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  assert.equal((fl.match(/leerFin\(ctx, \{ accion: '(finanzas_resumen|finanzas_mes|finanzas_movimientos|listar_pendientes)'/g) || []).length, 4, 'solo LECTURAS con copia');
  const oc = fs.readFileSync(new URL('../src/app/offline-consulta.js', import.meta.url), 'utf8');
  assert.match(oc, /VIGENCIA_VISTA = Object\.freeze\(\{ fin: 2 \* 86400000 \}\)/); assert.match(oc, /data: sinSecretos\(r\)/);
  const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
  assert.match(api, /if \(mutation && isNetworkError\(e\)\) throw Object\.assign\(new Error\('Sin conexión: no se envió ni se guardó nada/);
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /async function launchWhatsApp\(packageName\) \{ if\(deviceOffline\(\)\)showToast\('📴 Sin conexión: el mensaje NO se ha enviado/);
  assert.ok(main.split('\n').length < 2000);
});
