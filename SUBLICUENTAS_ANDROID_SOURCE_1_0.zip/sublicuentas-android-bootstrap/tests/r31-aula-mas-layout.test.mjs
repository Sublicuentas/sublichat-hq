import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { COURSES } from '../src/academia-data.js';
import {
  aulaDashboardHtml, aulaLessonHtml, aulaSettingsHtml, aulaUserKey, aulaUserName, aulaEarnedBadges, aulaCategories,
} from '../src/aula.js';
import { moviesContentHtml, matchesContentHtml, subliContentHtml, subliClientsPayload, todayHN, matchDayKey } from '../src/more.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('Aula: el panel copia la Academia web (cabecera, XP, logros, filtros y ruta de 60 niveles)', () => {
  const d = dom(aulaDashboardHtml({ done: [0, 1, 2], cat: 'Todos', usuario: 'sublicuentas' }));
  assert.match(d.querySelector('.dashHead h2').textContent, /Hola, Naara/);
  assert.equal(d.querySelectorAll('.stats .stat').length, 3);
  assert.equal(d.querySelectorAll('.badges .badge-pill').length, 11);
  assert.equal(d.querySelectorAll('.filter-btn').length, aulaCategories().length);
  assert.equal(d.querySelectorAll('.path .node').length, COURSES.length);
  assert.equal(d.querySelectorAll('.node.done').length, 3);
  assert.equal(d.querySelectorAll('.node.current').length, 1);
  assert.equal(d.querySelectorAll('.node.locked').length, COURSES.length - 4);
  assert.ok(d.querySelector('.coach-mascot svg'), 'mascota coach');
  assert.ok(d.querySelector('.avatar svg'), 'avatar del agente');
  const ids = [...d.querySelectorAll('[id]')].map(n => n.id);
  assert.equal(new Set(ids).size, ids.length, 'ids de SVG únicos (si no, se pisan los degradados)');
});

test('Aula: filtro por categoría muestra solo esa categoría', () => {
  const cat = aulaCategories()[1];
  const d = dom(aulaDashboardHtml({ done: [], cat, usuario: 'libni' }));
  const expected = COURSES.filter(c => c.cat === cat).length;
  assert.equal(d.querySelectorAll('.path .node').length, expected);
  assert.match(d.querySelector('.dashHead h2').textContent, /Libni/);
});

test('Aula: la lección sigue el orden de la web y el nivel se completa al contestar todo el quiz', () => {
  const c = COURSES[0];
  const blank = dom(aulaLessonHtml({ i: 0, done: [], sel: {}, usuario: 'naara' }));
  for (const t of ['Por qué importa', 'Cómo se hace', 'Ejemplos reales', '¿Cómo responderías?', 'Quiz del nivel', 'Consejo para hoy']) {
    assert.match(blank.body.textContent, new RegExp(t), t);
  }
  assert.equal(blank.querySelector('#academiaComplete').disabled, true);
  const sel = {};
  c.quiz.forEach((q, qi) => { sel[`0-q-${qi}`] = q.correct; });
  const full = dom(aulaLessonHtml({ i: 0, done: [], sel, usuario: 'naara' }));
  assert.equal(full.querySelector('#academiaComplete').disabled, false);
  assert.match(full.querySelector('.grade-box').textContent, /Nota: \d+\/\d+ \(100%\)/);
  assert.equal(full.querySelectorAll('.q-item .choice.good').length, c.quiz.length);
});

test('Aula: ajustes con 16 avatares y 16 mascotas y alias de usuario como la web', () => {
  const d = dom(aulaSettingsHtml({ usuario: 'relojes', avatar: 3, mascot: 4 }));
  assert.equal(d.querySelectorAll('[data-aula-avatar]').length, 16);
  assert.equal(d.querySelectorAll('[data-aula-mascot]').length, 16);
  assert.equal(d.querySelector('.avatar-tile.on').dataset.aulaAvatar, '3');
  assert.equal(d.querySelector('.mascot-tile.on').dataset.aulaMascot, '4');
  assert.equal(aulaUserKey('sublicuentas'), 'naara');
  assert.equal(aulaUserKey('relojes'), 'libni');
  assert.equal(aulaUserKey('Geissel'), 'geisell');
  assert.equal(aulaUserName('geisell'), 'Geisell');
  assert.ok(aulaEarnedBadges([0]).includes('Primer paso'));
});

test('Aula: el CSS de la web está copiado y limitado a .aula (no pisa el resto de la app)', () => {
  for (const sel of ['.aula .dashHead', '.aula .path', '.aula .node', '.aula .lesson', '.aula .choice.good', '.aula .avatar-grid']) {
    assert.ok(css.includes(sel), `falta ${sel}`);
  }
  assert.match(css, /@keyframes aula-pulse/);
  assert.doesNotMatch(css, /^\.node\{/m);
});

test('Más: Pelis, Partidos y Subli ya están conectados', () => {
  assert.match(main, /if \(state\.subview==='pelis'\) return moviesView\(\)/);
  assert.match(main, /if \(state\.subview==='partidos'\) return matchesView\(\)/);
  assert.match(main, /if \(state\.subview==='subli'\) return subliView\(\)/);
  assert.match(main, /if\(id==='nuevo-crm'\)\{state\.active='nuevo-crm'/);
  assert.match(api, /'\/api\/tmdb'/);
  assert.match(api, /'\/api\/partidos'/);
  assert.match(api, /'\/api\/chat', \{ pregunta/);
  assert.match(api, /accion:'ajustes'/);
});

test('Pelis y Partidos muestran resultados con plataformas y marcadores', () => {
  const movies = dom(moviesContentHtml({ query: 'Matrix', results: [{ titulo: 'Matrix', tipo: 'Película', anio: '1999', rating: 8.2, poster: null, sinopsis: 'Neo', proveedores: ['Netflix', 'Max'] }] }));
  assert.equal(movies.querySelectorAll('.mv-card').length, 1);
  assert.equal(movies.querySelectorAll('.mv-chips b').length, 2);
  assert.match(moviesContentHtml({ results: [] }), /Sin resultados/);
  const matches = dom(matchesContentHtml({ mode: 'nba', matches: [
    { liga: 'NBA', local: 'Lakers', visita: 'Celtics', golesLocal: 101, golesVisita: 99, estado: 'FT', horaHN: '8:00 p. m.', canal: 'ESPN' },
    { liga: 'NBA', local: 'Heat', visita: 'Bulls', golesLocal: null, golesVisita: null, estado: 'NS', horaHN: '9:00 p. m.' },
  ] }));
  assert.equal(matches.querySelectorAll('.mt-group').length, 1);
  assert.equal(matches.querySelectorAll('.mt-row').length, 2);
  assert.match(matches.body.textContent, /101 - 99/);
  assert.equal(matches.querySelector('[data-match-mode="nba"]').className, 'active');
});

test('Subli: chat y cartera con el mismo formato que Sublichat web', () => {
  const html = subliContentHtml({ messages: [{ role: 'user', text: 'hola' }, { role: 'bot', text: 'ok' }] });
  assert.equal(dom(html).querySelectorAll('.sb-msg.me').length, 1);
  const today = new Date(2026, 8, 21);
  const payload = subliClientsPayload([{ nombrePerfil: 'Ana', telefono: '999', vendedor: 'Relojes', servicios: [
    { plataforma: 'disneyp', precio: 90, fechaRenovacion: '21/09/2026', correo: 'a@a.com' },
    { plataforma: 'netflix', precio: 130, fechaRenovacion: '01/09/2026' },
    { plataforma: 'evoutouch2', precio: 200, fechaRenovacion: '30/09/2026' },
  ] }], today);
  assert.deepEqual(payload[0].cuentas.map(c => c.estado), ['vence hoy', 'vencido', 'vigente']);
  assert.equal(payload[0].cuentas[0].renueva, '2026-09-21');
  assert.equal(payload[0].cuentas[2].plataforma, 'Nanotech (2 dispositivos)');
});

test('Tickets: la pestaña inferior ya dispara la carga (antes quedaba "Cargando tickets…" para siempre)', () => {
  assert.match(main, /if\(state\.active==='tickets'\)await ensureTickets\(\);\}\)\);/);
  assert.match(main, /function afterRender\(\)/);
  assert.match(main, /!state\.ticketsLoaded && !state\.ticketsFetching && !state\.errors\.tickets\) ensureTickets\(\)/);
  assert.match(main, /id="ticketsRetry"/);
});

test('Cobros: filtro por vendedor', () => {
  assert.match(main, /id="renewSellerFilter"/);
  assert.match(main, /state\.renewSeller/);
  assert.match(main, /renewSellerFilter'\)\?\.addEventListener\('change'/);
});

test('Diseño: footer anclado abajo, Inicio fijo y botones de la ficha CRM compactos', () => {
  assert.match(css, /\.bottom-nav\{left:0!important;right:0!important;bottom:0!important/);
  assert.match(css, /\.app-main\.home-fixed\{[^}]*overflow:hidden/);
  assert.match(css, /\.module-grid\{grid-template-columns:repeat\(2,minmax\(0,1fr\)\)\}/);
  assert.match(css, /\.crm-form button\{min-height:40px!important/);
  assert.match(main, /shell\.classList\.add\('home-fixed'\)/);
});

test('Scroll: solo Inicio se fija; el resto de pantallas conserva el scroll normal', () => {
  // html/body con overflow-x u overscroll-behavior convierten el body en contenedor de scroll y matan el gesto en Android WebView.
  assert.doesNotMatch(css, /(^|\})\s*html\s*,\s*body\s*\{[^}]*(overflow-x\s*:\s*hidden|overscroll-behavior)/m);
  assert.doesNotMatch(css, /\.app-main\{[^}]*overflow-x\s*:\s*hidden/);
  assert.doesNotMatch(css, /body\.home-lock\{/);
  // La clase de fijado vive en el <main> de cada render: no puede quedarse pegada al cambiar de pantalla.
  assert.doesNotMatch(main, /document\.body\.classList\.add\('home-lock'\)/);
  assert.match(main, /state\.active==='inicio'\)\s*\{/);
});

test('Inicio: el hero no cuenta dos veces el área segura (el robot pisaba campana y avatar)', () => {
  assert.match(css, /\.visual-home-hero\{margin-top:calc\(-18px - env\(safe-area-inset-top\)\)!important;min-height:calc\(248px \+ env\(safe-area-inset-top\)\)!important\}/);
});

test('Partidos: "Hoy" muestra solo partidos de hoy (hora Honduras) y lo dice claro cuando no hay', () => {
  const today = '2026-09-20';
  assert.equal(todayHN(new Date('2026-09-20T18:00:00Z')), '2026-09-20');
  assert.equal(todayHN(new Date('2026-09-21T03:00:00Z')), '2026-09-20', 'a las 9 p. m. de Honduras sigue siendo el mismo día');
  // versión vieja de /api/partidos: solo trae horaHN
  assert.equal(matchDayKey({ horaHN: 'dom, 20 sept, 11:30 a. m.' }, today), '2026-09-20');
  assert.equal(matchDayKey({ horaHN: 'mar, 22 sept, 05:00 p. m.' }, today), '2026-09-22');
  assert.equal(matchDayKey({ horaHN: 'jue, 1 oct, 10:30 p. m. · Semifinal' }, today), '2026-10-01');
  assert.equal(matchDayKey({ horaHN: 'sáb, 3 ene, 08:00 p. m.' }, '2026-12-28'), '2027-01-03');
  // versión nueva: trae dia
  assert.equal(matchDayKey({ dia: '2026-09-20', horaHN: 'x' }, today), '2026-09-20');

  const todayGame = { liga: 'Premier League', local: 'Arsenal', visita: 'Chelsea', estado: 'NS', horaHN: 'dom, 20 sept, 11:30 a. m.' };
  const later = { liga: 'UFC', local: 'A', visita: 'B', estado: 'NS', horaHN: 'mar, 22 sept, 05:00 p. m.' };
  const withToday = dom(matchesContentHtml({ mode: 'hoy', matches: [later, todayGame], today }));
  assert.match(withToday.querySelector('.mt-day').textContent, /^Hoy · /);
  assert.equal(withToday.querySelectorAll('.mt-row').length, 1, 'solo el partido de hoy');
  assert.deepEqual([...withToday.querySelectorAll('.mt-liga')].map(x => x.textContent), ['Premier League']);

  const onlyLater = dom(matchesContentHtml({ mode: 'hoy', matches: [later], today }));
  assert.ok(onlyLater.querySelector('.mt-note'), 'aviso de que hoy no hay partidos');
  assert.match(onlyLater.body.textContent, /próximos eventos/);
  assert.doesNotMatch(onlyLater.body.textContent, /Hoy · /);

  // el servidor puede avisar soloProximos aunque el día coincida
  const flagged = dom(matchesContentHtml({ mode: 'hoy', matches: [todayGame], today, meta: { soloProximos: true } }));
  assert.ok(flagged.querySelector('.mt-note'));

  // otras pestañas no filtran por día
  assert.equal(dom(matchesContentHtml({ mode: 'ufc', matches: [later, todayGame], today })).querySelectorAll('.mt-row').length, 2);
  assert.match(main, /state\.matchMeta=\{hoy:String\(data\?\.hoy\|\|''\),soloProximos:Boolean\(data\?\.soloProximos\),parcial:Boolean\(data\?\.parcial\)\}/);
});
