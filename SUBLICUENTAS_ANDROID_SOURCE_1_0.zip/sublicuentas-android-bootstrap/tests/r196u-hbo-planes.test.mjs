// R196u Fase 3 · APK: HBO Platinum 5 / Standard 3 (lista, detalle y selector de cuenta). Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { planHboTexto, inventoryDetailHtml } from '../src/screens2.js';
const sel = fs.readFileSync(new URL('../src/app/selector-cuenta.js', import.meta.url), 'utf8');
const cli = (n) => Array.from({ length: n }, (_, i) => ({ clienteId: 'c' + i, nombre: 'Cliente ' + i }));

test('HBO-01 · APK muestra Platinum x/5, Standard x/3 y «Plan sin definir» en cuentas viejas', () => {
  assert.equal(planHboTexto({ plataforma: 'hbomax', planHbo: 'platinum', clientes: cli(4) }), 'Platinum 4/5');
  assert.equal(planHboTexto({ plataforma: 'hbomax', planHbo: 'standard', ocupados: 2 }), 'Standard 2/3');
  assert.equal(planHboTexto({ plataforma: 'hbomax', capacidad: 5, clientes: cli(4) }), 'Plan sin definir · 4/5');
  const html = inventoryDetailHtml({ item: { plataforma: 'hbomax', planHbo: 'standard', correo: 'hbo1@ejemplo.com', capacidad: 3, clientes: cli(1) }, label: 'HBO Max' });
  assert.match(html, /📦 Plan HBO/); assert.match(html, /Standard 1\/3/);
  assert.doesNotMatch(inventoryDetailHtml({ item: { plataforma: 'netflix', correo: 'n@ejemplo.com', capacidad: 5 } }), /Plan HBO/);
  assert.match(sel, /planHboTexto\(it\)/, 'el selector de venta muestra el plan');
});
