import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=appSource();
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R22 uses complete approved card artwork instead of cropped icon fragments',()=>{
  for (const asset of ['01_sala_de_juntas','02_control_financiero','03_control_maestro','04_recordatorios','05_pelis_y_estrenos']) assert.match(main,new RegExp(asset)); // R196w
  assert.doesNotMatch(main,/metric-icon-today\.png/);
  assert.doesNotMatch(main,/tool-icon-aula\.png/);
  assert.doesNotMatch(main,/07_vence_hoy_20\.png|08_proximos_27\.png|09_vencidos_39\.png/);
});
test('R21.8 cards do not rebuild artwork with cropped image containers',()=>{
  assert.doesNotMatch(main,/class="metric-icon"/);
  assert.doesNotMatch(main,/class="home-tool-icon"><img/);
  assert.match(css,/R21\.8/);
});
