import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R22 uses complete approved card artwork instead of cropped icon fragments',()=>{
  for (const asset of ['10_aula_de_clases.png','11_control_financiero.png','12_materia_cerebral.png','13_clientes.png','15_tickets_y_avisos.png']) assert.match(main,new RegExp(asset.replaceAll('.','\\.')));
  assert.doesNotMatch(main,/metric-icon-today\.png/);
  assert.doesNotMatch(main,/tool-icon-aula\.png/);
  assert.doesNotMatch(main,/07_vence_hoy_20\.png|08_proximos_27\.png|09_vencidos_39\.png/);
});
test('R21.8 cards do not rebuild artwork with cropped image containers',()=>{
  assert.doesNotMatch(main,/class="metric-icon"/);
  assert.doesNotMatch(main,/class="home-tool-icon"><img/);
  assert.match(css,/R21\.8/);
});
