import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildCrmUpsertPayload, buildRenewalPayload, buildNoRenewalPayload, intOrNull } from '../src/api.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8') + '\n' + fs.readFileSync(new URL('../src/screens2.js', import.meta.url), 'utf8');
const cap = JSON.parse(fs.readFileSync(new URL('../capacitor.config.json', import.meta.url), 'utf8'));
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

const nueva = { nombrePerfil: 'Juan', telefono: '99999999', plataforma: 'netflix', vendedor: 'Relojes', precio: 150, fechaRenovacion: '20/10/2026', correo: 'prueba@capuchino.lat', clave: 'x', pinPerfil: '3300' };

test('CRM: una venta NUEVA no manda índice de servicio (antes mandaba 0 y el servidor decía "cambió de posición")', () => {
  assert.equal(intOrNull(null), null);
  assert.equal(intOrNull(undefined), null);
  assert.equal(intOrNull(''), null);
  assert.equal(intOrNull('  '), null);
  assert.equal(intOrNull(-1), null);
  assert.equal(intOrNull('x'), null);
  assert.equal(intOrNull(0), 0);
  assert.equal(intOrNull('2'), 2);
  assert.equal(buildCrmUpsertPayload({ ...nueva, servicioIndex: null }).servicioIndex, null);
  assert.equal(buildCrmUpsertPayload({ ...nueva }).servicioIndex, null);
  assert.equal(buildCrmUpsertPayload({ ...nueva, servicioIndex: '' }).servicioIndex, null);
  // editar un servicio existente sí conserva su índice
  assert.equal(buildCrmUpsertPayload({ ...nueva, servicioIndex: 0 }).servicioIndex, 0);
  assert.equal(buildCrmUpsertPayload({ ...nueva, servicioIndex: 3 }).servicioIndex, 3);
  assert.equal(buildRenewalPayload({ clienteId: 'c1', plataforma: 'netflix', servicioIndex: null }).servicioIndex, null);
  assert.equal(buildRenewalPayload({ clienteId: 'c1', plataforma: 'netflix', servicioIndex: 1 }).servicioIndex, 1);
  assert.equal(buildNoRenewalPayload({ clienteId: 'c1', servicioIndex: null }).servicioIndex, null);
});

test('CRM: si el guardado falla, la ficha NO se reinicia', () => {
  const start = main.indexOf('async function saveCrm(');
  const block = main.slice(start, main.indexOf('\n}\n', start));
  assert.match(block, /const d=readCrmDraftFromDom\(\);[\s\S]*state\.crmDraft=d;[\s\S]*validateCrmDraft\(d\)/);
});

test('Perfil y Tickets: el botón atrás vuelve a la pantalla anterior', () => {
  assert.match(main, /if\(!state\.subview&&\['perfil','tickets','catalogo'\]\.includes\(state\.active\)\)/);
  assert.match(main, /state\.active=\(state\.backTo&&state\.backTo!==state\.active\)\?state\.backTo:'inicio'/);
  assert.match(main, /if\(directRoutes\.includes\(id\)\)state\.backTo=state\.active;/);
  assert.match(main, /state\.backTo='';state\.active=btn\.dataset\.tab/);
});

test('Avisos: la bandeja se refresca sola y muestra las respuestas que llegan por Telegram', () => {
  assert.match(main, /async function ensureTickets\(force=false\)/);
  assert.match(main, /function refreshTicketsSilently\(\)/);
  assert.match(main, /setInterval\(\(\)=>\{[\s\S]*refreshTicketsSilently\(\);[\s\S]*\},15000\)/);
  assert.match(main, /ticketMsgWho\(m,thread,mi\)/);
  assert.match(main, /id="ticketsRefresh"/);
  // la caja de respuesta conserva lo escrito y el envío confirma con el resultado real
  assert.match(main, /state\.ticketReplyText=e\.target\.value/);
  assert.match(main, /telegramToast\(result,'Respuesta enviada'\)/);
  // no se refresca mientras se escribe
  assert.match(main, /\/\^\(INPUT\|TEXTAREA\|SELECT\)\$\/\.test\(ae\.tagName\)/);
});

test('La app se llama Sublichat (el paquete com.sublicuentas.app no cambia)', () => {
  assert.equal(cap.appName, 'Sublichat');
  assert.equal(cap.appId, 'com.sublicuentas.app');
  assert.match(html, /<title>Sublichat<\/title>/);
});
