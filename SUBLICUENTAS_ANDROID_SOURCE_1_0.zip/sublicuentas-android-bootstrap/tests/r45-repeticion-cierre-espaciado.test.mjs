import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildChargeAiPayload } from '../src/api.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const calc = fs.readFileSync(new URL('../src/calculadora.js', import.meta.url), 'utf8');

const G = { nombre: 'Ana Paz', total: 150, fechaRenovacion: '21/10/2026', servicios: [{ plataforma: 'netflix', precio: 150 }] };

test('Mensaje con IA: ahora recibe el historial de la sesión y un estilo al azar, para no repetirse entre clientes', () => {
  const p1 = buildChargeAiPayload(G, 'mensaje actual', '2026-09-21', ['mensaje viejo 1', 'mensaje viejo 2']);
  assert.match(p1.pregunta, /MENSAJES YA USADOS EN ESTA CONVERSACIÓN/);
  assert.match(p1.pregunta, /\(1\) mensaje actual/);
  assert.match(p1.pregunta, /mensaje viejo 1/);
  assert.match(p1.pregunta, /mensaje viejo 2/);
  assert.match(p1.pregunta, /ESTILO DE ESTE MENSAJE:/);
  const noHist = buildChargeAiPayload(G, '', '2026-09-21', []);
  assert.match(noHist.pregunta, /\(ninguno todavía\)/);
  // dos llamadas seguidas no deberían pedir siempre el mismo estilo (con 8 estilos, en 30 intentos casi seguro varía)
  const styles = new Set();
  for (let i = 0; i < 30; i++) { const m = buildChargeAiPayload(G, '', '', []).pregunta.match(/ESTILO DE ESTE MENSAJE: ([^.]+)\./); styles.add(m[1]); }
  assert.ok(styles.size > 1, 'el estilo debe variar de una llamada a otra');
  assert.match(api, /export async function generateChargeMessageAI\(group=\{\}, currentText='', today='', history=\[\]\)/);
  assert.match(api, /buildChargeAiPayload\(group,currentText,today,history\)/);
});

test('main.js: guarda el historial de mensajes de IA por sesión de renovación y lo reinicia al abrir una nueva', () => {
  assert.match(main, /renewMessageHistory:\[\]/);
  assert.match(main, /state\.renewMessageVariant=0; state\.renewMessageHistory=\[\]; state\.renewMessage=buildChargeMessage/);
  assert.match(main, /generateChargeMessageAI\(g,current,todayISO\(\),state\.renewMessageHistory\|\|\[\]\)/);
  assert.match(main, /state\.renewMessageHistory=\[\.\.\.\(state\.renewMessageHistory\|\|\[\]\),next\]\.slice\(-6\)/);
});

test('Nuevo CRM y Catálogo: el botón para salir ahora es una X (cerrar), no una flecha de volver', () => {
  assert.match(main, /close:'<path d="M6 6l12 12M18 6 6 18"\/>'/);
  assert.match(main, /id="backMore" aria-label="Cerrar Nuevo CRM">\$\{icon\('close'\)\}/);
  assert.match(main, /id="backMore" aria-label="Cerrar catálogo">\$\{icon\('close'\)\}/);
  // la Ficha del cliente y las páginas normales de Más siguen con flecha (ahí sí es "volver", no "cerrar un formulario")
  assert.match(main, /id="backClients">\$\{icon\('back'\)\}/);
  assert.match(main, /id="backMore">\$\{icon\('back'\)\}/);
});

test('.back-btn ahora tiene un estilo propio consistente con los demás botones de icono (antes salía como botón gris del navegador)', () => {
  assert.match(css, /\.back-btn\{flex:none;width:46px;height:46px;border:1px solid #e0e9f2;border-radius:16px;background:#fff/);
  assert.match(css, /\.back-btn\.close-btn\{border-color:#f6c8c4/);
});

test('Calculadora: ya no hay dos bloques de CSS pisándose (quedó uno solo, limpio) y el robot trae medidas fijas', () => {
  assert.equal((css.match(/\.cc-hero\{/g) || []).length, 1, 'una sola definición de .cc-hero');
  assert.equal((css.match(/\.cc-bot img\{/g) || []).length, 1, 'una sola definición de .cc-bot img');
  assert.equal((css.match(/R43 · Calculadora de venta/g) || []).length, 1, 'un solo bloque de estilos de la calculadora');
  assert.match(calc, /<img src="\/assets\/mas\/robot-calc\.webp" width="150" height="142" alt="Sublibot con calculadora">/);
});

test('Inicio: se libera espacio en las tarjetas para que el nuevo margen se note de verdad (no lo absorbe el ajuste de escala)', () => {
  const marginRules = [...css.matchAll(/(?<!@media\([^)]*\)\{)\.visual-workspace\{margin-top:(\d+)px!important\}/g)];
  assert.ok(marginRules.length >= 1);
  assert.equal(marginRules.at(-1)[1], '34', 'la última regla de base (fuera de @media) debe ser 34px, más que antes');
  assert.match(css, /@media\(max-width:390px\)\{\.visual-workspace\{margin-top:26px!important\}\}/);
  assert.match(css, /\.home-tool-card\{aspect-ratio:3\.05\/1!important\}/);
  assert.match(css, /\.visual-metric\{aspect-ratio:1\.85\/1!important\}/);
});

test('Inicio: la píldora "Sincronizado" ya no flota sobre el saludo (causaba choque con frases largas del día)', () => {
  assert.match(main, /<h1>Hola, \$\{esc\(firstName\)\}<\/h1>\$\{mottoHtml\(dailyPhrase\(\)\)\}<div class="visual-sync">/);
  assert.match(css, /\.visual-home-brand \.visual-sync\{position:static/);
  assert.match(css, /\.app-main\.home-fixed\{display:flex!important;flex-direction:column;justify-content:center\}/);
  assert.match(css, /\.app-main\.home-fixed \.visual-workspace\{padding-bottom:0!important\}/);
});

test('Inicio: ninguna de las 40 frases del día se ve cortada (todas caben sin desbordar el cupo de líneas)', async () => {
  const { bootApp } = await import('./helpers/ui-harness.mjs');
  const block = main.slice(main.indexOf('const FRASES=['), main.indexOf('function mottoHtml'));
  const frases = new Function(`${block}\nreturn FRASES;`)();
  const longest = frases.map(f => f[1]).sort((a, b) => b.length - a.length)[0];
  assert.ok(longest.length <= 50, `la frase más larga (${longest.length} car.) sigue siendo razonable`);
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    const html = app.$('.app-main').innerHTML;
    assert.ok(/visual-home-brand"[\s\S]*?visual-sync/.test(html), 'el orden en el HTML es saludo→frase→píldora, todo dentro de la misma columna');
    assert.equal(app.logs.filter(l => l.startsWith('ERROR')).length, 0);
  } finally { app.close(); }
});
