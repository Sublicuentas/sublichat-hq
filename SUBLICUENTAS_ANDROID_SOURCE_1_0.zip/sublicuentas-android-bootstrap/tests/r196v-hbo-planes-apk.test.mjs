// R196v Fase 3 · APK: HBO Standard 3 / Platinum 5 en Nueva/Editar venta, filtros separados en Inventario y Bodega por plan.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { crmStoredPlatform, platformLabel } from '../src/operations.js';
import { platformLogoFile } from '../src/screens2.js';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');

// core.js usa import.meta.env (Vite) y no carga en node: se valida el código fuente.
const core = src('src/app/core.js'), cats = src('src/app/crm-categorias.js');
test('09 · Perfiles y Cuentas completas: HBO Standard / Platinum diferenciados; el genérico solo para ventas anteriores', () => {
  assert.match(core, /\['hbomax_standard','HBO Standard'\], \['hbomax_platinum','HBO Platinum'\], \['hbomax','HBO Max \(venta anterior, sin plan\)'\]/);
  assert.match(cats, /return CRM_PLATFORMS\.filter\(\(\[v\]\)=>v!=='hbomax'&&CUENTA_COMPLETA_PLATAFORMAS\.includes\(ccBase\(v\)\)\);/);
  assert.match(cats, /return CRM_PLATFORMS\.filter\(\(\[v\]\)=>v!=='hbomax'&&clasificarServicio\(\{plataforma:v\}\)\.categoria===cat\);/);
  assert.match(cats, /cat === 'cuentas_completas' \? `HBO \$\{p === 'platinum' \? 'Platinum' : 'Standard'\} · cuenta completa` : label/);
  assert.match(src('src/main.js'), /CRM_PLATFORMS\.filter\(\(\[value\]\)=>value!=='hbomax'\|\|d\.plataforma==='hbomax'\)/, 'catálogo de la venta sin el genérico');
});
test('reglas, logo y envío: mismas reglas que HBO; el plan viaja al servidor; editar conserva el plan', () => {
  assert.match(core, /\.replace\(\/\^hbomax\(standard\|platinum\)\$\/,'hbomax'\); \} \/\* R196v \*\//);
  assert.equal(crmStoredPlatform('hbomax_standard', 1), 'hbomax_standard');
  assert.equal(crmStoredPlatform('hbomax', 1), 'hbomax');
  assert.equal(platformLogoFile('hbomax_platinum'), 'hbo'); assert.equal(platformLabel('hbomaxstandard'), 'HBO Max Standard');
  assert.match(cats, /export function crmPlataformaConPlan\(base = '', s = \{\}\) \{ return base === 'hbomax' && \['standard', 'platinum'\]\.includes\(String\(s\.planHbo \|\| ''\)\) \? `hbomax_\$\{s\.planHbo\}` : base; \}/);
  assert.match(src('src/main.js'), /plataforma:crmPlataformaConPlan\(crmBasePlatform\(String\(s\.plataforma\|\|row\.plataforma\|\|'netflix'\)\),s\)/);
});

test('08 · Bodega: el selector filtra por plan/modalidad y el Inventario separa HBO Standard / Platinum', () => {
  const sel = src('src/app/selector-cuenta.js');
  assert.match(sel, /if\(planVenta&&String\(it\.planHbo\|\|''\)!==planVenta\)return false;/);
  assert.match(sel, /if\(cs\.some\(c=>c&&c\.cuentaCompleta===true\)\)return false; return cuentaCompleta\?inventoryStats\(it\)\.used===0:true;/);
  assert.match(src('src/main.js'), /canon:ph\?`hbomax\$\{ph\}`:platformCanon\(raw\.plataforma\)/);
  assert.ok(src('src/main.js').split('\n').length < 2000);
});
