// R188 · APK: Fase 3 (dispositivo por servicio, avisos centrales, modalidad Gemini/Duolingo/ChatGPT) y Fase 4 (Spotify Familiar).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { buildTraditionalFicha, fichaR188 } from '../src/operations.js';
import { buildCrmUpsertPayload } from '../src/api.js';
import * as E from '../src/app/entrega-plataforma.js';

test('copia fiel del módulo central (ESM) y la ficha usa los avisos exactos: Prime solo app, HBO código de hogar, Netflix sin duplicar', () => {
  const hq = new URL('../../../hq-gh/api/_entrega-plataforma.js', import.meta.url);
  if (fs.existsSync(hq)) {
    const a = fs.readFileSync(new URL('../src/app/entrega-plataforma.js', import.meta.url), 'utf8').split('\n').slice(1).join('\n').replace(/export \{[^}]*\};\n?$/, '');
    const b = fs.readFileSync(hq, 'utf8').split('\n').slice(1).join('\n').replace(/module\.exports = \{[^}]*\};\n?$/, '');
    assert.equal(a, b);
  }
  const prime = buildTraditionalFicha({ plataforma: 'Prime Video', plataformaRaw: 'primevideo', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.match(prime, /Solo disponible para la aplicación Prime Video\. Prohibido ingresar en Amazon\./);
  const hbo = buildTraditionalFicha({ plataforma: 'HBO Max', plataformaRaw: 'hbomax', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.match(hbo, /código de hogar en cualquier momento, incluso apenas/); assert.doesNotMatch(hbo, /15 días/);
  const nf = buildTraditionalFicha({ plataforma: 'Netflix', plataformaRaw: 'netflix', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.equal((nf.match(/código temporal/g) || []).length, 1, 'Netflix conserva su aviso (sin duplicar)');
  const cr = buildTraditionalFicha({ plataforma: 'Crunchyroll', plataformaRaw: 'crunchyroll', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.doesNotMatch(cr, /Honduras/i);
});

test('D01/D02: dispositivo de TV Digital va en ESE servicio; sin elegir = «Pendiente de seleccionar»', () => {
  assert.match(fichaR188('x\n\n🚀 Sublicuentas', { plataforma: 'oleadatv1', equipoTv: 'android_tv' }), /Dispositivo registrado: Android TV \/ TV Box\n\n🚀/);
  assert.match(fichaR188('x', { plataforma: 'stellatv1' }), /Pendiente de seleccionar/);
  assert.deepEqual(E.equiposPermitidos('stellatv1').includes('iphone'), false);
  const p = buildCrmUpsertPayload({ plataforma: 'oleadatv1', nombrePerfil: 'Ana', equipoTv: 'fire_tv', perfiles: [{ nombre: 'Ana', correo: 'u1', clave: 'k' }] });
  assert.equal(p.servicio.equipoTv, 'fire_tv');
  assert.equal(buildCrmUpsertPayload({ plataforma: 'netflix', nombrePerfil: 'Ana', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1', dispositivo: 'tv' }] }).servicio.equipoTv, undefined, 'streaming no lleva equipoTv');
});

test('D04/D05: Gemini con correo del cliente no manda contraseña; con cuenta entregada sí; ChatGPT siempre', () => {
  const g = buildCrmUpsertPayload({ plataforma: 'gemini', nombrePerfil: 'Ana', modalidadAcceso: 'correo_cliente', perfiles: [{ nombre: 'Ana', correo: 'c@gmail.com', clave: 'NOVIAJA' }] });
  assert.equal(g.servicio.clave, ''); assert.equal(g.servicio.perfiles[0].clave, ''); assert.equal(g.servicio.sinClave, true); assert.equal(g.servicio.modalidadAcceso, 'correo_cliente');
  const gp = buildCrmUpsertPayload({ plataforma: 'gemini', nombrePerfil: 'Ana', modalidadAcceso: 'proveedor', perfiles: [{ nombre: 'Ana', correo: 'cta@subli.hn', clave: 'P#1' }] });
  assert.equal(gp.servicio.clave, 'P#1'); assert.equal(gp.servicio.sinClave, undefined);
  const c = buildCrmUpsertPayload({ plataforma: 'chatgpt', nombrePerfil: 'Ana', perfiles: [{ nombre: 'Ana', correo: 'gpt@subli.hn', clave: 'G#1' }] });
  assert.equal(c.servicio.clave, 'G#1'); assert.equal(c.servicio.modalidadAcceso, 'proveedor');
  const fichaG = buildTraditionalFicha({ plataforma: 'Gemini', plataformaRaw: 'gemini', modalidadAcceso: 'correo_cliente', perfiles: [{ nombre: 'Ana', correo: 'c@gmail.com' }], fechaRenovacion: '04/12/2026' });
  assert.doesNotMatch(fichaG, /Clave/); assert.match(fichaG, /Invitación enviada a/);
  const fichaC = buildTraditionalFicha({ plataforma: 'ChatGPT', plataformaRaw: 'chatgpt', perfiles: [{ nombre: 'Ana', correo: 'gpt@subli.hn', clave: 'G#1' }], fechaRenovacion: '04/12/2026' });
  assert.match(fichaC, /🔑 Clave: G#1/);
});

test('Spotify Familiar (R196o): Inventario › Spotify; 1 correo + Agregar sin elegir fichas; sin Mover ni Desvincular; «Falta quitar en Spotify»', async () => {
  let fam = { id: 'f1', codigo: 'SP-001', madreCorreo: 'principal@ejemplo.com', capacidad: 5, ocupados: 4, libres: 1, estado: 'activa', pendientesSpotify: [{ correo: 'salio@ejemplo.com', motivo: 'no_renovo', at: '2026-11-12T10:00:00Z' }],
    miembros: ['a', 'b', 'c', 'd'].map((x, i) => ({ id: 'm' + i, correo: `${x}@ejemplo.com`, estado: 'activo', posicion: i + 1, clienteNombre: 'Cliente ' + x })) };
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/inventario') return undefined;
    if (body.accion === 'spotifyFamilias') return { ok: true, puedeAdministrar: true, familias: [fam] };
    if (body.accion === 'spotifyAgregarCorreo') { fam = { ...fam, ocupados: 5, libres: 0, miembros: [...fam.miembros, { id: 'm5', correo: body.correo.toLowerCase(), estado: 'activo', posicion: 5 }] }; return { ok: true, familia: fam, ficha: null, pendienteVincular: true, varias: 2, aviso: 'Hay 2 fichas con ese correo: se vincula sola cuando se guarde o renueve la ficha correcta.' }; }
    return { ok: true, items: [] };
  } });
  try {
    await app.click('[data-tab="mas"]', 300);
    assert.ok(!app.$('[data-open="spotify-familias"]'), 'Más no tiene tarjeta nueva de Spotify');
    await app.click('[data-open="inventario"]', 400);
    await app.click('[data-open-spotify]', 400);
    await app.waitFor(() => /SP-001/.test(app.$('.se-wrap')?.textContent || ''));
    assert.ok(app.$('[data-spf-crear]'), 'Sublicuentas ve «Crear familia»');
    await app.click('[data-spf-abrir="f1"]', 150);
    const t = app.$('.se-wrap').textContent;
    assert.match(t, /Invitados 4\/5/); assert.match(t, /Falta quitar en la app de Spotify.*salio@ejemplo\.com/);
    assert.doesNotMatch(app.$('.se-wrap').innerHTML, /Mover|Desvincular|data-spf-mover|data-spf-desv|data-spf-elegir/);
    app.$('#spfCorreo').value = 'Cuenta02@Ejemplo.com';
    await app.click('[data-spf-agregar]', 300);
    await app.waitFor(() => /5\/5/.test(app.$('.se-wrap')?.textContent || ''));
    const v = app.bodies.filter((b) => b?.accion === 'spotifyAgregarCorreo');
    assert.equal(v.length, 1); assert.deepEqual([v[0].familiaId, v[0].correo, v[0].clienteId], ['f1', 'Cuenta02@Ejemplo.com', undefined]);
    assert.ok(!app.$('[data-spf-elegir]'), 'no aparece lista de fichas');
    assert.ok(!app.bodies.some((b) => /spotifyMover|spotifyDesvincular|spotifyLiberar/.test(String(b?.accion))));
  } finally { app.close(); }
});

test('Spotify Familiar (R196o): un usuario que no es Sublicuentas no ve «Crear familia»', async () => {
  const fam = { id: 'f1', codigo: 'SP-001', madreCorreo: 'principal@ejemplo.com', capacidad: 5, ocupados: 0, libres: 5, estado: 'activa', miembros: [] };
  const app = await bootApp({ role: 'relojes', fetchExtra: async (path, body) => (path === '/api/inventario' && body.accion === 'spotifyFamilias' ? { ok: true, puedeAdministrar: false, familias: [fam] } : path === '/api/inventario' ? { ok: true, items: [] } : undefined) });
  try {
    await app.click('[data-tab="mas"]', 300); await app.click('[data-open="inventario"]', 400); await app.click('[data-open-spotify]', 400);
    await app.waitFor(() => /SP-001/.test(app.$('.se-wrap')?.textContent || ''));
    assert.ok(!app.$('[data-spf-crear]') && !app.$('#spfMadre'));
  } finally { app.close(); }
});
