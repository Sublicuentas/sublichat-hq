// R188 · APK: Fase 3 (dispositivo por servicio, avisos centrales, modalidad Gemini/Duolingo/ChatGPT) y Fase 4 (Spotify Familiar).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';
import { buildTraditionalFicha, fichaR188 } from '../src/operations.js';
import { buildCrmUpsertPayload } from '../src/api.js';
import * as E from '../src/app/entrega-plataforma.js';

test('copia fiel del módulo central (ESM) y la ficha usa los avisos exactos: Prime solo app, HBO código de hogar, Netflix sin duplicar', () => {
  const hq = new URL('../../../hq-gh/api/_entrega-plataforma.js', import.meta.url);
  if (fs.existsSync(hq)) {
    const a = fs.readFileSync(new URL('../src/app/entrega-plataforma.js', import.meta.url), 'utf8').split('\n').slice(1).join('\n').replace(/export \{[^}]*\};\n?$/, '');
    const b = fs.readFileSync(hq, 'utf8').split('\n').slice(1).join('\n').replace(/module\.exports = \{[^}]*\};\n?$/, '');
    assert.equal(a, b);
  }
  const prime = buildTraditionalFicha({ plataforma: 'Prime Video', plataformaRaw: 'primevideo', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.match(prime, /Solo disponible para la aplicación Prime Video\. Prohibido ingresar en Amazon\./);
  const hbo = buildTraditionalFicha({ plataforma: 'HBO Max', plataformaRaw: 'hbomax', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.match(hbo, /código de hogar en cualquier momento, incluso apenas/); assert.doesNotMatch(hbo, /15 días/);
  const nf = buildTraditionalFicha({ plataforma: 'Netflix', plataformaRaw: 'netflix', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.equal((nf.match(/código temporal/g) || []).length, 1, 'Netflix conserva su aviso (sin duplicar)');
  const cr = buildTraditionalFicha({ plataforma: 'Crunchyroll', plataformaRaw: 'crunchyroll', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026' });
  assert.doesNotMatch(cr, /Honduras/i);
});

test('D01/D02: dispositivo de TV Digital va en ESE servicio; sin elegir = «Pendiente de seleccionar»', () => {
  assert.match(fichaR188('x\n\n🚀 Sublicuentas', { plataforma: 'oleadatv1', equipoTv: 'android_tv' }), /Dispositivo registrado: Android TV \/ TV Box\n\n🚀/);
  assert.match(fichaR188('x', { plataforma: 'stellatv1' }), /Pendiente de seleccionar/);
  assert.deepEqual(E.equiposPermitidos('stellatv1').includes('iphone'), false);
  const p = buildCrmUpsertPayload({ plataforma: 'oleadatv1', nombrePerfil: 'Ana', equipoTv: 'fire_tv', perfiles: [{ nombre: 'Ana', correo: 'u1', clave: 'k' }] });
  assert.equal(p.servicio.equipoTv, 'fire_tv');
  assert.equal(buildCrmUpsertPayload({ plataforma: 'netflix', nombrePerfil: 'Ana', perfiles: [{ nombre: 'Ana', correo: 'a@x.hn', clave: 'k', pinPerfil: '1', dispositivo: 'tv' }] }).servicio.equipoTv, undefined, 'streaming no lleva equipoTv');
});

test('D04/D05: Gemini con correo del cliente no manda contraseña; con cuenta entregada sí; ChatGPT siempre', () => {
  const g = buildCrmUpsertPayload({ plataforma: 'gemini', nombrePerfil: 'Ana', modalidadAcceso: 'correo_cliente', perfiles: [{ nombre: 'Ana', correo: 'c@gmail.com', clave: 'NOVIAJA' }] });
  assert.equal(g.servicio.clave, ''); assert.equal(g.servicio.perfiles[0].clave, ''); assert.equal(g.servicio.sinClave, true); assert.equal(g.servicio.modalidadAcceso, 'correo_cliente');
  const gp = buildCrmUpsertPayload({ plataforma: 'gemini', nombrePerfil: 'Ana', modalidadAcceso: 'proveedor', perfiles: [{ nombre: 'Ana', correo: 'cta@subli.hn', clave: 'P#1' }] });
  assert.equal(gp.servicio.clave, 'P#1'); assert.equal(gp.servicio.sinClave, undefined);
  const c = buildCrmUpsertPayload({ plataforma: 'chatgpt', nombrePerfil: 'Ana', perfiles: [{ nombre: 'Ana', correo: 'gpt@subli.hn', clave: 'G#1' }] });
  assert.equal(c.servicio.clave, 'G#1'); assert.equal(c.servicio.modalidadAcceso, 'proveedor');
  const fichaG = buildTraditionalFicha({ plataforma: 'Gemini', plataformaRaw: 'gemini', modalidadAcceso: 'correo_cliente', perfiles: [{ nombre: 'Ana', correo: 'c@gmail.com' }], fechaRenovacion: '04/12/2026' });
  assert.doesNotMatch(fichaG, /Clave/); assert.match(fichaG, /Invitación enviada a/);
  const fichaC = buildTraditionalFicha({ plataforma: 'ChatGPT', plataformaRaw: 'chatgpt', perfiles: [{ nombre: 'Ana', correo: 'gpt@subli.hn', clave: 'G#1' }], fechaRenovacion: '04/12/2026' });
  assert.match(fichaC, /🔑 Clave: G#1/);
});

test('Spotify Familiar: se entra desde Inventario (Más no cambia), crea familia y vincula ficha existente por el servidor', async () => {
  let fam = { id: 'f1', codigo: 'SP-001', madreCorreo: 'principal@ejemplo.com', capacidad: 5, ocupados: 0, libres: 5, estado: 'activa', miembros: [] };
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/inventario') return undefined;
    if (body.accion === 'spotifyFamilias') return { ok: true, familias: [fam] };
    if (body.accion === 'spotifyBuscar') return { ok: true, servicios: [{ clienteId: 'ana', clienteNombre: 'Ana', compraId: 'c1', correo: 'cuenta02@ejemplo.com', fechaRenovacion: '04/12/2026' }] };
    if (body.accion === 'spotifyVincular') { fam = { ...fam, ocupados: 1, libres: 4, miembros: [{ correo: body.correo, estado: 'activo', clienteNombre: 'Ana' }] }; return { ok: true, familia: fam }; }
    return { ok: true, items: [] };
  } });
  try {
    await app.click('[data-tab="mas"]', 300);
    assert.ok(!app.$('[data-open="spotify-familias"]'), 'Más no tiene tarjeta nueva de Spotify');
    await app.click('[data-open="inventario"]', 400);
    await app.click('[data-open-spotify]', 400);
    await app.waitFor(() => /SP-001/.test(app.$('.se-wrap')?.textContent || ''));
    await app.click('[data-spf-abrir="f1"]', 150);
    app.$('#spfCorreo').value = 'cuenta02';
    await app.click('[data-spf-buscar]', 300);
    await app.click('[data-spf-vincular="cuenta02@ejemplo.com"]', 400);
    const v = app.bodies.find((b) => b?.accion === 'spotifyVincular');
    assert.deepEqual([v.familiaId, v.correo, v.clienteId, v.compraId], ['f1', 'cuenta02@ejemplo.com', 'ana', 'c1']);
    await app.waitFor(() => /1\/5/.test(app.$('.se-wrap')?.textContent || ''));
  } finally { app.close(); }
});
