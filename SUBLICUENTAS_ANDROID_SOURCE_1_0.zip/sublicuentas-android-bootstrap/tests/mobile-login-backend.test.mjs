import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const backend = fs.readFileSync(new URL('../../../mobile-login.js', import.meta.url), 'utf8');

test('mobile login wrapper preserves web auth and only opens known app origins', () => {
  assert.match(backend, /require\('\.\/login'\)/);
  assert.match(backend, /https:\/\/localhost/);
  assert.match(backend, /capacitor:\/\/localhost/);
  assert.match(backend, /req\.method === 'OPTIONS'/);
  assert.match(backend, /return loginHandler\(req, res\)/);
});
