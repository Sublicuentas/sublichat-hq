// R196u Fases 4 y 5 · APK: portada Spotify (SPT-01), AutoCAD (CAD-01/02), Eleven Reader (ELV-01) y Bodega VIP (consultar / entregar).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { platformLogoFile, platformLogoHtml, vipEstadoUnidad, vipResumenHtml } from '../src/screens2.js';
import { buildTraditionalFicha } from '../src/operations.js';
import { clasificarServicio } from '../src/app/catalogo-categorias.js';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');

test('SPT-01 · Spotify Familiar usa el logo de Spotify que ya existe (no la letra «S»), igual que Netflix o Disney', () => {
  assert.equal(platformLogoFile('spotifyfamiliar'), 'spotify');
  assert.equal(platformLogoFile('Spotify Familiar'), 'spotify');
  assert.match(platformLogoHtml('spotifyfamiliar', 'Spotify Familiar'), /<img class="pf-logo " src="\/assets\/plataformas\/spotify\.webp"/);
  assert.ok(fs.existsSync(new URL('../public/assets/plataformas/spotify.webp', import.meta.url)), 'el recurso va empaquetado en la APK (sin conexión)');
  assert.equal(platformLogoFile('netflix'), 'netflix');
});

test('CAD-01 · AutoCAD en Software: solo correo, sin pedir contraseña; la ficha trae los pasos de la invitación', () => {
  assert.equal(clasificarServicio({ plataforma: 'autocad' }).categoria, 'software');
  const t = buildTraditionalFicha({ nombrePerfil: 'Cliente Demo', plataforma: 'Autodesk AutoCAD', plataformaRaw: 'autocad', fechaRenovacion: '20/12/2026', precio: 0, perfiles: [{ nombre: 'Cliente Demo', correo: 'cad.demo@ejemplo.com' }], vendedor: 'Relojes' });
  assert.match(t, /Correo invitado: cad\.demo@ejemplo\.com/); assert.match(t, /Aceptar invitación/);
  assert.doesNotMatch(t, /Clave|Contraseña:|Pin:/, 'sin contraseña registrada no aparece');
  assert.match(src('src/app/core.js'), /passwordOpcional:key==='autocad'/);
  assert.match(src('src/main.js'), /if\(rules\.password&&!rules\.passwordOpcional&&!String\(p\.clave\|\|''\)\.trim\(\)\)return/);
  assert.match(src('src/app/core.js'), /\['adobeexpress','Adobe Express'\], \['autocad','Autodesk AutoCAD'\]/);
});

test('CAD-02 · AutoCAD con contraseña registrada: sale en la entrega', () => {
  const t = buildTraditionalFicha({ nombrePerfil: 'Cliente Demo', plataforma: 'Autodesk AutoCAD', plataformaRaw: 'autocad', fechaRenovacion: '20/12/2026', perfiles: [{ nombre: 'Cliente Demo', correo: 'cad.demo@ejemplo.com', clave: 'ClaveCad9' }], vendedor: 'Relojes' });
  assert.match(t, /🔑 Contraseña: ClaveCad9/);
});

test('ELV-01 · Eleven Reader en Música con correo + contraseña, sin PIN', () => {
  assert.equal(clasificarServicio({ plataforma: 'elevenreader' }).categoria, 'musica');
  const t = buildTraditionalFicha({ nombrePerfil: 'Cliente Demo', plataforma: 'Eleven Reader', plataformaRaw: 'elevenreader', fechaRenovacion: '20/12/2026', perfiles: [{ nombre: 'Cliente Demo', correo: 'er.demo@ejemplo.com', clave: 'ClaveEr7' }], vendedor: 'Relojes' });
  assert.match(t, /Acceso: Eleven Reader/); assert.match(t, /Correo: er\.demo@ejemplo\.com/); assert.match(t, /Clave: ClaveEr7/); assert.doesNotMatch(t, /Pin:/);
});

test('Bodega VIP en la APK: consulta por estado sin claves; suspendida o en revisión no se puede elegir en la venta', () => {
  const inv = [
    { plataforma: 'vipnetflix', correo: 'v1@ejemplo.com', clave: 'NoSeMuestra1', capacidad: 1, ocupados: 0 },
    { plataforma: 'vipnetflix', correo: 'v2@ejemplo.com', capacidad: 1, ocupados: 1 },
    { plataforma: 'vipnetflix', correo: 'v3@ejemplo.com', capacidad: 1, ocupados: 0, estadoBodega: 'suspendido' },
    { plataforma: 'netflix', correo: 'n@ejemplo.com', capacidad: 5 },
  ];
  assert.deepEqual(inv.slice(0, 3).map(vipEstadoUnidad), ['disponible', 'asignado', 'suspendido']);
  const h = vipResumenHtml(inv);
  assert.match(h, /Disponibles · 1/); assert.match(h, /Asignadas · 1/); assert.match(h, /Suspendidas · 1/);
  assert.doesNotMatch(h, /NoSeMuestra1|@ejemplo/, 'sin claves ni correos en el resumen');
  assert.match(src('src/app/selector-cuenta.js'), /!\['suspendido','revision'\]\.includes\(String\(it\.estadoBodega\|\|''\)\.toLowerCase\(\)\)/);
  assert.match(src('src/main.js'), /state\.invPlat==='vipnetflix'\?vipResumenHtml\(\(state\.inventory\|\|\[\]\)\):''/);
  assert.doesNotMatch(src('src/styles.css').split('R196u · Bodega Netflix VIP')[1] || '', /gradient/);
});
