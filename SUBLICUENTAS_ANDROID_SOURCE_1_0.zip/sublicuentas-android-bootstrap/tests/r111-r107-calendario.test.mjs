import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { renewalDateForMonths, dmyToIsoDate, isoToDmyDate } from '../src/operations.js';

const main = () => readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const api = () => readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');

test('R111: compra nueva guarda ficha + pago de forma atómica por /api/renovar', () => {
  const src = main();
  const save = src.slice(src.indexOf('async function saveCrm'), src.indexOf('function spinSplashLoaderWithJS'));
  assert.match(api(), /\.\.\.\(form\.pago && typeof form\.pago==='object' \? \{pago:form\.pago\} : \{\}\)/);
  assert.match(save, /form=\{[\s\S]*pago:/, 'el pago debe viajar dentro de la ficha');
  assert.doesNotMatch(save, /await registrarPagoCompra\(/, 'no debe registrar Finanzas en un segundo request');
  assert.doesNotMatch(save, /kind:'cobro',path:'\/api\/finanzas'/, 'offline también debe encolar una sola operación');
});

test('R111: renovación con pago usa el blindaje R107, sin POST separado a Finanzas', () => {
  const src = main();
  const renew = src.slice(src.indexOf('async function handleRenewalOption'), src.indexOf('function spinSplashLoaderWithJS'));
  assert.match(renew, /renewBody\.pago=groupPayment/, 'el pago debe viajar junto con la renovación portadora');
  assert.match(renew, /\.\.\.\(llevaPago\?\{pago:groupPayment\}:\{\}\)/, 'offline también debe encolar renovación + pago juntos');
  assert.doesNotMatch(renew, /authPost\('\/api\/finanzas',groupPayment\)/);
  assert.doesNotMatch(renew, /kind:'cobro',path:'\/api\/finanzas'/);
});

test('R111: meses de compra son meses calendario y la fecha usa selector nativo', () => {
  assert.equal(renewalDateForMonths('04/10/2026', 1), '04/11/2026');
  assert.equal(renewalDateForMonths('04/10/2026', 2), '04/12/2026');
  assert.equal(dmyToIsoDate('04/12/2026'), '2026-12-04');
  assert.equal(isoToDmyDate('2026-12-04'), '04/12/2026');
  const src = main();
  assert.match(src, /fechaRenovacion:renewalDateForMonths\(todayDMY\(\),1\)/);
  assert.match(src, /id="crmFecha"[^>]*type="date"/);
  assert.match(src, /#crmMeses'[\s\S]*renewalDateForMonths\(todayDMY\(\),/);
});
