// E2 · Entrega 2: tema LEGO 3D en Más + ajustes aprobados (Códigos, Subli, Baúl, Partidos/Fútbol).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { matchesContentHtml, matchPayload, FUT_LIGAS } from '../src/more.js';

const read = (p) => fs.readFileSync(new URL(`../src/${p}`, import.meta.url), 'utf8');

test('E2 · Códigos ya no dice «Del correo del hosting · respaldo de Telegram» y conserva Código / Link de clave / Netflix Hogar', () => {
  const src = read('app/codigos.js');
  assert.doesNotMatch(src, /respaldo de Telegram/);
  for (const t of ['Código', 'Link de clave', 'Netflix Hogar']) assert.ok(src.includes(t), t);
});

test('E2 · Subli: el menú ⋮ abre cerrado al entrar y solo se abre al tocarlo', () => {
  const main = read('main.js');
  assert.match(main, /if\(id==='subli'\)state\.subliMenuOpen=false;/);
  assert.match(main, /#subliMenuBtn'\)\?\.addEventListener\('click',\(\)=>\{state\.subliMenuOpen=!state\.subliMenuOpen/);
});

test('E2 · Baúl: el nombre visible es «Icomplay», nunca «Icomplay Max»', () => {
  const def = read('app/baul-apks.js').match(/export const nomTv = (\(p\) => .*);/)[1]; const nomTv = (0, eval)(def); // baul-apks.js necesita Vite; se prueba la función tal cual
  assert.equal(nomTv({ id: 'icomplay', nombre: 'Icomplay Max' }), 'Icomplay');
  assert.equal(nomTv({ id: 'x', nombre: 'ICOMPLAY MAX' }), 'Icomplay');
  assert.equal(nomTv({ id: 'oleada', nombre: 'Oleada TV' }), 'Oleada TV');
  assert.doesNotMatch(read('app/baul-apks.js').split('export const nomTv')[1], /esc\(p\.nombre\)/);
});

test('E2 · Partidos: pestaña Fútbol con todas las ligas del servidor; NBA, MLB, UFC, Tenis y F1 siguen igual', () => {
  assert.deepEqual(matchPayload('futbol'), { modo: 'futbol_dia' });
  assert.deepEqual(matchPayload('futliga:eng.1'), { modo: 'futliga', liga: 'eng.1' });
  assert.deepEqual(matchPayload('nba'), { modo: 'nba' });
  assert.deepEqual(matchPayload('equipo', 'Olimpia'), { modo: 'equipo', q: 'Olimpia' });
  const html = matchesContentHtml({ mode: 'futliga:hon.1', matches: [] });
  assert.match(html, /data-match-mode="futbol"/); assert.match(html, /class="active" data-match-mode="futliga:hon\.1"/);
  assert.equal((html.match(/data-match-mode="futliga:/g) || []).length, FUT_LIGAS.length);
  for (const m of ['hoy', 'nba', 'mlb', 'ufc', 'tenis', 'f1']) assert.match(html, new RegExp(`data-match-mode="${m}"`));
  assert.doesNotMatch(matchesContentHtml({ mode: 'nba', matches: [] }), /mt-ligas/); // las ligas solo dentro de Fútbol
});

test('E2 · LEGO de Más: solo bajo .theme-lego y sin degradados', () => {
  const css = read('lego.css'); const e2 = css.split('E2 · Tema LEGO 3D en Más')[1];
  assert.ok(e2);
  for (const sel of e2.match(/^[^@/{}\s*][^{]*\{/gm) || []) assert.match(sel, /theme-lego/, `fuera del tema: ${sel}`);
  assert.doesNotMatch(css, /linear-gradient/);
});
