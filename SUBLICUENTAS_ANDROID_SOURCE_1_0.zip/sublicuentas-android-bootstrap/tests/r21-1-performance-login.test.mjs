import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.1 restores cached core data before network synchronization',()=>{
  assert.match(main,/restoreCoreCache\(\)/);
  assert.match(main,/persistCoreCache\(\)/);
});
test('R21.1 login keeps stable mobile canvas when Android keyboard resizes viewport',()=>{
  assert.match(main,/--login-screen-height/);
  assert.match(css,/var\(--login-screen-height/);
  assert.match(main,/scrollIntoView/);
});
