import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.1 restores cached core data before network synchronization',()=>{
  assert.match(main,/restoreCoreCache\(\)/);
  assert.match(main,/persistCoreCache\(\)/);
});
test('R26 login keeps inputs reachable when the Android keyboard opens',()=>{
  assert.match(main,/scrollIntoView/);
});
