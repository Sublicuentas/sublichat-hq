// R200f · APK: mismas condiciones del servicio que la URL y la Web (22/11/2026). Datos ficticios.
import test from 'node:test';
import assert from 'node:assert/strict';
import { buildTraditionalFicha } from '../src/operations.js';

const f = (plataformaRaw, extra = {}) => buildTraditionalFicha({ plataforma: plataformaRaw, plataformaRaw, perfiles: [{ nombre: 'Ana Prueba', correo: 'a@prueba.test', clave: 'k', pinPerfil: '1' }], fechaRenovacion: '04/12/2026', ...extra });
const CUATRO = /🚨 Condiciones del servicio:\n📌 Cuenta solo para 1 dispositivo, no se permite acceder en otro\.\n📌 No se modifica perfil\.\n📌 Conexión válida en Honduras\.\n📌 Garantía vigente al cumplir indicaciones\./;

test('1 · perfiles de las 7 plataformas: las 4 condiciones, una sola vez, sin VPN ni aviso viejo', () => {
  for (const p of ['netflix', 'hbomax', 'primevideo', 'crunchyroll', 'disneyp', 'disneys', 'vix']) {
    const t = f(p);
    assert.match(t, CUATRO, p);
    assert.equal((t.match(/Condiciones del servicio/g) || []).length, 1, p);
    assert.doesNotMatch(t, /No usar vpn|Prohibido usar VPN|IMPORTANTE: CUENTA SOLO/i, p);
  }
});
test('2 · Netflix VIP con su texto; cuenta completa sin condiciones de perfil', () => {
  assert.match(f('vipnetflix'), /📌 Puede usarla en el dispositivo de su preferencia\.\n📌 No se puede usar en dos dispositivos en simultáneo\.\n📌 Garantía vigente al cumplir indicaciones\./);
  const c = f('hbomax', { tipoVenta: 'cuenta_completa' });
  assert.match(c, /Cuenta completa de uso exclusivo/); assert.doesNotMatch(c, /No se modifica perfil|1 dispositivo/);
});
