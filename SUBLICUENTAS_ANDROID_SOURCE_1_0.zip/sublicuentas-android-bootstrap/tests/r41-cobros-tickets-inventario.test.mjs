import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import {
  cobrosScreenHtml, ticketsScreenHtml, ticketRowHtml, ticketNeedsAttention, isAviso, ticketTitle, ticketStatus, inventoryScreenHtml, inventoryDetailHtml,
  inventoryCopyText, inventoryStats, inventoryFreeSlots, platformCanon, platformLogoFile, platformLogoHtml, invUsaUsuario,
} from '../src/screens2.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const exists = p => fs.existsSync(new URL(`../public${p}`, import.meta.url));
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('Cobros: encabezado con calendario, vendedor, pestañas con contadores y filas como el mockup', () => {
  const d = dom(cobrosScreenHtml({
    counts: { hoy: 12, proximo: 28, vencidos: 14 }, filter: 'hoy', seller: 'Relojes', sellers: ['Relojes', 'Sublicuentas'], heading: 'Domingo, 21 de septiembre', headingCount: 12,
    groups: [{ key: 'g1', day: 21, mon: 'SEP', nombre: 'Gisselle Fajardo', plataformas: 'ViX', nServicios: 1, nTotal: 3, total: 'L 120.00' }],
  }));
  assert.equal(d.querySelector('h1').textContent, 'Renovar');
  assert.match(d.body.textContent, /Cobro \+ gestión de servicios \+ renovación conectada a Sublichat\./);
  assert.ok(d.querySelector('img.cb-art[src$="cobros-hero.webp"]'));
  assert.equal(d.querySelector('#renewSellerFilter').value, 'Relojes');
  assert.deepEqual([...d.querySelectorAll('[data-filter]')].map(b => b.dataset.filter), ['hoy', 'proximo', 'vencidos']);
  assert.deepEqual([...d.querySelectorAll('.cb-t3 b')].map(e => e.textContent), ['12', '28', '14']);
  assert.equal(d.querySelector('.cb-t3 .active').dataset.filter, 'hoy');
  assert.match(d.querySelector('.cb-date').textContent, /Domingo, 21 de septiembre.*12 clientes/);
  const row = d.querySelector('[data-renew-group="g1"]');
  assert.match(row.textContent, /21SEP/); assert.match(row.textContent, /Gisselle Fajardo/); assert.match(row.textContent, /ViX · 1 servicio/); assert.match(row.textContent, /3 total/); assert.match(row.textContent, /L 120\.00/);
  assert.equal(d.querySelector('#cobrosBack').dataset.tab, 'inicio');
  assert.ok(d.querySelector('#refreshData'));
  assert.match(dom(cobrosScreenHtml({ heading: 'Vencidos', headingCount: 1 })).body.textContent, /Todo al día/);
  // los botones siguen conectados a la lógica de siempre
  assert.match(main, /return cobrosScreenHtml\(\{counts:renewalCounts\(\)/);
  assert.match(main, /\[data-filter\]'\)\.forEach/);
  assert.match(main, /function renewalGroups\(filter=state\.renewFilter\)/);
  assert.ok(exists('/assets/mas/cobros-hero.webp'));
});

const T = (o = {}) => ({ id: 'a', numero: 1, titulo: 'Ticket X', estado: 'abierto', respuestas: [], createdAt: '2026-09-21T10:24:00Z', ...o });
test('Tickets y avisos: solo se ven los abiertos sin responder; lo demás va al historial plegable', () => {
  assert.equal(ticketNeedsAttention(T()), true);
  assert.equal(ticketNeedsAttention(T({ respuestas: [{ texto: 'ok' }] })), false);
  assert.equal(ticketNeedsAttention(T({ estado: 'resuelto' })), false);
  assert.equal(ticketNeedsAttention(T({ estado: 'cerrado' })), false);
  assert.equal(ticketNeedsAttention(T({ estado: 'proceso' })), true);
  assert.equal(isAviso({ tipo: 'aviso' }), true);
  assert.equal(isAviso({ titulo: 'AVISO · Prueba' }), true);
  assert.equal(isAviso(T()), false);
  assert.equal(ticketTitle({ titulo: 'AVISO · Prueba apk' }), 'Prueba apk');
  assert.equal(ticketStatus(T({ estado: 'finalizado' }))[0], 'Resuelto');
  const rowHtml = t => ticketRowHtml(t, { actor: 'Sublicuentas', when: '21/09/2026' });
  const base = { noticeFormHtml: '<div class="tk-form"><input id="ticketNoticeTitle"><button id="ticketSendNotice">x</button></div>', ticketFormHtml: '<div class="tk-form"><input id="ticketTitle"><button id="ticketCreate">x</button></div>', rowHtml };
  const visible = [T({ id: 'v1', numero: 5, titulo: 'Abierto sin respuesta' })];
  const history = [T({ id: 'h1', numero: 3, titulo: 'Ya respondido', respuestas: [{ texto: 'x' }] })];
  const avisos = dom(ticketsScreenHtml({ ...base, tab: 'avisos', visible, history, counts: { history: 1 } }));
  assert.deepEqual([...avisos.querySelectorAll('[data-tk-tab]')].map(b => b.dataset.tkTab), ['avisos', 'tickets']);
  assert.equal(avisos.querySelector('.tk-seg .on').dataset.tkTab, 'avisos');
  assert.ok(avisos.querySelector('#ticketSendNotice')); assert.equal(avisos.querySelector('#ticketCreate'), null, 'en Avisos no se mezcla el formulario de tickets');
  assert.equal(avisos.querySelectorAll('.tk-list .tk-item').length, 1);
  assert.equal(avisos.querySelector('.tk-history-body'), null, 'el historial empieza plegado');
  assert.equal(avisos.querySelector('#ticketHistoryToggle b').textContent, '1');
  assert.ok(avisos.querySelector('#backMore') && avisos.querySelector('#ticketsRefresh'));
  const abierto = dom(ticketsScreenHtml({ ...base, tab: 'tickets', visible, history, historyOpen: true, counts: { history: 1 } }));
  assert.ok(abierto.querySelector('#ticketCreate')); assert.equal(abierto.querySelector('#ticketSendNotice'), null);
  assert.match(abierto.querySelector('.tk-banner').textContent, /Solicita soporte o reporta un problema/);
  assert.equal(abierto.querySelectorAll('.tk-history-body .tk-item').length, 1);
  assert.ok(abierto.querySelector('#ticketSearch') && abierto.querySelector('#ticketFilterBtn'));
  const buscando = dom(ticketsScreenHtml({ ...base, tab: 'tickets', visible: [...visible, ...history], history: [], query: 'resp', searching: true, filtersOpen: true }));
  assert.equal(buscando.querySelector('#ticketHistoryToggle'), null);
  assert.equal(buscando.querySelectorAll('[data-tk-status]').length, 6);
  const fila = dom(ticketRowHtml(T({ id: 'z', numero: 9, estado: 'proceso' }), { expanded: true, cardHtml: '<div id="card">detalle</div>', actor: 'Relojes', when: 'hoy' }));
  assert.equal(fila.querySelector('[data-tk-toggle]').dataset.tkToggle, 'z');
  assert.ok(fila.querySelector('#card')); assert.match(fila.querySelector('.tk-chip').textContent, /En proceso/);
  assert.equal(dom(ticketRowHtml(T(), {})).querySelector('#card'), null);
});

test('Tickets: main.js conserva la lógica (mismos IDs y acciones) y agrega borrador, hilo plegable y filtros', () => {
  for (const id of ['ticketNoticeTitle', 'ticketNoticeDetail', 'ticketSendNotice', 'ticketTitle', 'ticketDetail', 'ticketDest', 'ticketPriority', 'ticketCreate']) assert.ok(main.includes(`id="${id}"`), id);
  assert.match(main, /accion:'crear',tipo:'aviso',titulo:`AVISO · \$\{titulo\}`/);
  assert.match(main, /data-ticket-process=/); assert.match(main, /data-ticket-resolve=/); assert.match(main, /data-ticket-send=/);
  assert.match(main, /return ticketsScreenHtml\(\{tab,/);
  assert.match(main, /data-tk-thread=/);
  assert.match(main, /ticketDraft:\{\}/);
  assert.match(main, /state\.ticketDraft=\{\.\.\.state\.ticketDraft,title:'',detail:''\}/);
  for (const h of ['[data-tk-tab]', '#ticketSearch', '#ticketFilterBtn', '[data-tk-status]', '#ticketHistoryToggle', '[data-tk-toggle]']) assert.ok(main.includes(h), h);
});

const INV = [
  { id: 'a1', plataforma: 'crunchyroll', correo: 'jujutsu@sublicuentas.com', clave: 'Clave-123', capacidad: 3, disponibles: 2, clientes: [{ slot: 2, nombre: 'Ana Paz', pin: '4321' }], estado: 'activa', updatedAt: '2026-09-20T10:00:00Z' },
  { id: 'a2', plataforma: 'vipnetflix', correo: 'vip@x.com', clave: 'k', capacidad: 5, disponibles: 0, clientes: [] },
];
test('Inventario: logos por plataforma, categorías con conteo, búsqueda y ⋮ por cuenta', () => {
  assert.equal(platformLogoFile('vipnetflix'), 'netflix');
  assert.equal(platformLogoFile('disneyp'), 'disney');
  assert.equal(platformLogoFile('hbomax'), 'hbo');
  assert.equal(platformLogoFile('primevideo'), 'prime');
  assert.equal(platformLogoFile('stellatv2'), 'stella-tv');
  assert.equal(platformCanon('Crunchyroll'), 'crunchyroll');
  assert.match(platformLogoHtml('crunchyroll'), /\/assets\/plataformas\/crunchyroll\.webp/);
  assert.match(platformLogoHtml('desconocida', 'Zeta'), /pf-fallback[^>]*>Z</);
  for (const f of ['netflix', 'disney', 'hbo', 'prime', 'crunchyroll', 'paramount', 'spotify', 'youtube', 'vix', 'universal', 'stella-tv']) assert.ok(exists(`/assets/plataformas/${f}.webp`), f);
  const d = dom(inventoryScreenHtml({
    platforms: [{ key: 'crunchyroll', label: 'Crunchyroll', count: 32 }, { key: 'vipnetflix', label: 'Netflix VIP', count: 42 }], total: 247, plat: 'crunchyroll', query: '', sort: 'recientes',
    items: INV.map(raw => ({ raw, id: raw.id, label: raw.plataforma })), shown: 2, all: 2,
  }));
  assert.match(d.querySelector('h2').textContent, /Cuentas disponibles/);
  assert.match(d.querySelector('#invSearch').placeholder, /Buscar cuenta, correo o plataforma/);
  assert.equal(d.querySelector('.inv-chip[data-inv-plat=""] small').textContent, '247');
  assert.equal(d.querySelector('.inv-chip.on').dataset.invPlat, 'crunchyroll');
  assert.equal(d.querySelectorAll('.inv-chip img.pf-logo').length, 2);
  assert.equal(d.querySelectorAll('#invSort option').length, 4);
  assert.deepEqual([...d.querySelectorAll('[data-inv-open]')].map(b => b.dataset.invOpen), ['a1', 'a2']);
  assert.match(d.querySelector('.inv-row').textContent, /jujutsu@sublicuentas\.com/);
  assert.match(d.querySelector('.inv-row .inv-free').textContent, /2libres/);
  assert.match(d.querySelectorAll('.inv-row')[1].querySelector('.inv-free').textContent, /0llena/);
  assert.match(d.querySelector('.inv-tag').textContent, /1\/3 ocupados/);
  assert.ok(d.querySelector('#backMore') && d.querySelector('#invFilterBtn'));
  assert.equal(dom(inventoryScreenHtml({ filtersOpen: true })).querySelectorAll('[data-inv-cupo]').length, 3);
  assert.match(main, /return inventoryScreenHtml\(\{platforms,total:all\.length/);
});

test('Inventario ⋮: cuenta con clave, perfiles disponibles y asignados (como Sublichat)', () => {
  const d = dom(inventoryDetailHtml({ item: INV[0], label: 'Crunchyroll' }));
  const t = d.body.textContent;
  assert.match(t, /Correo/); assert.match(t, /jujutsu@sublicuentas\.com/);
  assert.match(t, /Clave/); assert.doesNotMatch(t, /Clave-123/, 'R69: la clave sale oculta por defecto'); assert.equal(d.querySelector('[data-secret="Clave-123"]').textContent, '••••••••'); assert.ok(d.querySelector('[data-reveal]'));
  assert.match(t, /Capacidad3/); assert.match(t, /Ocupados1/); assert.match(t, /Disponibles2/);
  assert.deepEqual([...d.querySelectorAll('.inv-slots span')].map(s => s.textContent), ['Perfil 1', 'Perfil 3']);
  assert.match(d.querySelector('.inv-assigned').textContent, /Perfil 2/); assert.match(d.querySelector('.inv-assigned').textContent, /Ana Paz/); assert.doesNotMatch(d.querySelector('.inv-assigned').textContent, /4321/, 'R69: PIN oculto'); assert.ok(d.querySelector('.inv-assigned [data-secret="4321"]'));
  assert.equal(d.querySelectorAll('[data-copy]').length, 2);
  assert.equal(d.querySelector('[data-copy="Clave-123"]').tagName, 'BUTTON');
  assert.ok(d.querySelector('[data-copy-all]'));
  assert.match(inventoryCopyText({ item: INV[0], label: 'Crunchyroll' }), /Crunchyroll\nCorreo: jujutsu@sublicuentas\.com\nClave: Clave-123/);
  assert.match(dom(inventoryDetailHtml({ item: INV[1], label: 'Netflix VIP' })).body.textContent, /cuenta está llena/);
  assert.equal(invUsaUsuario('stellatv1'), true); assert.equal(invUsaUsuario('netflix'), false);
  assert.match(inventoryCopyText({ item: { plataforma: 'stellatv1', correo: 'u1', clave: 'p' }, label: 'Stella TV' }), /Usuario: u1/);
  assert.deepEqual(inventoryStats(INV[0]), { clients: INV[0].clientes, used: 1, free: 2, cap: 3 });
  assert.equal(inventoryFreeSlots({ capacidad: 2, disponibles: 1, clientes: [{ nombre: 'x' }] }).count, 1);
  assert.match(main, /openSheet\(inventoryDetailHtml\(/);
  assert.match(main, /navigator\.clipboard\.writeText/);
});

test('Inicio nunca hace scroll: siempre fijo y, si no cabe, se ajusta la escala', () => {
  const block = main.slice(main.indexOf('function afterRender()'), main.indexOf('function openRenewGroup'));
  assert.match(block, /if \(shell && state\.session && !state\.splash && state\.active==='inicio'\) \{[\s\S]*shell\.classList\.add\('home-fixed'\)/);
  assert.doesNotMatch(block, /if \(contentBottom<=limit\+2\) \{ window\.scrollTo\(0,0\); shell\.classList\.add/);
  assert.match(block, /shell\.style\.zoom=/);
  assert.match(css, /\.app-main\.home-fixed\{overscroll-behavior:none;touch-action:none\}/);
  assert.match(css, /\.app-main\.home-fixed\{[^}]*overflow:hidden/);
});
