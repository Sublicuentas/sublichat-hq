import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { JSDOM } from 'jsdom';
import { matchesContentHtml, todayHN } from '../src/more.js';

const main = appSource();
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
const dom = html => new JSDOM(`<body>${html}</body>`).window.document;

test('Scroll: solo Inicio se fija, y la clase vive en el <main> (no en body) para no bloquear otras pantallas', () => {
  assert.match(css, /\.app-main\.home-fixed\{[^}]*overflow:hidden/);
  assert.doesNotMatch(css, /body\.home-lock\{/);
  assert.doesNotMatch(css, /html,body\{[^}]*overflow-x:hidden/);
  assert.doesNotMatch(css, /\.app-main\{overflow-x:hidden/);
  assert.match(css, /\.app-main\{overflow-x:clip/);
  assert.match(main, /shell\.classList\.add\('home-fixed'\)/);
  assert.doesNotMatch(main, /document\.body\.classList\.add\('home-lock'\)/);
  // home-fixed solo se agrega dentro del if de Inicio
  const block = main.slice(main.indexOf('function afterRender()'), main.indexOf('function openRenewGroup'));
  assert.match(block, /state\.active==='inicio'/);
  assert.ok((block.match(/home-fixed/g) || []).length >= 1);
});

test('Inicio: el robot ya no pisa la campana ni la foto (hero bajo la barra de estado)', () => {
  assert.match(css, /\.visual-home-hero\{margin-top:calc\(-18px - env\(safe-area-inset-top\)\)!important;min-height:calc\(248px \+ env\(safe-area-inset-top\)\)!important\}/);
});

test('Partidos: "Hoy" solo muestra partidos de hoy y avisa cuando son próximos o la carga fue parcial', () => {
  const today = todayHN();
  const other = '2099-01-05';
  const rows = [
    { liga: 'NBA', local: 'A', visita: 'B', dia: today, horaHN: 'hoy, 8:00 p. m.', estado: 'NS' },
    { liga: 'UFC', local: 'C', visita: 'D', dia: other, horaHN: 'lun, 5 ene, 5:00 p. m.', estado: 'NS' },
  ];
  const hoy = dom(matchesContentHtml({ mode: 'hoy', matches: rows, today, meta: { soloProximos: false, parcial: false } }));
  assert.equal(hoy.querySelectorAll('.mt-row').length, 1, 'solo el partido de hoy');
  assert.match(hoy.querySelector('.mt-day').textContent, /^Hoy · /);
  const prox = dom(matchesContentHtml({ mode: 'hoy', matches: [rows[1]], today, meta: { soloProximos: true } }));
  assert.match(prox.querySelector('.mt-note').textContent, /no hay partidos, o no se pudieron cargar/);
  assert.match(prox.body.textContent, /próximos eventos/);
  const parcial = dom(matchesContentHtml({ mode: 'hoy', matches: [rows[0]], today, meta: { parcial: true } }));
  assert.match(parcial.querySelector('.mt-note').textContent, /Algunas ligas no respondieron/);
  const nba = dom(matchesContentHtml({ mode: 'nba', matches: rows }));
  assert.equal(nba.querySelectorAll('.mt-row').length, 2, 'otros modos muestran todo');
  assert.doesNotMatch(nba.body.textContent, /Algunas ligas/);
});

test('Partidos: el error de la API llega con su motivo', () => {
  assert.match(main, /data\.detalle\[0\]/);
  assert.match(main, /parcial:Boolean\(data\?\.parcial\)/);
});
