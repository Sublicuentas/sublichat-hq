import test from 'node:test';
import assert from 'node:assert/strict';
import { buildExportDataset, servicesToCsv, servicesToTxt, exportFileName, buildExportWorkbook } from '../src/exportar.js';
import { bootApp } from './helpers/ui-harness.mjs';

const d = off => { const x = new Date(); x.setDate(x.getDate() + off); return `${String(x.getDate()).padStart(2, '0')}/${String(x.getMonth() + 1).padStart(2, '0')}/${x.getFullYear()}`; };
const rows = [
  { clienteId: 'c1', nombre: 'Wendy Borjas', telefono: '32195958', vendedor: 'Sublicuentas', plataforma: 'hbomax', precio: 80, fechaRenovacion: d(0), correo: 'w@x.com', perfiles: [{ clave: 'SECRETA', pinPerfil: '1234' }], raw: { clave: 'SECRETA', pin: '9999', token: 'tok', mesesContratados: 1 } },
  { clienteId: 'c1', nombre: 'Wendy Borjas', telefono: '32195958', vendedor: 'Sublicuentas', plataforma: 'viki', precio: 70, fechaRenovacion: d(4), perfiles: [], raw: {} },
  { clienteId: 'c2', nombre: 'José Núñez', telefono: '99', vendedor: 'Relojes', plataforma: 'netflix', precio: 130, fechaRenovacion: d(-2), perfiles: [], raw: {} },
];

test('R65 dataset: allowlist sin credenciales; clientes, servicios y total cuadran', () => {
  const data = buildExportDataset(rows);
  const json = JSON.stringify(data);
  for (const bad of ['SECRETA', '1234', '9999', 'tok', 'w@x.com']) assert.ok(!json.includes(bad), `no debe salir ${bad}`);
  assert.equal(data.meta.totalClients, 2); assert.equal(data.meta.totalServices, 3); assert.equal(data.meta.totalHnl, 280);
  assert.deepEqual(data.services.map(s => s.estado), ['HOY', 'PROXIMO', 'VENCIDO']);
  assert.equal(data.clients.find(c => c.cliente === 'Wendy Borjas').servicios, 2, 'cliente con varios servicios');
});

test('R65 CSV UTF-8 con tildes, TXT una fila por servicio, nombre de archivo del spec', async () => {
  const data = buildExportDataset(rows);
  const csv = servicesToCsv(data.services);
  assert.ok(csv.startsWith('\uFEFF')); assert.match(csv, /José Núñez/);
  const txt = servicesToTxt(data.services).split('\n'); assert.equal(txt.length, 4); assert.ok(txt.every(l => !l.includes('\r')));
  assert.equal(exportFileName('CLIENTES', 'vencidos', 'xlsx', new Date(2026, 8, 24)), 'SUBLICHAT_CLIENTES_VENCIDOS_2026-09-24.xlsx');
  assert.equal(exportFileName('COBROS', 'hoy', 'xlsx', new Date(2026, 8, 24)), 'SUBLICHAT_COBROS_HOY_2026-09-24.xlsx');
  const mod = await import('exceljs'); const ExcelJS = mod.default || mod;
  const wb = buildExportWorkbook(ExcelJS, data);
  assert.deepEqual(wb.worksheets.map(w => w.name), ['Resumen', 'Clientes', 'Servicios']);
  assert.equal(wb.getWorksheet('Servicios').rowCount, 4);
});

test('R65 botones Exportar en Clientes y Cobros abren la hoja con alcance y formato', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 400);
    assert.ok(app.$('.cli-tools #exportClients'), 'junto a "Más recientes"');
    await app.click('#exportClients', 200);
    const sheet = app.w.document.getElementById('srSheetHost');
    assert.ok(sheet && sheet.querySelector('input[name="exScope"][value="filtered"]:checked') && sheet.querySelector('input[name="exFormat"][value="xlsx"]:checked'));
    assert.match(sheet.textContent, /Sin claves, PIN/);
    sheet.querySelector('[data-sr-cancel]').click(); await app.sleep(100);
    await app.click('[data-tab="cobros"]', 400);
    assert.ok(app.$('.cb-date #exportCobros'), 'a la derecha del encabezado de fecha');
  } finally { app.close(); }
});
