import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const api=fs.readFileSync(new URL('../src/api.js', import.meta.url),'utf8');
test('Tickets Android includes create ticket, notices, recipients, image and replies',()=>{
  for(const token of ['Nuevo ticket','Publicar aviso','Todos','Personalizar','Adjuntar foto','Enviar ticket','Enviar aviso','Responder','En proceso','Finalizar']) assert.ok(main.includes(token),`missing ${token}`);
  assert.ok(api.includes('ticketAction'));
  for(const action of ["accion:'crear'","accion:'responder'","accion:'proceso'","accion:'resolver'"]) assert.ok(main.includes(action), `missing ${action}`);
});
