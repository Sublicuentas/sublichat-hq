import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=appSource() + '\n' + fs.readFileSync(new URL('../src/screens2.js', import.meta.url), 'utf8');
const api=fs.readFileSync(new URL('../src/api.js', import.meta.url),'utf8');
test('Tickets Android includes create ticket, notices, recipients, image and replies',()=>{
  for(const token of ['Nuevo ticket','Publicar aviso','Todos','Personalizar','Adjuntar foto','Enviar ticket','Enviar aviso','Responder','En proceso','Finalizar']) assert.ok(main.includes(token),`missing ${token}`);
  assert.ok(api.includes('ticketAction'));
  for(const action of ["accion:'crear'","accion:'responder'","accion:'proceso'","accion:'resolver'"]) assert.ok(main.includes(action), `missing ${action}`);
});

test('R20.1 Telegram: avisos pendientes exponen reintento y no se reportan como enviados', () => {
  assert.match(main, /reenviar_telegram/);
  assert.match(main, /data-ticket-retry-telegram/);
  assert.match(main, /Telegram no enviado/);
  assert.match(main, /telegramInfo/);
});
