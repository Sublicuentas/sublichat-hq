import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');

test('Android login bypasses patched Capacitor fetch and uses dedicated mobile endpoint', () => {
  assert.match(api, /globalThis\.CapacitorWebFetch/);
  assert.match(api, /\/api\/mobile-core\?action=login/);
  assert.match(api, /loginWebFetch\(\)/);
});
