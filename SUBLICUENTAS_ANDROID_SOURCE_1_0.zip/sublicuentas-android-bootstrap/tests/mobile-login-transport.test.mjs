import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const api = fs.readFileSync(new URL('../src/api.js', import.meta.url), 'utf8');

test('Android login calls the canonical /api/login endpoint directly through native transport', () => {
  assert.match(api, /nativeJsonRequest/);
  assert.match(api, /\/api\/login/);
  assert.equal(api.includes('/api/mobile-core?action=login'), false);
});
