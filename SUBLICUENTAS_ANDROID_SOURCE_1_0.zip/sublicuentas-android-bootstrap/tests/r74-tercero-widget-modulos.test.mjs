import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { serviceRowsFromClients, filterOperationalRows, filterClients } from '../src/data.js';
import { groupRenewalsByClientDate } from '../src/operations.js';
import { widgetPayload } from '../src/recordatorios.js';

const f = d => `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
const hoy = new Date(); const manana = new Date(); manana.setDate(hoy.getDate() + 1); const ayer = new Date(); ayer.setDate(hoy.getDate() - 1);
const clients = [
  { id: 'k1', nombrePerfil: 'Kassandra Molina', telefono: '89613761', vendedor: 'Relojes', servicios: [
    { plataforma: 'netflix', vendedor: 'Relojes', precio: 150, fechaRenovacion: f(manana), beneficiarioTipo: 'titular' },
    { plataforma: 'hbomax', vendedor: 'Relojes', precio: 80, fechaRenovacion: f(hoy), beneficiarioTipo: 'tercero', beneficiarioNombre: 'Aracely Méndes' } ] },
  { id: 's1', nombrePerfil: 'Otro Cliente', vendedor: 'Sublicuentas', servicios: [ { plataforma: 'disneyp', vendedor: 'Sublicuentas', precio: 100, fechaRenovacion: f(ayer) } ] },
];

test('R74 buscar por el nombre del tercero encuentra la ficha del titular (Clientes y buscador del CRM)', () => {
  const rows = serviceRowsFromClients(clients);
  const hits = filterOperationalRows(rows, { query: 'aracely', status: 'vigentes' });
  assert.equal(hits.length, 1); assert.equal(hits[0].nombre, 'Kassandra Molina');
  assert.equal(filterOperationalRows(rows, { query: 'mendes', status: 'vigentes' }).length, 1, 'sin tilde también');
  assert.equal(filterClients(clients, 'Aracely')[0]?.id, 'k1');
  assert.equal(filterOperationalRows(rows, { query: 'aracely', status: 'vencidos' }).length, 0);
});

test('R74 datos del widget: solo los cobros del usuario, agrupados por fecha', () => {
  const groups = groupRenewalsByClientDate(serviceRowsFromClients(clients));
  const p = widgetPayload({ groups, seller: 'relojes', sellerLabel: 'Relojes', now: new Date(2026, 8, 26, 4, 40) });
  assert.equal(p.vendedor, 'Relojes'); assert.equal(p.actualizado, '04:40');
  const key = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  assert.deepEqual(p.dias, { [key(hoy)]: 1, [key(manana)]: 1 }, 'Relojes: tercero hoy + titular mañana; nada de Sublicuentas');
  assert.deepEqual(widgetPayload({ groups, seller: 'sublicuentas' }).dias, { [key(ayer)]: 1 });
});

test('R74 el script nativo agrega widget + plugin al proyecto Android y es idempotente', () => {
  const root = new URL('..', import.meta.url).pathname;
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'r74-'));
  const pkg = path.join(tmp, 'android/app/src/main/java/com/sublicuentas/app'); fs.mkdirSync(pkg, { recursive: true });
  fs.writeFileSync(path.join(pkg, 'MainActivity.java'), 'package com.sublicuentas.app;\n\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {}\n');
  fs.writeFileSync(path.join(tmp, 'android/app/src/main/AndroidManifest.xml'), '<manifest><application>\n    </application></manifest>');
  fs.mkdirSync(path.join(tmp, 'scripts')); fs.copyFileSync(path.join(root, 'scripts/android-native.mjs'), path.join(tmp, 'scripts/android-native.mjs'));
  fs.cpSync(path.join(root, 'android-native'), path.join(tmp, 'android-native'), { recursive: true });
  for (let i = 0; i < 2; i += 1) execFileSync(process.execPath, [path.join(tmp, 'scripts/android-native.mjs')], { stdio: 'ignore' });
  const manifest = fs.readFileSync(path.join(tmp, 'android/app/src/main/AndroidManifest.xml'), 'utf8');
  assert.equal(manifest.split('.CobrosWidgetProvider').length - 1, 1);
  assert.match(manifest, /@xml\/widget_cobros_info/);
  assert.match(fs.readFileSync(path.join(pkg, 'MainActivity.java'), 'utf8'), /registerPlugin\(SubliWidgetPlugin\.class\)/);
  for (const f of ['CobrosWidgetProvider.java', 'SubliWidgetPlugin.java']) assert.ok(fs.existsSync(path.join(pkg, f)));
  for (const f of ['layout/widget_cobros.xml', 'xml/widget_cobros_info.xml', 'drawable/widget_bg.xml']) assert.ok(fs.existsSync(path.join(root, 'android-res', f)), f);
  assert.match(JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).scripts['capacitor:sync:after'], /android-native\.mjs/);
});

test('R74 main.js dividido: núcleo y pantallas en src/app/', () => {
  const root = new URL('../src/', import.meta.url);
  for (const m of ['core', 'icons', 'frases', 'avisos', 'cobros', 'inicio']) assert.ok(fs.existsSync(new URL(`app/${m}.js`, root)), m);
  const main = fs.readFileSync(new URL('main.js', root), 'utf8');
  assert.ok(main.split('\n').length < 2000);
  assert.doesNotMatch(main, /^const state = \{/m, 'el estado vive en src/app/core.js');
  assert.match(main, /ui\.render=/);
});
