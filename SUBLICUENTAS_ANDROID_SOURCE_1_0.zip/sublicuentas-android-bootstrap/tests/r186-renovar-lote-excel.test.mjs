// R186 · APK: renovar varios servicios = UNA operación en el servidor con UN pago y monto por servicio;
// vista previa con la fecha del servidor; Excel del mes a Descargas (sin "Compartir"); motor de fechas igual al servidor.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp, pagarHojaRenovacion } from './helpers/ui-harness.mjs';
import { renewalDateForPick } from '../src/operations.js';
import { sumarPeriodo } from '../src/app/renovacion-motor.js';

test('motor de la APK = motor del servidor (vectores R01/R02/R03 y vencido sin adelantar al día del pago)', () => {
  assert.equal(renewalDateForPick('04/11/2026', { months: 3 }), '04/02/2027');
  assert.equal(renewalDateForPick('04/11/2026', { days: 30 }), '04/12/2026');
  assert.equal(renewalDateForPick('04/11/2026', { days: 31 }), '05/12/2026');
  assert.equal(renewalDateForPick('04/11/2026', { months: 1 }), '04/12/2026', '1 mes = 30 días');
  assert.equal(renewalDateForPick('01/09/2026', { months: 1 }, new Date(2026, 10, 7, 12)), '01/10/2026', 'vencido: desde el vencimiento, no desde hoy');
  assert.equal(sumarPeriodo('30/11/2026', { unidad: 'meses', cantidad: 3 }).fechaNueva, '28/02/2027');
  const a = fs.readFileSync(new URL('../src/app/renovacion-motor.js', import.meta.url), 'utf8');
  assert.match(a, /COPIA FIEL de Sublichat HQ api\/_renovacion-motor\.js/);
});

test('renovar con pago: vista previa del servidor → hoja con un renglón por servicio → renovar_lote con 1 pago', async () => {
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (path, body) => {
    if (path !== '/api/renovar' || body.accion !== 'renovar_lote') return undefined;
    const lineas = (body.lineas || []).map((l, i) => ({ compraId: l.compraId, servicioIndex: l.servicioIndex ?? i, plataforma: l.plataforma, fechaAnterior: '04/11/2026', fechaNueva: '04/12/2026', periodos: 1, sigueVencida: false, monto: l.monto }));
    if (body.soloVista) return { ok: true, vista: true, lineas };
    return { ok: true, verified: true, accion: 'renovar_lote', lineas, total: body.pago?.montoTotal, pagoOperacion: { estado: 'pagado' } };
  } });
  try {
    await app.click('[data-tab="clientes"]', 400);
    await app.click(app.$('.cli-card .cli-dots'), 200);
    await app.click(app.$('[data-client-action="renew"]') || app.$('[data-client-action="charge"]'), 250);
    await app.click(app.$('[data-renew-days="30"]') || app.$$('[data-renew-days]')[0], 60);
    await app.click('#renewApply', 300);
    const prev = app.bodies.find((b) => b?.accion === 'renovar_lote' && b.soloVista);
    assert.ok(prev, 'pide la vista previa al servidor (no calcula en el teléfono)');
    assert.match(app.$('.fl-sheet')?.textContent || '', /vence 04\/11\/2026 → nuevo 04\/12\/2026/);
    assert.equal(app.$$('[data-rp-pagado]').length, 0, 'R196n: ya NO pide un monto por servicio');
    assert.ok(app.$('#rpCobrado'), 'R196n: un solo importe recibido');
    await pagarHojaRenovacion(app, '220');
    await app.waitFor(() => app.bodies.some((b) => b?.accion === 'renovar_lote' && !b.soloVista));
    const real = app.bodies.find((b) => b?.accion === 'renovar_lote' && !b.soloVista);
    assert.equal(real.pago.montoTotal, 220 * real.lineas.length); assert.equal(real.lineas.reduce((a, l) => a + l.monto, 0), real.pago.montoTotal);
    assert.ok(real.operationId && real.pago.operationId === real.operationId, 'mismo operationId para reintentos');
    assert.equal(app.bodies.filter((b) => b?.accion === 'renovar').length, 0, 'ya no manda una renovación por servicio');
    assert.equal(app.bodies.filter((b) => b?.accion === 'registrar_operacion_pago').length, 0, 'sin segundo cobro');
  } finally { app.close(); }
});

test('Excel: "Descargar" guarda en Descargas con el método nativo (MediaStore), sin abrir Compartir; tarjeta del mes', () => {
  const ff = fs.readFileSync(new URL('../src/finanzas-file.js', import.meta.url), 'utf8');
  assert.match(ff, /export async function guardarEnDescargas/); assert.match(ff, /plugin\.guardarDescarga\(/);
  const fn = ff.slice(ff.indexOf('export async function guardarEnDescargas'));
  assert.doesNotMatch(fn.split('catch (e)')[0], /Share\.share/);
  const java = fs.readFileSync(new URL('../android-native/java/SubliWidgetPlugin.java', import.meta.url), 'utf8');
  assert.match(java, /MediaStore\.Downloads\.EXTERNAL_CONTENT_URI/); assert.match(java, /public void guardarDescarga\(PluginCall call\)/);
  const lib = fs.readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  assert.match(lib, /accion: 'finanzas_mes'/); assert.match(lib, /Descargar Excel del mes/);
});
