// R198e · Fase 5 (QA) del PDF «Sublichat APK: modo offline completo»: casos que faltaban de la lista de 20 pruebas
// obligatorias, en simulación (jsdom + almacenamiento del teléfono). Lo que exige un teléfono real va en el reporte.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp, pagarHojaRenovacion } from './helpers/ui-harness.mjs';
import { miniIndexedDB } from './helpers/mini-idb.mjs';
import { cargarModulo } from './helpers/modulo-jsdom.mjs';

const dev = () => ({ idb: miniIndexedDB(), seguro: new Map(), local: new Map(), avion: false });
const SES = (u) => ({ usuario: u, role: u, uid: 'u', idToken: 't', refreshToken: 'r', expiresAt: Date.now() + 3.6e6 });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('10 · el MISMO borrador guardado dos veces sin señal queda UNA vez en la cola (fichas/renovaciones); dos egresos iguales no se fusionan', async () => {
  const d = dev(); d.avion = true;
  const { M, S: st, close } = await cargarModulo('app/offline-queue.js', { dispositivo: d });
  try {
    st.session = SES('sublicuentas'); st.clients = []; st.pendingOps = [];
    const ficha = { kind: 'ficha', path: '/api/renovar', label: 'Netflix · Prueba', body: { accion: 'ficha_upsert', clienteId: '', cliente: { nombrePerfil: 'Prueba' }, servicio: { compraId: 'cmp-1', plataforma: 'netflix', precio: 130 }, operationId: 'op-a' } };
    await M.enqueueOp(ficha); await M.enqueueOp({ ...ficha, body: { ...ficha.body, operationId: 'op-b' } });
    assert.equal(st.pendingOps.length, 1, 'doble toque: una sola venta en cola');
    const eg = { kind: 'egreso', path: '/api/finanzas', label: 'Egreso L50', body: { accion: 'registrar_egreso', motivo: 'Taxi', monto: 50, operationId: 'op-c' } };
    await M.enqueueOp(eg); await M.enqueueOp({ ...eg, body: { ...eg.body, operationId: 'op-d' } });
    assert.equal(st.pendingOps.length, 3, 'dos egresos iguales pueden ser reales: no se fusionan');
    assert.equal(st.pendingOps[0].body.colaOffline, true);
  } finally { close(); }
});

test('15 · cerrar sesión borra copia, cola y llave; el siguiente usuario no ve nada del anterior', async () => {
  const d = dev();
  const a = await bootApp({ role: 'sublicuentas', dispositivo: d });
  try {
    await a.sleep(1500);
    assert.ok([...d.idb._bases.keys()].includes('sublicuentas-offline-r101'), 'había copia cifrada');
    a.w.confirm = () => true;
    await a.click('[data-tab="mas"]', 300); await a.click('[data-open="perfil"]', 400);
    await a.click('#logoutBtn', 600);
    assert.equal([...d.idb._bases.keys()].includes('sublicuentas-offline-r101'), false, 'base cifrada borrada');
    assert.equal(d.seguro.has('offline_key_v1'), false, 'sin la llave nada se puede abrir');
    assert.equal(a.w.localStorage.getItem('sublicuentas-core-cache-r69'), null);
  } finally { a.close(); }
});

test('16 · permiso retirado en el servidor (403): se borra la copia de ese módulo y sin señal ya no se muestra', async () => {
  const d = dev();
  const { M, S: st, close } = await cargarModulo('app/offline-consulta.js', { dispositivo: d });
  try {
    st.session = SES('relojes');
    const r = await M.leerConCopia('fin', 'resumen', async () => ({ ok: true, totales: { ingresos: 100 } }));
    assert.equal(r.totales.ingresos, 100);
    d.avion = true; const c = await M.leerConCopia('fin', 'resumen', async () => { throw new TypeError('Failed to fetch'); });
    assert.ok(c._copiaAt, 'sin señal: copia con fecha');
    d.avion = false; await assert.rejects(M.leerConCopia('fin', 'resumen', async () => { throw Object.assign(new Error('Sin permiso'), { status: 403 }); }));
    d.avion = true; await assert.rejects(M.leerConCopia('fin', 'resumen', async () => { throw new TypeError('Failed to fetch'); }), /no se había descargado/, 'la copia financiera ya no existe');
    assert.equal(M.VIGENCIA_VISTA.fin, 2 * 86400000, 'y aun sin revocación, Finanzas vence a los 2 días');
  } finally { close(); }
});

test('18 · Wi-Fi/datos alternando varias veces: un solo envío confirmado, sin «Subiendo…» eterno ni caché dañado', async () => {
  const d = dev();
  const a = await bootApp({ role: 'sublicuentas', dispositivo: d });
  try {
    await a.sleep(1200);
    await a.click('[data-tab="clientes"]', 400); await a.click(a.$('.cli-card .cli-dots'), 200);
    await a.click(a.$('[data-client-action="renew"]') || a.$('[data-client-action="charge"]'), 250);
    await a.click(a.$('[data-renew-days="30"]') || a.$$('[data-renew-days]')[0], 60);
    await a.click('#renewApply', 400); await a.waitFor(() => a.$('[data-rp-banco]'), 3000);
    d.avion = true; a.w.dispatchEvent(new a.w.Event('offline')); await pagarHojaRenovacion(a, '130'); await a.sleep(500);
    for (let i = 0; i < 4; i++) { d.avion = !d.avion; a.w.dispatchEvent(new a.w.Event(d.avion ? 'offline' : 'online')); await a.sleep(250); }
    d.avion = false; a.w.dispatchEvent(new a.w.Event('online'));
    await a.waitFor(() => !a.$('.offline-band'), 9000); await a.sleep(400);
    const env = a.bodies.filter((b) => b?.accion === 'renovar');
    assert.ok(env.length >= 1); assert.equal(new Set(env.map((b) => b.operationId)).size, 1, 'todos los intentos con el MISMO operationId');
    assert.equal(a.$('.offline-band'), null, 'cola vacía al final');
    assert.ok(a.$('.cli-card'), 'la lista sigue sana');
  } finally { a.close(); }
});

test('19 · actualización de la APK: un cambio de la cola guardado por la versión anterior (sin estado ni intentos) se envía igual', () => {
  const q = fs.readFileSync(new URL('../src/app/offline-queue.js', import.meta.url), 'utf8');
  assert.match(q, /intentos:\(Number\(queue\[0\]\.intentos\)\|\|0\)\+1/, 'intentos ausente = 0');
  assert.match(q, /const op=\{\.\.\.queue\[0\],estado:'enviando'/, 'estado ausente: se manda igual');
  const o = fs.readFileSync(new URL('../src/app/offline.js', import.meta.url), 'utf8');
  assert.match(o, /const DB_NAME = 'sublicuentas-offline-r101'/, 'misma base: no se pierden borradores al actualizar');
  assert.match(o, /`queue:\$\{norm\(usuario\)\}`/);
});

test('Matriz de las 20 pruebas del PDF: cada una tiene evidencia automática o queda marcada para el teléfono real', () => {
  const r = fs.readFileSync(new URL('../docs/QA_OFFLINE_R198.md', import.meta.url), 'utf8');
  for (let i = 1; i <= 20; i++) assert.match(r, new RegExp(`\\| ${String(i).padStart(2, '0')} \\|`), `prueba ${i} en el reporte`);
});
