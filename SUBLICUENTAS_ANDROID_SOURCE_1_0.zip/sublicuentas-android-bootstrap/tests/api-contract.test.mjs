import test from 'node:test';
import assert from 'node:assert/strict';
import { API_BASE, decodeFirestoreValue, decodeFirestoreDocument, buildRenewalPayload, raffleLoadPayload, isRedirectStatus, resolveSafeRedirectUrl } from '../src/api.js';

test('Firestore REST values decode into normal JavaScript data', () => {
  const value = decodeFirestoreValue({ mapValue:{ fields:{ name:{stringValue:'Ana'}, active:{booleanValue:true}, amount:{integerValue:'130'}, tags:{arrayValue:{values:[{stringValue:'vip'}]}} } } });
  assert.deepEqual(value, { name:'Ana', active:true, amount:130, tags:['vip'] });
});

test('Firestore document preserves document id', () => {
  const doc = decodeFirestoreDocument({ name:'projects/x/databases/(default)/documents/clientes/abc123', fields:{ nombrePerfil:{stringValue:'Ana'} } });
  assert.equal(doc.id, 'abc123');
  assert.equal(doc.nombrePerfil, 'Ana');
});

test('renewal payload prioritizes clienteId and compraId and keeps DD/MM/YYYY', () => {
  const payload = buildRenewalPayload({ clienteId:'c1', compraId:'cmp1', servicioIndex:4, plataforma:'Netflix', correo:'a@b.com', fechaRenovacion:'16/09/2026', telefono:'9999-0000', nombreNorm:'ana' }, 30);
  assert.equal(payload.accion, 'renovar');
  assert.equal(payload.clienteId, 'c1');
  assert.equal(payload.compraId, 'cmp1');
  assert.equal(payload.fechaActual, '16/09/2026');
  assert.equal(payload.dias, 30);
});


test('raffle load uses the current sorteos API accion contract', () => {
  assert.deepEqual(raffleLoadPayload(), { accion:'cargar' });
});


test('login transport recognizes 307 and 308 as redirects', () => {
  assert.equal(isRedirectStatus(307), true);
  assert.equal(isRedirectStatus(308), true);
  assert.equal(isRedirectStatus(401), false);
});

test('login transport only follows HTTPS redirects to trusted Sublicuentas hosts', () => {
  assert.equal(
    resolveSafeRedirectUrl('https://sublichat-hq.vercel.app/api/login', 'https://sublicuentas.com/api/login'),
    'https://sublicuentas.com/api/login'
  );
  assert.equal(
    resolveSafeRedirectUrl('https://sublichat-hq.vercel.app/api/login', '/api/login'),
    'https://sublichat-hq.vercel.app/api/login'
  );
  assert.throws(() => resolveSafeRedirectUrl('https://sublichat-hq.vercel.app/api/login', 'http://sublicuentas.com/api/login'), /segura/i);
  assert.throws(() => resolveSafeRedirectUrl('https://sublichat-hq.vercel.app/api/login', 'https://evil.example/api/login'), /autorizado/i);
});


test('Android Core base uses the canonical Sublichat domain and trusts its redirect host', () => {
  assert.equal(API_BASE, 'https://sublichat.capuchino.lat');
  assert.equal(
    resolveSafeRedirectUrl('https://sublichat-hq.vercel.app/api/login', 'https://sublichat.capuchino.lat/api/login'),
    'https://sublichat.capuchino.lat/api/login'
  );
});
