import test from 'node:test';
import assert from 'node:assert/strict';
import { decodeFirestoreValue, decodeFirestoreDocument, buildRenewalPayload, raffleLoadPayload } from '../src/api.js';

test('Firestore REST values decode into normal JavaScript data', () => {
  const value = decodeFirestoreValue({ mapValue:{ fields:{ name:{stringValue:'Ana'}, active:{booleanValue:true}, amount:{integerValue:'130'}, tags:{arrayValue:{values:[{stringValue:'vip'}]}} } } });
  assert.deepEqual(value, { name:'Ana', active:true, amount:130, tags:['vip'] });
});

test('Firestore document preserves document id', () => {
  const doc = decodeFirestoreDocument({ name:'projects/x/databases/(default)/documents/clientes/abc123', fields:{ nombrePerfil:{stringValue:'Ana'} } });
  assert.equal(doc.id, 'abc123');
  assert.equal(doc.nombrePerfil, 'Ana');
});

test('renewal payload prioritizes clienteId and compraId and keeps DD/MM/YYYY', () => {
  const payload = buildRenewalPayload({ clienteId:'c1', compraId:'cmp1', servicioIndex:4, plataforma:'Netflix', correo:'a@b.com', fechaRenovacion:'16/09/2026', telefono:'9999-0000', nombreNorm:'ana' }, 30);
  assert.equal(payload.accion, 'renovar');
  assert.equal(payload.clienteId, 'c1');
  assert.equal(payload.compraId, 'cmp1');
  assert.equal(payload.fechaActual, '16/09/2026');
  assert.equal(payload.dias, 30);
});


test('raffle load uses the current sorteos API accion contract', () => {
  assert.deepEqual(raffleLoadPayload(), { accion:'cargar' });
});
