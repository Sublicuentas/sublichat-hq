import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('R21.3 forces the operational UI to the light Sublicuentas canvas',()=>{
  assert.match(css,/R21\.3/);
  assert.match(css,/--bg:#f7fbfe/);
  assert.match(css,/color-scheme:light/);
});
test('R21.3 uses a narrower mobile login form',()=>{
  assert.match(css,/\.visual-login-form\{[^}]*left:14%[^}]*right:14%/s);
});
test('R21.3 gives primary and navigation controls tactile 3D relief',()=>{
  assert.match(css,/box-shadow:0 7px 0/);
  assert.match(css,/\.bottom-nav button\.active[^}]*box-shadow/s);
});
test('R21.3 requests native fullscreen status bar hiding',()=>{
  assert.equal(pkg.dependencies['@capacitor/status-bar'],'^8.0.0');
  assert.match(main,/StatusBar\.hide/);
});
