import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const res = f => fs.readFileSync(new URL(`../android-res/${f}`, import.meta.url), 'utf8');
const java = f => fs.readFileSync(new URL(`../android-native/java/${f}`, import.meta.url), 'utf8');

test('R76 widget grande: diseño Marca Sublicuentas (azul marino, Subli en rojo, montos, barra roja)', () => {
  assert.match(res('drawable/widget_bg.xml'), /#0D2A5C/);
  const l = res('layout/widget_cobros.xml');
  assert.match(l, /android:text="Subli"[\s\S]*?#FF4B43/);
  for (const id of ['widget_hoy_total', 'widget_proximos_total', 'widget_vencidos_total']) assert.match(l, new RegExp(`@\\+id/${id}"`));
  assert.match(l, /@drawable\/widget_bar/);
  assert.match(java('CobrosWidgetProvider.java'), /L %,\.0f/);
});

test('R76 widget pequeño 2x1 con los mismos números', () => {
  const info = res('xml/widget_cobros_mini_info.xml');
  assert.match(info, /targetCellWidth="2"/); assert.match(info, /targetCellHeight="1"/);
  assert.match(java('CobrosWidgetMiniProvider.java'), /CobrosWidgetProvider\.leer\(context\)/);
  assert.match(java('SubliWidgetPlugin.java'), /CobrosWidgetMiniProvider\.updateAll/);
});

test('R76 el widget lee el formato nuevo {n,t} y el viejo (solo número)', () => {
  const j = java('CobrosWidgetProvider.java');
  assert.match(j, /dia != null \? dia\.optInt\("n", 0\) : dias\.optInt\(k, 0\)/);
});
