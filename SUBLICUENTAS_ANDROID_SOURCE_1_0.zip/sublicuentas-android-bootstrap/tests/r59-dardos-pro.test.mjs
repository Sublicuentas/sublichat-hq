import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreAtNormalized, calculateDartScore, dartsGameCreate, applyHit, dartsGameSubmission, calculateThrowVector, calculateProjectedImpact, DART_NUMBERS } from '../src/dardos.js';

const T20 = scoreAtNormalized(0, -0.6), BULL = scoreAtNormalized(0, 0), ONE = scoreAtNormalized(Math.sin(Math.PI / 10) * 0.4, -Math.cos(Math.PI / 10) * 0.4);

test('R59 scoring determinista (pruebas mínimas del PDF)', () => {
  assert.equal(BULL.score, 50); assert.equal(scoreAtNormalized(0.05, 0).score, 25);
  assert.equal(T20.score, 60); assert.equal(T20.zone, 'TRIPLE');
  assert.equal(scoreAtNormalized(0, -0.97).score, 40); assert.equal(scoreAtNormalized(1.2, 0).zone, 'MISS');
  assert.equal(calculateDartScore(200, 140, 200, 200, 100).score, 60, 'independiente del tamaño en pantalla');
  assert.deepEqual(DART_NUMBERS.slice(0, 5), [20, 1, 18, 4, 13]);
});

test('R59 301: tres dardos consumen un turno, bust restaura, 0 exacto termina', () => {
  let g = dartsGameCreate();
  g = applyHit(g, T20); g = applyHit(g, T20); assert.equal(g.dartsLeft, 1);
  g = applyHit(g, T20); assert.equal(g.round, 2); assert.equal(g.dartsLeft, 3); assert.equal(g.players[0].remaining, 121);
  g = applyHit(g, T20); g = applyHit(g, BULL); g = applyHit(g, BULL);
  assert.equal(g.players[0].remaining, 121, 'bust vuelve al inicio del turno'); assert.ok(g.lastBust);
  let w = dartsGameCreate(); for (const h of [T20, T20, T20, T20, T20, ONE]) w = applyHit(w, h);
  assert.equal(w.status, 'FINISHED'); assert.equal(w.players[0].remaining, 0); assert.ok(w.winnerUserId);
  const sub = dartsGameSubmission(w); assert.equal(sub.throws.length, 6); assert.ok(!('score' in sub), 'no manda puntaje: el servidor recalcula');
});

test('R59 gesto: hay que lanzar hacia arriba con fuerza; la fuerza decide la altura', () => {
  assert.equal(calculateThrowVector([{ x: 0, y: 0, time: 0 }, { x: 0, y: 40, time: 20 }]).valid, false, 'hacia abajo no vale');
  const v = calculateThrowVector([{ x: 0, y: 500, time: 0 }, { x: 0, y: 460, time: 20 }]);
  assert.ok(v.valid);
  const ideal = calculateProjectedImpact(200, 600, { velocityX: 0, velocityY: -2 }, 300);
  const fuerte = calculateProjectedImpact(200, 600, { velocityX: 0, velocityY: -4 }, 300);
  assert.equal(Math.round(ideal.y), 300); assert.ok(fuerte.y < ideal.y);
});

test('R62 Juegos sin el banner de Dardos; Dardos con contrarreloj; Continuar cierra el resultado', async () => {
  const { bootApp } = await import('./helpers/ui-harness.mjs');
  const { dartsGameCreate, dartsTimeUp, dartsTimeLeft, dartsGameSubmission } = await import('../src/dardos.js');
  const g = dartsGameCreate(); assert.ok(dartsTimeLeft(g) > 110000);
  const t = dartsTimeUp(g); assert.equal(t.status, 'FINISHED'); assert.ok(t.timeUp); assert.equal(t.winnerUserId, null);
  assert.equal(dartsGameSubmission(t).timeUp, true);
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250); await app.click('[data-open="materia"]', 400);
    assert.equal(app.$('.jg2-promo'), null, 'el banner de Dardos ya no está');
    await app.click('.jg2-play[data-jg-play="DARTS"]', 300);
    assert.ok(app.$('#dtTimer'), 'contador regresivo visible');
    await app.click('#jgQuit', 200);
    await app.click('.jg2-play[data-jg-play="BASKETBALL"]', 300);
    for (let i = 0; i < 5; i++) await app.click('#jgShoot', 60);
    await app.click('#jgFinish', 600);
    const cont = app.w.document.querySelector('#srSheetHost [data-sr-cancel].primary') || app.w.document.querySelector('#srSheetHost button[data-sr-cancel]');
    assert.ok(cont, 'sale la hoja de resultado');
    cont.click(); await app.sleep(200);
    assert.equal(app.w.document.getElementById('srSheetHost'), null, 'Continuar cierra la hoja');
  } finally { app.close(); }
});
