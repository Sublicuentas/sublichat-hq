import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
const api=fs.readFileSync(new URL('../src/api.js',import.meta.url),'utf8');

test('R21 client service cards expose a dedicated CRM detail action',()=>{
  assert.match(main,/data-client-service-detail=/);
  assert.match(main,/Detalle del servicio/);
});

test('R21 CRM service detail keeps service identity and operational fields visible',()=>{
  for(const label of ['Fecha de renovación','Vendedor','Precio','Correo','Perfil']) assert.match(main,new RegExp(label));
});

test('R21 no-renew remains explicitly service-only and client-preserving',()=>{
  assert.match(api,/preservarFicha:true/);
  assert.match(main,/Solo se dará de baja ESTE servicio/);
  assert.match(main,/clienteEliminado===true/);
});

test('R21 client detail has mobile service-detail styling',()=>{
  assert.match(css,/\.service-detail-grid/);
  assert.match(css,/\.service-detail-actions/);
});
