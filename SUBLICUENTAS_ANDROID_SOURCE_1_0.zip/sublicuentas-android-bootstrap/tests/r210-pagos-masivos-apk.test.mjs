// R210 · Finanzas › Pendientes (APK): pago masivo con fecha real, vincular sin duplicar y vista previa de solo lectura.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { masivoHtml, previaHtml, seleccion, periodoDe, filtroPeriodo } from '../src/app/pagos-masivos.js';
const rows = [{ id: 'a', deudorTipo: 'vendedor', deudorNombre: 'Geisell', saldoPendiente: 300, createdAt: '2026-10-05T00:00:00Z' }, { id: 'b', deudorTipo: 'vendedor', deudorNombre: 'Geisell', saldoPendiente: 200, createdAt: '2026-11-02T00:00:00Z' }];
test('selección, período de origen y formulario con fecha real, banco o vínculo', () => {
  const L = { pend: { rows }, sel: { a: true, b: true } };
  assert.deepEqual(seleccion(L), { rows, total: 500 });
  assert.equal(periodoDe(rows[0]), '2026-10');
  assert.match(filtroPeriodo(L), /octubre 2026/);
  assert.match(masivoHtml(L, { metodos: [] }), /Registrar pago masivo/);
  L.masivo = { modo: 'vincular', previa: { grupos: [{ posiblesPagos: [{ movimientoId: 'm1', fecha: '2026-10-31', monto: 300 }] }] } };
  const h = masivoHtml(L, { metodos: [] });
  assert.match(h, /Fecha REAL del pago/); assert.match(h, /NO se crea otro ingreso/); assert.match(h, /data-fl-mas-vinc="m1"/);
  assert.match(masivoHtml({ pend: { rows: [rows[0], { ...rows[1], deudorNombre: 'Otro' }] }, sel: { a: true, b: true }, masivo: { modo: 'nuevo' } }, { metodos: [] }), /un solo cliente o vendedor/);
});
test('vista previa: solo lectura y la regla del 50 % no se aplica sin confirmación', () => {
  const h = previaHtml({ previa: { total: 500, grupos: [], geisell: { filas: [{}], totales: { base: 1000, obligacion: 500, pagado: 300, saldoActual: 700, saldoPropuesto: 200 }, preguntas: ['¿Base?'] } } });
  assert.match(h, /VISTA PREVIA/); assert.match(h, /No cambia ningún saldo/); assert.match(h, /L200/);
  const src = fs.readFileSync(new URL('../src/app/finanzas-libro.js', import.meta.url), 'utf8');
  assert.match(src, /bindMasivo\(root, ctx, L, \{ post, recargar/);
  assert.match(fs.readFileSync(new URL('../src/app/pagos-masivos.js', import.meta.url), 'utf8'), /accion: 'registrar_pago_masivo', cuentas: rows\.map\(\(c\) => c\.id\), monto, fechaPago: M\.fecha/);
});
