import test from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { buildSaiyajinWorkbook } from '../src/app/excel-saiyajin.js';

test('R117 APK: Excel Saiyajin con las hojas del bot, bancos de mayor a menor y un pago por cliente', async () => {
  const data = { desde: '2026-10-01', hasta: '2026-10-05', totales: { ingresos: 400, egresosOperativos: 50, disponibleAntesPlanilla: 350, planilla: 0, resultado: 350, ventasGeneradas: 520 },
    ingresos: [{ fecha: '2026-10-03', plataforma: 'Netflix + Disney', monto: 150, banco: 'BAC', usuario: 'Relojes · APK', cliente: 'Ana' }, { fecha: '2026-10-04', plataforma: 'Spotify', monto: 250, banco: 'Ficohsa', usuario: 'Sublicuentas · Web', cliente: 'Luis' }],
    egresos: [{ fecha: '2026-10-04', detalle: 'Publicidad', monto: 50, banco: 'BAC', usuario: 'Sublicuentas' }],
    saldos: [{ nombre: 'Tigo Money', activado: true, saldo: 300, ingresos: 300 }, { nombre: 'Banco Atlántida', activado: true, saldo: 4122, ingresos: 4122 }],
    totalBancos: 4422, cartera: { pendienteClientes: 120, pendienteVendedores: 0, cuentas: [{ deudorTipo: 'cliente', deudorNombre: 'Ana', saldoPendiente: 120, montoTotalOperacion: 300, estado: 'parcial' }] }, planillaPagos: [], cierres: [] };
  const wb = buildSaiyajinWorkbook(ExcelJS, data);
  assert.deepEqual(wb.worksheets.map((w) => w.name), ['Resumen', 'Ingresos', 'Egresos', 'Bancos', 'Planilla', 'Distribución Planilla', 'Pendientes Cobro', 'Cierres']);
  const vals = (n) => { const out = []; wb.getWorksheet(n).eachRow((r) => out.push(r.values.slice(1).map((v) => (v && typeof v === 'object' && 'formula' in v ? v.result : v)))); return out; };
  const bancos = vals('Bancos').filter((r) => typeof r[5] === 'number').map((r) => r[0]);
  assert.deepEqual(bancos.slice(0, 2), ['Banco Atlántida', 'Tigo Money']);
  assert.ok(vals('Ingresos').some((r) => r[1] === 'Netflix + Disney' && r[2] === 150), 'un pago de 150, no 75 + 75');
  assert.equal(wb.getWorksheet('Ingresos').getRow(2).getCell(1).fill.fgColor.argb, 'FFE2231A', 'franja roja Saiyajin');
  const buf = await wb.xlsx.writeBuffer(); assert.ok(buf.byteLength > 5000);
});
