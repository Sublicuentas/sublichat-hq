// R196z3 · APK: plan y capacidad HBO se confirman y editan en vivo con /api/mobile-core (action hboPlan), misma regla que Web y Telegram.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const rd = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('detalle HBO: texto en vivo, Platinum/Standard/Editar capacidad, excepción confirmada, sin sacar clientes', () => {
  const m = rd('src/app/hbo-plan.js'), a = rd('src/api.js'), main = rd('src/main.js'), s2 = rd('src/screens2.js');
  assert.match(a, /action:'hboPlan'/); assert.match(m, /modo: 'ver'/); assert.match(m, /data-hbo-cap/); assert.match(m, /autorizarExcepcion: true/);
  assert.match(m, /No se elimina ningún cliente/); assert.doesNotMatch(m, /clientes\s*=\s*\[\]|splice\(/, 'nunca toca la lista de clientes');
  assert.match(main, /montarHboPlan\(host,d,state\)/); assert.match(s2, /data-hbo-texto/);
  assert.ok(main.split('\n').length <= 2000, 'main.js < 2000 líneas');
});
