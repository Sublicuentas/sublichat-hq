import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=appSource();
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R29 splash has a real spinning loader overlay driven by JS',()=>{ assert.match(main,/splash-loader/); assert.match(main,/spinSplashLoaderWithJS/); });
test('R26 login form sits centered over the full-bleed artwork',()=>{ assert.match(css,/\.splash-stage,\.visual-login-stage\{[^}]*width:100%/s); assert.match(css,/\.visual-login-form\{[^}]*left:11%[^}]*right:11%/s); });
test('R22 home uses approved complete visual assets and live values',()=>{
  // R196w · iconos 3D del kit aprobado (archivos estáticos, versión ligera)
  for (const asset of ['01_sala_de_juntas','02_control_financiero','03_control_maestro','04_recordatorios','05_pelis_y_estrenos']) assert.match(main,new RegExp(asset));
  assert.match(main,/mcard-today/); assert.match(main,/mcard-next/); assert.match(main,/mcard-expired/);
  assert.match(main,/\$\{summary\.hoy\}/); assert.match(main,/\$\{summary\.proximo\.count\}/); assert.match(main,/\$\{summary\.vencidos\}/);
});
