import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.5 splash has a real animated loader overlay',()=>{ assert.match(main,/splash-loader/); assert.match(css,/@keyframes splashSpin/); });
test('R21.5 login uses narrow phone-safe composition',()=>{ assert.match(css,/\.visual-login-stage\{[^}]*max-width:709px/s); assert.match(css,/\.visual-login-form\{[^}]*left:13%[^}]*right:13%/s); });
test('R21.8 home uses approved complete visual assets and live values',()=>{
  for (const asset of ['07_vence_hoy_20.png','08_proximos_27.png','09_vencidos_39.png','10_aula_de_clases.png','11_control_financiero.png','12_materia_cerebral.png','13_clientes.png','15_tickets_y_avisos.png']) assert.match(main,new RegExp(asset.replaceAll('.','\\.')));
  assert.match(main,/\$\{summary\.hoy\}/); assert.match(main,/\$\{summary\.proximo\.count\}/); assert.match(main,/\$\{summary\.vencidos\}/);
});
