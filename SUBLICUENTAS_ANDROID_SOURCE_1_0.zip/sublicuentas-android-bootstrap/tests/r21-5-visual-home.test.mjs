import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R21.5 splash has a real animated loader overlay',()=>{
  assert.match(main,/splash-loader/);
  assert.match(css,/@keyframes splashSpin/);
});
test('R21.5 login uses narrow phone-safe composition',()=>{
  assert.match(css,/\.visual-login-stage\{[^}]*max-width:709px/s);
  assert.match(css,/\.visual-login-form\{[^}]*left:13%[^}]*right:13%/s);
});
test('R21.5 home uses supplied visual assets and complete work grid',()=>{
  for (const asset of ['metric-icon-today.png','metric-icon-next.png','metric-icon-expired.png','tool-icon-aula.png','tool-icon-finance.png','tool-icon-brain.png','tool-icon-clients.png','tool-icon-tickets.png']) assert.match(main,new RegExp(asset.replaceAll('.','\\.')));
  assert.match(main,/\$\{summary\.hoy\}/);
  assert.match(main,/\$\{summary\.proximo\.count\}/);
  assert.match(main,/\$\{summary\.vencidos\}/);
});
