import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js', import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
test('R29 splash has a real spinning loader overlay driven by JS',()=>{ assert.match(main,/splash-loader/); assert.match(main,/spinSplashLoaderWithJS/); });
test('R26 login form sits centered over the full-bleed artwork',()=>{ assert.match(css,/\.splash-stage,\.visual-login-stage\{[^}]*width:100%/s); assert.match(css,/\.visual-login-form\{[^}]*left:11%[^}]*right:11%/s); });
test('R22 home uses approved complete visual assets and live values',()=>{
  for (const asset of ['10_aula_de_clases.png','11_control_financiero.png','12_materia_cerebral.png','13_clientes.png','15_tickets_y_avisos.png']) assert.match(main,new RegExp(asset.replaceAll('.','\\.')));
  assert.match(main,/mcard-today/); assert.match(main,/mcard-next/); assert.match(main,/mcard-expired/);
  assert.match(main,/\$\{summary\.hoy\}/); assert.match(main,/\$\{summary\.proximo\.count\}/); assert.match(main,/\$\{summary\.vencidos\}/);
});
