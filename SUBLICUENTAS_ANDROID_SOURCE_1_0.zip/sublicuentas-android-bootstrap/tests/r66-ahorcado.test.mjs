import test from 'node:test';
import assert from 'node:assert/strict';
import { hangmanNewGame, pressLetter, useHint, nextRound, finishGame, pauseHang, resumeHang, hangRemainingMs, hangRound, hangmanProSubmission, hangmanSceneSvg, calculateRoundPoints } from '../src/ahorcado.js';
import { HANGMAN_WORDS } from '../src/ahorcado-palabras.js';
import { bootApp } from './helpers/ui-harness.mjs';

test('R66 banco: 120+ palabras con pista y categoría; 5 rondas sin repetir y evitando recientes', () => {
  assert.ok(HANGMAN_WORDS.length >= 120);
  assert.ok(HANGMAN_WORDS.every(w => /^[A-ZÑ]+$/.test(w.answer) && w.clue && w.category));
  assert.equal(new Set(HANGMAN_WORDS.map(w => w.id)).size, HANGMAN_WORDS.length);
  const g = hangmanNewGame(); assert.equal(new Set(g.words).size, 5);
  const g2 = hangmanNewGame({ recentIds: g.words }); assert.equal(g2.words.filter(id => g.words.includes(id)).length, 0);
});

test('R66 ronda: acierto revela, error quita intento y avanza el ahorcado; 7 errores pierde; pista revela 1 letra', () => {
  let g = hangmanNewGame({ now: 0 });
  const ans = hangRound(g).answer;
  const bad = [...'QWXZJKVYHFBP'].filter(c => !ans.includes(c)).slice(0, 7);
  g = pressLetter(g, bad[0], 1000); assert.equal(hangRound(g).attemptsLeft, 6);
  assert.match(hangmanSceneSvg(1), /hg-part/); assert.doesNotMatch(hangmanSceneSvg(0), /class="hg-part"/);
  const h = useHint(g, 2000); assert.ok(h.letter && ans.includes(h.letter)); assert.equal(h.game.hintsLeft, 1);
  g = h.game; for (const c of bad.slice(1)) g = pressLetter(g, c, 3000);
  assert.equal(hangRound(g).status, 'LOST'); assert.equal(g.streak, 0);
  g = nextRound(g, 4000); assert.equal(g.rounds.length, 2);
  for (const c of new Set(hangRound(g).answer)) g = pressLetter(g, c, 5000);
  assert.equal(hangRound(g).status, 'WON'); assert.equal(g.streak, 1); assert.ok(hangRound(g).points >= 20);
  assert.equal(calculateRoundPoints({ status: 'WON', hintsUsed: 0 }, 3, 175), 20 + 10 + 5 + 10);
});

test('R66 pausa congela el reloj; terminar liquida y la evidencia no lleva puntaje', () => {
  let g = hangmanNewGame({ now: 0 }); g = pauseHang(g, 10000);
  const left = hangRemainingMs(g, 10000); assert.equal(hangRemainingMs(g, 90000), left);
  g = resumeHang(g, 90000); g = finishGame(g, 95000);
  assert.equal(g.status, 'COMPLETED'); const sub = hangmanProSubmission(g);
  assert.equal(sub.pro, true); assert.ok(!('totalPoints' in sub)); assert.equal(sub.rounds.length, 1);
});

test('R66 en la app: pantalla nueva con teclado, pistas, pausa y guardar', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250); await app.click('[data-open="materia"]', 400);
    await app.click('.jg2-play[data-jg-play="HANGMAN"]', 300);
    assert.ok(app.$('.hg-scene') && app.$('#hgHint') && app.$('#hgPause') && app.$('#hgSave'));
    assert.equal(app.$$('[data-hg-key]').length, 27, 'incluye la Ñ');
    await app.click('#hgHint', 150); assert.match(app.$('#hgHint').textContent, /Pistas \(1\)/);
    await app.click('#hgPause', 100); assert.ok(app.$('#hgResume')); await app.click('#hgResume', 100);
    await app.click('[data-hg-key="Q"]', 100);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});
