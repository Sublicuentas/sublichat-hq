import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { roleModules, roleCapabilities } from '../src/data.js';

test('R77 Códigos: Sublicuentas y Relojes lo ven en Más; Geisell no', () => {
  assert.ok(roleModules('sublicuentas', 'sublicuentas').more.includes('codigos'));
  assert.ok(roleModules('relojes', 'libni').more.includes('codigos'));
  assert.ok(!roleModules('geisell_admin', 'geisell').more.includes('codigos'));
  assert.equal(roleCapabilities('geisell_admin', 'geisell').codigos, false);
});

test('R77 buscar un código desde Más → Códigos', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(500);
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="codigos"]', 300);
    const input = app.$('#codCorreo'); assert.ok(input, 'pantalla Códigos');
    input.value = 'P@X.lat'; input.dispatchEvent(new app.w.Event('input'));
    await app.click('#codBuscar', 400);
    await app.waitFor(() => app.$('.cod-code'));
    assert.equal(app.$('.cod-code').textContent.trim(), '4821');
    assert.match(app.$('.cod-result').textContent, /Netflix/);
    assert.match(app.$('.cod-cliente').textContent, /Prueba/, 'reconoce al cliente dueño de esa cuenta');
    const call = app.calls.find(c => c.path === '/api/codigos'); assert.equal(call.action, 'buscar');
    assert.ok(app.$('#codCopy') && app.$('#codWa'));
    assert.ok(!app.w.localStorage.getItem('sublicuentas-core-cache-r69')?.includes('4821'), 'el código no se guarda en el teléfono');
  } finally { app.close(); }
});

test('R77 desde Clientes: "Buscar código de esta cuenta" abre Códigos y busca solo', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(500);
    await app.click('[data-tab="clientes"]', 300);
    const dots = app.$$('[data-client-actions]').find(b => b.closest('.cli-card')?.textContent.includes('Prueba'));
    await app.click(dots, 300);
    await app.click('[data-client-action="codigo"]', 500);
    await app.waitFor(() => app.$('.cod-code'));
    assert.equal(app.$('#codCorreo').value, 'p@x.lat');
  } finally { app.close(); }
});
