import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { roleModules, roleCapabilities } from '../src/data.js';

test('R79 Códigos: Sublicuentas, Relojes y Geisell lo ven en Más; un rol desconocido no', () => {
  assert.ok(roleModules('sublicuentas', 'sublicuentas').more.includes('codigos'));
  assert.ok(roleModules('relojes', 'libni').more.includes('codigos'));
  assert.ok(roleModules('geisell_admin', 'geisell').more.includes('codigos'));
  assert.equal(roleCapabilities('geisell_admin', 'geisell').codigos, true);
  assert.equal(roleCapabilities('asesor', 'heber').codigos, false);
});

test('R77 buscar un código desde Más → Códigos', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(500);
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="codigos"]', 300);
    const input = app.$('#codCorreo'); assert.ok(input, 'pantalla Códigos');
    input.value = 'P@X.lat'; input.dispatchEvent(new app.w.Event('input'));
    await app.click('#codBuscar', 400);
    await app.waitFor(() => app.$('.cod-code'));
    assert.equal(app.$('.cod-code').textContent.trim(), '4821');
    assert.match(app.$('.cod-found').textContent, /Netflix/);
    assert.match(app.$('.cod-cliente').textContent, /Prueba/, 'reconoce al cliente dueño de esa cuenta');
    const call = app.calls.find(c => c.path === '/api/codigos'); assert.equal(call.action, 'buscar');
    assert.ok(app.$('#codCopy') && app.$('#codWa'));
    assert.ok(!app.w.localStorage.getItem('sublicuentas-core-cache-r69')?.includes('4821'), 'el código no se guarda en el teléfono');
  } finally { app.close(); }
});

test('R77 desde Clientes: "Buscar código de esta cuenta" abre Códigos y busca solo', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.sleep(500);
    await app.click('[data-tab="clientes"]', 300);
    const dots = app.$$('[data-client-actions]').find(b => b.closest('.cli-card')?.textContent.includes('Prueba'));
    await app.click(dots, 300);
    await app.click('[data-client-action="codigo"]', 500);
    await app.waitFor(() => app.$('.cod-code'));
    assert.equal(app.$('#codCorreo').value, 'p@x.lat');
  } finally { app.close(); }
});

test('R78 sin lista de todos los correos: se escribe o se pega y busca solo (como en Telegram)', async () => {
  const app = await bootApp({ role: 'relojes' });
  try {
    await app.sleep(500);
    await app.click('[data-tab="mas"]', 300);
    await app.click('[data-open="codigos"]', 300);
    assert.equal(app.$('datalist'), null, 'ya no aparece la lista con todos los correos');
    assert.ok(app.$('.cod-hero img[src*="codigos-hero"]'), 'imagen 3D del diseño');
    const input = app.$('#codCorreo');
    input.value = 'p@x.lat'; input.dispatchEvent(new app.w.Event('paste'));
    await app.waitFor(() => app.$('.cod-code'));
    assert.equal(app.calls.filter(c => c.path === '/api/codigos').length, 1, 'al pegar un correo válido busca de una vez');
    assert.ok(app.$('.cod-pill') && /Listo para usar/.test(app.$('.cod-pill').textContent));
    assert.ok(app.$('.cod-important'));
    await app.click('#codRefresh', 400);
    await app.waitFor(() => app.calls.filter(c => c.path === '/api/codigos').length === 2);
  } finally { app.close(); }
});

test('R78 código de 6 dígitos se muestra agrupado "837 621"', async () => {
  const { codigoAgrupado } = await import('../src/app/codigos.js').catch(() => ({}));
  if (!codigoAgrupado) return; // el módulo importa core (navegador); se prueba igual en la UI
  assert.equal(codigoAgrupado('837621'), '837 621'); assert.equal(codigoAgrupado('4821'), '4821');
});

test('R79 error del servidor como objeto se muestra legible (nunca [object Object])', async () => {
  const { apiErrorText } = await import('../src/api.js');
  assert.match(apiErrorText({ error: { code: 'FUNCTION_INVOCATION_FAILED', message: 'A server error has occurred' } }, 500), /error.*500/i);
  assert.match(apiErrorText({ error: { code: 'FUNCTION_INVOCATION_TIMEOUT' } }, 504), /tardó demasiado/);
  assert.equal(apiErrorText({ error: 'Escriba un correo válido.' }, 400), 'Escriba un correo válido.');
  assert.doesNotMatch(apiErrorText({ error: {} }, 502), /object Object/);
});
