import test from 'node:test';
import assert from 'node:assert/strict';
import { appSource } from './helpers/app-source.mjs';
import { buildTraditionalFicha } from '../src/operations.js';

test('R79 la ficha de la cuenta de un tercero va a nombre del tercero, no del titular', () => {
  const main = appSource();
  assert.match(main, /nombrePerfil:crmBeneficiaryName\(d\)/);
  const ficha = buildTraditionalFicha({ nombrePerfil: 'Samantha Irias', plataforma: 'Netflix Premium VIP', plataformaRaw: 'vipnetflix', fechaRenovacion: '26/10/2026', perfiles: [{ nombre: 'Samantha Irias', correo: 'x@gmail.com', clave: 'casa22' }] });
  assert.match(ficha, /Samantha Irias/);
  assert.doesNotMatch(ficha, /Alba Barahona/);
});
