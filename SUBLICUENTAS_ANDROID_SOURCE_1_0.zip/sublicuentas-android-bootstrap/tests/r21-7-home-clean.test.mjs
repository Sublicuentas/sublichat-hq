import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
test('R21.7 metrics are native dynamic cards and never reuse numbered screenshots',()=>{
  assert.doesNotMatch(main,/07_vence_hoy_20\.png|08_proximos_27\.png|09_vencidos_39\.png/);
  assert.match(main,/metric-icon-today\.png/);
  assert.match(main,/summary\.hoy/);
});
test('R21.7 workspace restores objetivos and uses native clean cards',()=>{
  assert.match(main,/data-open="objetivos"/);
  assert.match(main,/class="home-tool-card/);
  assert.doesNotMatch(main,/class="visual-module-card"/);
});
test('R21.7 home has no dark card outlines',()=>{
  assert.match(css,/\.home-tool-card\{[^}]*border:0/);
  assert.match(css,/\.visual-metric\{[^}]*border:0/);
});
