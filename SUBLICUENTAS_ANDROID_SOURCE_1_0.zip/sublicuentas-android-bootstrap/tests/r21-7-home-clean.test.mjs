import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main=fs.readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
test('R22 metrics keep live values as real text (no baked-in numbers to cover up)',()=>{
  assert.match(main,/class="mcard mcard-today"/);
  assert.match(main,/class="mcard mcard-next"/);
  assert.match(main,/class="mcard mcard-expired"/);
  assert.match(main,/summary\.hoy/);
  assert.doesNotMatch(main,/metric-live-value/);
});
test('R26 workspace removed Objetivos and keeps native clean cards',()=>{
  assert.doesNotMatch(main,/data-open="objetivos"/);
  assert.doesNotMatch(main,/tool-goals/);
  assert.match(main,/class="home-tool-card/);
  assert.doesNotMatch(main,/class="visual-module-card"/);
});
test('R21.7 home has no dark card outlines',()=>{
  assert.match(css,/\.home-tool-card\{[^}]*border:0/);
  assert.match(css,/\.visual-metric\{[^}]*border:0/);
});
