import { appSource } from './helpers/app-source.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { bootApp } from './helpers/ui-harness.mjs';

const main = appSource();

test('Clientes: escribir en el buscador ya NO redibuja toda la pantalla (evita el salto/parpadeo mientras se teclea)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 400);
    const input = app.$('#clientSearch');
    input.focus();
    const heroBefore = app.$('.cli-hero'); // parte de la pantalla que NO debería tocarse al escribir
    const tabsBefore = app.$('.cli-tabs');
    for (const ch of 'ana') {
      input.value += ch;
      input.dispatchEvent(new app.w.Event('input', { bubbles: true }));
    }
    assert.equal(app.$('#clientSearch'), input, 'el input de búsqueda sigue siendo el MISMO elemento del DOM (no se redibujó toda la pantalla)');
    assert.equal(app.w.document.activeElement, input, 'el foco nunca se perdió mientras se escribía');
    assert.equal(app.$('.cli-hero'), heroBefore, 'el encabezado tampoco se redibujó');
    assert.equal(app.$('.cli-tabs'), tabsBefore, 'las pestañas tampoco se redibujaron');
    assert.equal(input.value, 'ana');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Clientes: la lista y el contador SÍ reflejan la búsqueda escrita (el filtro real sigue funcionando)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 400);
    const before = app.$$('.cli-card').length;
    const input = app.$('#clientSearch');
    input.value = 'zzz-no-deberia-existir-nadie-asi';
    input.dispatchEvent(new app.w.Event('input', { bubbles: true }));
    assert.equal(app.$$('.cli-card').length, 0);
    assert.ok(app.$('.empty-state'));
    assert.match(app.$('.cli-meta').textContent, /Mostrando 0 de/);
    input.value = '';
    input.dispatchEvent(new app.w.Event('input', { bubbles: true }));
    assert.equal(app.$$('.cli-card').length, before, 'al borrar la búsqueda vuelve a mostrar todos');
    // el ⋮ y abrir la ficha siguen funcionando después de una búsqueda (no quedaron listeners rotos)
    if (before > 0) { await app.click(app.$$('.cli-dots')[0], 200); assert.ok(app.$('.client-svc-picker') || app.$('#clientActionsSheet') || app.$$('[data-client-action]').length, 'el menú de acciones abre tras haber buscado'); }
  } finally { app.close(); }
});

test('Nuevo CRM: el botón "Guardar CRM" ahora sí hace algo y avisa cuando termina (antes no tenía ningún manejador de clic)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="clientes"]', 300);
    await app.click('[data-tab-jump="nuevo-crm"]', 400);
    assert.ok(app.$('#crmSubmit'), 'abre Nuevo CRM');
    const setVal = (sel, v) => { const el = app.$(sel); el.value = v; el.dispatchEvent(new app.w.Event('input', { bubbles: true })); };
    setVal('#crmNombre', 'Cliente de prueba');
    setVal('#crmTelefono', '99998888');
    const emailInput = app.$('[data-crm-profile] [data-p-email]');
    if (emailInput) { emailInput.value = 'prueba@correo.com'; emailInput.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
    const passInput = app.$('[data-crm-profile] [data-p-password]');
    if (passInput) { passInput.value = 'clave123'; passInput.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
    const pinInput = app.$('[data-crm-profile] [data-p-pin]');
    if (pinInput) { pinInput.value = '1234'; pinInput.dispatchEvent(new app.w.Event('input', { bubbles: true })); }
    const deviceSel = app.$('[data-crm-profile] [data-p-device]');
    if (deviceSel) { deviceSel.value = 'tv'; deviceSel.dispatchEvent(new app.w.Event('change', { bubbles: true })); }
    await app.click('#crmSubmit', 400);
    const bodyText = app.w.document.body.textContent;
    assert.match(bodyText, /guardad[oa]/i, 'aparece un aviso de que se guardó');
    assert.ok(app.calls.some(c => c.path === '/api/renovar' && c.action === 'ficha_upsert'), 'sí se mandó a guardar la venta al servidor');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('Tickets: ahora hay un botón para eliminar un aviso (antes no había forma de borrar los de prueba)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="tickets"]', 400);
    assert.ok(app.$('.tk-item'), 'se ve al menos un aviso en la lista');
    await app.click('[data-tk-toggle]', 300);
    assert.ok(app.$('.ticket-full-card'), 'se expande el detalle del aviso');
    const delBtn = app.$('[data-ticket-delete]');
    assert.ok(delBtn, 'el detalle tiene un botón de eliminar');
    await app.click(delBtn, 400);
    assert.ok(app.calls.some(c => c.path === '/api/tickets' && c.action === 'eliminar'), 'se mandó a eliminar el aviso al servidor');
    assert.match(app.w.document.body.textContent, /eliminado/i, 'aparece un aviso de confirmación');
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('WhatsApp: se pregunta una sola vez cuál app usar (normal o Business) y luego se recuerda, sin volver a preguntar', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await app.click('[data-tab="mas"]', 250);
    await app.click('[data-open="perfil"]', 300);
    assert.match(app.$('.settings-panel').textContent, /Se preguntará la próxima vez/, 'todavía no hay ninguna app de WhatsApp recordada');
    app.w.localStorage.setItem('sublicuentas-whatsapp-app', 'com.whatsapp.w4b');
    await app.click('[data-tab="clientes"]', 200);
    await app.click('[data-tab="mas"]', 150);
    await app.click('[data-open="perfil"]', 300);
    assert.match(app.$('.settings-panel').textContent, /WhatsApp Business/, 'una vez elegida, se recuerda y se muestra cuál es');
    await app.click('#whatsappAppReset', 200);
    assert.ok(app.$('.whatsapp-sheet'), 'R51: "Cambiar" abre el selector de app');
    await app.click('[data-whatsapp-package="ask"]', 300);
    assert.match(app.$('.settings-panel').textContent, /Se preguntará la próxima vez/, 'el botón "Cambiar" permite volver a preguntar');
    assert.equal(app.w.localStorage.getItem('sublicuentas-whatsapp-app'), null);
    assert.deepEqual(app.logs.filter(l => l.startsWith('ERROR')), []);
  } finally { app.close(); }
});

test('WhatsApp: requestWhatsApp no abre el selector si ya hay una app guardada; sí lo abre si no hay ninguna', () => {
  assert.match(main, /function requestWhatsApp\(text='', phone=''\) \{\n\s*state\.whatsappText=String\(text\|\|''\); state\.whatsappPhone=normalizeWhatsAppPhone\(phone\);\n\s*const saved=localStorage\.getItem\('sublicuentas-whatsapp-app'\);\n\s*if \(saved==='com\.whatsapp' \|\| saved==='com\.whatsapp\.w4b'\) \{ launchWhatsApp\(saved\); return; \}/);
  assert.match(main, /localStorage\.setItem\('sublicuentas-whatsapp-app', packageName\);/);
});
