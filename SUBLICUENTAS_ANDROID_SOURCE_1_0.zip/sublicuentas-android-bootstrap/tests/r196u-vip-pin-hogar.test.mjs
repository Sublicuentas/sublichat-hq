// R196u Fase 2 · APK: PIN opcional de Netflix VIP (CRM + ficha) e indicador de Hogar / Bodega VIP en el inventario.
import test from 'node:test';
import assert from 'node:assert/strict';
import { buildCrmUpsertPayload } from '../src/api.js';
import { buildTraditionalFicha } from '../src/operations.js';
import fs from 'node:fs';
const core = fs.readFileSync(new URL('../src/app/core.js', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
import { hogarTexto, inventoryDetailHtml } from '../src/screens2.js';

const base = { nombrePerfil: 'Cliente Demo', telefono: '99999999', plataforma: 'vipnetflix', vendedor: 'Relojes', precio: 150, fechaRenovacion: '20/12/2026', correo: 'vip1@ejemplo.com', clave: 'claveVip' };

test('PIN-01 · CRM VIP: el PIN es opcional (se muestra, no se exige) y se guarda solo si se escribió', () => {
  assert.match(core, /pin:!CRM_NO_PIN\.has\(key\),.*pinOpcional:key==='vipnetflix'/, 'no es obligatorio, pero el campo aparece');
  assert.match(main, /field\('\[data-p-pin\]',!cc&&\(rules\.pin\|\|rules\.pinOpcional\)\);/);
  assert.match(main, /rules\.pin&&!String\(p\.pinPerfil\|\|''\)\.trim\(\)\)return `\$\{label\}: falta el PIN individual\.`/, 'la validación obligatoria sigue solo para rules.pin');
  const sin = buildCrmUpsertPayload({ ...base, perfiles: [{ nombre: 'Cliente Demo', correo: base.correo, clave: base.clave, pinPerfil: '' }] });
  assert.equal(sin.servicio.sinPinPerfil, true); assert.equal(sin.servicio.pinPerfil, undefined);
  const con = buildCrmUpsertPayload({ ...base, perfiles: [{ nombre: 'Cliente Demo', correo: base.correo, clave: base.clave, pinPerfil: '4321' }] });
  assert.equal(con.servicio.pinPerfil, '4321'); assert.equal(con.servicio.sinPinPerfil, undefined);
  const spotify = buildCrmUpsertPayload({ ...base, plataforma: 'spotify', perfiles: [{ nombre: 'X', correo: 'a@b.com', clave: 'x', pinPerfil: '1111' }] });
  assert.equal(spotify.servicio.sinPinPerfil, true, 'las demás sin PIN siguen igual');
});

test('PIN-01 · ficha VIP: sin PIN no hay línea (ni «PIN: —»); con PIN aparece una sola vez', () => {
  const f = (pin) => buildTraditionalFicha({ ...base, perfiles: [{ nombre: 'Cliente Demo', correo: base.correo, clave: base.clave, pinPerfil: pin }] });
  assert.doesNotMatch(f(''), /PIN/);
  assert.equal((f('4321').match(/🔏 PIN de perfil: 4321/g) || []).length, 1);
});

test('HOG-01 · inventario APK: la madre muestra el Hogar; pendiente si el cliente salió; VIP muestra estado y «Sin PIN» sin revelar valores', () => {
  const madre = { plataforma: 'netflix', correo: 'premium01@ejemplo.com', capacidad: 5, clientes: [{ clienteId: 'A', compraId: 'cA', nombre: 'Cliente A', slot: 1 }, { clienteId: 'B', compraId: 'cB', nombre: 'Cliente B', slot: 2 }], hogar: { clienteId: 'B', compraId: 'cB', nombre: 'Cliente B' } };
  assert.equal(hogarTexto(madre), 'Hogar: Cliente B · Perfil 2');
  assert.equal(hogarTexto({ ...madre, hogar: null }), 'Hogar sin asignar');
  assert.equal(hogarTexto({ ...madre, clientes: madre.clientes.slice(0, 1) }), 'Hogar pendiente: Cliente B ya no está en esta cuenta');
  assert.match(inventoryDetailHtml({ item: madre, label: 'Netflix' }), /🏠 Hogar<\/span><b>Hogar: Cliente B · Perfil 2/);
  const vip = inventoryDetailHtml({ item: { plataforma: 'vipnetflix', correo: 'vip1@ejemplo.com', capacidad: 1, ocupados: 0, proveedor: 'Deku peruano', tienePin: true, pin: '4321' }, label: 'Netflix VIP' });
  assert.match(vip, /Bodega VIP<\/span><b>Disponible/); assert.match(vip, /Deku peruano/); assert.match(vip, /PIN configurado/); assert.doesNotMatch(vip, /4321/);
});
