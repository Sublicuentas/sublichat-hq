import test from 'node:test';
import assert from 'node:assert/strict';
import {
  memoryCreate, memoryFlip, memoryResolveMismatch, memorySubmission,
  hangmanCreate, hangmanGuess, hangmanHint, hangmanSubmission,
  wordSearchCreate, wordSearchSelect, wordSearchHint, wordSearchSubmission,
} from '../src/juegos-engine.js';
import { HANGMAN_WORDS, WORDSEARCH_SETS } from '../src/juegos-data.js';

const seq = (...vals) => { let i = 0; return () => vals[Math.min(i++, vals.length - 1)]; };

// PRNG determinista simple (mulberry32) para que las pruebas sean repetibles sin usar Math.random real,
// pero SIN quedar pegado en el mismo valor (una función constante rompe la colocación de palabras al
// no poder "reintentar" con una posición distinta).
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}


/* ───────────── Pares de cartas ───────────── */
test('Pares de cartas: 24 cartas = 12 pares, sin repetir símbolos por accidente', () => {
  const s = memoryCreate(12, mulberry32(49664));
  assert.equal(s.cards.length, 24);
  const bySym = {}; s.cards.forEach(c => { (bySym[c.symbol] ||= []).push(c); });
  assert.equal(Object.keys(bySym).length, 12);
  for (const list of Object.values(bySym)) assert.equal(list.length, 2);
});

test('Pares de cartas: emparejar todo da 12 pares, 12 movimientos y combo máximo 12', () => {
  let s = memoryCreate(12, mulberry32(81811));
  const bySym = {}; s.cards.forEach((c, i) => { (bySym[c.symbol] ||= []).push(i); });
  for (const sym in bySym) { const [a, b] = bySym[sym]; s = memoryFlip(s, a); s = memoryFlip(s, b); }
  assert.equal(s.pairsFound, 12); assert.equal(s.moves, 12); assert.equal(s.maxCombo, 12); assert.ok(s.finishedAt);
  assert.deepEqual(memorySubmission(s, 120), { pairsFound: 12, moves: 12, maxCombo: 12, timeLimitSec: 120, timeRemainingSec: 120 });
});

test('Pares de cartas: una pareja fallida no cuenta como acierto, resetea el combo y se resuelve con memoryResolveMismatch', () => {
  let s = memoryCreate(2, mulberry32(81801)); // 2 pares únicos: forzamos un fallo seguro tomando símbolos distintos
  const a = 0; const b = s.cards.findIndex((c, i) => i !== a && c.symbol !== s.cards[a].symbol);
  s = memoryFlip(s, a); s = memoryFlip(s, b);
  assert.equal(s.pending, true); assert.equal(s.pairsFound, 0); assert.equal(s.combo, 0); assert.equal(s.moves, 1);
  assert.deepEqual(s.flipped, [a, b]);
  s = memoryResolveMismatch(s);
  assert.deepEqual(s.flipped, []); assert.equal(s.pending, false);
  // mientras está "pending" no se puede seguir volteando otra carta
  const before = s; const stuck = memoryFlip({ ...before, pending: true }, 2);
  assert.equal(stuck.pending, true);
});

test('Pares de cartas: no se puede voltear una carta ya emparejada ni la misma dos veces', () => {
  let s = memoryCreate(12, mulberry32(29634));
  s = memoryFlip(s, 0);
  const again = memoryFlip(s, 0);
  assert.deepEqual(again.flipped, [0], 'tocar la misma carta dos veces no la duplica en flipped');
});

/* ───────────── El ahorcado ───────────── */
test('El ahorcado: 5 palabras por partida, cada una viene del banco y en mayúsculas sin acentos', () => {
  const s = hangmanCreate(5, 7, 2, mulberry32(22316));
  assert.equal(s.rounds.length, 5);
  for (const r of s.rounds) { assert.equal(r.word, r.word.toUpperCase()); assert.doesNotMatch(r.word, /[ÁÉÍÓÚÑ]/); assert.ok(HANGMAN_WORDS.some(w => w.word.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '') === r.word)); }
});

test('El ahorcado: adivinar todas las letras resuelve la palabra y pasa a la siguiente ronda', () => {
  let s = hangmanCreate(2, 7, 2, () => 0);
  const w1 = s.rounds[0].word;
  for (const ch of new Set(w1)) s = hangmanGuess(s, ch);
  assert.equal(s.rounds[0].solved, true); assert.equal(s.roundIndex, 1);
});

test('El ahorcado: 7 letras incorrectas pierden la ronda y avanzan sin resolverla', () => {
  let s = hangmanCreate(1, 7, 2, () => 0);
  const word = s.rounds[0].word;
  const wrongLetters = 'ZXQWKJ0'.split('').filter(l => !word.includes(l));
  // usamos letras del alfabeto que no estén en la palabra hasta acumular 7 fallos
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').filter(l => !word.includes(l));
  for (let i = 0; i < 7; i++) s = hangmanGuess(s, alphabet[i]);
  assert.equal(s.rounds[0].wrong.length, 7); assert.equal(s.rounds[0].gaveUp, true); assert.equal(s.rounds[0].solved, false);
  assert.ok(s.finishedAt, 'era la única ronda: la partida termina');
});

test('El ahorcado: letra repetida no cuenta dos veces y una pista revela una letra sin exceder el máximo', () => {
  let s = hangmanCreate(1, 7, 2, () => 0);
  const word = s.rounds[0].word; const letter = word[0];
  s = hangmanGuess(s, letter); const afterFirst = s.rounds[0].guessed.length;
  s = hangmanGuess(s, letter);
  assert.equal(s.rounds[0].guessed.length, afterFirst, 'repetir la misma letra no hace nada');
  s = hangmanHint(s); assert.equal(s.hintsUsed, 1);
  s = hangmanHint(s); assert.equal(s.hintsUsed, 2);
  s = hangmanHint(s); assert.equal(s.hintsUsed, 2, 'no pasa del máximo de 2 pistas');
});

test('El ahorcado: la sumisión final refleja resueltas, errores totales y pistas', () => {
  let s = hangmanCreate(2, 7, 2, mulberry32(43676));
  const w0 = s.rounds[0].word; for (const ch of new Set(w0)) s = hangmanGuess(s, ch);
  const sub = hangmanSubmission(s, 180);
  assert.equal(sub.solvedWords, 1); assert.equal(sub.hintsUsed, 0); assert.equal(sub.timeLimitSec, 180);
});

/* ───────────── Sopa de letras ───────────── */
test('Sopa de letras: las 12 palabras del set quedan realmente colocadas en el tablero (en línea recta)', () => {
  const s = wordSearchCreate(12, 0, mulberry32(9278));
  assert.equal(s.words.length, WORDSEARCH_SETS[0].words.length);
  for (const w of s.words) {
    const [r0, c0] = w.start, [r1, c1] = w.end;
    const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0);
    let text = '';
    for (let i = 0; i < w.word.length; i++) text += s.grid[r0 + dr * i][c0 + dc * i];
    assert.equal(text, w.word, `la palabra ${w.word} debe leerse en línea recta en el tablero`);
  }
  for (const row of s.grid) for (const cell of row) assert.match(cell, /^[A-Z]$/);
});

test('Sopa de letras: seleccionar el inicio y fin correctos de una palabra la marca como encontrada (también al revés)', () => {
  let s = wordSearchCreate(12, 0, mulberry32(81801));
  const target = s.words[0];
  s = wordSearchSelect(s, target.start[0], target.start[1]);
  s = wordSearchSelect(s, target.end[0], target.end[1]);
  assert.equal(s.words[0].found, true); assert.equal(s.combo, 1); assert.equal(s.maxCombo, 1);
  // al revés (fin -> inicio) también debe reconocerla, en otra palabra
  const t2 = s.words.find(w => !w.found);
  s = wordSearchSelect(s, t2.end[0], t2.end[1]);
  s = wordSearchSelect(s, t2.start[0], t2.start[1]);
  assert.equal(s.words.find(w => w.id === t2.id).found, true, 'reconoce la palabra seleccionada en reversa');
});

test('Sopa de letras: una selección que no forma ninguna palabra cuenta como fallo y resetea el combo', () => {
  let s = wordSearchCreate(12, 0, mulberry32(29634));
  const t = s.words[0]; s = wordSearchSelect(s, t.start[0], t.start[1]); s = wordSearchSelect(s, t.end[0], t.end[1]); // 1 acierto: combo=1
  assert.equal(s.combo, 1);
  // seleccionar dos celdas que no correspondan a ninguna palabra (una casilla sola no forma nada largo)
  const r = t.start[0] === 0 ? 1 : 0, c = 0;
  s = wordSearchSelect(s, r, c); s = wordSearchSelect(s, r, (c + 1) % s.size === r ? c + 2 : c + 1);
  assert.ok(s.wrongSelections >= 0);
});

test('Sopa de letras: la pista revela la siguiente palabra pendiente sin lanzar error', () => {
  let s = wordSearchCreate(12, 1, mulberry32(2441));
  const before = s.words.filter(w => w.found).length;
  s = wordSearchHint(s);
  assert.equal(s.words.filter(w => w.found).length, before + 1);
  assert.equal(s.hintsUsed, 1);
});

test('Sopa de letras: encontrar las 12 palabras termina la partida y la sumisión refleja todo', () => {
  let s = wordSearchCreate(12, 0, mulberry32(48935));
  while (s.words.some(w => !w.found)) s = wordSearchHint(s);
  assert.ok(s.finishedAt);
  const sub = wordSearchSubmission(s, 240);
  assert.equal(sub.foundWords, 12); assert.equal(sub.hintsUsed, 12);
});

test('Sopa de letras: una selección en diagonal que no es línea recta reinicia la selección (no revienta)', () => {
  let s = wordSearchCreate(12, 0, mulberry32(81801));
  s = wordSearchSelect(s, 0, 0);
  s = wordSearchSelect(s, 5, 2); // no está en línea recta desde (0,0)
  assert.deepEqual(s.selectStart, [5, 2]);
});

test('Variedad real: hay más de una sopa de letras y el mazo de Pares no siempre usa los mismos símbolos', async () => {
  const { WORDSEARCH_SETS, MEMORY_SYMBOLS } = await import('../src/juegos-data.js');
  assert.ok(WORDSEARCH_SETS.length >= 6, 'antes solo había 2 sopas de letras; ahora deben ser varias');
  assert.ok(MEMORY_SYMBOLS.length > 12, 'antes había exactamente 12 símbolos (los mismos siempre); ahora hay de sobra para variar el mazo');
  const seenSets = new Set(), seenSymbolSets = new Set();
  for (let i = 0; i < 60; i++) {
    seenSets.add(wordSearchCreate(12, i % WORDSEARCH_SETS.length).words.map(w => w.word).sort().join(','));
    seenSymbolSets.add(memoryCreate(12).cards.map(c => c.symbol).filter((v, idx, a) => a.indexOf(v) === idx).sort().join(','));
  }
  assert.ok(seenSets.size >= 5, 'las sopas de letras realmente varían entre partidas');
  assert.ok(seenSymbolSets.size >= 5, 'el mazo de símbolos de Pares realmente varía entre partidas');
});
