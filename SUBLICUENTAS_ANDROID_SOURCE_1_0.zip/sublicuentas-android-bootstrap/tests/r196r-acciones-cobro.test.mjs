// R196r · Acciones del Cliente (8 botones + Cerrar) y Cobro y Renovación (plantillas, IA rápida, renovación).
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootApp } from './helpers/ui-harness.mjs';
import { TONOS, OCASIONES, LONGITUDES, siguientePlantilla, generarPlantilla, totalCombinaciones, normalizarParams } from '../src/app/plantillas-cobro.js';
import { buildChargeAiPayloadRapido } from '../src/api.js';

const G = { nombre: 'Cliente Prueba', clienteId: 'x1', fechaRenovacion: '14/11/2026', servicios: [{ plataforma: 'disneyp', precio: 120 }, { plataforma: 'spotify', precio: 90 }, { plataforma: 'crunchyroll', precio: 50 }] };

test('R196r plantillas: 20 sucesivas por tono, todas distintas y con los datos exactos (sin inventar)', () => {
  for (const [tono] of TONOS) for (const [longitud] of LONGITUDES) {
    const usados = [];
    for (let i = 0; i < 20; i++) usados.push(siguientePlantilla(G, { tono, longitud }, usados).texto);
    assert.equal(new Set(usados).size, 20, `${tono}/${longitud}: sin repetidos`);
    for (const t of usados) {
      assert.match(t, /\*Cliente Prueba\*/); assert.match(t, /\*L260\*/); assert.match(t, /Disney Premium \+ Spotify \+ Crunchyroll/);
      assert.doesNotMatch(t, /descuento|gratis|promoci|oferta|transferencia|dep[oó]sito|banco|tarjeta/i);
    }
  }
});

test('R196r plantillas: longitud y ocasión cambian el texto; el total de combinaciones es real (no «infinito»)', () => {
  assert.equal(generarPlantilla(G, { longitud: 'corta' }, 7).split('\n').length, 1);
  assert.equal(generarPlantilla(G, { longitud: 'media' }, 7).split('\n').length, 2);
  assert.equal(generarPlantilla(G, { longitud: 'larga' }, 7).split('\n').length, 3);
  const porOcasion = new Set(OCASIONES.map(([o]) => generarPlantilla(G, { ocasion: o }, 3)));
  assert.equal(porOcasion.size, OCASIONES.length);
  assert.ok(totalCombinaciones() > 100000 && Number.isFinite(totalCombinaciones()));
  assert.deepEqual(normalizarParams({ tono: 'xx' }), { ocasion: 'renovacion', tono: 'amigable', longitud: 'media' });
});

test('R196r IA rápida: prompt corto con solo los datos necesarios y un solo intento', () => {
  const p = buildChargeAiPayloadRapido(G, { ocasion: 'recordatorio', tono: 'formal', previos: ['a\nb', 'c'] }, '2026-11-14');
  assert.equal(p.mode, 'rewrite'); assert.deepEqual(p.clientes, []);
  assert.ok(p.pregunta.length < 600, `prompt corto (${p.pregunta.length})`);
  assert.match(p.pregunta, /\*L260\*/); assert.match(p.pregunta, /Ocasión: recordatorio\. Tono: formal/);
});

async function abrirMenu(app, nombre = 'Prueba') {
  await app.click('[data-tab="clientes"]', 300);
  for (const b of app.$$('#closeClientActionsBtn')) b.click();
  const card = app.$$('.cli-card').find((c) => c.textContent.includes(nombre)) || app.$('.cli-card');
  await app.click(card.querySelector('.cli-dots'), 200);
}

test('R196r Acciones del Cliente: 3 secciones, 8 acciones compactas, Cerrar al primer toque', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await abrirMenu(app);
    const secciones = app.$$('.ca-sec-t').map((h) => h.lastChild.textContent.trim());
    assert.deepEqual(secciones, ['Acciones principales', 'Gestión del cliente', 'Accesos y estado']);
    assert.deepEqual(app.$$('[data-client-action]').map((b) => b.dataset.clientAction), ['renew', 'charge', 'add-service', 'edit', 'ficha', 'codigo', 'url', 'no-renew']);
    assert.equal(app.$$('.ca-row small').length, 0, 'filas sin subtítulo');
    assert.ok(app.$('.ca-chip') && app.$('.ca-precio'));
    await app.click('#closeClientActionsBtn', 50);
    assert.equal(app.$('.client-actions-sheet'), null, 'Cerrar cierra al primer toque');
    assert.ok(app.$('.cli-card'), 'vuelve al listado sin recargar');
  } finally { app.close(); }
});

test('R196r Entregar ficha: se ve la ficha con Copiar y Enviar (no salta directo a WhatsApp)', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await abrirMenu(app);
    await app.click('[data-client-action="ficha"]', 250);
    assert.ok(app.$('#clientFichaText'), 'muestra la ficha');
    assert.match(app.$('#clientFichaText').value, /p@x\.lat/);
    assert.ok(app.$('#clientCopyFicha') && app.$('#clientSendFicha'));
    assert.equal(app.$('.whatsapp-sheet'), null, 'no abre WhatsApp sin que el usuario lo pida');
    await app.click('#clientActionBack', 150);
    assert.ok(app.$('[data-client-action="renew"]'), 'Volver regresa al panel');
  } finally { app.close(); }
});

test('R196r Acceso URL: carga visible al instante, una sola solicitud aunque se toque dos veces', async () => {
  let soltar; const espera = new Promise((r) => { soltar = r; });
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (p, b) => { if (p === '/api/renovar' && b.accion === 'asegurar_enlaces') { await espera; return { ok: true, linkPublico: '/c/tok9' }; } return undefined; } });
  try {
    await abrirMenu(app);
    const btn = app.$('[data-client-action="url"]'); btn.click(); btn.click();
    await app.sleep(80);
    assert.ok(app.$('.ca-cargando'), 'hoja de carga inmediata');
    soltar(); await app.waitFor(() => app.$('#clientCopyUrlMessage'));
    assert.equal(app.calls.filter((c) => c.action === 'asegurar_enlaces').length, 1, 'sin doble solicitud');
    assert.match(app.$('#clientUrlMessage').value, /c\/tok9/);
  } finally { app.close(); }
});

test('R196r No renovó: si el usuario NO confirma, no se da de baja; si confirma, una sola baja', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    app.w.confirm = () => false;
    await abrirMenu(app); await app.click('[data-client-action="no-renew"]', 300);
    assert.equal(app.calls.filter((c) => c.action === 'no_renovo').length, 0, 'negativa = sin baja');
    app.w.confirm = () => true;
    await abrirMenu(app); const b = app.$('[data-client-action="no-renew"]'); b.click(); b.click(); await app.sleep(500);
    assert.equal(app.calls.filter((c) => c.action === 'no_renovo').length, 1, 'doble toque = una baja');
  } finally { app.close(); }
});

test('R196r Buscar código: con correo abre Códigos; sin correo avisa y no se va del panel', async () => {
  const clients = [{ id: 'z1', nombre: 'Sin Correo', telefono: '99990000', servicios: [{ plataforma: 'netflix', precio: 100, fechaRenovacion: '20/10/2026', compraId: 'q1' }] }];
  const app = await bootApp({ role: 'sublicuentas', clients });
  try {
    await abrirMenu(app, 'Sin Correo'); await app.click('[data-client-action="codigo"]', 250);
    assert.match(app.w.document.body.textContent, /no tiene correo registrado/);
    assert.ok(app.$('.client-actions-sheet'), 'sigue en el panel');
  } finally { app.close(); }
});

test('R196r Mensaje de cobro: abre Cobro y Renovación con plantillas, selectores, carrusel y renovación compacta', async () => {
  const app = await bootApp({ role: 'sublicuentas' });
  try {
    await abrirMenu(app); await app.click('[data-client-action="charge"]', 300);
    for (const s of ['.rn-tabs', '#rnOcasion', '#rnTono', '#rnLongitud', '#rnPrev', '#rnNext', '.rn-dots', '#renewAnotherStyle', '#renewCopyMessage', '#renewOpenWhatsApp', '#rnAiOcasion', '#renewAiMessage', '#renewApply', '#renewNoRenewAll', '#renewExactDate']) assert.ok(app.$(s), s);
    assert.equal(app.$$('.rn-presets .rn-preset').length, 6);
    const vistos = [app.$('#renewChargeText').value];
    for (let i = 0; i < 12; i++) { await app.click('#rnNext', 20); vistos.push(app.$('#renewChargeText').value); }
    assert.equal(new Set(vistos).size, vistos.length, 'las flechas no repiten');
    await app.click('#rnPrev', 20); assert.equal(app.$('#renewChargeText').value, vistos[vistos.length - 2], 'la flecha izquierda vuelve al anterior');
    const tono = app.$('#rnTono').value; await app.click('#renewAnotherStyle', 20);
    assert.notEqual(app.$('#rnTono').value, tono, 'Otros estilos cambia de tono');
    app.$('#rnLongitud').value = 'corta'; app.$('#rnLongitud').dispatchEvent(new app.w.Event('change')); await app.sleep(20);
    assert.equal(app.$('#renewChargeText').value.split('\n').length, 1);
  } finally { app.close(); }
});

test('R196r IA: sin respuesta → plantilla local; doble toque = una llamada; Cancelar no bloquea', async () => {
  let llamadas = 0;
  const app = await bootApp({ role: 'sublicuentas', fetchExtra: async (p) => { if (p === '/api/chat') { llamadas += 1; return { error: 'Gemini tardó demasiado' }; } return undefined; } });
  try {
    await abrirMenu(app); await app.click('[data-client-action="renew"]', 300);
    const b = app.$('#renewAiMessage'); b.click(); b.click(); b.click();
    await app.waitFor(() => app.$('#renewAiMessage'));
    assert.equal(llamadas, 1, 'un solo intento');
    assert.match(app.$('.rn-ai-note').textContent, /plantilla local/);
    assert.ok(app.$('#renewChargeText').value.length > 20, 'queda un mensaje usable');
  } finally { app.close(); }
});
