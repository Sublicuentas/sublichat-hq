# Sublichat R69 · Brief "Mejoras APK Sublicuentas" (25/09/2026)

## Dónde va cada cosa
| Carpeta del zip | Proyecto / destino |
|---|---|
| `1_APK_rama_android-v1-r13-limpio/SUBLICUENTAS_ANDROID_SOURCE_1_0.zip` | APK Android · subir SIN descomprimir a la raíz de la rama `android-v1-r13-limpio` (ahora incluye `package-lock.json`) |
| `2_WEB_Sublichat_HQ_rama_main/` | Sublichat HQ web (Vercel) · reemplazar `api/renovar.js`, `api/mobile-core.js`, `api/acceso.js`, `acceso.html` y agregar `tests/r69-backend-brief.test.mjs` |
| `3_GITHUB_rama_android-v1-r13-limpio/.github/workflows/` | reemplazar `android-debug-apk.yml` y agregar `android-release-apk.yml` |

## Paquetes
- **A · Sincronización**: carga por recurso (clientes, inventario, finanzas, perfil), Reload en cola, Reload solo de lo visible, `lastSuccessfulSyncAt` por recurso, estado visible (Actualizando… / Actualizado HH:MM / Sin conexión - mostrando datos guardados), refresco silencioso al volver (>15 s, sin polling), sin redibujar mientras se escribe en el CRM, ya no hay `state.loading` global.
- **B · Seguridad local**: sesión en almacén seguro (Android Keystore, `@aparajita/capacitor-secure-storage`); `idToken` solo en memoria; migración automática y borrado de la sesión en texto plano; caché sin claves/PIN/correos/credenciales/finanzas; cerrar sesión borra todo lo privado; claves y PIN ocultos con Mostrar/Copiar.
- **C · Geisell**: `canonicalSeller()` ("Geissel" → "geisell") en filtros, conteos, renovaciones y opciones; Geisell ve Control Maestro (Perfil al final, sin permisos nuevos).
- **D · Max Player / TV**: con Max Player la entrega solo lleva usuario/clave de Max Player + dispositivos + renovación + hora; selector de credencial guardada o manual; Stella/Oleada sin URL/lista de LatinTV; URL pública con fecha y hora.
- **E · Auditoría** (servidor): cada mutación de `api/renovar.js` registra en `auditoria_eventos` autor (uid/usuario/rol DEL TOKEN), acción, cliente, plataforma, campos modificados (valores sensibles nunca), resultado, origen, build y requestId.
- **F · Idempotencia**: la APK manda `operationId` (UUID) y lo reutiliza en el reintento; el servidor guarda `operaciones_idempotentes/{uid}_{operationId}` y devuelve la misma respuesta sin duplicar (en curso → 409 reintentable). CRM reutiliza el mismo id si el usuario reintenta tras un error.
- **G · Configuración remota**: `POST /api/mobile-core {action:'config'}` (doc Firestore `configuracion_app/android` sobre valores por defecto) con `configVersion`, `apiVersion`, `minAppBuild`, `syncStaleSeconds`, `sellerPhones`, `calculatorBasePrices`, `tvDigitalRules`, `featureFlags`. Si la APK es más vieja que `MIN_ANDROID_BUILD` → escrituras bloqueadas (426 UPDATE_REQUIRED) y aviso "Actualización requerida".
- **H · Build**: `package-lock.json` + `npm ci`; verificación del package id del APK; workflow Release firmado (zipalign + apksigner verify + no debuggable + SHA-256 + versionCode creciente).

## Qué configurar (una sola vez)
1. **GitHub → Settings → Secrets → Actions** (rama Android): `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. Guarde la keystore fuera del repositorio: sin ella no se pueden publicar actualizaciones.
2. **Vercel** (opcional): `MIN_ANDROID_BUILD` = build mínimo aceptado para escribir. Sin la variable no se bloquea nada.
3. **Firestore** (opcional): documento `configuracion_app/android` para cambiar teléfonos/precios/reglas sin recompilar (suba `configVersion` al editar).

## Pendiente / notas (BACKEND_REQUIRED)
- Idempotencia/auditoría cubre `api/renovar.js` (fichas, renovaciones, no renovó, eliminar, agregar, editar). Tickets, perfil e inventario (otros endpoints) aún no validan `operationId`; la APK ya lo envía.
- Los teléfonos/precios del código quedan como respaldo de arranque hasta que responda la configuración remota.
- No se tocaron: juegos, selección de banco, /code, IMAP ni Activar TV.
