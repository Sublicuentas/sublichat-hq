// Juegos PRO — pantallas (HTML). La lógica de cada juego vive en juegos-engine.js; aquí solo se pinta el
// estado y se arman los botones. Los puntos oficiales SIEMPRE vienen del servidor (api/juegos.js).
import { CATEGORIES } from './juegos-data.js';
import { sellerForSession } from './operations.js';
import { DART_RINGS, COLOR_PALETTE } from './juegos-engine.js';
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const pad2 = n => String(n).padStart(2, '0');
export const fmtClock = totalSec => `${pad2(Math.floor(Math.max(0, totalSec) / 60))}:${pad2(Math.max(0, totalSec) % 60)}`;
const fmtNum = n => (Number(n) || 0).toLocaleString('es-HN');

export const GAME_META = Object.freeze({
  WORD_SEARCH: { title: 'Sopa de letras', tagline: '3 niveles: arrastra sobre las letras y encuentra todas las palabras.', icon: '🔤', ready: true },
  HANGMAN: { title: 'El ahorcado', tagline: 'Adivina la palabra antes de quedarte sin intentos.', icon: '🪢', ready: true },
  MEMORY_PAIRS: { title: 'Memoria', tagline: 'Encuentra los pares antes de que acabe el tiempo.', icon: '🃏', ready: true },
  BASKETBALL: { title: 'Básquet', tagline: '5 tiros: ajusta ángulo y fuerza y encesta.', icon: '🏀', ready: true },
  DARTS: { title: 'Dardos PRO', tagline: '301 a pulso: arrastra el dardo, suéltalo y cierra en 0 exacto.', icon: '🎯', ready: true },
  COLOR_CHALLENGE: { title: 'Colorear', tagline: 'Copia el modelo con precisión: el que más acierta, más puntos.', icon: '🎨', ready: true },
});
const BADGE_ICON = { EXPLORADOR: '⭐', AVANZADO: '🥉', EXPERTO: '🥈', MAESTRO: '🥇', LEYENDA: '👑' };

const I = Object.freeze({
  back: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>',
  trophy: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 5H4a3 3 0 0 0 3 5M17 5h3a3 3 0 0 1-3 5"/></svg>',
  star: '<svg viewBox="0 0 24 24" width="16" height="16" fill="#FFD84D"><path d="m12 2 2.9 6.3 6.9.7-5.2 4.7 1.5 6.8L12 17l-6.1 3.5 1.5-6.8-5.2-4.7 6.9-.7Z"/></svg>',
  fire: '<svg viewBox="0 0 24 24" width="18" height="18" fill="#ff7a1a"><path d="M12 2s-5 5-5 10a5 5 0 0 0 10 0c0-2-1-3-1-3s.5 2-1 3c.3-2-1-4-1-4s0 2-1 3c-.5-1-1-3-1-3-.5 2 0 4 0 4-1-1-1-2-1-3 0-2 1-4 1-4Z"/></svg>',
});
const clock = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#41607a" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>';
const pauseIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="#0a1f3a"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>';
const refreshIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/></svg>';
const bulbIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3 11.2c.6.4 1 1 1 1.8h4c0-.8.4-1.4 1-1.8A6 6 0 0 0 12 3Z"/></svg>';

const topBar = (title) => `<header class="jg-top"><button type="button" class="jg-back" id="backMore" aria-label="Volver">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>`;
const sublibot = (msg) => `<div class="jg-bot"><div class="jg-bot-face">🙂</div><div class="jg-bubble"><b>¡Hola!</b><p>Soy <b>Sublibot</b>. ${esc(msg)}</p></div></div>`;
const statRow = (items) => `<div class="jg-stats">${items.map(([label, val, id]) => `<div class="jg-stat"><small>${esc(label)}</small><b${id ? ` id="${id}"` : ''}>${val}</b></div>`).join('<i class="jg-sep"></i>')}</div>`;

/* ───────────── Hub "Juegos PRO" (categoría Materia cerebral) ───────────── */
export function juegosHubHtml({ resumen = null, error = '' } = {}) {
  const pts = resumen ? fmtNum(resumen.totalPoints) : '—';
  const head = `<header class="jg-top"><button type="button" class="jg-back" id="jgRankBack" aria-label="Volver al tablero">${I.back}</button><h1>Sublichat</h1><div class="jg-pointspill">${I.star}<span>Puntos: ${pts}</span></div><button type="button" class="jg-rankbtn" id="jgOpenRanking">${I.trophy}<small>Ranking</small></button></header>`;
  const cards = Object.entries(GAME_META).map(([code, g]) => `<button type="button" class="jg-card ${g.ready ? '' : 'soon'}" data-jg-open="${g.ready ? code : ''}" ${g.ready ? '' : 'disabled'}><span class="jg-card-ico">${g.icon}</span><span class="jg-card-txt"><b>${esc(g.title)}</b><small>${esc(g.tagline)}</small></span>${g.ready ? '' : '<em class="jg-soon-tag">Próximamente</em>'}</button>`).join('');
  const body = error
    ? `<div class="error-box"><span>${esc(error)}</span></div><button type="button" class="primary" id="jgRetry">Reintentar</button>`
    : `<div class="jg-hero"><i>🎮</i><span>Juegos PRO</span></div><h2 class="jg-h1">Materia cerebral</h2><p class="jg-sub">Entrena tu mente, suma puntos reales y sube en el ranking del equipo.</p>${sublibot('Elige un juego y demuestra de qué estás hecho. Modo PRO, solo para mentes curiosas.')}<div class="jg-grid">${cards}</div>`;
  return `<section class="jg-page">${head}${body}</section>`;
}

/* ───────────── Tablero "Juegos" (R52: rediseño + nombre del acceso, no el nombre personal) ───────────── */
// El jugador se muestra con el nombre del ACCESO (Sublicuentas, Relojes, Geisell), igual que en el resto de la app.
export function playerAccessName(userId = '', displayName = '') {
  return sellerForSession('', userId) || sellerForSession('', displayName) || '';
}
const ACCESS_NAMES = ['Sublicuentas', 'Relojes', 'Geisell'];
function mergeByAccess(entries = []) {
  const map = new Map();
  for (const e of entries) {
    const name = playerAccessName(e.userId, e.displayName);
    if (!ACCESS_NAMES.includes(name)) continue; // R53: solo se muestran los 3 accesos, ningún otro nombre
    const prev = map.get(name);
    if (!prev) { map.set(name, { ...e, name, ids: [String(e.userId || '')] }); continue; }
    const score = (Number(prev.score) || 0) + (Number(e.score) || 0);
    const best = (Number(e.score) || 0) > (Number(prev.bestScore ?? prev.score) || 0) ? e : prev;
    map.set(name, { ...prev, score, bestScore: Math.max(Number(prev.bestScore ?? prev.score) || 0, Number(e.score) || 0), streak: Math.max(Number(prev.streak) || 0, Number(e.streak) || 0), badge: best.badge || prev.badge, ids: [...prev.ids, String(e.userId || '')] });
  }
  return [...map.values()].sort((x, y) => (Number(y.score) || 0) - (Number(x.score) || 0));
}
const JG_ICO = {
  chart: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#e2231a"><rect x="3" y="12" width="4.5" height="9" rx="1.2"/><rect x="9.8" y="5" width="4.5" height="16" rx="1.2"/><rect x="16.5" y="9" width="4.5" height="12" rx="1.2"/></svg>',
  pad: '<svg viewBox="0 0 48 32" width="44" height="30"><rect x="1" y="3" width="46" height="26" rx="13" fill="#e2231a"/><path d="M12 11v10M7 16h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="33" cy="13" r="2.4" fill="#fff"/><circle cx="38" cy="18" r="2.4" fill="#fff"/></svg>',
  chev: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
  crown: '<svg viewBox="0 0 64 44" width="70" height="48"><path d="M6 14 18 26 32 6l14 20 12-12-5 26H11Z" fill="#f7a8a3" opacity=".55"/></svg>',
};
const GAME_TILE = { WORD_SEARCH: { ico: '🔤', bg: '#e8f0ff' }, HANGMAN: { ico: '🪢', bg: '#e6f7ef' }, MEMORY_PAIRS: { ico: '<img src="/assets/memoria/memory-icon.webp" alt="" style="width:48px;height:48px">', bg: '#fff5dc' }, BASKETBALL: { ico: '🏀', bg: '#fff1e4' }, DARTS: { ico: '🎯', bg: '#ffecec' }, COLOR_CHALLENGE: { ico: '🎨', bg: '#fff8dc' } };
export function leaderboardHtml({ scope = 'general', data = null, loading = false, error = '', me = null, myTotals = null, meLabel = '', avatar = '', gameCode = 'MEMORY_PAIRS' } = {}) {
  const head = `<header class="jg-top jg2-top"><button type="button" class="jg-back" id="backMore" aria-label="Volver">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>
    <section class="jg2-hero"><div><h2>Juegos</h2><p>Juega, suma puntos y sube en el ranking</p></div><div class="jg2-hero-art">${JG_ICO.pad}<span class="jg2-bubble">Pequeños juegos,<br>grandes logros</span></div></section>`;
  const tabs = `<nav class="jg-tabs jg2-tabs">${[['general', '🏆', 'General'], ['semanal', '📅', 'Semanal'], ['porJuego', '🎮', 'Por juego']].map(([v, e, l]) => `<button type="button" class="${scope === v ? 'on' : ''}" data-jg-scope="${v}"><span>${e}</span>${l}</button>`).join('')}</nav>`;
  const readyGames = Object.entries(GAME_META).filter(([, g]) => g.ready);
  const gameChips = scope === 'porJuego' ? `<div class="jg2-gamechips">${readyGames.map(([code, g]) => `<button type="button" class="${code === gameCode ? 'on' : ''}" data-jg-rankgame="${code}">${g.icon} ${esc(g.title)}</button>`).join('')}</div>` : '';
  let body;
  if (loading) body = '<div class="loading-card"><span class="spinner"></span><strong>Cargando ranking…</strong></div>';
  else if (error) body = `<div class="error-box"><span>${esc(error)}</span></div><button type="button" class="primary jg2-retry" data-jg-scope="${scope}">Reintentar</button>`;
  else {
    const rows = mergeByAccess(data?.entries || []);
    const isMe = r => (me && r.ids.includes(String(me))) || (meLabel && r.name === meLabel);
    const meIdx = rows.findIndex(isMe);
    const meRow = data?.me || {};
    const myScore = meIdx >= 0 ? rows[meIdx].score : (meRow.score ?? (scope === 'general' ? myTotals?.totalPoints : 0) ?? 0);
    const myRank = meIdx >= 0 ? meIdx + 1 : (meRow.rank ?? null);
    const badge = myTotals?.badge || { code: 'EXPLORADOR', name: meIdx >= 0 ? (rows[meIdx].badge || 'Explorador') : 'Explorador' };
    const streak = Number(myTotals?.streak?.current ?? (meIdx >= 0 ? rows[meIdx].streak : 0)) || 0;
    const initial = esc(String(meLabel || 'S').trim().charAt(0).toUpperCase());
    const avatarHtml = avatar ? `<img class="jg-avatar jg2-avatar" src="${esc(avatar)}" alt="">` : `<span class="jg-avatar jg2-avatar jg2-initial">${initial}</span>`;
    const trs = rows.map((r, i) => `<tr class="${isMe(r) ? 'me' : ''}"><td><span class="jg-pos p${i + 1 <= 3 ? i + 1 : ''}">${i + 1}</span></td><td class="jg2-name">${esc(r.name)}</td><td>${fmtNum(r.score)}</td>${scope === 'general' ? `<td>🔥 ${Number(r.streak) || 0}</td><td>${esc(r.badge || '')}</td>` : '<td colspan="2"></td>'}</tr>`).join('');
    const byGame = myTotals?.byGame || {};
    const best = readyGames.reduce((acc, [code]) => ((byGame[code] || 0) > (byGame[acc] || 0) ? code : acc), readyGames[0]?.[0]);
    body = `<section class="jg-mecard jg2-mecard"><div class="jg2-me-id">${avatarHtml}<small>${esc(meLabel || 'Mi acceso')}</small><span class="jg2-badge">${BADGE_ICON[badge.code] || '⭐'} ${esc(badge.name || 'Explorador')}</span></div>
        <div class="jg2-me-stat"><small>Mi puntaje</small><b>${fmtNum(myScore)}</b><span>puntos</span></div>
        <div class="jg2-me-stat"><small>Posición</small><b>${myRank ? `#${myRank}` : '—'}</b></div>
        <div class="jg2-me-stat"><small>Racha</small><b>🔥 ${streak}</b></div><i class="jg2-crown">${JG_ICO.crown}</i></section>
      <section class="jg2-card"><h3 class="jg2-h3">${JG_ICO.chart}Ranking de jugadores</h3>${gameChips}
      <div class="jg2-table-wrap"><table class="jg-table jg2-table"><thead><tr><th>#</th><th>Jugador</th><th>Puntos</th>${scope === 'general' ? '<th>Racha</th><th>Insignia</th>' : '<th colspan="2"></th>'}</tr></thead><tbody>${trs || '<tr><td colspan="5" class="jg-empty">Todavía no hay resultados en esta vista. ¡Juegue una partida y sea el primero!</td></tr>'}</tbody></table></div></section>
      ${true ? `<div class="jg2-bygame-head"><h3>${JG_ICO.pad}Mis puntos por juego</h3><button type="button" class="jg2-more" id="jgGoHub">Juega y suma más puntos ${JG_ICO.chev}</button></div>
      <div class="jg-bygame jg2-bygame">${readyGames.map(([code, g]) => `<div class="jg-bygame-card jg2-game ${code === best && (byGame[code] || 0) > 0 ? 'hot' : ''}"><span class="jg2-tile" style="background:${GAME_TILE[code]?.bg || '#eef3f8'}">${GAME_TILE[code]?.ico || g.icon}</span><b>${esc(g.title)}</b><small>${fmtNum(byGame[code])} pts</small><button type="button" class="jg2-play" data-jg-play="${code}">Jugar</button></div>`).join('')}</div>` : ''}`;
  }
  return `<section class="jg-page jg2-page">${head}${tabs}${body}</section>`;
}

/* ───────────── envoltorio común de una partida ───────────── */
function gameShell({ title, sub, stats, controls, body, footer }) {
  return `<section class="jg-page game">
    <header class="jg-top"><button type="button" class="jg-back" id="jgQuit" aria-label="Salir del juego">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>
    <div class="jg-gamehead"><div><p class="jg-eyebrow">🎮 Juegos PRO</p><h2>${esc(title)}</h2><p class="jg-sub">${esc(sub)}</p></div></div>
    <div class="jg-panel">${statRow(stats)}<div class="jg-controls">${controls}</div></div>
    <div class="jg-board">${body}</div>
    ${footer || ''}
  </section>`;
}

/* ───────────── Pares de cartas ───────────── */
const CARD_ICONS = { heart: '❤️', diamond: '♦️', spade: '♠️', crown: '👑', club: '♣️', star: '⭐', moon: '🌙', bolt: '⚡', gift: '🎁', ring: '💍', gem: '💎', flag: '🚩' };
export function memoryScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const pct = Math.round((state.pairsFound / (state.cards.length / 2)) * 100);
  const grid = state.cards.map((c, i) => {
    const open = c.matched || state.flipped.includes(i);
    return `<button type="button" class="jg-card2 ${open ? 'open' : ''} ${c.matched ? 'matched' : ''}" data-jg-flip="${i}" ${open || finished ? 'disabled' : ''} aria-label="Carta ${i + 1}"><span class="jg-card2-face">${open ? CARD_ICONS[c.symbol] : 'S'}</span></button>`;
  }).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Combo', `x${state.combo}`], ['Movimientos', state.moves]];
  const controls = `<button type="button" class="jg-ctrl" id="jgRestart">${refreshIco}<small>Reiniciar</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-progress"><span>Pares encontrados: ${state.pairsFound}/${state.cards.length / 2}</span><div class="jg-bar"><i style="width:${pct}%"></i></div><b>${pct}%</b></div><div class="jg-memgrid">${grid}</div>`;
  return gameShell({ title: 'Pares de cartas', sub: 'Encuentra todos los pares de cartas y demuestra tu memoria. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── El ahorcado ───────────── */
export function hangmanScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const round = state.rounds[state.roundIndex] || state.rounds.at(-1);
  const cat = CATEGORIES[round.category] || round.category;
  const cells = [...round.word].map(ch => `<span class="jg-letterbox ${round.guessed.includes(ch) || round.gaveUp ? 'shown' : ''}">${round.guessed.includes(ch) || round.gaveUp ? ch : ''}</span>`).join('');
  const lives = Math.max(0, state.maxErrors - round.wrong.length);
  const hearts = Array.from({ length: state.maxErrors }, (_, i) => `<span class="jg-heart ${i < lives ? '' : 'off'}">❤</span>`).join('');
  const alphabet = 'QWERTYUIOPASDFGHJKLZXCVBNM'.split('');
  const keys = alphabet.map(l => `<button type="button" class="jg-key ${round.guessed.includes(l) ? 'ok' : ''} ${round.wrong.includes(l) ? 'bad' : ''}" data-jg-letter="${l}" ${round.guessed.includes(l) || round.wrong.includes(l) || round.solved || round.gaveUp || finished ? 'disabled' : ''}>${l}</button>`).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Ronda', `${state.roundIndex + 1}/${state.rounds.length}`], ['Racha', `x${state.rounds.filter(r => r.solved).length}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgHint" ${state.hintsUsed >= state.maxHints || round.solved || round.gaveUp ? 'disabled' : ''}>${bulbIco}<small>Pistas (${state.maxHints - state.hintsUsed})</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-hang-top"><span class="jg-catchip">${clock}${esc(cat)}</span><small>${round.guessed.length + round.wrong.length ? '' : ''}</small></div>
    <div class="jg-letters">${cells}</div><p class="jg-clue">${esc(round.clue)}</p>
    <div class="jg-hearts"><span>Intentos restantes</span>${hearts}</div>
    <div class="jg-keyboard">${keys}</div>`;
  return gameShell({ title: 'El ahorcado', sub: 'Adivina la palabra antes de quedarte sin intentos. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── Sopa de letras ───────────── */
export function wordSearchScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const sel = state.selectStart ? `${state.selectStart[0]}_${state.selectStart[1]}` : '';
  const foundCells = new Set(); state.words.forEach(w => { if (w.found && w.cells) w.cells.forEach(([r, c]) => foundCells.add(`${r}_${c}`)); });
  const grid = state.grid.map((row, r) => row.map((ch, c) => {
    const key = `${r}_${c}`; const on = key === sel; const done = foundCells.has(key);
    return `<button type="button" class="jg-letter-cell ${on ? 'on' : ''} ${done ? 'done' : ''}" data-jg-cell="${r},${c}" ${finished ? 'disabled' : ''} aria-label="Celda ${r + 1},${c + 1}">${ch}</button>`;
  }).join('')).join('');
  const foundCount = state.words.filter(w => w.found).length;
  const list = state.words.map(w => `<li class="${w.found ? 'done' : ''}">${w.found ? '✓' : '•'} ${esc(w.word)}</li>`).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Combo', `x${state.combo}`], ['Encontradas', `${foundCount}/${state.words.length}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgHint" ${finished ? 'disabled' : ''}>${bulbIco}<small>Pista</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-ws-layout"><div class="jg-ws-grid" style="--jg-size:${state.size}">${grid}</div><aside class="jg-ws-list"><h4>📖 Palabras a encontrar <em>${foundCount}/${state.words.length}</em></h4><ul>${list}</ul></aside></div>`;
  return gameShell({ title: 'Sopa de letras', sub: 'Encuentra todas las palabras y demuestra cuánto sabes. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── resultado (hoja de confirmación con puntos oficiales) ───────────── */
export function resultSheetHtml({ status = 'loading', awardedPoints = 0, totalPoints = 0, streak = null, badge = null, error = '', repetido = false } = {}) {
  if (status === 'loading') return `<div class="jg-result"><span class="spinner"></span><b>Guardando tu resultado…</b><small>El servidor confirma tus puntos oficiales.</small></div>`;
  if (status === 'error') return `<div class="jg-result"><span class="jg-result-x">⚠️</span><b>No se pudo guardar</b><small>${esc(error || 'Revisa tu conexión e inténtalo de nuevo.')}</small><button type="button" class="primary" data-sr-cancel>Cerrar</button></div>`;
  return `<div class="jg-result done"><span class="jg-result-ico">🏆</span><b>+${fmtNum(awardedPoints)} SP</b><small>${repetido ? 'Esta partida ya se había guardado antes.' : '¡Puntos confirmados por el servidor!'}</small>
    <div class="jg-result-row"><span>Total acumulado</span><b>${fmtNum(totalPoints)}</b></div>
    ${streak ? `<div class="jg-result-row"><span>Racha</span><b>${I.fire}${streak.current} día${streak.current === 1 ? '' : 's'}</b></div>` : ''}
    ${badge ? `<div class="jg-result-row"><span>Insignia</span><b>${BADGE_ICON[badge.code] || '⭐'} ${esc(badge.name)}</b></div>` : ''}
    <button type="button" class="primary" data-sr-cancel>Continuar</button></div>`;
}


/* ───────────── Básquet (R55) ───────────── */
export function basketballScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const X = x => 30 + x, Y = y => 205 - y;
  const { dx, dy } = state.lastResult && !state.finishedAt ? state.hoop : state.hoop;
  const hx = X(dx), hy = Y(dy);
  const a = state.angle * Math.PI / 180, L = 22 + state.power * 0.55;
  const path = state.lastPath ? state.lastPath.map(([x, y]) => `${X(x)},${Y(y)}`).join(' ') : '';
  const prevHoop = state.lastResult?.hoop;
  const court = `<svg class="jg-bk-court" viewBox="0 0 360 240" role="img" aria-label="Cancha de básquet">
    <rect x="0" y="205" width="360" height="35" fill="#f4a259"/><path d="M0 205H360" stroke="#c97a32" stroke-width="3"/>
    ${prevHoop && (prevHoop.dx !== dx || prevHoop.dy !== dy) ? `<g opacity=".3"><path d="M${X(prevHoop.dx) - 12} ${Y(prevHoop.dy)}H${X(prevHoop.dx) + 12}" stroke="#e2231a" stroke-width="4" stroke-linecap="round"/><text x="${X(prevHoop.dx)}" y="${Y(prevHoop.dy) - 8}" text-anchor="middle" font-size="9" font-weight="800" fill="#0a1f3a">tiro anterior</text></g>` : ''}
    ${prevHoop && state.lastPath ? `<polyline points="${path}" fill="none" stroke="${state.lastResult.made ? '#1faa4f' : '#e2231a'}" stroke-width="3" stroke-dasharray="6 6" stroke-linecap="round" class="jg-bk-trail"/>` : ''}
    <rect x="${hx + 14}" y="${hy - 46}" width="6" height="${46 + 205 - hy}" fill="#9aa8b8"/><rect x="${hx + 8}" y="${hy - 52}" width="10" height="40" rx="2" fill="#fff" stroke="#0a1f3a" stroke-width="2"/>
    <path d="M${hx - 12} ${hy}H${hx + 12}" stroke="#e2231a" stroke-width="4" stroke-linecap="round"/><path d="M${hx - 11} ${hy + 2}L${hx - 6} ${hy + 18}H${hx + 6}L${hx + 11} ${hy + 2}M${hx - 6} ${hy + 2}L${hx} ${hy + 18}L${hx + 6} ${hy + 2}" stroke="#c9d3de" stroke-width="1.5" fill="none"/>
    <line id="jgBkAim" x1="${X(0)}" y1="${Y(0)}" x2="${X(0) + L * Math.cos(a)}" y2="${Y(0) - L * Math.sin(a)}" stroke="#0a1f3a" stroke-width="3" stroke-dasharray="4 4" stroke-linecap="round"/>
    <circle cx="${X(0)}" cy="${Y(0)}" r="11" fill="#ff7a1a" stroke="#8a3b00" stroke-width="2"/><path d="M${X(0) - 11} ${Y(0)}H${X(0) + 11}M${X(0)} ${Y(0) - 11}V${Y(0) + 11}" stroke="#8a3b00" stroke-width="1.5"/>
  </svg>`;
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Encestes', `${state.made}/${state.shots.length}`], ['Tiros', `${state.shots.length}/${state.total}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgRestart">${refreshIco}<small>Reiniciar</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `${state.lastResult ? `<p class="jg-bk-msg ${state.lastResult.made ? 'ok' : ''}">${esc(state.lastResult.feedback)}</p>` : '<p class="jg-bk-msg">Mueva el ángulo y la fuerza, luego toque Lanzar.</p>'}${court}
    <div class="jg-bk-controls"><label>Ángulo <b id="jgAngleVal">${state.angle}°</b><input type="range" id="jgAngle" min="20" max="80" step="1" value="${state.angle}" ${finished ? 'disabled' : ''}></label>
    <label>Fuerza <b id="jgPowerVal">${state.power}</b><input type="range" id="jgPower" min="0" max="100" step="1" value="${state.power}" ${finished ? 'disabled' : ''}></label>
    <button type="button" class="jg-cta jg-bk-shoot" id="jgShoot" ${finished ? 'disabled' : ''}>🏀 Lanzar</button></div>`;
  return gameShell({ title: 'Básquet', sub: '5 tiros. Ajusta el ángulo y la fuerza; el aro cambia de lugar en cada tiro. Las canastas limpias suman extra.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── Dardos (R55) ───────────── */
export function dartsScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const colors = ['#e2231a', '#1faa4f', '#0a1f3a', '#f5efe0', '#0a1f3a', '#f5efe0'];
  const rings = DART_RINGS.slice().reverse().map(([r], i, arr) => `<circle r="${r * 100}" fill="${colors[arr.length - 1 - i]}" stroke="#c9b98f" stroke-width="0.8"/>`).join('');
  const labels = DART_RINGS.map(([r, p], i) => { const prev = i ? DART_RINGS[i - 1][0] : 0; const y = -((r + prev) / 2) * 100; return `<text x="0" y="${y + 3}" text-anchor="middle" font-size="${i ? 7 : 5}" font-weight="900" fill="${i === 2 || i === 4 ? '#fff' : i === 0 ? '#fff' : '#0a1f3a'}" opacity=".8">${p}</text>`; }).join('');
  const marks = state.throws.slice(-6).map(t => `<g transform="translate(${t.x * 100} ${t.y * 100})"><circle r="4.2" fill="${t.bust ? '#9aa8b8' : '#ffd84d'}" stroke="#0a1f3a" stroke-width="1.6"/></g>`).join('');
  const last = state.throws.at(-1);
  const board = `<svg class="jg-dt-board" viewBox="-110 -110 220 220" role="img" aria-label="Diana">
    <circle r="108" fill="#3b2a1a"/>${rings}${labels}${marks}
    ${finished ? '' : `<g id="jgAim" transform="translate(0 0)"><circle r="9" fill="none" stroke="#18b6c9" stroke-width="2.4"/><path d="M-14 0H-5M5 0H14M0 -14V-5M0 5V14" stroke="#18b6c9" stroke-width="2.4" stroke-linecap="round"/></g>`}
  </svg>`;
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Faltan', state.remaining], ['Dardos', `${state.throws.length}/${state.max}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgRestart">${refreshIco}<small>Reiniciar</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const msg = state.finished ? `¡Cerró en ${state.throws.length} dardos! 🎯` : !last ? `Llegue a <b>0 exacto</b> desde ${state.target}. Si se pasa, el dardo no resta. Toque Lanzar en el momento justo.` : last.bust ? `Se pasó (${last.points}). Necesita ${state.remaining} o menos.` : last.points === 50 ? '¡DIANA! −50 🎯' : last.points ? `−${last.points} · faltan ${state.remaining}` : 'Fuera del tablero';
  const body = `<p class="jg-bk-msg ${state.finished || last?.points >= 25 ? 'ok' : ''}">${msg}</p>${board}
    <button type="button" class="jg-cta jg-bk-shoot" id="jgThrow" ${finished ? 'disabled' : ''}>🎯 Lanzar dardo</button>`;
  return gameShell({ title: 'Dardos', sub: `Cuenta regresiva desde ${state.target}: llegue exacto a 0 con la menor cantidad de dardos.`, stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── Colorear (R55) ───────────── */
export function colorScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const done = Object.keys(state.fills).length, total = state.regions.length;
  const ok = state.regions.reduce((t, _, i) => t + (state.fills[i] === state.model[i] ? 1 : 0), 0);
  const precision = Math.round(ok / total * 100);
  const vb = state.designId === 'flor' ? '0 30 300 280' : '0 0 300 300';
  const art = `<svg class="jg-co-art" viewBox="${vb}" role="img" aria-label="Dibujo para colorear">${state.regions.map((d, i) => `<path d="${d}" data-jg-region="${i}" fill="${state.fills[i] || '#ffffff'}" stroke="#0a1f3a" stroke-width="2" stroke-linejoin="round"/>`).join('')}</svg>`;
  const model = `<svg class="jg-co-model" viewBox="${vb}" role="img" aria-label="Modelo">${state.regions.map((d, i) => `<path d="${d}" fill="${state.model[i]}" stroke="#0a1f3a" stroke-width="2"/>`).join('')}</svg>`;
  const palette = `<div class="jg-co-palette">${COLOR_PALETTE.map(c => `<button type="button" class="${c === state.selected ? 'on' : ''}" data-jg-color="${c}" style="--c:${c}" aria-label="Color ${c}"></button>`).join('')}</div>`;
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Precisión', `${precision}%`], ['Pintado', `${done}/${total}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgNextDesign" ${finished ? 'disabled' : ''}>${refreshIco}<small>Otro dibujo</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-co-head">${model}<p><b>${esc(state.designName)} · Modo reto:</b> copie los colores del modelo. Con menos de <b>70%</b> de precisión no suma puntos; cambiar una parte que ya estaba bien cuenta como error.</p></div>
    <div class="jg-progress"><span>Correctas: ${ok}/${total}</span><div class="jg-bar"><i style="width:${precision}%"></i></div><b>${precision}%</b></div>${palette}${art}`;
  const canFinish = finished || done >= total;
  return gameShell({ title: 'Colorear', sub: 'Elige un color y toca cada parte para copiar el modelo.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${canFinish ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}
