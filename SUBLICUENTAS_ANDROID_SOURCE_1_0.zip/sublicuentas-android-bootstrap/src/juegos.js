// Juegos PRO — pantallas (HTML). La lógica de cada juego vive en juegos-engine.js; aquí solo se pinta el
// estado y se arman los botones. Los puntos oficiales SIEMPRE vienen del servidor (api/juegos.js).
import { CATEGORIES } from './juegos-data.js';
import { sellerForSession } from './operations.js';
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const pad2 = n => String(n).padStart(2, '0');
export const fmtClock = totalSec => `${pad2(Math.floor(Math.max(0, totalSec) / 60))}:${pad2(Math.max(0, totalSec) % 60)}`;
const fmtNum = n => (Number(n) || 0).toLocaleString('es-HN');

export const GAME_META = Object.freeze({
  WORD_SEARCH: { title: 'Sopa de letras', tagline: 'Encuentra todas las palabras y demuestra cuánto sabes.', icon: '🔤', ready: true },
  HANGMAN: { title: 'El ahorcado', tagline: 'Adivina la palabra antes de quedarte sin intentos.', icon: '🪢', ready: true },
  MEMORY_PAIRS: { title: 'Pares de cartas', tagline: 'Encuentra todos los pares de cartas y demuestra tu memoria.', icon: '🃏', ready: true },
  BASKETBALL: { title: 'Básquet', tagline: 'Ajusta el ángulo, define la fuerza y encesta.', icon: '🏀', ready: false },
  DARTS: { title: 'Dardos', tagline: 'Apunta, lanza y demuestra tu precisión.', icon: '🎯', ready: false },
  COLOR_CHALLENGE: { title: 'Colorear', tagline: 'Relájate, da rienda suelta a tu creatividad.', icon: '🎨', ready: false },
});
const BADGE_ICON = { EXPLORADOR: '⭐', AVANZADO: '🥉', EXPERTO: '🥈', MAESTRO: '🥇', LEYENDA: '👑' };

const I = Object.freeze({
  back: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>',
  trophy: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 5H4a3 3 0 0 0 3 5M17 5h3a3 3 0 0 1-3 5"/></svg>',
  star: '<svg viewBox="0 0 24 24" width="16" height="16" fill="#FFD84D"><path d="m12 2 2.9 6.3 6.9.7-5.2 4.7 1.5 6.8L12 17l-6.1 3.5 1.5-6.8-5.2-4.7 6.9-.7Z"/></svg>',
  fire: '<svg viewBox="0 0 24 24" width="18" height="18" fill="#ff7a1a"><path d="M12 2s-5 5-5 10a5 5 0 0 0 10 0c0-2-1-3-1-3s.5 2-1 3c.3-2-1-4-1-4s0 2-1 3c-.5-1-1-3-1-3-.5 2 0 4 0 4-1-1-1-2-1-3 0-2 1-4 1-4Z"/></svg>',
});
const clock = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#41607a" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>';
const pauseIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="#0a1f3a"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>';
const refreshIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/></svg>';
const bulbIco = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3 11.2c.6.4 1 1 1 1.8h4c0-.8.4-1.4 1-1.8A6 6 0 0 0 12 3Z"/></svg>';

const topBar = (title) => `<header class="jg-top"><button type="button" class="jg-back" id="backMore" aria-label="Volver">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>`;
const sublibot = (msg) => `<div class="jg-bot"><div class="jg-bot-face">🙂</div><div class="jg-bubble"><b>¡Hola!</b><p>Soy <b>Sublibot</b>. ${esc(msg)}</p></div></div>`;
const statRow = (items) => `<div class="jg-stats">${items.map(([label, val, id]) => `<div class="jg-stat"><small>${esc(label)}</small><b${id ? ` id="${id}"` : ''}>${val}</b></div>`).join('<i class="jg-sep"></i>')}</div>`;

/* ───────────── Hub "Juegos PRO" (categoría Materia cerebral) ───────────── */
export function juegosHubHtml({ resumen = null, error = '' } = {}) {
  const pts = resumen ? fmtNum(resumen.totalPoints) : '—';
  const head = `<header class="jg-top"><button type="button" class="jg-back" id="backMore" aria-label="Volver">${I.back}</button><h1>Sublichat</h1><div class="jg-pointspill">${I.star}<span>Puntos: ${pts}</span></div><button type="button" class="jg-rankbtn" id="jgOpenRanking">${I.trophy}<small>Ranking</small></button></header>`;
  const cards = Object.entries(GAME_META).map(([code, g]) => `<button type="button" class="jg-card ${g.ready ? '' : 'soon'}" data-jg-open="${g.ready ? code : ''}" ${g.ready ? '' : 'disabled'}><span class="jg-card-ico">${g.icon}</span><span class="jg-card-txt"><b>${esc(g.title)}</b><small>${esc(g.tagline)}</small></span>${g.ready ? '' : '<em class="jg-soon-tag">Próximamente</em>'}</button>`).join('');
  const body = error
    ? `<div class="error-box"><span>${esc(error)}</span></div><button type="button" class="primary" id="jgRetry">Reintentar</button>`
    : `<div class="jg-hero"><i>🎮</i><span>Juegos PRO</span></div><h2 class="jg-h1">Materia cerebral</h2><p class="jg-sub">Entrena tu mente, suma puntos reales y sube en el ranking del equipo.</p>${sublibot('Elige un juego y demuestra de qué estás hecho. Modo PRO, solo para mentes curiosas.')}<div class="jg-grid">${cards}</div>`;
  return `<section class="jg-page">${head}${body}</section>`;
}

/* ───────────── Tablero "Juegos" (R52: rediseño + nombre del acceso, no el nombre personal) ───────────── */
// El jugador se muestra con el nombre del ACCESO (Sublicuentas, Relojes, Geisell), igual que en el resto de la app.
export function playerAccessName(userId = '', displayName = '') {
  return sellerForSession('', userId) || sellerForSession('', displayName) || String(displayName || userId || 'Jugador');
}
function mergeByAccess(entries = []) {
  const map = new Map();
  for (const e of entries) {
    const name = playerAccessName(e.userId, e.displayName);
    const prev = map.get(name);
    if (!prev) { map.set(name, { ...e, name, ids: [String(e.userId || '')] }); continue; }
    const score = (Number(prev.score) || 0) + (Number(e.score) || 0);
    const best = (Number(e.score) || 0) > (Number(prev.bestScore ?? prev.score) || 0) ? e : prev;
    map.set(name, { ...prev, score, bestScore: Math.max(Number(prev.bestScore ?? prev.score) || 0, Number(e.score) || 0), streak: Math.max(Number(prev.streak) || 0, Number(e.streak) || 0), badge: best.badge || prev.badge, ids: [...prev.ids, String(e.userId || '')] });
  }
  return [...map.values()].sort((x, y) => (Number(y.score) || 0) - (Number(x.score) || 0));
}
const JG_ICO = {
  chart: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#e2231a"><rect x="3" y="12" width="4.5" height="9" rx="1.2"/><rect x="9.8" y="5" width="4.5" height="16" rx="1.2"/><rect x="16.5" y="9" width="4.5" height="12" rx="1.2"/></svg>',
  pad: '<svg viewBox="0 0 48 32" width="44" height="30"><rect x="1" y="3" width="46" height="26" rx="13" fill="#e2231a"/><path d="M12 11v10M7 16h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="33" cy="13" r="2.4" fill="#fff"/><circle cx="38" cy="18" r="2.4" fill="#fff"/></svg>',
  chev: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
  crown: '<svg viewBox="0 0 64 44" width="70" height="48"><path d="M6 14 18 26 32 6l14 20 12-12-5 26H11Z" fill="#f7a8a3" opacity=".55"/></svg>',
};
const GAME_TILE = { WORD_SEARCH: { ico: '🔤', bg: '#e8f0ff' }, HANGMAN: { ico: '🪢', bg: '#e6f7ef' }, MEMORY_PAIRS: { ico: '🃏', bg: '#f1eefc' } };
export function leaderboardHtml({ scope = 'general', data = null, loading = false, error = '', me = null, myTotals = null, meLabel = '', avatar = '', gameCode = 'MEMORY_PAIRS' } = {}) {
  const head = `<header class="jg-top jg2-top"><button type="button" class="jg-back" id="jgRankBack" aria-label="Volver">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>
    <section class="jg2-hero"><div><h2>Juegos</h2><p>Juega, suma puntos y sube en el ranking</p></div><div class="jg2-hero-art">${JG_ICO.pad}<span class="jg2-bubble">Pequeños juegos,<br>grandes logros</span></div></section>`;
  const tabs = `<nav class="jg-tabs jg2-tabs">${[['general', '🏆', 'General'], ['semanal', '📅', 'Semanal'], ['porJuego', '🎮', 'Por juego']].map(([v, e, l]) => `<button type="button" class="${scope === v ? 'on' : ''}" data-jg-scope="${v}"><span>${e}</span>${l}</button>`).join('')}</nav>`;
  const readyGames = Object.entries(GAME_META).filter(([, g]) => g.ready);
  const gameChips = scope === 'porJuego' ? `<div class="jg2-gamechips">${readyGames.map(([code, g]) => `<button type="button" class="${code === gameCode ? 'on' : ''}" data-jg-rankgame="${code}">${g.icon} ${esc(g.title)}</button>`).join('')}</div>` : '';
  let body;
  if (loading) body = '<div class="loading-card"><span class="spinner"></span><strong>Cargando ranking…</strong></div>';
  else if (error) body = `<div class="error-box"><span>${esc(error)}</span></div><button type="button" class="primary jg2-retry" data-jg-scope="${scope}">Reintentar</button>`;
  else {
    const rows = mergeByAccess(data?.entries || []);
    const isMe = r => (me && r.ids.includes(String(me))) || (meLabel && r.name === meLabel);
    const meIdx = rows.findIndex(isMe);
    const meRow = data?.me || {};
    const myScore = meIdx >= 0 ? rows[meIdx].score : (meRow.score ?? (scope === 'general' ? myTotals?.totalPoints : 0) ?? 0);
    const myRank = meIdx >= 0 ? meIdx + 1 : (meRow.rank ?? null);
    const badge = myTotals?.badge || { code: 'EXPLORADOR', name: meIdx >= 0 ? (rows[meIdx].badge || 'Explorador') : 'Explorador' };
    const streak = Number(myTotals?.streak?.current ?? (meIdx >= 0 ? rows[meIdx].streak : 0)) || 0;
    const initial = esc(String(meLabel || 'S').trim().charAt(0).toUpperCase());
    const avatarHtml = avatar ? `<img class="jg-avatar jg2-avatar" src="${esc(avatar)}" alt="">` : `<span class="jg-avatar jg2-avatar jg2-initial">${initial}</span>`;
    const trs = rows.map((r, i) => `<tr class="${isMe(r) ? 'me' : ''}"><td><span class="jg-pos p${i + 1 <= 3 ? i + 1 : ''}">${i + 1}</span></td><td class="jg2-name">${esc(r.name)}</td><td>${fmtNum(r.score)}</td>${scope === 'general' ? `<td>🔥 ${Number(r.streak) || 0}</td><td>${esc(r.badge || '')}</td>` : '<td colspan="2"></td>'}</tr>`).join('');
    const best = readyGames.reduce((acc, [code]) => ((myTotals?.byGame?.[code] || 0) > (myTotals?.byGame?.[acc] || 0) ? code : acc), readyGames[0]?.[0]);
    body = `<section class="jg-mecard jg2-mecard"><div class="jg2-me-id">${avatarHtml}<small>${esc(meLabel || 'Mi acceso')}</small><span class="jg2-badge">${BADGE_ICON[badge.code] || '⭐'} ${esc(badge.name || 'Explorador')}</span></div>
        <div class="jg2-me-stat"><small>Mi puntaje</small><b>${fmtNum(myScore)}</b><span>puntos</span></div>
        <div class="jg2-me-stat"><small>Posición</small><b>${myRank ? `#${myRank}` : '—'}</b></div>
        <div class="jg2-me-stat"><small>Racha</small><b>🔥 ${streak}</b></div><i class="jg2-crown">${JG_ICO.crown}</i></section>
      <section class="jg2-card"><h3 class="jg2-h3">${JG_ICO.chart}Ranking de jugadores</h3>${gameChips}
      <div class="jg2-table-wrap"><table class="jg-table jg2-table"><thead><tr><th>#</th><th>Jugador</th><th>Puntos</th>${scope === 'general' ? '<th>Racha</th><th>Insignia</th>' : '<th colspan="2"></th>'}</tr></thead><tbody>${trs || '<tr><td colspan="5" class="jg-empty">Todavía no hay resultados en esta vista. ¡Juegue una partida y sea el primero!</td></tr>'}</tbody></table></div></section>
      ${myTotals ? `<div class="jg2-bygame-head"><h3>${JG_ICO.pad}Mis puntos por juego</h3><button type="button" class="jg2-more" id="jgGoHub">Juega y suma más puntos ${JG_ICO.chev}</button></div>
      <div class="jg-bygame jg2-bygame">${readyGames.map(([code, g]) => `<div class="jg-bygame-card jg2-game ${code === best && (myTotals.byGame?.[code] || 0) > 0 ? 'hot' : ''}"><span class="jg2-tile" style="background:${GAME_TILE[code]?.bg || '#eef3f8'}">${GAME_TILE[code]?.ico || g.icon}</span><b>${esc(g.title)}</b><small>${fmtNum(myTotals.byGame?.[code])} pts</small><button type="button" class="jg2-play" data-jg-play="${code}">Jugar</button></div>`).join('')}</div>` : ''}`;
  }
  return `<section class="jg-page jg2-page">${head}${tabs}${body}</section>`;
}

/* ───────────── envoltorio común de una partida ───────────── */
function gameShell({ title, sub, stats, controls, body, footer }) {
  return `<section class="jg-page game">
    <header class="jg-top"><button type="button" class="jg-back" id="jgQuit" aria-label="Salir del juego">${I.back}</button><h1>Sublichat</h1><span class="jg-topfill"></span></header>
    <div class="jg-gamehead"><div><p class="jg-eyebrow">🎮 Juegos PRO</p><h2>${esc(title)}</h2><p class="jg-sub">${esc(sub)}</p></div></div>
    <div class="jg-panel">${statRow(stats)}<div class="jg-controls">${controls}</div></div>
    <div class="jg-board">${body}</div>
    ${footer || ''}
  </section>`;
}

/* ───────────── Pares de cartas ───────────── */
const CARD_ICONS = { heart: '❤️', diamond: '♦️', spade: '♠️', crown: '👑', club: '♣️', star: '⭐', moon: '🌙', bolt: '⚡', gift: '🎁', ring: '💍', gem: '💎', flag: '🚩' };
export function memoryScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const pct = Math.round((state.pairsFound / (state.cards.length / 2)) * 100);
  const grid = state.cards.map((c, i) => {
    const open = c.matched || state.flipped.includes(i);
    return `<button type="button" class="jg-card2 ${open ? 'open' : ''} ${c.matched ? 'matched' : ''}" data-jg-flip="${i}" ${open || finished ? 'disabled' : ''} aria-label="Carta ${i + 1}"><span class="jg-card2-face">${open ? CARD_ICONS[c.symbol] : 'S'}</span></button>`;
  }).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Combo', `x${state.combo}`], ['Movimientos', state.moves]];
  const controls = `<button type="button" class="jg-ctrl" id="jgRestart">${refreshIco}<small>Reiniciar</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-progress"><span>Pares encontrados: ${state.pairsFound}/${state.cards.length / 2}</span><div class="jg-bar"><i style="width:${pct}%"></i></div><b>${pct}%</b></div><div class="jg-memgrid">${grid}</div>`;
  return gameShell({ title: 'Pares de cartas', sub: 'Encuentra todos los pares de cartas y demuestra tu memoria. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── El ahorcado ───────────── */
export function hangmanScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const round = state.rounds[state.roundIndex] || state.rounds.at(-1);
  const cat = CATEGORIES[round.category] || round.category;
  const cells = [...round.word].map(ch => `<span class="jg-letterbox ${round.guessed.includes(ch) || round.gaveUp ? 'shown' : ''}">${round.guessed.includes(ch) || round.gaveUp ? ch : ''}</span>`).join('');
  const lives = Math.max(0, state.maxErrors - round.wrong.length);
  const hearts = Array.from({ length: state.maxErrors }, (_, i) => `<span class="jg-heart ${i < lives ? '' : 'off'}">❤</span>`).join('');
  const alphabet = 'QWERTYUIOPASDFGHJKLZXCVBNM'.split('');
  const keys = alphabet.map(l => `<button type="button" class="jg-key ${round.guessed.includes(l) ? 'ok' : ''} ${round.wrong.includes(l) ? 'bad' : ''}" data-jg-letter="${l}" ${round.guessed.includes(l) || round.wrong.includes(l) || round.solved || round.gaveUp || finished ? 'disabled' : ''}>${l}</button>`).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Ronda', `${state.roundIndex + 1}/${state.rounds.length}`], ['Racha', `x${state.rounds.filter(r => r.solved).length}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgHint" ${state.hintsUsed >= state.maxHints || round.solved || round.gaveUp ? 'disabled' : ''}>${bulbIco}<small>Pistas (${state.maxHints - state.hintsUsed})</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-hang-top"><span class="jg-catchip">${clock}${esc(cat)}</span><small>${round.guessed.length + round.wrong.length ? '' : ''}</small></div>
    <div class="jg-letters">${cells}</div><p class="jg-clue">${esc(round.clue)}</p>
    <div class="jg-hearts"><span>Intentos restantes</span>${hearts}</div>
    <div class="jg-keyboard">${keys}</div>`;
  return gameShell({ title: 'El ahorcado', sub: 'Adivina la palabra antes de quedarte sin intentos. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── Sopa de letras ───────────── */
export function wordSearchScreenHtml({ state, timeLeftSec, finished = false } = {}) {
  const sel = state.selectStart ? `${state.selectStart[0]}_${state.selectStart[1]}` : '';
  const foundCells = new Set(); state.words.forEach(w => { if (w.found && w.cells) w.cells.forEach(([r, c]) => foundCells.add(`${r}_${c}`)); });
  const grid = state.grid.map((row, r) => row.map((ch, c) => {
    const key = `${r}_${c}`; const on = key === sel; const done = foundCells.has(key);
    return `<button type="button" class="jg-letter-cell ${on ? 'on' : ''} ${done ? 'done' : ''}" data-jg-cell="${r},${c}" ${finished ? 'disabled' : ''} aria-label="Celda ${r + 1},${c + 1}">${ch}</button>`;
  }).join('')).join('');
  const foundCount = state.words.filter(w => w.found).length;
  const list = state.words.map(w => `<li class="${w.found ? 'done' : ''}">${w.found ? '✓' : '•'} ${esc(w.word)}</li>`).join('');
  const stats = [['Tiempo', fmtClock(timeLeftSec), 'jgTimer'], ['Combo', `x${state.combo}`], ['Encontradas', `${foundCount}/${state.words.length}`]];
  const controls = `<button type="button" class="jg-ctrl" id="jgHint" ${finished ? 'disabled' : ''}>${bulbIco}<small>Pista</small></button><button type="button" class="jg-ctrl" id="jgPause">${pauseIco}<small>Pausar</small></button>`;
  const body = `<div class="jg-ws-layout"><div class="jg-ws-grid" style="--jg-size:${state.size}">${grid}</div><aside class="jg-ws-list"><h4>📖 Palabras a encontrar <em>${foundCount}/${state.words.length}</em></h4><ul>${list}</ul></aside></div>`;
  return gameShell({ title: 'Sopa de letras', sub: 'Encuentra todas las palabras y demuestra cuánto sabes. Modo PRO, solo para mentes curiosas.', stats, controls, body,
    footer: `<button type="button" class="jg-cta" id="jgFinish" ${finished ? '' : 'disabled'}>▶ Finalizar y guardar puntos</button>` });
}

/* ───────────── resultado (hoja de confirmación con puntos oficiales) ───────────── */
export function resultSheetHtml({ status = 'loading', awardedPoints = 0, totalPoints = 0, streak = null, badge = null, error = '', repetido = false } = {}) {
  if (status === 'loading') return `<div class="jg-result"><span class="spinner"></span><b>Guardando tu resultado…</b><small>El servidor confirma tus puntos oficiales.</small></div>`;
  if (status === 'error') return `<div class="jg-result"><span class="jg-result-x">⚠️</span><b>No se pudo guardar</b><small>${esc(error || 'Revisa tu conexión e inténtalo de nuevo.')}</small><button type="button" class="primary" data-sr-cancel>Cerrar</button></div>`;
  return `<div class="jg-result done"><span class="jg-result-ico">🏆</span><b>+${fmtNum(awardedPoints)} SP</b><small>${repetido ? 'Esta partida ya se había guardado antes.' : '¡Puntos confirmados por el servidor!'}</small>
    <div class="jg-result-row"><span>Total acumulado</span><b>${fmtNum(totalPoints)}</b></div>
    ${streak ? `<div class="jg-result-row"><span>Racha</span><b>${I.fire}${streak.current} día${streak.current === 1 ? '' : 's'}</b></div>` : ''}
    ${badge ? `<div class="jg-result-row"><span>Insignia</span><b>${BADGE_ICON[badge.code] || '⭐'} ${esc(badge.name)}</b></div>` : ''}
    <button type="button" class="primary" data-sr-cancel>Continuar</button></div>`;
}
