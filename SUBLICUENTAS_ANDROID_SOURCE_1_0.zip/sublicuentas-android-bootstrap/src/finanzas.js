// Control financiero de la app · misma lógica que Control financiero de Sublichat HQ (sublichat-app.js):
// une finanzas (histórico) + finanzas_movimientos (actual), normaliza cada movimiento y arma resúmenes y el Excel.
import { platformLabel } from './operations.js';

const TZ = 'America/Tegucigalpa';
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const money = n => `L ${Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/* ───────────── normalización (igual que la web) ───────────── */
export function finMoney(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? Math.abs(v) : 0;
  const n = Number(String(v ?? '0').replace(/[^0-9.,-]/g, '').replace(/,/g, ''));
  return Number.isFinite(n) ? Math.abs(n) : 0;
}
export function finCalendarDate(v) {
  if (v === null || v === undefined || v === '') return null;
  const s = String(v).trim();
  let m = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  let y, mo, d;
  if (m) { d = +m[1]; mo = +m[2]; y = +m[3]; }
  else {
    m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:$|T)/);
    if (!m) return null;
    y = +m[1]; mo = +m[2]; d = +m[3];
  }
  const out = new Date(y, mo - 1, d, 12, 0, 0, 0);
  return out.getFullYear() === y && out.getMonth() === mo - 1 && out.getDate() === d ? out : null;
}
export function finTimestampDate(v) {
  if (!v) return null;
  let raw = null;
  try {
    if (typeof v.toDate === 'function') raw = v.toDate();
    else if (v instanceof Date) raw = v;
    else if (typeof v === 'number' && Number.isFinite(v)) raw = new Date(v < 1e12 ? v * 1000 : v);
    else if (typeof v === 'object' && Number.isFinite(v.seconds ?? v._seconds)) raw = new Date(Number(v.seconds ?? v._seconds) * 1000);
    else raw = new Date(String(v));
  } catch (_) { return null; }
  if (!raw || Number.isNaN(raw.getTime())) return null;
  try {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: TZ, year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(raw);
    const pick = t => Number(parts.find(p => p.type === t)?.value || 0);
    const y = pick('year'), mo = pick('month'), d = pick('day');
    if (y && mo && d) return new Date(y, mo - 1, d, 12, 0, 0, 0);
  } catch (_) { /* cae al día local */ }
  return new Date(raw.getFullYear(), raw.getMonth(), raw.getDate(), 12, 0, 0, 0);
}
export function finBusinessDate(m = {}) {
  // Primero la fecha escrita de la operación (como el bot); los timestamps técnicos solo son respaldo.
  for (const value of [m.fecha, m.fechaPago, m.fecha_pago, m.fecha_dmy, m.fechaMovimiento, m.date]) {
    const parsed = finCalendarDate(value); if (parsed) return parsed;
  }
  for (const value of [m.fechaTS, m.fecha_ts, m.timestamp, m.ts, m.createdAt, m.created_at, m.updatedAt, m.updated_at]) {
    const parsed = finTimestampDate(value); if (parsed) return parsed;
  }
  return null;
}
const finText = v => String(v ?? '').trim();
const finKey = v => finText(v).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
export function finBank(m = {}) {
  const raw = finText(m.banco || m.metodoPago || m.metodo_pago || m.metodo || m.cuenta || m.bank);
  if (!raw || ['no especificado', 'ninguno', 'n/a', '—', '-'].includes(finKey(raw))) return 'Sin banco';
  return raw;
}
export function finParse(m = {}) {
  const tipo = finText(m.tipo || m.type || m.movimiento || 'ingreso').toLowerCase();
  const esEgreso = tipo.includes('egreso') || tipo.includes('gasto') || tipo.includes('salida') || tipo === 'out';
  const plataforma = finText(m.plataforma || m.servicio || m.producto || m.platform);
  const detalle = finText(m.detalle || m.descripcion || m.nota || m.observacion);
  const conceptoIngreso = plataforma ? platformLabel(plataforma) : finText(m.concepto || m.descripcion || m.concept || m.clienteNombre || m.nombre || detalle);
  const conceptoEgreso = finText(m.motivo || m.concepto || m.descripcion || m.concept || m.detalle || m.nota || m.observacion);
  return {
    id: String(m.id || ''),
    tipo: esEgreso ? 'egreso' : 'ingreso',
    monto: finMoney(m.monto ?? m.cantidad ?? m.valor ?? m.amount ?? m.total),
    fecha: finBusinessDate(m),
    banco: finBank(m),
    concepto: (esEgreso ? conceptoEgreso : conceptoIngreso) || 'Movimiento',
    plataforma,
    detalle,
    cliente: finText(m.clienteNombre || m.cliente || m.nombre),
    vendedor: finText(m.vendedor || m.cobradoPor || m.registradoPor),
    fuente: m._source || '',
  };
}

// Une el histórico (`finanzas`) con lo actual (`finanzas_movimientos`) por id; lo actual manda (igual que la web).
export function mergeFinanceSources(historico = [], actual = []) {
  const byId = new Map();
  (Array.isArray(historico) ? historico : []).forEach((d, i) => byId.set(String(d?.id ?? `h${i}`), { ...d, _source: 'finanzas' }));
  (Array.isArray(actual) ? actual : []).forEach((d, i) => byId.set(String(d?.id ?? `a${i}`), { ...d, _source: 'finanzas_movimientos' }));
  return [...byId.values()];
}
export function parseAllFinance(rows = []) {
  return (Array.isArray(rows) ? rows : []).map(finParse).filter(m => m.fecha);
}

/* ───────────── períodos, filtros y agregados ───────────── */
const pad = n => String(n).padStart(2, '0');
export const isoDay = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const noon = d => new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12, 0, 0, 0);

export function weekRange(today = new Date()) {
  const d = noon(today); const day = (d.getDay() + 6) % 7;
  const start = new Date(d); start.setDate(d.getDate() - day);
  const end = new Date(start); end.setDate(start.getDate() + 6);
  return { start, end };
}
export function periodRange(period = 'mes', today = new Date(), custom = {}) {
  const t = noon(today);
  if (period === 'hoy') return { desde: t, hasta: t, label: 'Hoy' };
  if (period === 'semana') { const { start, end } = weekRange(t); return { desde: start, hasta: end, label: 'Esta semana' }; }
  if (period === 'mes') return { desde: new Date(t.getFullYear(), t.getMonth(), 1, 12), hasta: new Date(t.getFullYear(), t.getMonth() + 1, 0, 12), label: 'Este mes' };
  if (period === 'rango') {
    const desde = finCalendarDate(custom.desde), hasta = finCalendarDate(custom.hasta);
    return { desde, hasta, label: `${custom.desde || '…'} a ${custom.hasta || '…'}` };
  }
  return { desde: null, hasta: null, label: 'Todo' };
}
export function filterMovs(movs = [], { desde = null, hasta = null, tipo = 'todos', banco = '' } = {}) {
  return movs.filter(m => {
    if (desde && m.fecha < desde) return false;
    if (hasta && m.fecha > hasta) return false;
    if (tipo === 'ingreso' && m.tipo !== 'ingreso') return false;
    if (tipo === 'egreso' && m.tipo !== 'egreso') return false;
    if (banco && m.banco !== banco) return false;
    return true;
  });
}
export function totalsOf(movs = []) {
  const ing = movs.filter(m => m.tipo === 'ingreso').reduce((s, m) => s + m.monto, 0);
  const egr = movs.filter(m => m.tipo === 'egreso').reduce((s, m) => s + m.monto, 0);
  return { ing, egr, neto: ing - egr, n: movs.length };
}
export function byBankOf(movs = []) {
  const map = {};
  movs.forEach(m => { const b = m.banco || '—'; map[b] ||= { banco: b, ing: 0, egr: 0 }; if (m.tipo === 'ingreso') map[b].ing += m.monto; else map[b].egr += m.monto; });
  return Object.values(map).map(x => ({ ...x, neto: x.ing - x.egr })).sort((a, b) => b.ing - a.ing || b.egr - a.egr);
}
const monthKey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
export function monthName(key) { const [y, m] = key.split('-'); return new Date(+y, +m - 1, 1).toLocaleDateString('es-HN', { month: 'long', year: 'numeric' }); }
export function lastMonthsOf(movs = [], today = new Date(), count = 6) {
  const out = [];
  for (let off = -(count - 1); off <= 0; off += 1) {
    const r = new Date(today.getFullYear(), today.getMonth() + off, 1);
    const mm = movs.filter(m => m.fecha.getFullYear() === r.getFullYear() && m.fecha.getMonth() === r.getMonth());
    const t = totalsOf(mm);
    out.push({ key: monthKey(r), label: r.toLocaleDateString('es-HN', { month: 'short' }), ...t });
  }
  return out;
}

// "Cierre del mes" de Control financiero (web): se calcula por fechas de renovación de la cartera, sin marca de pago.
export function cierreDelMes(rows = [], today = new Date()) {
  const base = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12, 0, 0, 0);
  const inMonth = (d, off) => { const r = new Date(base.getFullYear(), base.getMonth() + off, 1); return d.getFullYear() === r.getFullYear() && d.getMonth() === r.getMonth(); };
  const items = (Array.isArray(rows) ? rows : []).map(r => ({ d: finCalendarDate(r?.fechaRenovacion), precio: Number(r?.precio) || 0 })).filter(x => x.d);
  const sum = list => list.reduce((s, x) => s + x.precio, 0);
  const mesItems = items.filter(x => inMonth(x.d, 0));
  const esperado = sum(mesItems);
  const pendiente = sum(mesItems.filter(x => Math.round((x.d - base) / 86400000) < 0));
  const anterior = sum(items.filter(x => inMonth(x.d, -1)));
  const deltaPct = anterior > 0 ? Math.round(((esperado - anterior) / anterior) * 100) : null;
  return { mes: base.toLocaleDateString('es-HN', { month: 'long', year: 'numeric' }), esperado, pendiente, anterior, deltaPct, servicios: mesItems.length };
}

export function financeFileName(scope = 'todo', today = new Date()) {
  return `Finanzas_Sublichat_${scope === 'todo' ? 'todo' : 'periodo'}_${isoDay(today)}.xlsx`;
}

/* ───────────── pantalla ───────────── */
export const FIN_PERIODS = Object.freeze([['hoy', 'Hoy'], ['semana', 'Semana'], ['mes', 'Mes'], ['todo', 'Todo'], ['rango', 'Rango']]);

export function financeContentHtml({ movs = [], period = 'mes', desde = '', hasta = '', tipo = 'todos', shown = 60, busy = false, today = new Date(), canWrite = false, errorText = '', cierreMes = null } = {}) {
  const range = periodRange(period, today, { desde, hasta });
  const inRange = filterMovs(movs, { desde: range.desde, hasta: range.hasta });
  const t = totalsOf(inRange);
  const list = filterMovs(inRange, { tipo }).sort((a, b) => b.fecha - a.fecha);
  const banks = byBankOf(inRange);
  const maxBank = Math.max(1, ...banks.map(b => Math.max(b.ing, b.egr)));
  const months = lastMonthsOf(movs, today, 6);
  const maxMonth = Math.max(1, ...months.map(m => Math.max(m.ing, m.egr)));
  const week = weekRange(today);
  const weekMovs = filterMovs(movs, { desde: week.start, hasta: week.end });
  const wt = totalsOf(weekMovs);

  const tabs = `<div class="mt-modes fin-tabs">${FIN_PERIODS.map(([id, label]) => `<button type="button" class="${period === id ? 'active' : ''}" data-fin-period="${id}">${label}</button>`).join('')}</div>`;
  const rangeForm = period === 'rango' ? `<div class="fin-range"><label><span>Desde</span><input type="date" id="finDesde" value="${esc(desde)}"></label><label><span>Hasta</span><input type="date" id="finHasta" value="${esc(hasta)}"></label><button type="button" class="secondary" id="finApplyRange">Aplicar</button></div>` : '';
  const err = errorText ? `<div class="error-box"><span>${esc(errorText)}</span></div>` : '';
  const kpis = `<section class="finance-grid fin-kpis"><article><span>Ingresos</span><strong class="fin-ing">${money(t.ing)}</strong></article><article><span>Egresos</span><strong class="fin-egr">${money(t.egr)}</strong></article><article class="wide"><span>Ganancia · ${esc(range.label)} · ${t.n} movimiento${t.n === 1 ? '' : 's'}</span><strong>${money(t.neto)}</strong></article></section>`;
  const excel = `<div class="fin-actions"><button type="button" class="primary" id="finXlsAll" ${busy || !movs.length ? 'disabled' : ''}>${busy ? 'Generando…' : '📊 Excel · todo'}</button><button type="button" class="secondary" id="finXlsPeriod" ${busy || !inRange.length ? 'disabled' : ''}>📅 Excel · ${esc(range.label)}</button></div><p class="muted note">El Excel trae 4 hojas (Resumen, Por Mes, Por Banco y Movimientos con todos los datos). Al terminar elija dónde guardarlo o enviarlo.</p>`;
  const bankRows = banks.length ? banks.map(b => `<div class="fin-bank"><div class="fin-bank-head"><strong>${esc(b.banco)}</strong><span>${money(b.neto)}</span></div><div class="fin-bar"><i class="ing" style="width:${Math.round(b.ing / maxBank * 100)}%"></i></div><div class="fin-bar"><i class="egr" style="width:${Math.round(b.egr / maxBank * 100)}%"></i></div><small>Ingresos ${money(b.ing)} · Egresos ${money(b.egr)}</small></div>`).join('') : '<p class="muted note">Sin movimientos en este período.</p>';
  const monthRows = months.map(m => `<div class="fin-month"><span class="fin-month-l">${esc(m.label)}</span><div class="fin-month-bars"><div class="fin-bar"><i class="ing" style="width:${Math.round(m.ing / maxMonth * 100)}%"></i></div><div class="fin-bar"><i class="egr" style="width:${Math.round(m.egr / maxMonth * 100)}%"></i></div></div><span class="fin-month-v">${money(m.neto)}</span></div>`).join('');
  const tipos = [['todos', 'Todos'], ['ingreso', 'Ingresos'], ['egreso', 'Egresos']];
  const movRows = list.slice(0, shown).map(m => `<div class="fin-mov"><div class="fin-mov-c"><strong>${esc(m.concepto)}</strong><small>${esc(m.fecha.toLocaleDateString('es-HN'))} · ${esc(m.banco)}${m.cliente && m.tipo === 'ingreso' && m.cliente !== m.concepto ? ` · ${esc(m.cliente)}` : ''}</small></div><b class="${m.tipo === 'ingreso' ? 'fin-ing' : 'fin-egr'}">${m.tipo === 'ingreso' ? '+' : '−'}${money(m.monto)}</b></div>`).join('');
  const more = list.length > shown ? `<button type="button" class="secondary full" id="finMore">Ver más (${list.length - shown})</button>` : '';
  const egresoForm = canWrite ? `<section class="panel fin-form"><h3>➖ Registrar egreso</h3><input id="finEgMotivo" placeholder="Motivo (compra, banco, soporte…)"><div class="fin-form-row"><input id="finEgMonto" type="number" inputmode="decimal" placeholder="Monto Lps."><input id="finEgBanco" placeholder="Banco / método"></div><input id="finEgFecha" type="date" value="${isoDay(today)}"><button type="button" class="primary" id="finEgSave">Guardar egreso</button></section>` : '';
  const cierre = canWrite ? `<section class="panel fin-form"><h3>🧾 Cierre semanal</h3><div class="finance-grid fin-kpis"><article><span>Ingresos</span><strong class="fin-ing">${money(wt.ing)}</strong></article><article><span>Egresos</span><strong class="fin-egr">${money(wt.egr)}</strong></article><article class="wide"><span>Neto estimado · ${esc(week.start.toLocaleDateString('es-HN'))} al ${esc(week.end.toLocaleDateString('es-HN'))}</span><strong>${money(wt.neto)}</strong></article></div><button type="button" class="secondary" id="finCierreSave">Guardar cierre de la semana</button></section>` : '';
  const cierreMesHtml = cierreMes ? `<section class="panel fin-cierre-mes"><h3>🗓️ Cierre del mes · ${esc(cierreMes.mes)}</h3><div class="finance-grid fin-kpis"><article><span>Esperado este mes</span><strong>${money(cierreMes.esperado)}</strong></article><article><span>Pendiente / vencido</span><strong class="fin-egr">${money(cierreMes.pendiente)}</strong></article><article class="wide"><span>vs mes pasado</span><strong class="${cierreMes.deltaPct == null ? '' : (cierreMes.deltaPct >= 0 ? 'fin-ing' : 'fin-egr')}">${cierreMes.deltaPct == null ? '—' : `${cierreMes.deltaPct >= 0 ? '+' : ''}${cierreMes.deltaPct}%`}</strong></article></div><p class="muted note">Calculado por fechas de renovación. No incluye marca de pago.</p></section>` : '';
  return `${err}${cierreMesHtml}${tabs}${rangeForm}${kpis}${excel}<h3 class="fin-h">🏦 Por banco / método</h3><section class="panel">${bankRows}</section><h3 class="fin-h">📈 Últimos 6 meses</h3><section class="panel fin-months">${monthRows}<div class="fin-legend"><i class="ing"></i> Ingresos <i class="egr"></i> Egresos</div></section><h3 class="fin-h">🧾 Movimientos (${list.length})</h3><div class="mt-modes">${tipos.map(([id, label]) => `<button type="button" class="${tipo === id ? 'active' : ''}" data-fin-tipo="${id}">${label}</button>`).join('')}</div><section class="fin-list">${movRows || '<div class="empty-state"><strong>Sin movimientos</strong><span>No hay movimientos con estos filtros.</span></div>'}</section>${more}${egresoForm}${cierre}`;
}

/* ───────────── Excel (mismas 4 hojas que la web + datos completos) ───────────── */
const C = { navy: 'FF0F2D52', blue: 'FF139CE8', blueLight: 'FFE8F8FF', zebra: 'FFF2FBFF', white: 'FFFFFFFF', border: 'FFD5E4F1', green: 'FF166534', greenBg: 'FFDCFCE7', red: 'FFB91C1C', redBg: 'FFFEE2E2' };
const MONEY_FMT = '"Lps" #,##0';
const border = () => { const c = { style: 'thin', color: { argb: C.border } }; return { top: c, left: c, bottom: c, right: c }; };
const solid = argb => ({ type: 'pattern', pattern: 'solid', fgColor: { argb } });
function headerRow(row) {
  row.eachCell(cell => { cell.fill = solid(C.blue); cell.font = { bold: true, color: { argb: C.white }, size: 11 }; cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true }; cell.border = border(); });
  row.height = 22;
}
function titleRow(ws, text, cols) {
  ws.mergeCells(1, 1, 1, cols);
  const cell = ws.getCell(1, 1);
  cell.value = text; cell.fill = solid(C.navy); cell.font = { bold: true, color: { argb: C.white }, size: 16 }; cell.alignment = { vertical: 'middle', horizontal: 'left', indent: 1 };
  ws.getRow(1).height = 30;
}
const zebra = (row, idx) => row.eachCell(c => { c.border = border(); if (idx % 2 === 0) c.fill = solid(C.zebra); });
const totalStyle = row => row.eachCell(c => { c.font = { bold: true, color: { argb: C.navy } }; c.fill = solid(C.blueLight); c.border = border(); });
const netFont = v => ({ bold: true, color: { argb: v >= 0 ? C.green : C.red } });

export function buildFinanceWorkbook(ExcelJS, movsIn = [], { label = 'Todo', now = new Date(), cierre = null } = {}) {
  const movs = movsIn.slice().sort((a, b) => a.fecha - b.fecha);
  if (!movs.length) throw new Error('No hay movimientos para exportar.');
  const meses = {};
  movs.forEach(m => { const k = monthKey(m.fecha); meses[k] ||= { ing: 0, egr: 0, nMov: 0 }; if (m.tipo === 'ingreso') meses[k].ing += m.monto; else meses[k].egr += m.monto; meses[k].nMov += 1; });
  const claves = Object.keys(meses).sort();
  const { ing: totIng, egr: totEgr, neto: gananciaTotal } = totalsOf(movs);

  const wb = new ExcelJS.Workbook();
  wb.creator = 'Sublichat'; wb.created = now;

  // Hoja 1 · Resumen
  const wsR = wb.addWorksheet('Resumen', { views: [{ state: 'frozen', ySplit: 9 }] });
  wsR.columns = [{ width: 26 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 26 }];
  titleRow(wsR, '📊 SUBLICUENTAS · REPORTE FINANCIERO', 5);
  wsR.getCell(2, 1).value = 'Generado'; wsR.getCell(2, 2).value = now.toLocaleString('es-HN');
  wsR.getCell(3, 1).value = 'Período'; wsR.getCell(3, 2).value = `${monthName(claves[0])} → ${monthName(claves[claves.length - 1])}${label && label !== 'Todo' ? ` · filtro: ${label}` : ''}`;
  wsR.getCell(4, 1).value = 'Movimientos'; wsR.getCell(4, 2).value = movs.length;
  [2, 3, 4].forEach(r => { wsR.getCell(r, 1).font = { bold: true, color: { argb: C.navy } }; });
  [
    { label: 'INGRESOS', valor: totIng, bg: C.greenBg, fg: C.green, col: 1 },
    { label: 'EGRESOS', valor: totEgr, bg: C.redBg, fg: C.red, col: 2 },
    { label: 'GANANCIA NETA', valor: gananciaTotal, bg: gananciaTotal >= 0 ? C.greenBg : C.redBg, fg: gananciaTotal >= 0 ? C.green : C.red, col: 3 },
  ].forEach(k => {
    const cLabel = wsR.getCell(6, k.col), cVal = wsR.getCell(7, k.col);
    cLabel.value = k.label; cLabel.font = { bold: true, size: 10, color: { argb: k.fg } }; cLabel.fill = solid(k.bg); cLabel.alignment = { horizontal: 'center' }; cLabel.border = border();
    cVal.value = k.valor; cVal.numFmt = MONEY_FMT; cVal.font = { bold: true, size: 14, color: { argb: k.fg } }; cVal.fill = solid(k.bg); cVal.alignment = { horizontal: 'center' }; cVal.border = border();
  });
  wsR.getRow(6).height = 18; wsR.getRow(7).height = 24;
  ['Mes', 'Ingresos', 'Egresos', 'Ganancia', 'Variación % vs mes anterior'].forEach((v, i) => { wsR.getCell(9, i + 1).value = v; });
  headerRow(wsR.getRow(9));
  let prev = null, rIdx = 10;
  claves.forEach(k => {
    const g = meses[k].ing - meses[k].egr;
    const varPct = prev !== null && prev !== 0 ? (g - prev) / Math.abs(prev) : null;
    const row = wsR.getRow(rIdx);
    row.getCell(1).value = monthName(k);
    row.getCell(2).value = meses[k].ing; row.getCell(2).numFmt = MONEY_FMT;
    row.getCell(3).value = meses[k].egr; row.getCell(3).numFmt = MONEY_FMT;
    row.getCell(4).value = g; row.getCell(4).numFmt = MONEY_FMT; row.getCell(4).font = netFont(g);
    if (varPct != null) { row.getCell(5).value = varPct; row.getCell(5).numFmt = '+0.0%;-0.0%'; row.getCell(5).font = { color: { argb: varPct >= 0 ? C.green : C.red } }; }
    else row.getCell(5).value = '—';
    zebra(row, rIdx); prev = g; rIdx += 1;
  });
  wsR.autoFilter = { from: { row: 9, column: 1 }, to: { row: 9, column: 5 } };

  // Hoja 2 · Por Mes
  const wsM = wb.addWorksheet('Por Mes', { views: [{ state: 'frozen', ySplit: 1 }] });
  wsM.columns = [{ width: 26 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 16 }];
  ['Mes', 'Ingresos', 'Egresos', 'Ganancia', 'N° movimientos'].forEach((v, i) => { wsM.getCell(1, i + 1).value = v; });
  headerRow(wsM.getRow(1));
  let mIdx = 2;
  claves.forEach(k => {
    const row = wsM.getRow(mIdx); const g = meses[k].ing - meses[k].egr;
    row.getCell(1).value = monthName(k);
    row.getCell(2).value = meses[k].ing; row.getCell(2).numFmt = MONEY_FMT;
    row.getCell(3).value = meses[k].egr; row.getCell(3).numFmt = MONEY_FMT;
    row.getCell(4).value = g; row.getCell(4).numFmt = MONEY_FMT; row.getCell(4).font = netFont(g);
    row.getCell(5).value = meses[k].nMov;
    zebra(row, mIdx); mIdx += 1;
  });
  const totM = wsM.getRow(mIdx);
  totM.getCell(1).value = 'TOTAL';
  totM.getCell(2).value = totIng; totM.getCell(2).numFmt = MONEY_FMT;
  totM.getCell(3).value = totEgr; totM.getCell(3).numFmt = MONEY_FMT;
  totM.getCell(4).value = gananciaTotal; totM.getCell(4).numFmt = MONEY_FMT;
  totM.getCell(5).value = movs.length;
  totalStyle(totM);
  wsM.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: 5 } };

  // Hoja 3 · Por Banco
  const bancos = byBankOf(movs);
  const wsB = wb.addWorksheet('Por Banco', { views: [{ state: 'frozen', ySplit: 1 }] });
  wsB.columns = [{ width: 24 }, { width: 16 }, { width: 16 }, { width: 16 }];
  ['Banco / Método', 'Ingresos', 'Egresos', 'Neto'].forEach((v, i) => { wsB.getCell(1, i + 1).value = v; });
  headerRow(wsB.getRow(1));
  let bIdx = 2;
  bancos.forEach(b => {
    const row = wsB.getRow(bIdx);
    row.getCell(1).value = b.banco;
    row.getCell(2).value = b.ing; row.getCell(2).numFmt = MONEY_FMT;
    row.getCell(3).value = b.egr; row.getCell(3).numFmt = MONEY_FMT;
    row.getCell(4).value = b.neto; row.getCell(4).numFmt = MONEY_FMT; row.getCell(4).font = netFont(b.neto);
    zebra(row, bIdx); bIdx += 1;
  });
  const totB = wsB.getRow(bIdx);
  totB.getCell(1).value = 'TOTAL';
  totB.getCell(2).value = totIng; totB.getCell(2).numFmt = MONEY_FMT;
  totB.getCell(3).value = totEgr; totB.getCell(3).numFmt = MONEY_FMT;
  totB.getCell(4).value = gananciaTotal; totB.getCell(4).numFmt = MONEY_FMT;
  totalStyle(totB);
  wsB.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: 4 } };

  // Hoja 4 · Movimientos (detalle completo)
  const wsV = wb.addWorksheet('Movimientos', { views: [{ state: 'frozen', ySplit: 1 }] });
  wsV.columns = [{ width: 12 }, { width: 11 }, { width: 40 }, { width: 20 }, { width: 14 }, { width: 18 }, { width: 28 }, { width: 22 }, { width: 18 }, { width: 22 }];
  ['Fecha', 'Tipo', 'Concepto', 'Banco / Método', 'Monto', 'Plataforma', 'Detalle', 'Cliente', 'Vendedor / Registró', 'Origen'].forEach((v, i) => { wsV.getCell(1, i + 1).value = v; });
  headerRow(wsV.getRow(1));
  movs.slice().sort((a, b) => b.fecha - a.fecha).forEach((m, i) => {
    const row = wsV.getRow(i + 2);
    row.getCell(1).value = m.fecha.toLocaleDateString('es-HN');
    row.getCell(2).value = m.tipo === 'ingreso' ? 'Ingreso' : 'Egreso';
    row.getCell(3).value = m.concepto || '—';
    row.getCell(4).value = m.banco || '—';
    row.getCell(5).value = m.monto; row.getCell(5).numFmt = MONEY_FMT;
    row.getCell(6).value = m.plataforma ? platformLabel(m.plataforma) : '';
    row.getCell(7).value = m.detalle || '';
    row.getCell(8).value = m.cliente || '';
    row.getCell(9).value = m.vendedor || '';
    row.getCell(10).value = m.fuente === 'finanzas' ? 'Histórico' : (m.fuente === 'finanzas_movimientos' ? 'Actual' : '');
    row.getCell(2).font = { bold: true, color: { argb: m.tipo === 'ingreso' ? C.green : C.red } };
    zebra(row, i + 2);
  });
  wsV.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: 10 } };
  if (cierre) {
    const wsC = wb.addWorksheet('Cierre del mes', { views: [{ state: 'frozen', ySplit: 1 }] });
    wsC.columns = [{ width: 30 }, { width: 20 }];
    wsC.getCell(1, 1).value = `Cierre del mes · ${cierre.mes}`; wsC.getCell(1, 2).value = 'Monto';
    headerRow(wsC.getRow(1));
    const filas = [
      ['Esperado este mes', cierre.esperado, true], ['Pendiente / vencido', cierre.pendiente, true], ['Mes pasado', cierre.anterior, true],
      ['vs mes pasado', cierre.deltaPct == null ? '—' : cierre.deltaPct / 100, false], ['Servicios que renuevan este mes', cierre.servicios, false],
    ];
    filas.forEach(([k, v, money], i) => {
      const row = wsC.getRow(i + 2); row.getCell(1).value = k; row.getCell(2).value = v;
      if (money) row.getCell(2).numFmt = MONEY_FMT; else if (k === 'vs mes pasado' && typeof v === 'number') row.getCell(2).numFmt = '+0%;-0%';
      row.getCell(1).font = { bold: true, color: { argb: C.navy } }; zebra(row, i + 2);
    });
    wsC.getCell(8, 1).value = 'Calculado por fechas de renovación. No incluye marca de pago.'; wsC.getCell(8, 1).font = { italic: true, color: { argb: 'FF6B7280' } };
  }
  return wb;
}
