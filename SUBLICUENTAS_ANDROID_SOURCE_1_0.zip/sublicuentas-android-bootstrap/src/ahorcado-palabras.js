// Banco controlado de palabras para Ahorcado PRO (respuesta en MAYÚSCULAS sin tildes; la Ñ se conserva).
const W = (cat, list) => list.map(([answer, clue, difficulty = 'MEDIUM'], i) => ({ id: `${cat.slice(0, 3).toLowerCase()}-${String(i + 1).padStart(2, '0')}`, answer, clue, category: cat, difficulty }));
export const HANGMAN_CATEGORIES = Object.freeze({
  TECNOLOGIA: { label: 'Tecnología', icon: '💻' }, STREAMING: { label: 'Streaming', icon: '📺' }, VIDEOJUEGOS: { label: 'Videojuegos', icon: '🎮' },
  MUSICA: { label: 'Música', icon: '🎵' }, ANIMALES: { label: 'Animales', icon: '🐾' }, OBJETOS: { label: 'Objetos', icon: '🧸' },
});
export const HANGMAN_WORDS = [
  ...W('TECNOLOGIA', [
    ['SERVIDOR', 'Computadora que atiende las peticiones de otras computadoras.'], ['API', 'Interfaz para conectar sistemas o aplicaciones.', 'EASY'], ['TECLADO', 'Tiene letras y sirve para escribir en la computadora.', 'EASY'],
    ['PANTALLA', 'Donde se ven las imágenes del teléfono o la computadora.', 'EASY'], ['ROUTER', 'Aparato que reparte el internet de la casa.'], ['CONTRASEÑA', 'Clave secreta para entrar a una cuenta.'],
    ['NUBE', 'Lugar en internet donde se guardan archivos.', 'EASY'], ['CARGADOR', 'Le devuelve la batería al celular.', 'EASY'], ['ALGORITMO', 'Serie de pasos para resolver un problema.', 'HARD'],
    ['BLUETOOTH', 'Conexión inalámbrica para audífonos y bocinas.', 'HARD'], ['PROGRAMADOR', 'Persona que escribe código.', 'HARD'], ['NAVEGADOR', 'Programa para abrir páginas web.'],
    ['CORREO', 'Mensaje electrónico con asunto y destinatario.', 'EASY'], ['DESCARGA', 'Bajar un archivo de internet al dispositivo.'], ['APLICACION', 'Programa que se instala en el celular.'],
    ['INTELIGENCIA', 'La artificial responde preguntas y crea textos.', 'HARD'], ['MOUSE', 'Se mueve con la mano para controlar el puntero.', 'EASY'], ['WIFI', 'Internet sin cables.', 'EASY'],
    ['ANTIVIRUS', 'Protege el equipo de programas maliciosos.'], ['BATERIA', 'Guarda la energía del teléfono.', 'EASY'], ['PIXEL', 'Punto más pequeño de una imagen digital.'],
  ]),
  ...W('STREAMING', [
    ['NETFLIX', 'Plataforma de streaming muy conocida.', 'EASY'], ['DISNEY', 'Plataforma con Marvel, Pixar y Star Wars.', 'EASY'], ['SPOTIFY', 'Plataforma verde para escuchar música.', 'EASY'],
    ['CRUNCHYROLL', 'Plataforma especializada en anime.', 'HARD'], ['PERFIL', 'Cada persona de la cuenta tiene el suyo.', 'EASY'], ['TEMPORADA', 'Grupo de episodios de una serie.'],
    ['EPISODIO', 'Cada capítulo de una serie.'], ['ESTRENO', 'Cuando una película sale por primera vez.'], ['SUBTITULOS', 'Texto abajo de la pantalla con lo que dicen.', 'HARD'],
    ['DOCUMENTAL', 'Película que cuenta hechos reales.'], ['PALOMITAS', 'Botana clásica para ver películas.'], ['TRAILER', 'Adelanto corto de una película.'],
    ['MARATON', 'Ver muchos capítulos seguidos.'], ['CANAL', 'Por donde se transmite un programa.', 'EASY'], ['PANTALLAS', 'Dispositivos al mismo tiempo que permite un plan.'],
    ['RENOVACION', 'Pago mensual para seguir con el servicio.', 'HARD'], ['SUSCRIPCION', 'Plan que se paga cada mes.', 'HARD'], ['ANIME', 'Animación japonesa.', 'EASY'],
    ['TELENOVELA', 'Historia dramática de muchos capítulos.', 'HARD'], ['CATALOGO', 'Lista de películas y series disponibles.'],
  ]),
  ...W('VIDEOJUEGOS', [
    ['CONSOLA', 'Aparato para jugar conectado al televisor.', 'EASY'], ['CONTROL', 'Se sostiene con las dos manos para jugar.', 'EASY'], ['NIVEL', 'Cada etapa de un juego.', 'EASY'],
    ['MINECRAFT', 'Juego de construir con bloques.'], ['FORTNITE', 'Battle royale con bailes famosos.'], ['MARIO', 'Plomero de gorra roja.', 'EASY'],
    ['JOYSTICK', 'Palanca para moverse en el juego.'], ['PUNTAJE', 'Números que ganás al jugar.'], ['VIDAS', 'Corazones que te quedan antes de perder.', 'EASY'],
    ['JEFE', 'Enemigo fuerte al final del nivel.', 'EASY'], ['MULTIJUGADOR', 'Modo para jugar con otras personas.', 'HARD'], ['AVATAR', 'Personaje que te representa.'],
    ['PLAYSTATION', 'Consola de Sony.', 'HARD'], ['ARCADE', 'Máquina de juegos con monedas.'], ['TROFEO', 'Premio al lograr un reto.'],
    ['PIKACHU', 'Pokémon amarillo eléctrico.'], ['TETRIS', 'Juego de piezas que caen.'], ['PARTIDA', 'Cada juego completo que jugás.'],
    ['RANKING', 'Tabla de los mejores jugadores.'], ['TUTORIAL', 'Guía que enseña a jugar.'],
  ]),
  ...W('MUSICA', [
    ['GUITARRA', 'Instrumento de seis cuerdas.', 'EASY'], ['BATERIA', 'Instrumento de tambores y platillos.'], ['CANCION', 'Música con letra.', 'EASY'],
    ['PLAYLIST', 'Lista de canciones guardadas.'], ['AUDIFONOS', 'Se ponen en los oídos para escuchar.'], ['MICROFONO', 'Sirve para cantar más fuerte.'],
    ['CONCIERTO', 'Presentación en vivo de un artista.'], ['REGGAETON', 'Género urbano muy bailado.'], ['PUNTA', 'Ritmo garífuna de Honduras.', 'EASY'],
    ['MARIMBA', 'Instrumento de teclas de madera.'], ['PIANO', 'Instrumento de teclas blancas y negras.', 'EASY'], ['VIOLIN', 'Instrumento de cuerdas que se toca con arco.'],
    ['CORO', 'Grupo de personas que canta.', 'EASY'], ['RITMO', 'Lo que marca el compás de la música.', 'EASY'], ['ALBUM', 'Colección de canciones de un artista.', 'EASY'],
    ['BACHATA', 'Género romántico dominicano.'], ['SALSA', 'Género para bailar en pareja.', 'EASY'], ['TROMPETA', 'Instrumento de metal que se sopla.'],
    ['KARAOKE', 'Cantar con la letra en pantalla.'], ['BOCINA', 'Aparato que hace sonar la música fuerte.'],
  ]),
  ...W('ANIMALES', [
    ['JAGUAR', 'Felino manchado de la selva.', 'EASY'], ['GUACAMAYA', 'Ave nacional de Honduras, de muchos colores.', 'HARD'], ['DELFIN', 'Mamífero marino muy inteligente.'],
    ['TORTUGA', 'Animal lento con caparazón.'], ['ELEFANTE', 'Animal enorme con trompa.'], ['JIRAFA', 'Animal de cuello muy largo.', 'EASY'],
    ['PINGUINO', 'Ave que no vuela y vive en el frío.'], ['MARIPOSA', 'Insecto de alas de colores.'], ['CANGURO', 'Salta y lleva a su cría en una bolsa.'],
    ['VENADO', 'Animal nacional de Honduras.', 'EASY'], ['IGUANA', 'Reptil verde que toma el sol.', 'EASY'], ['TIBURON', 'Pez grande con muchos dientes.'],
    ['COCODRILO', 'Reptil grande de río.', 'HARD'], ['PANDA', 'Oso blanco y negro que come bambú.', 'EASY'], ['ARDILLA', 'Roedor que guarda nueces.'],
    ['BUHO', 'Ave que sale de noche.', 'EASY'], ['CAMALEON', 'Cambia de color.', 'HARD'], ['PULPO', 'Tiene ocho brazos.', 'EASY'],
    ['LEON', 'El rey de la selva.', 'EASY'], ['COLIBRI', 'Ave pequeñita que aletea muy rápido.'],
  ]),
  ...W('OBJETOS', [
    ['PARAGUAS', 'Te protege de la lluvia.'], ['MOCHILA', 'Se lleva en la espalda.'], ['LAMPARA', 'Da luz en la mesa.'],
    ['RELOJ', 'Marca la hora.', 'EASY'], ['ESPEJO', 'Refleja tu imagen.', 'EASY'], ['TIJERAS', 'Sirven para cortar papel.'],
    ['CUADERNO', 'Tiene hojas para escribir.'], ['BOTELLA', 'Guarda agua u otras bebidas.'], ['LLAVERO', 'Mantiene juntas las llaves.'],
    ['ALMOHADA', 'Donde se pone la cabeza al dormir.'], ['CEPILLO', 'Se usa para los dientes o el pelo.'], ['VENTILADOR', 'Da aire cuando hace calor.', 'HARD'],
    ['HAMACA', 'Cama colgante para descansar.', 'EASY'], ['SARTEN', 'Se usa para freír en la cocina.'], ['CUCHARA', 'Cubierto para la sopa.'],
    ['BILLETERA', 'Donde se guarda el dinero.', 'HARD'], ['LENTES', 'Ayudan a ver mejor.', 'EASY'], ['GORRA', 'Protege la cabeza del sol.', 'EASY'],
    ['CALENDARIO', 'Muestra los días del mes.', 'HARD'], ['LINTERNA', 'Luz portátil para la oscuridad.'],
  ]),
];
