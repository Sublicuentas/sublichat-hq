// Bancos de palabras para El ahorcado y Sopa de letras (mismas categorías que pide la especificación:
// tecnología, ciencia, historia, cine). Contenido general de cultura, sin datos sensibles.
export const CATEGORIES = Object.freeze({
  TECNOLOGIA: '💻 Tecnología', CIENCIA: '🧪 Ciencia', HISTORIA: '🏛️ Historia', CINE: '🎬 Cine',
});

export const HANGMAN_WORDS = Object.freeze([
  { word: 'INTERNET', category: 'TECNOLOGIA', clue: 'Red global que conecta millones de dispositivos en todo el mundo.' },
  { word: 'ALGORITMO', category: 'TECNOLOGIA', clue: 'Serie de pasos para resolver un problema o realizar una tarea.' },
  { word: 'SERVIDOR', category: 'TECNOLOGIA', clue: 'Computadora que atiende las peticiones de otras computadoras.' },
  { word: 'SOFTWARE', category: 'TECNOLOGIA', clue: 'Programas e instrucciones que hacen funcionar un dispositivo.' },
  { word: 'BLUETOOTH', category: 'TECNOLOGIA', clue: 'Tecnología para conectar dispositivos sin cables a corta distancia.' },
  { word: 'CONTRASENA', category: 'TECNOLOGIA', clue: 'Palabra secreta que protege el acceso a una cuenta.' },
  { word: 'GALAXIA', category: 'CIENCIA', clue: 'Conjunto enorme de estrellas, planetas y polvo cósmico.' },
  { word: 'NEURONA', category: 'CIENCIA', clue: 'Célula que transmite información en el sistema nervioso.' },
  { word: 'OXIGENO', category: 'CIENCIA', clue: 'Gas esencial para la respiración de la mayoría de los seres vivos.' },
  { word: 'GRAVEDAD', category: 'CIENCIA', clue: 'Fuerza que atrae los objetos hacia el centro de la Tierra.' },
  { word: 'VACUNA', category: 'CIENCIA', clue: 'Preparado que ayuda al cuerpo a defenderse de una enfermedad.' },
  { word: 'FOTOSINTESIS', category: 'CIENCIA', clue: 'Proceso con el que las plantas convierten luz en energía.' },
  { word: 'IMPERIO', category: 'HISTORIA', clue: 'Territorio muy extenso gobernado por un solo poder central.' },
  { word: 'REVOLUCION', category: 'HISTORIA', clue: 'Cambio profundo y a veces violento en el orden de una sociedad.' },
  { word: 'PIRAMIDE', category: 'HISTORIA', clue: 'Construcción antigua de base cuadrada usada como tumba real.' },
  { word: 'CIVILIZACION', category: 'HISTORIA', clue: 'Conjunto de costumbres, ciencia y arte de un pueblo avanzado.' },
  { word: 'INDEPENDENCIA', category: 'HISTORIA', clue: 'Momento en que un territorio deja de depender de otro poder.' },
  { word: 'CONQUISTA', category: 'HISTORIA', clue: 'Toma de un territorio por la fuerza de las armas.' },
  { word: 'PELICULA', category: 'CINE', clue: 'Obra audiovisual que se proyecta en una sala o pantalla.' },
  { word: 'DIRECTOR', category: 'CINE', clue: 'Persona a cargo de guiar la realización de una obra audiovisual.' },
  { word: 'GUION', category: 'CINE', clue: 'Texto que describe diálogos y escenas de una producción.' },
  { word: 'ESTRENO', category: 'CINE', clue: 'Primera vez que se presenta una obra al público.' },
  { word: 'ANIMACION', category: 'CINE', clue: 'Técnica que da movimiento a dibujos o modelos digitales.' },
  { word: 'PROTAGONISTA', category: 'CINE', clue: 'Personaje principal alrededor del cual gira la historia.' },
]);

export const WORDSEARCH_SETS = Object.freeze([
  { id: 'mix_01', words: [
    { word: 'CINE', category: 'CINE' }, { word: 'PELICULA', category: 'CINE' }, { word: 'DIRECTOR', category: 'CINE' },
    { word: 'TECNOLOGIA', category: 'TECNOLOGIA' }, { word: 'ROBOTICA', category: 'TECNOLOGIA' }, { word: 'INTERNET', category: 'TECNOLOGIA' },
    { word: 'CIVILIZACION', category: 'HISTORIA' }, { word: 'IMPERIO', category: 'HISTORIA' }, { word: 'REVOLUCION', category: 'HISTORIA' },
    { word: 'GALAXIA', category: 'CIENCIA' }, { word: 'NEURONA', category: 'CIENCIA' }, { word: 'CUANTICA', category: 'CIENCIA' },
  ] },
  { id: 'mix_02', words: [
    { word: 'GUION', category: 'CINE' }, { word: 'ESTRENO', category: 'CINE' }, { word: 'ANIMACION', category: 'CINE' },
    { word: 'SOFTWARE', category: 'TECNOLOGIA' }, { word: 'SERVIDOR', category: 'TECNOLOGIA' }, { word: 'ALGORITMO', category: 'TECNOLOGIA' },
    { word: 'PIRAMIDE', category: 'HISTORIA' }, { word: 'CONQUISTA', category: 'HISTORIA' }, { word: 'IMPERIO', category: 'HISTORIA' },
    { word: 'OXIGENO', category: 'CIENCIA' }, { word: 'GRAVEDAD', category: 'CIENCIA' }, { word: 'VACUNA', category: 'CIENCIA' },
  ] },
]);

// Símbolos de las cartas de Pares (coinciden con el mockup: corazón, diamante, pica, corona y el logo "S").
export const MEMORY_SYMBOLS = Object.freeze(['heart', 'diamond', 'spade', 'crown', 'club', 'star', 'moon', 'bolt', 'gift', 'ring', 'gem', 'flag']);
