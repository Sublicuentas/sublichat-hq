// Dardos PRO (R59) · según "Sublichat - Dardos PRO v2": 301, 3 dardos por turno, lanzamiento a pulso con el dedo
// (pointer events), puntaje por el punto REAL de impacto (sin sorteo), bust restaura el turno, llegar a 0 exacto gana.
// Motor puro (sin DOM) + pintura del tablero SVG + control del gesto.

/* ─────────── A) tablero y scoring determinista ─────────── */
export const DART_NUMBERS = [20, 1, 18, 4, 13, 6, 10, 15, 2, 17, 3, 19, 7, 16, 8, 11, 14, 9, 12, 5];
export const DART_R = Object.freeze({ bull: 0.03735, outerBull: 0.09353, tripleIn: 0.58235, tripleOut: 0.62941, doubleIn: 0.95294, doubleOut: 1 });

// Recibe el impacto normalizado respecto al centro (1 = borde exterior del doble). Igual que calculateDartScore del PDF.
export function scoreAtNormalized(nx, ny) {
  const x = Number(nx) || 0, y = Number(ny) || 0;
  const r = Math.sqrt(x * x + y * y);
  const hit = (number, multiplier, score, zone) => ({ number, multiplier, score, zone, normalizedX: x, normalizedY: y });
  if (r > DART_R.doubleOut) return hit(0, 0, 0, 'MISS');
  if (r <= DART_R.bull) return hit(50, 1, 50, 'BULL');
  if (r <= DART_R.outerBull) return hit(25, 1, 25, 'OUTER_BULL');
  let angle = Math.atan2(x, -y) * 180 / Math.PI;
  if (angle < 0) angle += 360;
  const number = DART_NUMBERS[Math.floor((angle + 9) / 18) % 20];
  if (r >= DART_R.tripleIn && r <= DART_R.tripleOut) return hit(number, 3, number * 3, 'TRIPLE');
  if (r >= DART_R.doubleIn) return hit(number, 2, number * 2, 'DOUBLE');
  return hit(number, 1, number, 'SINGLE');
}
export function calculateDartScore(impactX, impactY, centerX, centerY, boardRadius) {
  return scoreAtNormalized((impactX - centerX) / boardRadius, (impactY - centerY) / boardRadius);
}
export function hitLabel(h) {
  if (!h || h.zone === 'MISS') return 'Fuera';
  if (h.zone === 'BULL') return 'Bull 50';
  if (h.zone === 'OUTER_BULL') return 'Bull 25';
  return `${h.zone === 'TRIPLE' ? 'T' : h.zone === 'DOUBLE' ? 'D' : ''}${h.number}`;
}

/* ─────────── C) reglas 301, bust y turnos ─────────── */
export const DARTS_MODE = 301, DARTS_MAX_ROUNDS = 12, DARTS_TIME_MS = 120000; // R62: 2 minutos para cerrar el 301
export function dartsGameCreate({ userId = 'yo', displayName = 'Jugador', mode = DARTS_MODE, maxRounds = DARTS_MAX_ROUNDS, timeLimitMs = DARTS_TIME_MS } = {}) {
  return { timeLimitMs, timeUp: false, id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`, mode, status: 'PLAYING', players: [{ userId, displayName, remaining: mode }],
    currentPlayerIndex: 0, dartsLeft: 3, round: 1, maxRounds, turnStartScore: mode, winnerUserId: null, currentTurnThrows: [], lastTurnThrows: [],
    allThrows: [], lastHit: null, lastBust: false, bestTurnScore: 0, startedAt: Date.now(), finishedAt: null };
}
function advanceTurn(g) {
  const turnScore = g.turnStartScore - g.players[g.currentPlayerIndex].remaining;
  g.bestTurnScore = Math.max(g.bestTurnScore, turnScore);
  g.lastTurnThrows = g.currentTurnThrows;
  g.currentPlayerIndex = (g.currentPlayerIndex + 1) % g.players.length;
  g.dartsLeft = 3; g.currentTurnThrows = [];
  g.turnStartScore = g.players[g.currentPlayerIndex].remaining;
  if (g.currentPlayerIndex === 0) g.round += 1;
  if (g.round > g.maxRounds) { g.round = g.maxRounds; g.status = 'FINISHED'; g.finishedAt = Date.now(); } // se acabaron las rondas: partida completada sin ganar
  return g;
}
export function applyHit(game, hit) {
  if (!game || game.status !== 'PLAYING' || !hit) return game;
  const g = { ...game, players: game.players.map(p => ({ ...p })), currentTurnThrows: [...game.currentTurnThrows], allThrows: [...game.allThrows] };
  const player = g.players[g.currentPlayerIndex];
  const candidate = player.remaining - hit.score;
  const entry = { ...hit, round: g.round, dartIndex: 4 - g.dartsLeft, bust: candidate < 0 };
  g.currentTurnThrows.push(entry); g.allThrows.push(entry); g.lastHit = entry; g.lastBust = candidate < 0;
  if (candidate < 0) { player.remaining = g.turnStartScore; return advanceTurn(g); }
  if (candidate === 0) {
    player.remaining = 0; g.status = 'FINISHED'; g.winnerUserId = player.userId; g.dartsLeft = 0; g.finishedAt = Date.now();
    g.bestTurnScore = Math.max(g.bestTurnScore, g.turnStartScore); g.lastTurnThrows = g.currentTurnThrows;
    return g;
  }
  player.remaining = candidate;
  g.dartsLeft = Math.max(0, g.dartsLeft - 1);
  return g.dartsLeft === 0 ? advanceTurn(g) : g;
}
// Contador regresivo: si no cierra el 301 a tiempo, pierde (la partida termina sin ganar).
export function dartsTimeLeft(g, now = Date.now()) { return Math.max(0, (g.timeLimitMs || DARTS_TIME_MS) - (now - g.startedAt)); }
export function dartsTimeUp(g, now = Date.now()) { return g.status !== 'PLAYING' ? g : { ...g, status: 'FINISHED', timeUp: true, finishedAt: now, lastTurnThrows: g.currentTurnThrows.length ? g.currentTurnThrows : g.lastTurnThrows }; }
// Métricas para api/juegos.js: el servidor recibe SOLO las coordenadas normalizadas y recalcula todo (antitrampa).
export function dartsGameSubmission(g) {
  const throws = g.allThrows.map(t => ({ nx: Math.round(t.normalizedX * 10000) / 10000, ny: Math.round(t.normalizedY * 10000) / 10000 }));
  const valid = g.allThrows.filter(t => t.zone !== 'MISS');
  return {
    throws, mode: g.mode, maxRounds: g.maxRounds, elapsedMs: Math.round((g.finishedAt || Date.now()) - g.startedAt), timeLimitMs: g.timeLimitMs || DARTS_TIME_MS, timeUp: g.timeUp === true,
    // compatibilidad con la versión anterior del servidor (la nueva las ignora y recalcula desde "throws")
    finished: g.winnerUserId != null, dartsUsed: g.allThrows.length,
    avgAccuracy: g.allThrows.length ? Math.round(valid.length / g.allThrows.length * 100) : 0,
    bonusHits: g.allThrows.filter(t => t.zone === 'BULL' || (t.zone === 'TRIPLE' && t.number === 20)).length,
  };
}

/* ─────────── B) gesto de lanzamiento (Pointer Events) ─────────── */
export function calculateThrowVector(samples = []) {
  if (samples.length < 2) return { valid: false, velocityX: 0, velocityY: 0, speed: 0 };
  const recent = samples.slice(-5);
  const first = recent[0], last = recent[recent.length - 1];
  const dt = Math.max(last.time - first.time, 1);
  const vx = (last.x - first.x) / dt, vy = (last.y - first.y) / dt;
  const speed = Math.sqrt(vx * vx + vy * vy);
  return { valid: vy < -0.25 && speed >= 0.30, velocityX: vx, velocityY: vy, speed };
}
// Proyección del impacto: el vuelo sigue la dirección del gesto. La distancia depende de la FUERZA:
// a la velocidad ideal (IDEAL_SPEED px/ms) el dardo llega a la altura del centro; más fuerte = más arriba, más suave = más abajo.
export const IDEAL_SPEED = 2.0;
export function calculateProjectedImpact(releaseX, releaseY, vector, boardCenterY) {
  const reach = Math.max(1, releaseY - boardCenterY);
  const up = Math.max(0.05, -vector.velocityY);
  // Raíz cuadrada: la fuerza sí cambia la altura, pero sin volverse incontrolable en un dedo real.
  const dist = reach * Math.sqrt(up / IDEAL_SPEED);
  return { x: releaseX + (vector.velocityX / up) * dist, y: releaseY - dist };
}

/* ─────────── tablero SVG (viewBox -120..120, radio del doble = 100) ─────────── */
let boardCache = '';
export function dartBoardSvgInner() {
  if (boardCache) return boardCache;
  const R = 100, pt = (r, deg) => { const a = (deg - 90) * Math.PI / 180; return `${(r * Math.cos(a)).toFixed(2)} ${(r * Math.sin(a)).toFixed(2)}`; };
  const wedge = (r0, r1, a0, a1) => `M${pt(r0, a0)}L${pt(r1, a0)}A${r1} ${r1} 0 0 1 ${pt(r1, a1)}L${pt(r0, a1)}A${r0} ${r0} 0 0 0 ${pt(r0, a0)}Z`;
  const rr = k => DART_R[k] * R;
  let out = `<circle r="119" fill="#141414"/><circle r="119" fill="none" stroke="#e2231a" stroke-width="3"/><circle r="${R + 1.2}" fill="#101010"/>`;
  DART_NUMBERS.forEach((n, i) => {
    const a0 = i * 18 - 9, a1 = i * 18 + 9, dark = i % 2 === 0;
    const single = dark ? '#161616' : '#f3e7c9', ring = dark ? '#e2231a' : '#1f9d4c';
    out += `<path d="${wedge(rr('outerBull'), rr('tripleIn'), a0, a1)}" fill="${single}"/>`;
    out += `<path d="${wedge(rr('tripleIn'), rr('tripleOut'), a0, a1)}" fill="${ring}"/>`;
    out += `<path d="${wedge(rr('tripleOut'), rr('doubleIn'), a0, a1)}" fill="${single}"/>`;
    out += `<path d="${wedge(rr('doubleIn'), R, a0, a1)}" fill="${ring}"/>`;
    const [tx, ty] = pt(110, i * 18).split(' ');
    out += `<text x="${tx}" y="${ty}" dy="4" text-anchor="middle" font-size="11.5" font-weight="900" fill="#fff" transform="rotate(${i * 18} ${tx} ${ty})">${n}</text>`;
  });
  for (let i = 0; i < 20; i++) out += `<path d="M${pt(rr('outerBull'), i * 18 - 9)}L${pt(R, i * 18 - 9)}" stroke="#b8b8b8" stroke-width=".4"/>`;
  out += `<circle r="${rr('outerBull')}" fill="#1f9d4c" stroke="#b8b8b8" stroke-width=".4"/><circle r="${rr('bull')}" fill="#e2231a" stroke="#b8b8b8" stroke-width=".4"/>`;
  return (boardCache = out);
}
export function embeddedDartSvg(nx, ny, id = '') {
  const x = (nx * 100).toFixed(1), y = (ny * 100).toFixed(1);
  return `<g class="dt-emb" ${id ? `id="${id}"` : ''} transform="translate(${x} ${y})"><path d="M0 0L-1.4 -22H1.4Z" fill="#8a6a1c"/><path d="M0 -20L-7 -31L-2 -29L0 -33L2 -29L7 -31Z" fill="#ffc21a" stroke="#b07c00" stroke-width=".6"/><circle r="1.6" fill="#222"/></g>`;
}

/* ─────────── pantalla (misma línea visual de la referencia) ─────────── */
const fmtClockMs = ms => { const t = Math.ceil(ms / 1000); return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`; };
const escH = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DART_ICON = '<svg viewBox="0 0 40 40" width="30" height="30"><path d="M6 34L24 16" stroke="#8a6a1c" stroke-width="2.4" stroke-linecap="round"/><path d="M22 18L30 6L33 9L34 14L22 18Z" fill="#ffc21a" stroke="#b07c00" stroke-width="1"/><path d="M22 18L34 10L31 7Z" fill="#ffd95a"/></svg>';
const ACTIVE_DART = '<svg viewBox="0 0 60 200" width="50" height="160" aria-hidden="true"><path d="M30 0L27 44H33Z" fill="#5d6570"/><rect x="25" y="44" width="10" height="62" rx="4" fill="#c99a2e"/><g stroke="#8a6a1c" stroke-width="1.2">'
  + Array.from({ length: 9 }, (_, i) => `<path d="M25 ${50 + i * 6}H35"/>`).join('') + '</g><rect x="26" y="106" width="8" height="26" rx="3" fill="#1b1b1b"/><path d="M30 128L6 186L30 176L54 186Z" fill="#ffc21a" stroke="#b07c00" stroke-width="1.5"/><path d="M30 128V198" stroke="#e0a800" stroke-width="3"/></svg>';

export function dartsProScreenHtml({ game, totalSP = 0, message = '' } = {}) {
  const g = game, me = g.players[0];
  const showThrows = g.currentTurnThrows.length ? g.currentTurnThrows : (g.status === 'FINISHED' ? g.lastTurnThrows : (Date.now() < (g._showPrevUntil || 0) ? g.lastTurnThrows : []));
  const embedded = showThrows.filter(t => t.zone !== 'MISS').map(t => embeddedDartSvg(t.normalizedX, t.normalizedY)).join('');
  const slots = [0, 1, 2].map(i => { const t = showThrows[i]; return `<div class="dt-slot ${t ? 'on' : ''}">${DART_ICON}<b>${t ? escH(t.bust ? 'BUST' : String(t.score)) : '—'}</b></div>`; }).join('');
  const last = g.lastHit;
  const lastBadge = !last ? '' : last.bust ? '<em class="bust">Bust</em>' : last.score ? `<em>+${last.score}</em>` : '';
  const won = g.status === 'FINISHED' && g.winnerUserId != null;
  const finishPanel = g.status === 'FINISHED' ? `<section class="dt-finish ${won ? 'won' : ''}"><b>${won ? `¡Cerró el 301 en ${g.allThrows.length} dardos! 🎯` : g.timeUp ? '⏱ ¡Se acabó el tiempo! Perdió' : 'Se terminaron las rondas'}</b><span>${won ? 'Guarde su partida para sumar SP al total global.' : `Le quedaron ${me.remaining} puntos. Puede guardar y sumar algunos SP por sus aciertos, o intentar otra vez.`}</span>
      <div class="dt-finish-actions"><button type="button" class="dt-btn ghost" id="jgRestart">↻ Otra partida</button><button type="button" class="dt-btn" id="jgFinish">Guardar y sumar SP</button></div></section>` : '';
  return `<section class="jg-page dt-page">
    <header class="dt-top"><button type="button" class="dt-back" id="jgQuit" aria-label="Salir">←</button>
      <h1><svg viewBox="-120 -120 240 240" width="34" height="34">${dartBoardSvgInner()}</svg>Dardos <em>PRO</em></h1>
      <span class="dt-sp"><i>★</i>${Number(totalSP || 0).toLocaleString('en-US')} <b>SP</b></span></header>
    <div class="dt-scorebar"><div class="dt-score"><b>${me.remaining}</b><small>DE ${g.mode} · RONDA ${g.round}/${g.maxRounds}</small></div><div class="dt-clock ${dartsTimeLeft(g) <= 20000 && g.status === 'PLAYING' ? 'low' : ''}"><small>TIEMPO</small><b id="dtTimer">${fmtClockMs(g.status === 'PLAYING' ? dartsTimeLeft(g) : Math.max(0, (g.timeLimitMs || DARTS_TIME_MS) - ((g.finishedAt || Date.now()) - g.startedAt)))}</b></div></div>
    <div class="dt-stage">
      <svg id="dtBoard" class="dt-board" viewBox="-120 -120 240 240" role="img" aria-label="Tablero de dardos">${dartBoardSvgInner()}<g id="dtEmbedded">${embedded}</g></svg>
      <aside class="dt-turn" aria-label="Dardos del turno">${slots}</aside>
    </div>
    <div class="dt-cards"><div class="dt-card"><small>Último tiro</small><b>${last ? escH(hitLabel(last)) : '—'}</b>${lastBadge}</div><div class="dt-card"><small>Puntos restantes</small><b class="red">${me.remaining}</b></div></div>
    ${finishPanel || `<div class="dt-throwzone" id="dtThrowZone"><div class="dt-chev" aria-hidden="true"><i></i><i></i></div><div class="dt-active" id="dtActive">${ACTIVE_DART}</div>
      <p class="dt-hint" id="dtHint">${escH(message || 'Arrastre el dardo y suéltelo hacia arriba. Cierre el 301 en 0 exacto antes de que acabe el tiempo.')}</p></div>`}
  </section>`;
}

/* ─────────── control del gesto + vuelo ─────────── */
export function attachDartsControls({ onHit, onInvalid, isBlocked = () => false } = {}) {
  const zone = document.getElementById('dtThrowZone'), dart = document.getElementById('dtActive'), board = document.getElementById('dtBoard');
  if (!zone || !dart || !board) return () => {};
  let samples = [], active = false, start = null, flying = false;
  const tip = () => { const r = dart.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + 4 }; };
  const down = e => {
    if (flying || isBlocked()) return;
    active = true; start = { x: e.clientX, y: e.clientY };
    samples = [{ x: e.clientX, y: e.clientY, time: performance.now() }];
    try { zone.setPointerCapture(e.pointerId); } catch (_) {}
    dart.classList.add('grab'); e.preventDefault();
  };
  const move = e => {
    if (!active) return;
    samples.push({ x: e.clientX, y: e.clientY, time: performance.now() }); if (samples.length > 12) samples.shift();
    dart.style.transform = `translate(${e.clientX - start.x}px, ${Math.min(40, e.clientY - start.y)}px)`;
  };
  const up = e => {
    if (!active) return; active = false; dart.classList.remove('grab');
    samples.push({ x: e.clientX, y: e.clientY, time: performance.now() });
    const vector = calculateThrowVector(samples);
    const release = tip();
    if (!vector.valid) { dart.style.transform = ''; onInvalid?.(); return; }
    const br = board.getBoundingClientRect();
    const cx = br.left + br.width / 2, cy = br.top + br.height / 2, radius = br.width / 2 * (100 / 120);
    const impact = calculateProjectedImpact(release.x, release.y, vector, cy);
    const hit = calculateDartScore(impact.x, impact.y, cx, cy, radius);
    // Vuelo: un dardo fijo sale del punto de suelta y viaja al punto de impacto (220-320 ms).
    flying = true; dart.style.visibility = 'hidden'; dart.style.transform = '';
    const fly = document.createElement('div'); fly.className = 'dt-fly'; fly.innerHTML = ACTIVE_DART;
    fly.style.left = `${release.x - 25}px`; fly.style.top = `${release.y}px`;
    document.body.appendChild(fly);
    const ms = Math.round(Math.max(220, Math.min(320, 600 / Math.max(vector.speed, 0.5))));
    requestAnimationFrame(() => { fly.style.transition = `transform ${ms}ms cubic-bezier(.2,.7,.3,1)`; fly.style.transform = `translate(${impact.x - release.x}px, ${impact.y - release.y}px) scale(.32)`; });
    setTimeout(() => { fly.remove(); flying = false; onHit?.(hit); }, ms + 20);
  };
  const cancel = () => { if (!active) return; active = false; dart.classList.remove('grab'); dart.style.transform = ''; };
  zone.addEventListener('pointerdown', down); zone.addEventListener('pointermove', move); zone.addEventListener('pointerup', up); zone.addEventListener('pointercancel', cancel);
  return () => { zone.removeEventListener('pointerdown', down); zone.removeEventListener('pointermove', move); zone.removeEventListener('pointerup', up); zone.removeEventListener('pointercancel', cancel); };
}
