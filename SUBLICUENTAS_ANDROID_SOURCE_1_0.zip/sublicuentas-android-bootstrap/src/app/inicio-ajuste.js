// R121 · Inicio: aire fijo entre el último módulo ("Tickets y avisos") y la barra inferior.
// Regla del pedido: NO se rediseña nada y NADA cambia de tamaño (ni los 3 cuadros, ni el robot, ni el logo,
// ni las tarjetas de Herramientas). El aire sale únicamente de los espacios en blanco entre bloques.
// Sin importaciones a propósito: así se puede probar sola (core.js lee import.meta.env).
export const AIRE_INICIO = 28;   // dp entre "Tickets y avisos" y la barra (el pedido: 24–32)
export const ZOOM_MIN_INICIO = 0.68;
const entre = (v, min, max) => Math.max(min, Math.min(max, v));

// La escala que Inicio YA usaba cuando el contenido no cabe. Se conserva igual: así nada crece ni se achica.
export function zoomBaseInicio(top, limite, fondo) {
  if (!(fondo > limite + 2) || !(fondo > top)) return 1;
  return entre((limite - top) / (fondo - top), ZOOM_MIN_INICIO, 1);
}
// Cuánto hay que acortar los márgenes (0 = nada, 1 = al mínimo) para que el contenido termine en "objetivo".
// fondoSuelto / fondoApretado = dónde termina el contenido con los márgenes normales / al mínimo.
export function apretarNecesario(fondoSuelto, fondoApretado, objetivo) {
  if (fondoSuelto <= objetivo) return 0;
  const flexible = fondoSuelto - fondoApretado;
  if (!(flexible > 0)) return 1;
  return Math.min(1, Math.ceil(((fondoSuelto - objetivo) / flexible) * 1000) / 1000);
}

function medirYAjustar(shell, nav, win) {
  if (!shell) return null;
  const apretar = v => shell.style.setProperty('--inicio-apretar', String(v));
  const escalar = z => { shell.style.zoom = z < 1 ? String(z) : ''; };
  escalar(1); apretar(0);
  const sy = Number(win.scrollY) || 0;
  const limite = nav ? nav.getBoundingClientRect().top + sy : win.innerHeight;
  const top = shell.getBoundingClientRect().top + sy;
  const fondoDe = () => Math.max(0, ...[...shell.children].map(k => k.getBoundingClientRect().bottom + sy));
  const objetivo = limite - AIRE_INICIO;
  const fondo = fondoDe();
  if (!(limite > top) || !(fondo > top) || fondo <= objetivo) return { zoom: 1, apretar: 0 }; // ya hay aire: no se toca nada
  // 1) Misma escala de siempre → mismos tamaños de siempre.
  let zoom = zoomBaseInicio(top, limite, fondo);
  escalar(zoom);
  // 2) El aire sale de los márgenes: se mide de verdad con los márgenes normales y al mínimo, y se toma lo justo.
  const suelto = fondoDe(); apretar(1); let apretado = fondoDe();
  const cuanto = apretarNecesario(suelto, apretado, objetivo);
  apretar(cuanto);
  // 3) Último recurso (pantallas muy bajitas): con los márgenes al mínimo todavía no cabe → se reduce un poco más.
  for (let i = 0; cuanto >= 1 && i < 4 && apretado > objetivo + 0.5 && zoom > ZOOM_MIN_INICIO; i++) {
    zoom = entre(zoom * (objetivo - top) / (apretado - top), ZOOM_MIN_INICIO, 1);
    escalar(zoom); apretado = fondoDe();
  }
  return { zoom, apretar: cuanto };
}

export function ajustarInicio(shell, nav, win = globalThis) {
  const r = medirYAjustar(shell, nav, win);
  // El logo, el robot o la letra pueden terminar de cargar un instante después y mover el alto: se vuelve a
  // medir cuando eso pasa, para que el aire quede exacto y no dependa de qué tan rápido cargó el teléfono.
  if (shell && !shell.__inicioVigila) {
    shell.__inicioVigila = true;
    const otraVez = () => { if (shell.isConnected) medirYAjustar(shell, win.document.querySelector('.bottom-nav') || nav, win); };
    shell.querySelectorAll('img').forEach(img => { if (!img.complete) img.addEventListener('load', otraVez, { once: true }); });
    try { win.document.fonts?.ready?.then(otraVez, () => {}); } catch (_) {}
  }
  return r;
}
