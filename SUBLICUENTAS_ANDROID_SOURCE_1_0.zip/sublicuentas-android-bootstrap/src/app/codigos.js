// R77 · Pantalla "Códigos": códigos de Netflix, Disney+, HBO Max, Prime, ViX, Universal+ y Spotify
// leídos del correo del hosting por Sublichat HQ (Vercel, /api/codigos) con la misma lógica del bot.
// Es un camino independiente de Telegram/Render: si el bot falla, los códigos siguen saliendo aquí.
// Los códigos NO se guardan en el teléfono: solo viven en pantalla mientras se usan.
import { buscarCodigo } from '../api.js';
import { platformLabel } from '../operations.js';
import { state, esc, allRows, cap, ui } from './core.js';

const MODOS = [['codigo', 'Código'], ['link', 'Link de clave'], ['hogar', 'Netflix Hogar']];
const PLAT_ICO = { netflix: '🎬', disney: '🏰', hbo: '🎞️', prime: '🎥', paramount: '💿', universal: '🌎', spotify: '🎵', vix: '📱', cuenta: '🔑' };
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function codigosState() {
  if (!state.codigos) state.codigos = { correo: '', modo: 'codigo', busy: false, resultado: null, error: '', recientes: [] };
  return state.codigos;
}
export function canCodigos() { return Boolean(cap().codigos); }

// Correos de las cuentas que ya están en Clientes (para sugerir mientras se escribe).
function correosConocidos() {
  const set = new Map();
  for (const r of allRows()) {
    const c = String(r.correo || '').trim().toLowerCase();
    if (c && EMAIL_RE.test(c) && !set.has(c)) set.set(c, platformLabel(r.plataforma));
  }
  return [...set.entries()].sort((a, b) => a[0].localeCompare(b[0])).slice(0, 400);
}
// Clientes que usan ese correo. Una cuenta de Netflix se comparte entre varios perfiles: si hay más de un
// cliente, NO se elige teléfono por su cuenta (WhatsApp se abre sin número y usted elige el contacto).
function clientesDeCorreo(correo) {
  const c = String(correo || '').trim().toLowerCase();
  const byClient = new Map();
  for (const r of allRows()) if (String(r.correo || '').trim().toLowerCase() === c) byClient.set(r.clienteId || `${r.nombre}|${r.telefono}`, r);
  return [...byClient.values()];
}
function clienteDeCorreo(correo) { const list = clientesDeCorreo(correo); return list.length === 1 ? list[0] : null; }
export function haceCuanto(ts, now = Date.now()) {
  const min = Math.floor((now - Number(ts || 0)) / 60000);
  if (!ts || min < 0) return '';
  if (min < 1) return 'hace menos de 1 min';
  if (min < 60) return `hace ${min} min`;
  const h = Math.floor(min / 60); return `hace ${h} h ${min % 60} min`;
}
// Mensaje para mandar al cliente por WhatsApp.
export function mensajeCodigo(r = {}) {
  if (r.tipo === 'codigo') return `🔑 Su código de *${r.plataformaNombre || 'la plataforma'}* es: *${r.codigo}*\n\nÚselo ahora; vence en pocos minutos.`;
  if (r.tipo === 'link') return `🔗 Enlace de *${r.plataformaNombre || 'la plataforma'}*:\n${r.link}`;
  return '';
}

export function resultadoHtml(r, { error = '' } = {}) {
  if (error) return `<div class="cod-result cod-error"><strong>No se pudo consultar</strong><span>${esc(error)}</span></div>`;
  if (!r) return '';
  const ico = PLAT_ICO[r.plataforma] || '🔑';
  const meta = `${r.asunto ? `<small class="cod-asunto">📨 ${esc(r.asunto)}</small>` : ''}${r.ts ? `<small class="cod-when">🕒 Llegó ${esc(haceCuanto(r.ts))}${r.fecha ? ` · ${esc(r.fecha)}` : ''}</small>` : ''}`;
  if (r.tipo === 'codigo') {
    return `<div class="cod-result cod-ok${r.repetido ? ' cod-warn' : ''}"><p class="cod-plat">${ico} ${esc(r.plataformaNombre || '')}${r.detalle ? ` · ${esc(r.detalle)}` : ''}</p>
      <div class="cod-code" aria-label="Código">${esc(r.codigo)}</div>${meta}
      ${r.repetido ? `<p class="cod-note">⏳ Este código ya se entregó antes y Disney+ todavía no manda otro. Pida <b>Reenviar código</b> en Disney y vuelva a buscar en unos segundos.</p>` : ''}
      <div class="cod-actions"><button type="button" class="primary" id="codCopy">Copiar código</button><button type="button" class="secondary" id="codWa">Enviar por WhatsApp</button></div></div>`;
  }
  if (r.tipo === 'link') {
    const titulo = r.motivo === 'hogar' ? 'Confirmar Netflix Hogar' : r.motivo === 'temporal' ? 'Código temporal de Netflix (en el enlace)' : 'Enlace para restablecer la clave';
    return `<div class="cod-result cod-ok"><p class="cod-plat">${ico} ${esc(r.plataformaNombre || '')}</p><strong class="cod-link-title">${esc(titulo)}</strong>${meta}
      <div class="cod-actions"><button type="button" class="primary" id="codOpen">Abrir enlace</button><button type="button" class="secondary" id="codCopyLink">Copiar enlace</button><button type="button" class="secondary" id="codWa">Enviar por WhatsApp</button></div></div>`;
  }
  const textos = {
    hogar_aviso: ['Es un correo de Netflix Hogar', 'Toque “Netflix Hogar” arriba y busque otra vez.'],
    ilegible: ['Llegó el correo de Disney+, pero no se pudo leer el código', 'No se muestra uno anterior para no darle un código vencido. Revíselo con /debug en el bot.'],
    sin_emails: ['No hay correos recientes para esta cuenta', 'Revise que el correo esté bien escrito o que la plataforma ya haya enviado el correo.'],
    sin_codigo: ['No hay un código reciente', 'Pida el código en la plataforma y vuelva a buscar en unos segundos.'],
    sin_link: ['No hay un enlace de restablecimiento reciente', 'Pida “Olvidé mi contraseña” en la plataforma y vuelva a buscar.'],
    sin_hogar: ['No hay un correo reciente de Netflix Hogar', 'Pida el código de Hogar en el televisor y vuelva a buscar.'],
  }[r.tipo] || ['Sin resultado', ''];
  return `<div class="cod-result cod-empty"><strong>${esc(textos[0])}</strong><span>${esc(textos[1])}</span></div>`;
}

export function codigosView() {
  const s = codigosState();
  if (!canCodigos()) return ui.subPage('Códigos', 'No disponible', '<div class="empty-state"><strong>Solo para Sublicuentas y Relojes</strong></div>');
  const opts = correosConocidos().map(([c, p]) => `<option value="${esc(c)}">${esc(p)}</option>`).join('');
  const chips = MODOS.map(([id, label]) => `<button type="button" class="cod-chip${s.modo === id ? ' on' : ''}" data-cod-modo="${id}">${esc(label)}</button>`).join('');
  const recientes = s.recientes.length ? `<div class="cod-recent"><small>Buscados hace poco</small>${s.recientes.map(c => `<button type="button" data-cod-reciente="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : '';
  const usados = s.resultado ? clientesDeCorreo(s.correo) : [];
  const cliente = usados.length === 1 ? usados[0] : null;
  return ui.subPage('Códigos', 'Del correo del hosting · respaldo de Telegram', `<section class="panel cod-panel">
      <label class="crm-field"><span>Correo de la cuenta</span><input id="codCorreo" type="email" inputmode="email" autocomplete="off" autocapitalize="off" spellcheck="false" list="codCorreos" placeholder="cuenta@sublicuentas.com" value="${esc(s.correo)}"><datalist id="codCorreos">${opts}</datalist></label>
      <div class="cod-chips">${chips}</div>
      <button type="button" class="primary cod-buscar" id="codBuscar" ${s.busy ? 'disabled' : ''}>${s.busy ? 'Leyendo el correo del hosting…' : 'Buscar'}</button>
      ${s.busy ? '<p class="muted cod-wait">Puede tardar hasta 15 segundos (Disney+ se revisa dos veces para no darle un código viejo).</p>' : ''}
      ${cliente ? `<p class="muted cod-cliente">Cliente: <b>${esc(cliente.nombre)}</b> · ${esc(platformLabel(cliente.plataforma))}</p>` : usados.length > 1 ? `<p class="muted cod-cliente">Cuenta compartida por <b>${usados.length} clientes</b>: al enviar por WhatsApp elija el contacto.</p>` : ''}
    </section>
    ${resultadoHtml(s.resultado, { error: s.error })}
    ${recientes}
    <p class="muted cod-privacy">🔒 Los códigos no se guardan en el teléfono. Cada consulta queda registrada en la bitácora (sin el código).</p>`);
}

export async function runCodigos(correoIn, modoIn) {
  const s = codigosState();
  const correo = String(correoIn ?? s.correo).trim().toLowerCase();
  const modo = modoIn || s.modo;
  s.correo = correo; s.modo = modo;
  if (!EMAIL_RE.test(correo)) { s.error = 'Escriba un correo válido.'; s.resultado = null; ui.render(); return; }
  if (s.busy) return;
  s.busy = true; s.error = ''; s.resultado = null; ui.render();
  try {
    const out = await buscarCodigo(correo, modo);
    s.resultado = out?.resultado || null;
    s.recientes = [correo, ...s.recientes.filter(c => c !== correo)].slice(0, 5);
  } catch (e) {
    s.error = String(e?.message || 'No se pudo consultar.');
  } finally { s.busy = false; ui.render(); }
}

// Abrir Códigos ya con el correo de una cuenta (desde Clientes) y buscar de una vez.
export function openCodigosFor(correo) {
  const s = codigosState();
  state.active = 'mas'; state.subview = 'codigos';
  s.correo = String(correo || '').trim().toLowerCase(); s.modo = 'codigo'; s.resultado = null; s.error = '';
  ui.render();
  if (EMAIL_RE.test(s.correo)) runCodigos(s.correo, 'codigo');
}

export function bindCodigos() {
  if (state.subview !== 'codigos') return;
  const s = codigosState();
  const input = document.querySelector('#codCorreo');
  input?.addEventListener('input', () => { s.correo = input.value; });
  input?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); runCodigos(input.value); } });
  document.querySelector('#codBuscar')?.addEventListener('click', () => runCodigos(input?.value));
  document.querySelectorAll('[data-cod-modo]').forEach(b => b.addEventListener('click', () => { s.modo = b.dataset.codModo; s.correo = input?.value ?? s.correo; s.resultado = null; s.error = ''; ui.render(); }));
  document.querySelectorAll('[data-cod-reciente]').forEach(b => b.addEventListener('click', () => runCodigos(b.dataset.codReciente)));
  const r = s.resultado;
  document.querySelector('#codCopy')?.addEventListener('click', () => ui.copy(r?.codigo, 'Código copiado.'));
  document.querySelector('#codCopyLink')?.addEventListener('click', () => ui.copy(r?.link, 'Enlace copiado.'));
  document.querySelector('#codOpen')?.addEventListener('click', () => ui.openLink(r?.link));
  document.querySelector('#codWa')?.addEventListener('click', () => ui.whatsapp(mensajeCodigo(r), clienteDeCorreo(s.correo)?.telefono || ''));
}
