// R77 · Pantalla "Códigos": códigos de Netflix, Disney+, HBO Max, Prime, ViX, Universal+ y Spotify
// leídos del correo del hosting por Sublichat HQ (Vercel, /api/codigos) con la misma lógica del bot.
// Es un camino independiente de Telegram/Render: si el bot falla, los códigos siguen saliendo aquí.
// Los códigos NO se guardan en el teléfono: solo viven en pantalla mientras se usan.
import { buscarCodigo } from '../api.js';
import { platformLabel } from '../operations.js';
import { state, esc, allRows, cap, ui } from './core.js';

const MODOS = [['codigo', 'Código'], ['link', 'Link de clave'], ['hogar', 'Netflix Hogar']];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function codigosState() {
  if (!state.codigos) state.codigos = { correo: '', modo: 'codigo', busy: false, resultado: null, error: '', recientes: [] };
  return state.codigos;
}
export function canCodigos() { return Boolean(cap().codigos); }

// Clientes que usan ese correo. Una cuenta de Netflix se comparte entre varios perfiles: si hay más de un
// cliente, NO se elige teléfono por su cuenta (WhatsApp se abre sin número y usted elige el contacto).
function clientesDeCorreo(correo) {
  const c = String(correo || '').trim().toLowerCase();
  const byClient = new Map();
  for (const r of allRows()) if (String(r.correo || '').trim().toLowerCase() === c) byClient.set(r.clienteId || `${r.nombre}|${r.telefono}`, r);
  return [...byClient.values()];
}
function clienteDeCorreo(correo) { const list = clientesDeCorreo(correo); return list.length === 1 ? list[0] : null; }
export function haceCuanto(ts, now = Date.now()) {
  const min = Math.floor((now - Number(ts || 0)) / 60000);
  if (!ts || min < 0) return '';
  if (min < 1) return 'hace menos de 1 min';
  if (min < 60) return `hace ${min} min`;
  const h = Math.floor(min / 60); return `hace ${h} h ${min % 60} min`;
}
// Mensaje para mandar al cliente por WhatsApp.
export function mensajeCodigo(r = {}) {
  if (r.tipo === 'codigo') return `🔑 Su código de *${r.plataformaNombre || 'la plataforma'}* es: *${r.codigo}*\n\nÚselo ahora; vence en pocos minutos.`;
  if (r.tipo === 'link') return `🔗 Enlace de *${r.plataformaNombre || 'la plataforma'}*:\n${r.link}`;
  return '';
}

// R78 · Diseño nuevo (mockup del dueño): íconos de línea, tarjeta de resultado con check verde,
// código grande agrupado, Fuente / Obtenido y recuadro "Importante".
const IC = {
  mail: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="m4 7 8 6 8-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  ticket: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v2a2.5 2.5 0 0 0 0 5v2a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 16.5v-2a2.5 2.5 0 0 0 0-5z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M9 10.5h6M9 13.5h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  link: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  tv: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 20h6M12 16v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  search: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="m16 16 4.5 4.5" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>',
  info: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="currentColor"/><path d="M12 11v6" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/><circle cx="12" cy="7.5" r="1.4" fill="#fff"/></svg>',
  check: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="currentColor"/><path d="m7 12.5 3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  copy: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M16 8V6.5A2.5 2.5 0 0 0 13.5 4h-7A2.5 2.5 0 0 0 4 6.5v7A2.5 2.5 0 0 0 6.5 16H8" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  clock: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  shield: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5 4.5 5.5v6c0 4.6 3.1 8.6 7.5 10 4.4-1.4 7.5-5.4 7.5-10v-6z" fill="currentColor"/><path d="m8.5 12 2.4 2.4L15.5 9.8" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  wa: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M9 8.5c0 3.5 3 6.5 6.5 6.5l1-1.5-2-1-1 1c-1.2-.5-2-1.3-2.5-2.5l1-1-1-2z" fill="currentColor"/></svg>',
  open: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  warn: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="currentColor"/><path d="M12 7v6" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><circle cx="12" cy="16.8" r="1.5" fill="#fff"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.3-5.6M20 4v5h-5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 5-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};
const MODO_ICO = { codigo: IC.ticket, link: IC.link, hogar: IC.tv };

// "837621" → "837 621" · "4821" se deja igual.
export function codigoAgrupado(c = '') { const s = String(c || ''); return /^\d{6}$/.test(s) ? `${s.slice(0, 3)} ${s.slice(3)}` : s; }

export function resultadoHtml(r, { error = '', busy = false } = {}) {
  if (busy) return `<section class="cod-card cod-loading"><span class="cod-spin" aria-hidden="true"></span><div><strong>Leyendo el correo del hosting…</strong><small>Puede tardar hasta 15 segundos. Disney+ se revisa dos veces para no darle un código viejo.</small></div></section>`;
  if (error) return `<section class="cod-card cod-state cod-bad"><span class="cod-state-ico">${IC.warn}</span><div><strong>No se pudo consultar</strong><small>${esc(error)}</small></div></section>`;
  if (!r) return '';
  const cuando = r.ts ? haceCuanto(r.ts) : '';
  const meta = `<div class="cod-meta"><div><span class="cod-meta-ico">${IC.mail}</span><p><small>Fuente</small><b>${esc(r.plataformaNombre ? `${r.plataformaNombre} · correo de la cuenta` : 'Correo de la cuenta')}</b></p></div><div><span class="cod-meta-ico">${IC.clock}</span><p><small>Obtenido</small><b>${esc(r.fecha || cuando || '—')}</b></p></div></div>`;
  const head = (titulo, pill, warn = false) => `<header class="cod-head"><span class="cod-ok-ico${warn ? ' warn' : ''}">${warn ? IC.warn : IC.check}</span><div><h3>${esc(titulo)}</h3><small>Obtenido del correo de la cuenta${cuando ? `<br>${esc(cuando.charAt(0).toUpperCase() + cuando.slice(1))}` : ''}</small></div><span class="cod-pill${warn ? ' warn' : ''}">${esc(pill)}</span></header>`;
  if (r.tipo === 'codigo') {
    return `<section class="cod-card cod-found${r.repetido ? ' is-warn' : ''}">${head(r.detalle || 'Código encontrado', r.repetido ? 'Ya entregado' : 'Listo para usar', Boolean(r.repetido))}
      <div class="cod-codebox"><span class="cod-code" aria-label="Código">${esc(codigoAgrupado(r.codigo))}</span><button type="button" class="cod-copy-ico" id="codCopyIco" aria-label="Copiar código">${IC.copy}</button></div>
      <button type="button" class="cod-btn-outline" id="codCopy">${IC.copy}<span>Copiar código</span></button>
      <button type="button" class="cod-btn-outline cod-wa" id="codWa">${IC.wa}<span>Enviar por WhatsApp</span></button>
      ${meta}
      <div class="cod-important"><span class="cod-imp-ico">${IC.shield}</span><div><strong>Importante</strong><ul>${r.repetido ? '<li>Este código ya se entregó y Disney+ todavía no manda otro: pida <b>Reenviar código</b> y busque de nuevo.</li>' : ''}<li>Cada código tiene un único uso.</li><li>Si el código no funciona, genere uno nuevo.</li></ul></div></div>
    </section>`;
  }
  if (r.tipo === 'link') {
    const titulo = r.motivo === 'hogar' ? 'Enlace de Netflix Hogar' : r.motivo === 'temporal' ? 'Código temporal (en el enlace)' : 'Enlace para restablecer la clave';
    return `<section class="cod-card cod-found">${head(titulo, 'Listo para usar')}
      <button type="button" class="cod-btn-primary" id="codOpen">${IC.open}<span>Abrir enlace</span></button>
      <button type="button" class="cod-btn-outline" id="codCopyLink">${IC.copy}<span>Copiar enlace</span></button>
      <button type="button" class="cod-btn-outline cod-wa" id="codWa">${IC.wa}<span>Enviar por WhatsApp</span></button>
      ${meta}
      <div class="cod-important"><span class="cod-imp-ico">${IC.shield}</span><div><strong>Importante</strong><ul><li>El enlace vence en poco tiempo.</li><li>Si ya no abre, pídalo otra vez en la plataforma.</li></ul></div></div>
    </section>`;
  }
  const textos = {
    hogar_aviso: ['Es un correo de Netflix Hogar', 'Toque “Netflix Hogar” arriba y busque otra vez.'],
    ilegible: ['Llegó el correo de Disney+, pero no se pudo leer el código', 'No se muestra uno anterior para no darle un código vencido.'],
    sin_emails: ['No hay correos recientes para esta cuenta', 'Revise que el correo esté bien escrito o que la plataforma ya haya enviado el correo.'],
    sin_codigo: ['No hay un código reciente', 'Pida el código en la plataforma y vuelva a buscar en unos segundos.'],
    sin_link: ['No hay un enlace de restablecimiento reciente', 'Pida “Olvidé mi contraseña” en la plataforma y vuelva a buscar.'],
    sin_hogar: ['No hay un correo reciente de Netflix Hogar', 'Pida el código de Hogar en el televisor y vuelva a buscar.'],
  }[r.tipo] || ['Sin resultado', ''];
  return `<section class="cod-card cod-state"><span class="cod-state-ico">${IC.info}</span><div><strong>${esc(textos[0])}</strong><small>${esc(textos[1])}</small></div></section>`;
}

export function codigosView() {
  const s = codigosState();
  if (!canCodigos()) return ui.subPage('Códigos', 'No disponible', '<div class="empty-state"><strong>Solo para Sublicuentas, Relojes y Geisell</strong></div>');
  const chips = MODOS.map(([id, label]) => `<button type="button" class="cod-chip${s.modo === id ? ' on' : ''}" data-cod-modo="${id}">${MODO_ICO[id]}<span>${esc(label)}</span></button>`).join('');
  const usados = s.resultado ? clientesDeCorreo(s.correo) : [];
  const cliente = usados.length === 1 ? usados[0] : null;
  const recientes = s.recientesOpen && s.recientes.length ? `<div class="cod-recent">${s.recientes.map(c => `<button type="button" data-cod-reciente="${esc(c)}">${IC.clock}<span>${esc(c)}</span></button>`).join('')}</div>` : '';
  return `<section class="cod-top"><button class="cod-round" id="backMore" aria-label="Volver">${IC.back}</button><button class="cod-round" id="codRefresh" aria-label="Buscar de nuevo" ${s.correo && !s.busy ? '' : 'disabled'}>${IC.refresh}</button></section>
  <section class="cod-hero"><div><p class="eyebrow">SUBLICUENTAS</p><h1>Códigos</h1><p class="cod-sub">Del correo del hosting · respaldo de Telegram</p></div><img src="/assets/mas/codigos-hero.webp" alt="" width="280" height="225" decoding="async"></section>
  <section class="cod-panel">
    <label class="cod-label" for="codCorreo">Correo de la cuenta</label>
    <div class="cod-input"><span class="cod-input-ico">${IC.mail}</span><input id="codCorreo" type="email" inputmode="email" autocomplete="off" autocapitalize="off" spellcheck="false" enterkeyhint="search" placeholder="Escriba o pegue el correo" value="${esc(s.correo)}">${s.recientes.length ? `<button type="button" class="cod-input-chev${s.recientesOpen ? ' open' : ''}" id="codRecientes" aria-label="Buscados hace poco">${IC.chevron}</button>` : ''}</div>
    ${recientes}
    <div class="cod-chips">${chips}</div>
    <button type="button" class="cod-search" id="codBuscar" ${s.busy ? 'disabled' : ''}>${s.busy ? '<span class="cod-spin sm" aria-hidden="true"></span><span>Buscando…</span>' : `${IC.search}<span>Buscar</span>`}</button>
    <div class="cod-info"><span>${IC.info}</span><p>Los códigos no se guardan en el teléfono. Cada consulta queda registrada en la bitácora (sin el código).</p></div>
    ${cliente ? `<p class="cod-cliente">Cliente: <b>${esc(cliente.nombre)}</b> · ${esc(platformLabel(cliente.plataforma))}</p>` : usados.length > 1 ? `<p class="cod-cliente">Cuenta compartida por <b>${usados.length} clientes</b>: al enviar por WhatsApp elija el contacto.</p>` : ''}
    ${resultadoHtml(s.resultado, { error: s.error, busy: s.busy })}
  </section>`;
}

export async function runCodigos(correoIn, modoIn) {
  const s = codigosState();
  const correo = String(correoIn ?? s.correo).trim().toLowerCase();
  const modo = modoIn || s.modo;
  s.correo = correo; s.modo = modo;
  if (!EMAIL_RE.test(correo)) { s.error = 'Escriba un correo válido.'; s.resultado = null; ui.render(); return; }
  if (s.busy) return;
  s.busy = true; s.error = ''; s.resultado = null; ui.render();
  try {
    const out = await buscarCodigo(correo, modo);
    s.resultado = out?.resultado || null;
    s.recientes = [correo, ...s.recientes.filter(c => c !== correo)].slice(0, 5);
    s.recientesOpen = false;
  } catch (e) {
    s.error = String(e?.message || 'No se pudo consultar.');
  } finally { s.busy = false; ui.render(); }
}

// Abrir Códigos ya con el correo de una cuenta (desde Clientes) y buscar de una vez.
export function openCodigosFor(correo) {
  const s = codigosState();
  state.active = 'mas'; state.subview = 'codigos';
  s.correo = String(correo || '').trim().toLowerCase(); s.modo = 'codigo'; s.resultado = null; s.error = '';
  ui.render();
  if (EMAIL_RE.test(s.correo)) runCodigos(s.correo, 'codigo');
}

export function bindCodigos() {
  if (state.subview !== 'codigos') return;
  const s = codigosState();
  const input = document.querySelector('#codCorreo');
  input?.addEventListener('input', () => { s.correo = input.value; });
  input?.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); runCodigos(input.value); } });
  // Como en Telegram: pega el correo y busca solo (escribiendo a mano se busca con Enter o con el botón).
  input?.addEventListener('paste', () => setTimeout(() => { const v = String(input.value || '').trim(); if (EMAIL_RE.test(v)) { input.blur(); runCodigos(v); } }, 0));
  document.querySelector('#codBuscar')?.addEventListener('click', () => runCodigos(input?.value));
  document.querySelector('#codRefresh')?.addEventListener('click', () => runCodigos(s.correo));
  document.querySelector('#codRecientes')?.addEventListener('click', () => { s.recientesOpen = !s.recientesOpen; ui.render(); });
  document.querySelectorAll('[data-cod-modo]').forEach(b => b.addEventListener('click', () => { s.modo = b.dataset.codModo; s.correo = input?.value ?? s.correo; s.resultado = null; s.error = ''; ui.render(); }));
  document.querySelectorAll('[data-cod-reciente]').forEach(b => b.addEventListener('click', () => runCodigos(b.dataset.codReciente)));
  const r = s.resultado;
  document.querySelector('#codCopy')?.addEventListener('click', () => ui.copy(r?.codigo, 'Código copiado.'));
  document.querySelector('#codCopyIco')?.addEventListener('click', () => ui.copy(r?.codigo, 'Código copiado.'));
  document.querySelector('#codCopyLink')?.addEventListener('click', () => ui.copy(r?.link, 'Enlace copiado.'));
  document.querySelector('#codOpen')?.addEventListener('click', () => ui.openLink(r?.link));
  document.querySelector('#codWa')?.addEventListener('click', () => ui.whatsapp(mensajeCodigo(r), clienteDeCorreo(s.correo)?.telefono || ''));
}
