// R196r · Cobro y Renovación — Plantillas de mensajes (carrusel por ocasión/tono/longitud) + Generador IA (rápido).
// · Variedad real: cada flecha / «Otros estilos» genera otra combinación y nunca repite las últimas 40 del cliente.
// · IA: un solo intento, 9 s de límite, sin doble toque, cancelable; si tarda o falla, plantilla local al instante.
// · Se mide cada etapa (toque → solicitud → respuesta → pantalla) y se muestra el último tiempo real.
import { state, esc, showToast, ui } from './core.js';
import { OCASIONES, TONOS, LONGITUDES, PARAMS_DEFECTO, normalizarParams, siguientePlantilla, totalCombinaciones, normalizarTexto } from './plantillas-cobro.js';
import { generateChargeMessageAIRapido } from '../api.js';
import { normalizeChargeAiMessage, splitChargeAiLines, chargePlatformName } from '../operations.js';

export const IA_TIMEOUT_MS = 9000;
const MAX_HIST = 40;
const TOTAL = totalCombinaciones();

function claveCliente(g) { return String(g?.clienteId || g?.key || g?.nombre || ''); }
function historial(g) { const k = claveCliente(g); state.renewHist = state.renewHist || {}; return (state.renewHist[k] = state.renewHist[k] || []); }
function recordar(g, texto) { const h = historial(g); h.push(texto); if (h.length > MAX_HIST) h.splice(0, h.length - MAX_HIST); }

// Al abrir la hoja: primera plantilla distinta de las que ya se le mandaron a ESTE cliente en la sesión.
export function iniciarMensajes(g) {
  const params = normalizarParams(state.renewTpl?.params || PARAMS_DEFECTO);
  const { texto } = siguientePlantilla(g, params, historial(g));
  recordar(g, texto);
  state.renewTpl = { params, lista: [{ texto, fuente: 'plantilla' }], idx: 0 };
  state.renewMessage = texto;
  state.renewAi = { busy: false, token: 0, ocasion: state.renewAi?.ocasion || 'renovacion', ultimo: state.renewAi?.ultimo || null };
}
function agregar(g, texto, fuente) {
  const t = state.renewTpl; t.lista.push({ texto, fuente }); if (t.lista.length > 30) t.lista.shift(); t.idx = t.lista.length - 1;
  recordar(g, texto); state.renewMessage = texto;
}
function nuevaLocal(g) {
  const usados = [...historial(g), ...state.renewTpl.lista.map((x) => x.texto), state.renewMessage];
  return siguientePlantilla(g, state.renewTpl.params, usados).texto;
}

const sel = (id, label, lista, valor, ico) => `<label class="rn-sel"><span class="rn-sel-ico" aria-hidden="true">${ico}</span><span class="rn-sel-k">${label}:</span><select id="${id}" aria-label="${label}">${lista.map(([v, t]) => `<option value="${v}" ${v === valor ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;

export function mensajesHtml() {
  const t = state.renewTpl || { params: PARAMS_DEFECTO, lista: [], idx: 0 };
  const ai = state.renewAi || {};
  const cur = t.lista[t.idx] || { fuente: 'plantilla' };
  const n = 4; const dot = t.idx % n;
  const ult = ai.ultimo;
  const ultTxt = ult ? (ult.motivo === 'cancelado' ? 'Generación cancelada: se conserva el mensaje actual.' : ult.fuente === 'ia' ? `Última respuesta IA: ${(ult.ms / 1000).toFixed(1)} s` : `IA no respondió (${esc(ult.motivo || 'sin respuesta')}); se usó plantilla local en ${Math.max(1, ult.msLocal || 0)} ms`) : `Responde con IA; si tarda más de ${IA_TIMEOUT_MS / 1000} s, usa una plantilla local.`;
  return `
    <div class="rn-tabs" role="tablist">
      <button type="button" role="tab" class="rn-tab ${state.renewTab !== 'ia' ? 'on' : ''}" data-rn-tab="msg" aria-selected="${state.renewTab !== 'ia'}"><span aria-hidden="true">💬</span>Mensajes de renovación</button>
      <button type="button" role="tab" class="rn-tab ${state.renewTab === 'ia' ? 'on' : ''}" data-rn-tab="ia" aria-selected="${state.renewTab === 'ia'}"><span aria-hidden="true">✨</span>Generador IA (rápido)<b class="rn-bolt" aria-hidden="true">⚡</b></button>
    </div>
    <section class="rn-tplcard" id="rnTplCard">
      <header class="rn-tpl-head"><span class="rn-tpl-ico" aria-hidden="true">🗂️</span><div><b>Plantillas de mensajes</b><small>Explore y elija el mensaje ideal para su cliente.</small></div><span class="rn-tpl-count" title="Combinaciones reales de la biblioteca">${TOTAL.toLocaleString('en-US')} combinaciones</span></header>
      <div class="rn-sels">${sel('rnOcasion', 'Ocasión', OCASIONES, t.params.ocasion, '🏷️')}${sel('rnTono', 'Tono', TONOS, t.params.tono, '🎚️')}${sel('rnLongitud', 'Longitud', LONGITUDES, t.params.longitud, '☰')}</div>
      <div class="rn-carousel">
        <button type="button" class="rn-arrow" id="rnPrev" aria-label="Plantilla anterior" ${t.idx <= 0 ? 'disabled' : ''}>‹</button>
        <div class="rn-slide"><span class="rn-badge ${cur.fuente === 'ia' ? 'ia' : ''}">${cur.fuente === 'ia' ? '✨ Generado con IA' : '👑 Plantilla destacada'}</span><textarea id="renewChargeText" rows="${Math.min(9, Math.max(5, Math.ceil(String(state.renewMessage || '').length / 34) + 1))}" aria-label="Mensaje de cobro">${esc(state.renewMessage || '')}</textarea></div>
        <button type="button" class="rn-arrow" id="rnNext" aria-label="Otra plantilla">›</button>
      </div>
      <div class="rn-dots" aria-hidden="true">${Array.from({ length: n }, (_, i) => `<i class="${i === dot ? 'on' : ''}"></i>`).join('')}</div>
      <div class="rn-tpl-actions">
        <button type="button" class="rn-btn rn-style" id="renewAnotherStyle"><span class="rn-emoji">🎨</span>Otros estilos</button>
        <button type="button" class="rn-btn rn-copy" id="renewCopyMessage"><span class="rn-emoji">📋</span>Copiar</button>
        <button type="button" class="rn-btn rn-wa" id="renewOpenWhatsApp"><span class="rn-emoji">💬</span>Abrir WhatsApp</button>
      </div>
    </section>
    <section class="rn-aicard" id="rnAiCard">
      <header><span class="rn-ai-ico" aria-hidden="true">⚡</span><div><b>Generador de mensaje IA (rápido)</b><small>Crea un mensaje único con los datos de esta ficha.</small></div></header>
      <div class="rn-ai-row">
        <label class="rn-sel rn-ai-sel"><span class="rn-sel-ico" aria-hidden="true">✨</span><select id="rnAiOcasion" aria-label="Ocasión del mensaje IA" ${ai.busy ? 'disabled' : ''}>${OCASIONES.map(([v, l]) => `<option value="${v}" ${v === (ai.ocasion || 'renovacion') ? 'selected' : ''}>${esc(v === 'renovacion' ? 'Renovación de servicios' : l)}</option>`).join('')}</select></label>
        ${ai.busy ? `<button type="button" class="rn-ai-go busy" id="renewAiCancel"><span class="rn-spin" aria-hidden="true"></span>Generando… · Cancelar</button>` : `<button type="button" class="rn-ai-go" id="renewAiMessage"><span aria-hidden="true">✨</span>Generar mensaje</button>`}
      </div>
      <p class="rn-ai-note" role="status" aria-live="polite">${ultTxt}</p>
    </section>`;
}

function datosCorrectos(texto, g) {
  const plano = String(texto || '').replace(/\*/g, '');
  const total = Number(g?.total || 0);
  const nombre = String(g?.nombre || '').split(/\s+/)[0] || '';
  const montoOk = !total || [String(total), total.toLocaleString('es-HN'), total.toLocaleString('en-US')].some((v) => plano.includes(v));
  const nombreOk = !nombre || plano.toLowerCase().includes(nombre.toLowerCase());
  const svcs = (Array.isArray(g?.servicios) ? g.servicios : []).map((s) => chargePlatformName(s?.plataforma).split(/\s+/)[0].toLowerCase()).filter(Boolean);
  const svcOk = svcs.every((s) => plano.toLowerCase().includes(s));
  const inventa = /\b(descuento|gratis|promoci[oó]n|oferta|regalo|2x1|meses? gratis)\b/i.test(plano);
  return montoOk && nombreOk && svcOk && !inventa;
}

// ctx: { getGroup, render, requestWhatsApp, today }
export function bindMensajes(ctx) {
  const $ = (s) => document.querySelector(s);
  const g = () => ctx.getGroup();
  const texto = () => String($('#renewChargeText')?.value ?? state.renewMessage ?? '');
  const ta = $('#renewChargeText'); if (ta && ta.scrollHeight > ta.clientHeight) ta.style.height = `${ta.scrollHeight + 4}px`;
  $('#renewChargeText')?.addEventListener('input', (e) => { state.renewMessage = e.target.value; const t = state.renewTpl; if (t?.lista[t.idx]) t.lista[t.idx].texto = e.target.value; });
  document.querySelectorAll('[data-rn-tab]').forEach((b) => b.addEventListener('click', () => {
    state.renewTab = b.dataset.rnTab === 'ia' ? 'ia' : 'msg';
    document.querySelectorAll('[data-rn-tab]').forEach((x) => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-selected', String(on)); });
    document.querySelector(state.renewTab === 'ia' ? '#rnAiCard' : '#rnTplCard')?.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
  }));
  const cambiarParam = (k) => (e) => { const grp = g(); if (!grp) return; state.renewTpl.params = normalizarParams({ ...state.renewTpl.params, [k]: e.target.value }); agregar(grp, nuevaLocal(grp), 'plantilla'); ctx.render(); };
  $('#rnOcasion')?.addEventListener('change', cambiarParam('ocasion'));
  $('#rnTono')?.addEventListener('change', cambiarParam('tono'));
  $('#rnLongitud')?.addEventListener('change', cambiarParam('longitud'));
  $('#rnPrev')?.addEventListener('click', () => { const t = state.renewTpl; if (t.idx > 0) { t.idx -= 1; state.renewMessage = t.lista[t.idx].texto; ctx.render(); } });
  $('#rnNext')?.addEventListener('click', () => {
    const grp = g(); if (!grp) return; const t = state.renewTpl;
    if (t.idx < t.lista.length - 1) { t.idx += 1; state.renewMessage = t.lista[t.idx].texto; } else agregar(grp, nuevaLocal(grp), 'plantilla');
    ctx.render();
  });
  // «Otros estilos»: cambia a OTRO tono (rotando) y genera una combinación nueva de ese tono.
  $('#renewAnotherStyle')?.addEventListener('click', () => {
    const grp = g(); if (!grp) return; const t = state.renewTpl;
    const ids = TONOS.map(([id]) => id); t.params = normalizarParams({ ...t.params, tono: ids[(ids.indexOf(t.params.tono) + 1) % ids.length] });
    agregar(grp, nuevaLocal(grp), 'plantilla'); ctx.render();
  });
  $('#renewCopyMessage')?.addEventListener('click', async () => { try { await navigator.clipboard.writeText(texto()); showToast('Mensaje de cobro copiado.'); } catch (_) { showToast('No se pudo copiar el mensaje.'); } });
  $('#renewOpenWhatsApp')?.addEventListener('click', () => { const grp = ctx.getActive?.() || g(); const row = grp?.servicios?.[0] || grp?.serviciosCliente?.[0]; ctx.requestWhatsApp(texto(), grp?.telefono || row?.telefono || ''); });
  $('#rnAiOcasion')?.addEventListener('change', (e) => { state.renewAi.ocasion = e.target.value; });
  $('#renewAiCancel')?.addEventListener('click', () => { const a = state.renewAi; a.token += 1; a.busy = false; a.ultimo = { fuente: 'local', motivo: 'cancelado' }; ctx.render(); showToast('Generación IA cancelada. Se mantiene el mensaje actual.'); });
  $('#renewAiMessage')?.addEventListener('click', () => generarIA(ctx));
}

export async function generarIA(ctx) {
  const grp = ctx.getGroup(); const a = state.renewAi; if (!grp || !a || a.busy) return; // un solo intento a la vez (sin doble toque)
  const token = (a.token += 1); const clave = state.renewGroupKey; const t0 = performance.now();
  a.busy = true; ctx.render(); // indicador inmediato; la hoja sigue usable
  const marca = { toqueAIndicadorMs: Math.round(performance.now() - t0) };
  const vigente = () => state.renewAi === a && a.token === token && state.renewGroupKey === clave;
  const previos = [...historial(grp)].slice(-3);
  try {
    const r = await generateChargeMessageAIRapido(grp, { ocasion: a.ocasion || 'renovacion', tono: state.renewTpl?.params?.tono || 'amigable', previos }, ctx.today(), { timeoutMs: IA_TIMEOUT_MS });
    if (!vigente()) return; // se canceló o se cerró la hoja: se ignora la respuesta
    if (r?.error) throw new Error(r.error);
    const raw = String(r?.respuesta || r?.text || r?.response || '').trim();
    if (!raw || /^(No obtuve respuesta|Gemini cortó)/i.test(raw)) throw new Error('la IA no devolvió texto');
    const msg = normalizeChargeAiMessage(splitChargeAiLines(raw), grp);
    if (!datosCorrectos(msg, grp)) throw new Error('la IA cambió u omitió datos de la ficha');
    if (historial(grp).map(normalizarTexto).includes(normalizarTexto(msg))) throw new Error('la IA repitió un mensaje');
    a.busy = false; agregar(grp, msg, 'ia');
    a.ultimo = { fuente: 'ia', ms: Math.round(performance.now() - t0), etapas: { ...marca, ...(r?._etapas || {}) } };
    ctx.render(); a.ultimo.etapas.pantallaMs = Math.round(performance.now() - t0);
    showToast('✨ Mensaje IA actualizado.');
  } catch (e) {
    if (!vigente()) return;
    const t1 = performance.now(); a.busy = false; agregar(grp, nuevaLocal(grp), 'plantilla');
    const motivo = e?.timeout ? `más de ${IA_TIMEOUT_MS / 1000} s` : String(e?.message || 'sin respuesta').slice(0, 60);
    a.ultimo = { fuente: 'local', motivo, msLocal: Math.round(performance.now() - t1), ms: Math.round(performance.now() - t0), etapas: marca };
    ctx.render(); showToast(`IA no disponible (${motivo}). Se aplicó una plantilla local.`);
  }
}
