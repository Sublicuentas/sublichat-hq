// R188 · Fase 3 en la APK (PDF «Sublichat 5 puntos», bloque 04). Se guarda en el SERVICIO (nunca en el cliente global):
//   · equipoTv: dispositivo del cliente para TV Digital (Android TV, Fire TV…). Sin elegir = «Pendiente de seleccionar».
//   · modalidadAcceso: Gemini / Duolingo → «correo propio del cliente» (sin contraseña: no se pide, no se guarda, no se muestra)
//     o «cuenta entregada por Sublicuentas» (correo + contraseña). ChatGPT siempre con correo + contraseña.
// El servidor (Sublichat HQ api/renovar.js) vuelve a validar; esto solo arma el formulario.
import { EQUIPOS, familiaTv, equiposPermitidos, usaModalidad, modalidadAcceso, MODALIDADES } from './entrega-plataforma.js';

const escH = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function crmR188Html(d = {}) {
  const out = [];
  if (familiaTv(d.plataforma)) {
    const ids = equiposPermitidos(d.plataforma);
    out.push(`<label class="crm-field crm2-r188"><span class="crm-field-label">Dispositivo del cliente (este servicio)</span><select id="crmEquipoTv" aria-label="Dispositivo del cliente"><option value="">Pendiente de seleccionar</option>${ids.map((k) => `<option value="${k}" ${d.equipoTv === k ? 'selected' : ''}>${escH(EQUIPOS[k])}</option>`).join('')}</select></label>`);
  }
  if (usaModalidad(d.plataforma)) {
    const m = modalidadAcceso(d.plataforma, d);
    out.push(`<label class="crm-field crm2-r188"><span class="crm-field-label">Modalidad de acceso</span><select id="crmModalidad" aria-label="Modalidad de acceso">${Object.entries(MODALIDADES).map(([k, l]) => `<option value="${k}" ${m === k ? 'selected' : ''}>${escH(l)}${k === 'correo_cliente' ? ' (sin contraseña)' : ' (correo + contraseña)'}</option>`).join('')}</select></label>`);
  }
  return out.length ? `<section class="panel-soft crm2-r188-box">${out.join('')}</section>` : '';
}
// Lee el formulario al borrador. Si el cliente usa su propio correo, la contraseña se borra del borrador (no viaja).
export function crmR188Read(d = {}) {
  const eq = document.querySelector('#crmEquipoTv'); if (eq) d.equipoTv = String(eq.value || '');
  const md = document.querySelector('#crmModalidad'); if (md) d.modalidadAcceso = md.value === 'proveedor' ? 'proveedor' : 'correo_cliente';
  if (modalidadAcceso(d.plataforma, d) === 'correo_cliente' && Array.isArray(d.perfiles)) d.perfiles = d.perfiles.map((p) => ({ ...p, clave: '' }));
  return d;
}
export function crmR188Payload(form = {}) {
  const out = {};
  if (familiaTv(form.plataforma)) out.equipoTv = String(form.equipoTv || '');
  const m = modalidadAcceso(form.plataforma, form); if (m) out.modalidadAcceso = m;
  return out;
}
export function bindCrmR188(rerender) {
  document.querySelector('#crmModalidad')?.addEventListener('change', () => rerender());
}
