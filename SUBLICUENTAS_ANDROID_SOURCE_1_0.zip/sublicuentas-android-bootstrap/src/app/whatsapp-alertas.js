// src/app/whatsapp-alertas.js · R120 — Perfil: número para futuras alertas por WhatsApp.
// SOLO configuración persistente (perfiles_usuario.whatsapp_alert_number, whatsapp_alerts_enabled=false).
// No envía mensajes ni usa tokens: la integración futura (WhatsApp Business / Cloud API) saldrá del backend.
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export function normalizarWhatsapp(v = '') {
  const dig = String(v || '').replace(/\D/g, '');
  if (!dig) return '';
  if (dig.length === 8) return `+504${dig}`;
  return dig.length >= 8 && dig.length <= 15 ? `+${dig}` : null;
}
export function waAlertasHtml(state) {
  const n = state.profile?.whatsapp_alert_number || '';
  const local = n.startsWith('+504') ? n.slice(4) : n.replace(/^\+/, '');
  const pref = n && !n.startsWith('+504') ? '+' : '+504';
  return `<section class="panel settings-panel wa-alertas"><div class="setting-line"><span><strong>Alertas por WhatsApp</strong><small>${n ? `Configurado · ${esc(n)}` : 'No configurado'} · los envíos se activarán más adelante</small></span></div>
    <label class="wa-row"><span>Número para alertas</span><div class="wa-input"><input id="waPrefijo" value="${esc(pref)}" inputmode="tel" aria-label="Prefijo"><input id="waNumero" value="${esc(local)}" inputmode="tel" placeholder="9999-9999" aria-label="Número"></div></label>
    <button class="secondary" id="waGuardar">Guardar número</button></section>`;
}
export function bindWaAlertas({ state, authPost, showToast, render }) {
  document.querySelector('#waGuardar')?.addEventListener('click', async () => {
    const pref = String(document.querySelector('#waPrefijo')?.value || '+504').replace(/\D/g, '');
    const num = String(document.querySelector('#waNumero')?.value || '').replace(/\D/g, '');
    const full = num ? normalizarWhatsapp(`${pref}${num}`) : '';
    if (full === null) return showToast('Número inválido. Ejemplo: +504 9999-9999');
    const r = await authPost('/api/perfil', { accion: 'guardar', usuario: state.session?.usuario || '', whatsapp_alert_number: full || '' }).catch((e) => ({ ok: false, error: e?.message }));
    if (!r?.ok) return showToast(r?.error || 'No se pudo guardar el número.');
    state.profile = { ...(state.profile || {}), whatsapp_alert_number: full || null, whatsapp_alerts_enabled: false };
    showToast(full ? `✅ Número guardado: ${full}` : 'Número eliminado.'); render();
  });
}
