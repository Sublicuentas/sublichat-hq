// R198b · Fase 2 del PDF «Sublichat APK: modo offline completo» (18/11/2026).
// Copia de CONSULTA para TODOS los usuarios con permiso (Sublicuentas, Relojes, Geisell…), cifrada con la llave del
// Keystore (misma base que R101) y aislada por usuario:
//   · clientes / CRM (sin claves, PIN, correos de acceso, códigos ni tokens),
//   · inventario y Control Maestro como FOTO del último estado (los cupos se muestran «por confirmar»),
//   · tickets y destinatarios, catálogo.
// Antes los clientes y tickets quedaban en localStorage en texto plano; ahora, si el teléfono tiene almacén cifrado,
// localStorage ya no guarda esas listas (solo el perfil y la fecha).
// Vigencia: una copia con más de 7 días no se usa (se pide conexión). Cerrar sesión la borra (wipeOffline).
// La copia NUNCA reemplaza datos frescos del servidor: solo rellena lo que no llegó.
import { state, esc } from './core.js';
import { saveBox, loadBox, offlineSupported, offlineAllowed, isOfflineError } from './offline.js';
const deviceOffline = () => typeof navigator !== 'undefined' && navigator.onLine === false;
import { roleCapabilities } from '../data.js';

const CAJA = 'consulta_v1';
export const VIGENCIA_MS = 7 * 86400000;
// Igual que SENSITIVE_KEY_RE de main.js (R69): nada de esto sale del servidor al teléfono en la copia de consulta.
export const SECRETO_RE = /^(clave|claves|password|pass|passwd|contrasena|contraseña|pin|pinperfil|pinPerfil|maxplayerclave|maxPlayerClave|maxplayerusuario|maxPlayerUsuario|iptvclave|iptvClave|iptvusuario|token|idtoken|idToken|refreshtoken|refreshToken|cookie|cookies|secret|correo|email|usuarioacceso|codigo|code)$/i;
export function sinSecretos(v, depth = 0) {
  if (depth > 8 || v == null) return v;
  if (Array.isArray(v)) return v.map((x) => sinSecretos(x, depth + 1));
  if (typeof v === 'object') { const o = {}; for (const [k, val] of Object.entries(v)) { if (SECRETO_RE.test(k)) continue; o[k] = sinSecretos(val, depth + 1); } return o; }
  return v;
}
// Inventario: el correo de la cuenta madre es su identificador visible en Control Maestro; se conserva SOLO enmascarado.
const enmascarar = (c = '') => { const t = String(c || ''); const [u, d] = t.split('@'); return d ? `${u.slice(0, 2)}***@${d}` : t ? `${t.slice(0, 2)}***` : ''; };
function inventarioConsulta(lista = []) {
  return (Array.isArray(lista) ? lista : []).map((x) => ({ ...sinSecretos(x), correo: enmascarar(x?.correo || x?.email || ''), _copiaConsulta: true }));
}

export const copia = { usuario: '', syncedAt: 0, controlInventory: null, controlSyncedAt: 0, catalog: null, tickets: null, recipients: [], vencida: false };
let restaurado = false, t = null;
const caps = () => roleCapabilities(state.session?.role || '', state.session?.usuario || '');
export const sinRed = () => deviceOffline() || state.sync === 'offline';
const fecha = (ms) => { if (!ms) return 'sin fecha'; const d = new Date(ms), p = (n) => String(n).padStart(2, '0'); return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}, ${p(d.getHours())}:${p(d.getMinutes())}`; };

export function consultaGuardar() {
  if (!state.session || !offlineSupported() || !restaurado) return;
  clearTimeout(t);
  const usuario = state.session.usuario;
  t = setTimeout(() => {
    if (state.session?.usuario !== usuario) return;
    const c = caps();
    const control = c.controlMaestro && Array.isArray(state.controlInventory) && !state.controlDesdeCopia ? { lista: inventarioConsulta(state.controlInventory), at: state.controlSyncedAt || Date.now() } : { lista: copia.controlInventory, at: copia.controlSyncedAt };
    const tickets = state.ticketsLoaded && Array.isArray(state.tickets) ? state.tickets : copia.tickets;
    const datos = {
      clients: sinSecretos(state.clients || []), inventory: c.inventario ? inventarioConsulta(state.inventory || []) : [],
      controlInventory: control.lista || null, controlSyncedAt: control.at || 0,
      catalog: c.catalogo ? (state.catalogDesdeCopia ? copia.catalog : state.catalog || copia.catalog) : null,
      tickets: tickets || null, recipients: state.ticketRecipients || copia.recipients || [], syncedAt: state.offlineSyncedAt || 0,
    };
    copia.controlInventory = datos.controlInventory; copia.controlSyncedAt = datos.controlSyncedAt; copia.catalog = datos.catalog; copia.tickets = datos.tickets; copia.recipients = datos.recipients;
    saveBox(usuario, CAJA, datos).catch(() => {});
  }, 1200);
}

export async function consultaRestaurar() {
  if (!state.session) return false;
  const usuario = state.session.usuario;
  restaurado = false; Object.assign(copia, { usuario, syncedAt: 0, controlInventory: null, controlSyncedAt: 0, catalog: null, tickets: null, recipients: [], vencida: false });
  if (!offlineSupported()) { restaurado = true; return false; }
  const box = await loadBox(usuario, CAJA).catch(() => null);
  if (state.session?.usuario !== usuario) return false;
  restaurado = true;
  const d = box?.data; if (!d) return false;
  if (Date.now() - (Number(d.syncedAt) || box.guardadoAt) > VIGENCIA_MS) { copia.vencida = true; return false; }
  Object.assign(copia, { syncedAt: Number(d.syncedAt) || 0, controlInventory: d.controlInventory || null, controlSyncedAt: Number(d.controlSyncedAt) || 0, catalog: d.catalog || null, tickets: d.tickets || null, recipients: d.recipients || [] });
  if (!(state.clients || []).length && Array.isArray(d.clients)) state.clients = d.clients;
  if (!(state.inventory || []).length && Array.isArray(d.inventory) && d.inventory.length) { state.inventory = d.inventory; state.inventoryDesdeCopia = true; }
  if (!state.tickets && Array.isArray(d.tickets)) { state.tickets = d.tickets; state.ticketRecipients = d.recipients || []; }
  if (!state.offlineSyncedAt && copia.syncedAt) state.offlineSyncedAt = copia.syncedAt;
  return true;
}

// Control Maestro: si el servidor no responde por falta de señal, se muestra la foto guardada (nunca un cupo inventado).
export function controlDesdeCopia(error) {
  if (!copia.controlInventory || copia.usuario !== state.session?.usuario) return false;
  if (!(sinRed() || /fetch|red|conexi|network|internet/i.test(String(error?.message || error || '')))) return false;
  state.controlInventory = copia.controlInventory; state.controlDesdeCopia = true; return true;
}
export function catalogoDesdeCopia() {
  if (!copia.catalog || copia.usuario !== state.session?.usuario) return false;
  state.catalog = copia.catalog; state.catalogDesdeCopia = true; return true;
}

// Aviso dentro de la banda global para las pantallas de cuentas: foto del último estado, disponibilidad por confirmar.
export function avisoCuentasHtml() {
  const enCuentas = ['inventario', 'control-maestro', 'control'].includes(state.subview || '');
  if (!enCuentas || !(sinRed() || state.controlDesdeCopia || state.inventoryDesdeCopia)) return '';
  const at = state.subview === 'control-maestro' ? (state.controlDesdeCopia ? copia.controlSyncedAt : state.controlSyncedAt) : state.offlineSyncedAt;
  return `<small class="offline-cupos">Cuentas, perfiles y cupos: foto del ${esc(fecha(at))} · <b>disponibilidad por confirmar</b>. ${offlineAllowed(state.session) && offlineSupported() ? '' : 'Correos enmascarados y claves no guardadas en este equipo. '}${caps().nuevoCrm ? 'Asignar o vender se valida con el servidor al reconectar.' : ''}</small>`;
}
export { fecha as fechaConsulta };

// ---------------------------------------------------------------- R198d · Fase 4: vistas guardadas de módulos en vivo
// Finanzas, Panel de Socios (pedidos), Sala de Juntas, Partidos y Pelis: la última LECTURA buena se guarda cifrada por
// usuario (sin claves, PIN, correos de acceso ni tokens) y, sin señal, se muestra con su fecha y el sello del módulo.
// Nunca se guarda ni se simula una ESCRITURA: pagos, entregas, invitaciones, reuniones y mensajes requieren internet.
const CAJA_VISTAS = 'vistas_v1';
export const VIGENCIA_VISTA = Object.freeze({ fin: 2 * 86400000 }); // datos financieros: 2 días como máximo
let vistas = null, vistasUsuario = '', tVistas = null;
async function mapaVistas() {
  const u = state.session?.usuario; if (!u) return {};
  if (vistas && vistasUsuario === u) return vistas;
  const b = await loadBox(u, CAJA_VISTAS).catch(() => null);
  if (state.session?.usuario !== u) return {};
  vistas = b?.data && typeof b.data === 'object' ? b.data : {}; vistasUsuario = u; return vistas;
}
function guardarVistas() {
  const u = vistasUsuario; clearTimeout(tVistas);
  tVistas = setTimeout(() => {
    if (state.session?.usuario !== u || !vistas) return;
    vistas = Object.fromEntries(Object.entries(vistas).sort((a, b) => b[1].at - a[1].at).slice(0, 40)); // poda: 40 lecturas recientes
    saveBox(u, CAJA_VISTAS, vistas).catch(() => {});
  }, 600);
}
const conSello = (data, at) => { if (Array.isArray(data)) { const a = [...data]; a._copiaAt = at; return a; } return { ...(data || {}), _copiaAt: at }; };
export async function leerConCopia(modulo, clave, fn) {
  const k = `${modulo}|${String(clave || '').slice(0, 300)}`;
  try {
    if (deviceOffline()) throw Object.assign(new Error('Sin conexión'), { offline: true }); // modo avión: directo a la copia, sin esperar reintentos
    const r = await fn();
    if (r && r.ok !== false && !r.error && offlineSupported() && state.session) {
      const m = await mapaVistas(); m[k] = { data: sinSecretos(r), at: Date.now() }; guardarVistas();
      if (state.vistaCopia?.[modulo]) state.vistaCopia = { ...state.vistaCopia, [modulo]: 0 };
    }
    return r;
  } catch (e) {
    if (Number(e?.status) === 403 || /sin_permiso|no tiene (permiso|acceso)/i.test(String(e?.data?.error || e?.message || ''))) { // R198e · permiso retirado: se borra la copia de ese módulo
      const m = await mapaVistas(); for (const key of Object.keys(m)) if (key.startsWith(`${modulo}|`)) delete m[key];
      if (state.vistaCopia?.[modulo]) state.vistaCopia = { ...state.vistaCopia, [modulo]: 0 }; guardarVistas(); throw e;
    }
    if (!(sinRed() || isOfflineError(e))) throw e;
    const v = (await mapaVistas())[k];
    if (!v) throw Object.assign(new Error('Sin conexión: esta pantalla no se había descargado. Ábrala una vez con internet.'), { offline: true });
    if (Date.now() - v.at > (VIGENCIA_VISTA[modulo] || VIGENCIA_MS)) throw Object.assign(new Error('Sin conexión: la copia guardada venció. Conéctese para actualizar.'), { offline: true });
    state.vistaCopia = { ...(state.vistaCopia || {}), [modulo]: v.at };
    return conSello(v.data, v.at);
  }
}
const SELLOS = Object.freeze({
  finanzas: ['fin', (f) => `Finanzas: resumen guardado del ${f} · <b>dato histórico</b>. Sin internet no se registra ni se contabiliza nada.`],
  'socios-entregas': ['socios', (f) => `Pedidos de socios guardados del ${f}. Entregar, publicar o avisar por Telegram requiere internet.`],
  partidos: ['partidos', (f) => `Partidos: programación guardada del ${f} · <b>los marcadores NO son en vivo</b>.`],
  pelis: ['pelis', (f) => `Pelis: resultados guardados del ${f} · pueden estar desactualizados.`],
});
export function avisoVistaHtml() {
  const s = SELLOS[state.subview || '']; if (!s || !sinRed()) return '';
  const at = state.vistaCopia?.[s[0]];
  return `<small class="offline-cupos">${at ? s[1](esc(fecha(at))) : 'Esta pantalla se muestra solo con lo que ya estaba cargado. Las acciones requieren internet.'}</small>`;
}
