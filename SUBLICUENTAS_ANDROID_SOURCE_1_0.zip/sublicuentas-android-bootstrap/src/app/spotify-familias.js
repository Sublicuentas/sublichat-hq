// R188 · Spotify Familiar en la APK (PDF «Sublichat 5 puntos», bloque 01). Se entra desde Más › Inventario (Más no cambia).
// Mismas reglas que Web y bot, en el SERVIDOR (/api/inventario · _spotify-familias.js): 1 madre + 5 invitados, exclusividad,
// en transacción y con auditoría. No se guarda contraseña de Spotify.
// R196p · «Eliminar correo» por invitado (solo Sublicuentas).
// R196o · PDF «Spotify Familiar · lógica estricta»: sin «Mover», sin «Desvincular» y sin elegir fichas de una lista. Se escribe
//   el correo dentro de la madre; «No renovó» en la ficha libera el espacio solo. «Crear familia» solo para Sublicuentas.
import { authPost } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';

export function canSpotify() { return ['sublicuentas', 'relojes', 'geisell'].includes(operatorIdentity(state.session?.role || '', state.session?.usuario || '')); }
// R196m · Alta directa por correo (1 campo + Agregar, sin listas).
export function spState() { if (!state.spf) state.spf = { familias: null, abierta: '', aviso: '', enviando: false, cargando: false, error: '', puedeAdministrar: false }; return state.spf; }
export function spotifyEntradaHtml() { return canSpotify() ? `<button type="button" class="se-btn ghost spf-entrada" data-open-spotify>🎵 Spotify Familiar · familias e invitados</button>` : ''; }

async function inv(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/inventario', { accion, ...extra }); }
  catch (e) { throw new Error(e?.data?.error || (Number(e?.status) === 403 ? 'Su usuario no tiene Spotify Familiar.' : e?.message || 'Sin conexión')); }
  if (!r || r.ok === false) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
export async function spCargar() {
  const s = spState(); s.cargando = true; s.error = ''; ui.render();
  try { const r = await inv('spotifyFamilias'); s.familias = r.familias || []; s.puedeAdministrar = !!r.puedeAdministrar; } catch (e) { s.error = e.message; s.familias = s.familias || []; }
  s.cargando = false; if (state.subview === 'spotify-familias') ui.render();
}
// Para la ficha (CRM): ¿a qué familia pertenece este correo invitado?
export async function spResolver(correo) { try { return (await inv('spotifyResolver', { correo })).familia || null; } catch (_) { return null; } }

export function spotifyView() {
  const s = spState();
  if (!canSpotify()) return ui.subPage('Spotify Familiar', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene Spotify Familiar</strong></div>');
  if (s.familias === null && !s.cargando) setTimeout(spCargar, 0);
  const fam = (s.familias || []).find((f) => f.id === s.abierta);
  const lista = (s.familias || []).map((f) => `<button type="button" class="se-item spf-fam ${f.id === s.abierta ? 'on' : ''}" data-spf-abrir="${esc(f.id)}"><div><b>${esc(f.codigo)} · ${esc(f.madreCorreo)}</b><small>Invitados ${f.ocupados}/${f.capacidad}</small></div></button>`).join('');
  const detalle = fam ? `<article class="se-card"><b>${esc(fam.codigo)} · Cuenta madre</b><small>${esc(fam.madreCorreo)}</small><b>Invitados ${fam.ocupados}/${fam.capacidad}</b>
    ${fam.miembros.filter((m) => m.estado === 'activo').map((m) => `<div class="spf-m"><span>${esc(m.correo)}${m.clienteNombre ? ` · ${esc(m.clienteNombre)}` : ''} · ${m.retiroPendiente ? '<b class="bad">Retiro en Spotify pendiente</b>' : '<b class="ok">Vinculada</b>'}</span>${s.puedeAdministrar ? `<button type="button" class="se-btn ghost" data-spf-elim="${esc(m.correo)}">Eliminar correo</button>` : ''}</div>`).join('')}
    ${Array.from({ length: fam.libres }).map(() => '<small>+ Espacio disponible</small>').join('')}
    ${fam.libres ? `<label class="spf-label" for="spfCorreo">Correo del invitado</label><div class="spf-alta"><input class="se-input" id="spfCorreo" type="email" inputmode="email" autocomplete="off" placeholder="cliente@gmail.com"${s.enviando ? ' disabled' : ''}><button type="button" class="se-btn" data-spf-agregar${s.enviando ? ' disabled' : ''}>${s.enviando ? 'Agregando…' : 'Agregar'}</button></div>
      ${s.aviso ? `<small class="baul-aviso">${esc(s.aviso)}</small>` : ''}` : '<small>Familia completa (5 de 5). Se libera un espacio cuando un cliente «No renovó».</small>'}
    ${(fam.pendientesSpotify || []).length ? `<small class="baul-aviso"><b>Falta quitar en la app de Spotify</b> (ya no ocupan espacio): ${fam.pendientesSpotify.map((p) => esc(p.correo)).join(', ')}</small>` : ''}
    <small class="baul-aviso">Sublichat no envía invitaciones ni revisa Spotify: solo lleva el control de cupos.</small></article>` : '';
  return ui.subPage('Spotify Familiar', 'Madre + 5 invitados · igual que en la web y el bot', `<section class="se-wrap">
    ${s.error ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}
    ${s.cargando && !s.familias ? '<div class="loading-card"><span class="spinner"></span><strong>Cargando familias…</strong></div>' : lista || '<div class="empty-state"><strong>Sin familias todavía</strong></div>'}
    ${detalle}
    ${s.puedeAdministrar ? '<input class="se-input" id="spfMadre" type="email" placeholder="Correo madre (administradora)"><button type="button" class="se-btn" data-spf-crear>Crear familia</button>' : ''}</section>`);
}

async function accion(fn, ok) {
  const s = spState();
  try { const r = await fn(); s.error = ''; if (r?.familia?.id) s.abierta = r.familia.id; showToast?.(ok + (r?.advertencia ? ` · ${r.advertencia}` : '')); await spCargar(); }
  catch (e) { s.error = e.message; ui.render(); }
}
export function bindSpotify() {
  document.querySelector('[data-open-spotify]')?.addEventListener('click', () => { state.subview = 'spotify-familias'; ui.render(); });
  if (state.subview !== 'spotify-familias') return;
  const s = spState(), qa = (x) => document.querySelectorAll(x), val = (id) => String(document.getElementById(id)?.value || '').trim();
  const fam = () => (s.familias || []).find((f) => f.id === s.abierta);
  qa('[data-spf-abrir]').forEach((b) => b.addEventListener('click', () => { s.abierta = b.dataset.spfAbrir; s.aviso = ''; ui.render(); }));
  qa('[data-spf-crear]').forEach((b) => b.addEventListener('click', () => accion(() => inv('spotifyCrear', { madreCorreo: val('spfMadre') }), 'Familia creada')));
  const agregar = async (correo) => {
    if (s.enviando) return; // doble toque: una sola alta
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(correo)) { s.error = 'Escriba un correo válido (ej. cliente@gmail.com).'; ui.render(); return; }
    s.enviando = true; s.error = ''; s.aviso = ''; ui.render();
    try {
      const r = await inv('spotifyAgregarCorreo', { familiaId: fam()?.id, correo });
      s.enviando = false;
      s.aviso = r.pendienteVincular ? r.aviso : (r.familia?.idempotente ? 'Ese correo ya estaba en esta cuenta: no se duplicó.' : 'Agregado y vinculado con su ficha.');
      showToast?.(s.aviso); await spCargar();
    } catch (e) { s.enviando = false; s.error = e.message; ui.render(); }
  };
  qa('[data-spf-agregar]').forEach((b) => b.addEventListener('click', () => agregar(val('spfCorreo'))));
  // R196p · Eliminar correo (solo Sublicuentas; el servidor también lo verifica): misma función que Telegram y la web.
  qa('[data-spf-elim]').forEach((b) => b.addEventListener('click', async () => {
    const f = fam(), c = b.dataset.spfElim; if (!f || s.enviando) return;
    if (!confirm(`¿Eliminar ${c} de la familia ${f.codigo}?\n\nSe libera el espacio. El cliente, su ficha, ventas e historial no se borran. Falta quitarlo en la app de Spotify.`)) return;
    s.enviando = true;
    try {
      const r = await inv('spotifyEliminarCorreo', { familiaId: f.id, correo: c });
      s.enviando = false; s.error = '';
      s.aviso = r.yaEstaba ? r.aviso : `Correo eliminado de ${r.codigo}. Espacios ocupados: ${r.ocupados}/${r.capacidad}. Falta quitarlo en la app de Spotify.`;
      showToast?.(s.aviso); await spCargar();
    } catch (e) { s.enviando = false; s.error = e.message; ui.render(); }
  }));
}
// Ficha (CRM): al escribir el correo invitado de Spotify se muestra su familia (madre, código y espacio). Se asigna sola al guardar.
export function spotifyCrmHintHtml(d = {}) { return /spotify/i.test(String(d.plataforma || '')) && canSpotify() ? '<p class="crm-info spf-hint" id="crmSpotifyInfo">🎵 Escriba el correo invitado para ver su familia Spotify.</p>' : ''; }
export function bindSpotifyCrm() {
  const box = document.getElementById('crmSpotifyInfo'); if (!box) return;
  const inp = document.querySelector('[data-crm-profile] [data-p-email]');
  const ver = async () => {
    const c = String(inp?.value || '').trim(); if (!/@/.test(c)) return;
    box.textContent = '🎵 Buscando familia…';
    const f = await spResolver(c);
    box.innerHTML = f && f.tipo === 'invitado' ? `🎵 Familia <b>${esc(f.codigo)}</b> · Madre: <b>${esc(f.madreCorreo)}</b> · Espacio ${f.posicion} de ${f.capacidad}. Se asigna sola al guardar.`
      : f && f.tipo === 'madre' ? `🎵 Ese correo es la madre de ${esc(f.codigo)}.` : '🎵 Ese correo no está en ninguna familia. Vincúlelo en Más › Inventario › Spotify Familiar.';
  };
  inp?.addEventListener('change', ver); if (inp?.value) ver();
}
