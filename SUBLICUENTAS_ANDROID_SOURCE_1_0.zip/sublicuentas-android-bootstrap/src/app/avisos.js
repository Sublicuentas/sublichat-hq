// R74 · Avisos nativos del teléfono: recordatorios de cobro (R73) y widget de pantalla de inicio.
import { reminderSellerOf, loadReminderConfig, REMINDER_CHANNEL, isReminderId, planReminders, widgetPayload } from '../recordatorios.js';
import { groupRenewalsByClientDate } from '../operations.js';
import { operationalFilterOptions, canonicalSeller } from '../data.js';
import { state, allRows, hasCobrosTab, esc, ui } from './core.js';

// ===== R73 · Recordatorios de cobro (7 AM "Hoy toca cobrar a N" · 7 PM "Mañana vencen N"), solo del usuario =====
export const REMINDERS={status:'',timer:0,listening:false,lastSig:''};
// R75 · IMPORTANTE: un plugin de Capacitor NUNCA se devuelve "suelto" desde una función async.
// El plugin es un Proxy que responde a cualquier propiedad, también a `.then`; la promesa lo toma como
// si fuera otra promesa, llama a un método nativo "then" que no existe y se queda colgada: por eso el
// widget decía "Abra la app para cargar" y los recordatorios de cobro no se programaban.
// Siempre se envuelve: { LN } / { W }.
export async function notificationsPlugin() {
  try { const { Capacitor }=await import('@capacitor/core'); if(!Capacitor?.isNativePlatform?.())return null; const m=await import('@capacitor/local-notifications'); return m.LocalNotifications?{ LN:m.LocalNotifications }:null; } catch(_) { return null; }
}
export function reminderSeller() { return reminderSellerOf(state.session?.role||'', state.session?.usuario||''); }
export function scheduleCobroReminders(opts={}) {
  clearTimeout(REMINDERS.timer);
  REMINDERS.timer=setTimeout(()=>{ syncCobroReminders(opts).catch(()=>{}); updateHomeWidget().catch(()=>{}); }, opts.now?0:1500);
}
export async function syncCobroReminders({ask=false}={}) {
  const LN=(await notificationsPlugin())?.LN; if(!LN){ REMINDERS.status='web'; return; }
  const cfg=loadReminderConfig();
  if (!REMINDERS.listening) {
    REMINDERS.listening=true;
    LN.addListener('localNotificationActionPerformed',ev=>{ const x=ev?.notification?.extra||{}; if(x.ir==='cobros')openCobrosFromReminder(x.filtro||'hoy'); });
    try { await LN.createChannel({ id:REMINDER_CHANNEL, name:'Recordatorios de cobro', description:'Aviso diario de cobros de hoy y de mañana', importance:4, visibility:1, vibration:true }); } catch(_) {}
  }
  let perm=(await LN.checkPermissions())?.display;
  if (cfg.activo && perm!=='granted' && (ask || perm==='prompt' || perm==='prompt-with-rationale')) perm=(await LN.requestPermissions())?.display;
  REMINDERS.status=perm==='granted'?'ok':'denied';
  // Quita solo los recordatorios de cobro viejos y vuelve a programarlos con los números actuales.
  const pending=(await LN.getPending())?.notifications||[];
  const old=pending.filter(n=>isReminderId(n.id)).map(n=>({id:n.id}));
  if (old.length) await LN.cancel({ notifications:old });
  if (!cfg.activo || perm!=='granted' || !state.session || !Array.isArray(state.clients)) return;
  const plan=planReminders({ groups:groupRenewalsByClientDate(allRows()), seller:reminderSeller(), cfg, now:new Date() });
  if (plan.length) await LN.schedule({ notifications:plan });
}
export function openCobrosFromReminder(filtro) {
  const seller=reminderSeller();
  const label=operationalFilterOptions(allRows()).sellers.find(x=>canonicalSeller(x)===seller)||'';
  state.subview=null; state.selectedClientId=''; state.renewGroupKey='';
  if (hasCobrosTab()) { state.active='renovar'; state.renewFilter=['proximo','vencidos'].includes(filtro)?filtro:'hoy'; state.renewSeller=label; }
  else { state.active='clientes'; state.clientStatusFilter=filtro==='proximo'?'proximos':filtro==='vencidos'?'vencidos':'hoy'; state.clientSellerFilter=label; }
  ui.render();
}
export function reminderSettingsHtml() {
  const c=loadReminderConfig();
  const st=REMINDERS.status==='denied'?'Permiso de notificaciones apagado: actívelo en Ajustes de Android → Apps → Sublichat.':REMINDERS.status==='web'?'Solo funcionan en la app de Android.':'Solo sus cobros, igual que el aviso del bot.';
  return `<div class="setting-line reminder-line"><span><strong>Recordatorios de cobro</strong><small>${esc(st)}</small></span><label class="switch"><input type="checkbox" id="remActivo" ${c.activo?'checked':''}><i></i></label></div>
    <div class="setting-line reminder-times" ${c.activo?'':'hidden'}><label><small>“Hoy toca cobrar”</small><input type="time" id="remHoraHoy" value="${esc(c.horaHoy)}"></label><label><small>“Mañana vencen”</small><input type="time" id="remHoraManana" value="${esc(c.horaManana)}"></label></div>
    <div class="setting-line"><span><strong>Widget de Cobros</strong><small>Mantenga presionada la pantalla de inicio → Widgets → Sublichat. Hay uno grande (4x2, con montos) y uno pequeño (2x1). Solo sus cobros.</small></span></div>`;
}

// ===== R74 · Widget "Cobros" de la pantalla de inicio (Hoy · Próximos · Vencidos), solo del usuario =====
let widgetPlugin=null;
async function homeWidgetPlugin() {
  try { const { Capacitor, registerPlugin }=await import('@capacitor/core'); if(!Capacitor?.isNativePlatform?.())return null; widgetPlugin=widgetPlugin||registerPlugin('SubliWidget'); return { W:widgetPlugin }; } catch(_) { return null; }
}
export function sellerLabelFor(seller) { return operationalFilterOptions(allRows()).sellers.find(x=>canonicalSeller(x)===seller) || (seller ? seller.charAt(0).toUpperCase()+seller.slice(1) : ''); }
export async function updateHomeWidget() {
  const W=(await homeWidgetPlugin())?.W; if(!W)return;
  if (!state.session) { await W.update({ data:'' }); return; } // sin sesión el widget queda vacío
  if (!Array.isArray(state.clients)) return;
  const seller=reminderSeller();
  const payload=widgetPayload({ groups:groupRenewalsByClientDate(allRows()), seller, sellerLabel:sellerLabelFor(seller), now:new Date() });
  await W.update({ data:JSON.stringify(payload) });
}
