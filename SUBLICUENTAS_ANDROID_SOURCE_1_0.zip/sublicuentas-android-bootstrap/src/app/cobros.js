// R74 · Pantalla Cobros y hoja de Cobro y renovación.
import { canonicalSeller, parseDateDMY, money, operationalFilterOptions } from '../data.js';
import { groupRenewalsByClientDate, platformLabel, renewalDateForMonths, servicesForRenewalDate, buildChargeMessage, chargePlatformName, randomChargeVariant, renewalGroupKeyOf } from '../operations.js';
import { cobrosScreenHtml, platformLogoHtml } from '../screens2.js';
import { state, allRows, rowKey, esc, ui } from './core.js';
import { CRM_ICO, svg } from './icons.js';

export function renewalGroups(filter=state.renewFilter) {
  const sellerNorm=canonicalSeller(state.renewSeller||'');
  const rows=sellerNorm ? allRows().filter(r=>canonicalSeller(r.vendedor)===sellerNorm) : allRows();
  const groups=groupRenewalsByClientDate(rows);
  const base=new Date();base.setHours(12,0,0,0);
  const parsed=groups.map(g=>({g,d:parseDateDMY(g.fechaRenovacion)})).filter(x=>x.d);
  if(filter==='hoy')return parsed.filter(x=>Math.round((x.d-base)/86400000)===0).map(x=>x.g);
  if(filter==='vencidos')return parsed.filter(x=>x.d<base).sort((a,b)=>a.d-b.d).map(x=>x.g);
  const future=parsed.filter(x=>x.d>base).sort((a,b)=>a.d-b.d); if(!future.length)return[];
  const first=future[0].d.toDateString();return future.filter(x=>x.d.toDateString()===first).map(x=>x.g);
}
export function renewalCounts() { return {hoy:renewalGroups('hoy').length,proximo:renewalGroups('proximo').length,vencidos:renewalGroups('vencidos').length}; }
export function renewView() {
  const groups=renewalGroups();
  const long=d=>{const t=d.toLocaleDateString('es-HN',{weekday:'long',day:'numeric',month:'long'});return t.charAt(0).toUpperCase()+t.slice(1);};
  const first=groups[0]?parseDateDMY(groups[0].fechaRenovacion):null;
  const heading=state.renewFilter==='hoy'?long(new Date()):state.renewFilter==='vencidos'?'Vencidos':(first?long(first):'Próximo');
  const rows=groups.slice(0,120).map(g=>{const d=parseDateDMY(g.fechaRenovacion);return {key:g.key,day:d?d.getDate():'—',mon:d?d.toLocaleDateString('es-HN',{month:'short'}).replace('.','').toUpperCase():'',nombre:g.nombre,tercero:g.esTercero?g.titularNombre:'',plataformas:g.servicios.map(x=>platformLabel(x.plataforma)||x.plataforma).join(' + '),nServicios:g.servicios.length,nTotal:g.serviciosCliente.length,total:money(g.total)};});
  return cobrosScreenHtml({counts:renewalCounts(),filter:state.renewFilter,seller:state.renewSeller,sellers:operationalFilterOptions(allRows()).sellers,groups:rows,heading,headingCount:groups.length});
}
export function activeRenewGroup() {
  if(!state.renewGroupKey)return null;
  return groupRenewalsByClientDate(allRows()).find(g=>g.key===state.renewGroupKey) || null;
}
export const RENEW_MONTHS=['ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEPT','OCT','NOV','DIC'];
export function renewPickLabel(p={}) { return p.exactDate?`hasta ${p.exactDate}`:p.months?`+${p.months} meses`:`+${p.days||30} días`; }
export function renewPreviewDate(fecha='',p={}) {
  if(p.exactDate)return p.exactDate;
  if(p.months)return renewalDateForMonths(fecha,p.months)||'';
  const d=parseDateDMY(fecha); if(!d)return '';
  d.setDate(d.getDate()+Number(p.days||30));
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}
export function renewPickEquals(a={},b={}) { return (a.exactDate||'')===(b.exactDate||'') && Number(a.months||0)===Number(b.months||0) && Number(a.days||0)===Number(b.days||0); }
export function renewChargeGroup() { // el mismo grupo que se ve en pantalla: solo los servicios de esa fecha
  const raw=activeRenewGroup(); if(!raw)return null;
  const due=servicesForRenewalDate(raw.servicios,raw.fechaRenovacion);
  return {...raw,servicios:due,total:due.reduce((sum,row)=>sum+(Number(row.precio)||0),0)};
}
export function renewalSheet() {
  const raw=activeRenewGroup(); if(!raw)return '';
  const dueServices=servicesForRenewalDate(raw.servicios,raw.fechaRenovacion);
  const g={...raw,servicios:dueServices,total:dueServices.reduce((sum,row)=>sum+(Number(row.precio)||0),0)};
  const selected=new Set(state.renewSelection.length?state.renewSelection:g.servicios.map(rowKey));
  const msg=state.renewMessage || buildChargeMessage(g,state.renewMessageVariant);
  const pick=state.renewPick||{days:30};
  const date=parseDateDMY(g.fechaRenovacion);
  const today=new Date(); today.setHours(12,0,0,0);
  const diff=date?Math.round((date-today)/86400000):null;
  const tone=diff===null?'blue':diff<0?'red':diff===0?'orange':'blue';
  const first=g.servicios[0]||{};
  const names=g.servicios.map(s=>chargePlatformName(s.plataforma)).join(' + ');
  const preview=renewPreviewDate(g.fechaRenovacion,pick);
  const busy=state.mutating;
  const ico={
    back:'<path d="m15 5-7 7 7 7"/>', dots:'<circle cx="12" cy="5" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="19" r="1.6" fill="currentColor"/>',
    chat:'<path d="M20 12a8 8 0 0 1-11.8 7L4 20l1.1-3.8A8 8 0 1 1 20 12Z"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01"/>',
    copy:CRM_ICO.copy, doc:CRM_ICO.doc, wa:CRM_ICO.wa, cal:CRM_ICO.calendar, refresh:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
    ban:'<circle cx="12" cy="12" r="8.5"/><path d="m6 6 12 12"/>', gear:'<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>',
    check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>', edit:'<path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>'
  };
  const presets=[[{days:30},'+30 días',ico.refresh],[{days:31},'+31 días',ico.cal],[{months:2},'+2 meses',ico.cal],[{months:3},'+3 meses',ico.cal]];
  const presetBtn=([p,label,path])=>`<button type="button" class="rn-preset ${renewPickEquals(pick,p)?'on':''}" ${p.days?`data-renew-days="${p.days}"`:`data-renew-months="${p.months}"`} ${busy?'disabled':''}>${svg(path,20)}<span>${label}</span></button>`;
  return `<div class="sheet-backdrop renew-backdrop" id="closeSheet"><section class="bottom-sheet renewal-full-sheet rn-sheet" role="dialog" aria-modal="true" aria-label="Cobro y Renovación" onclick="event.stopPropagation()">
    <header class="rn-top"><button type="button" class="rn-iconbtn" id="renewBack" aria-label="Volver">${svg(ico.back,22)}</button><h2>Cobro y Renovación</h2><button type="button" class="rn-iconbtn" id="renewMenuBtn" aria-label="Más opciones" aria-expanded="${state.renewMenu?'true':'false'}">${svg(ico.dots,22)}</button>
      ${state.renewMenu?`<div class="rn-menu" role="menu"><button type="button" id="renewOpenCrm" role="menuitem">${svg(ico.check,18)} Ficha CRM + WhatsApp grupo</button><button type="button" id="renewEditService" role="menuitem">${svg(ico.edit,18)} Editar ficha del servicio</button><button type="button" id="toggleRenewManage" role="menuitem">${svg(ico.gear,18)} ${state.renewManage?'Ocultar gestión':'Gestionar servicios'}</button></div>`:''}
    </header>
    <section class="rn-client t-${tone}">
      <div class="rn-cal"><i></i><b>${date?date.getDate():'—'}</b><small>${date?RENEW_MONTHS[date.getMonth()]:'SIN FECHA'}</small></div>
      <div class="rn-client-txt"><h3>${esc(g.nombre)}</h3>${g.esTercero?`<small class="rn-tercero">🔑 Tercero · titular: ${esc(g.titularNombre)}</small>`:''}<p>${esc(names||'—')} · ${esc(g.fechaRenovacion||'sin fecha')}</p><b>${money(g.total)}</b>${diff!==null?`<em class="rn-due">${diff<0?`Vencido hace ${-diff} día${diff===-1?'':'s'}`:diff===0?'Vence hoy':diff===1?'Vence mañana':`Vence en ${diff} días`}</em>`:''}</div>
      <div class="rn-logo">${platformLogoHtml(first.plataforma,platformLabel(first.plataforma),'rn-logo-img')}${g.servicios.length>1?`<span class="rn-count">+${g.servicios.length-1}</span>`:''}</div>
    </section>
    ${state.renewManage?`<section class="renew-manage rn-manage"><p class="muted note">Quite con “No renovó” los servicios que ya no continuarán. Deje marcados los que sí se renovarán.</p>${g.serviciosCliente.map(row=>`<article class="manage-service"><label><input type="checkbox" data-renew-select="${esc(rowKey(row))}" ${selected.has(rowKey(row))?'checked':''}><span><strong>${esc(platformLabel(row.plataforma))}</strong><small>${money(row.precio)} · ${esc(row.fechaRenovacion||'sin fecha')} · ${row.perfiles?.length||1} perfil${(row.perfiles?.length||1)===1?'':'es'} · ${esc(row.vendedor||'Sin vendedor')}</small></span></label><div><button type="button" class="secondary mini" data-edit-service="${esc(rowKey(row))}">✏️ Editar</button><button type="button" class="danger-btn mini" data-no-renew="${esc(rowKey(row))}">🗑️ No renovó</button></div></article>`).join('')}</section>`:''}
    <section class="rn-msgcard">
      <header><span class="rn-msg-ico">${svg(ico.chat,22)}</span><b>Mensaje de cobro</b><button type="button" class="rn-pill" id="renewCopyPill">${svg(ico.copy,16)} Copiar</button></header>
      <textarea id="renewChargeText" rows="5" aria-label="Mensaje de cobro">${esc(msg)}</textarea>
    </section>
    <div class="charge-actions rn-actions">
      <button type="button" class="rn-btn rn-style" id="renewAnotherStyle"><span class="rn-emoji">🎨</span>Otro estilo</button>
      <button type="button" class="rn-btn rn-ai" id="renewAiMessage"><span class="rn-emoji">✨</span>Mensaje IA corto</button>
      <button type="button" class="rn-btn rn-copy" id="renewCopyMessage">${svg(ico.doc,22)}Copiar</button>
      <button type="button" class="rn-btn rn-wa" id="renewOpenWhatsApp">${svg(ico.wa,24)}Abrir WhatsApp</button>
    </div>
    <section class="renew-options rn-renew">
      <p class="rn-renew-title"><span class="rn-dollar">$</span>¿Ya pagó? Elija cuánto renovar:</p>
      <div class="renew-preset-grid rn-presets">${presets.map(presetBtn).join('')}</div>
      <details class="rn-calendar" ${pick.exactDate||state.renewCalOpen?'open':''} id="renewCalDetails"><summary>${svg(ico.cal,22)}<span>${pick.exactDate?`Fecha elegida: ${esc(pick.exactDate)}`:'Elegir fecha en calendario'}</span></summary><input id="renewExactDate" type="date" value="${pick.exactDate?pick.exactDate.split('/').reverse().join('-'):''}" aria-label="Fecha exacta de renovación"></details>
      <p class="rn-preview">${preview?`Nueva fecha: <b>${esc(preview)}</b> · ${esc(renewPickLabel(pick))}`:`Se renovará ${esc(renewPickLabel(pick))}`}${selected.size>1?` · ${selected.size} servicios`:''}</p>
    </section>
    <button type="button" class="rn-big rn-go" id="renewApply" ${busy?'disabled':''}>${svg(ico.refresh,24)}${busy?'Renovando…':'Renovar a fecha elegida'}</button>
    <button type="button" class="rn-big rn-no" id="renewNoRenewAll" ${busy?'disabled':''}>${svg(ico.ban,24)}No renovó</button>
    <button type="button" class="rn-big rn-close" id="cancelRenew">Cerrar</button>
  </section></div>`;
}
export function openRenewGroup(key) {
  const g=groupRenewalsByClientDate(allRows()).find(x=>x.key===key); if(!g)return;
  state.renewGroupKey=g.key; state.renewSelection=g.servicios.map(rowKey); state.renewManage=false; state.renewMenu=false; state.renewCalOpen=false; state.renewPick={days:30}; state.renewMessageVariant=randomChargeVariant(); state.renewMessageHistory=[]; state.renewMessage=buildChargeMessage(renewChargeGroup()||g,state.renewMessageVariant); ui.render();
}
export function openRenewForRow(row) {
  if(!row)return;
  const key=renewalGroupKeyOf(row); const g=groupRenewalsByClientDate(allRows()).find(x=>x.key===key); // R72: respeta titular / tercero
  if(g)openRenewGroup(g.key);
}
