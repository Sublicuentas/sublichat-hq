// E1 · Selector de vendedor (render 05): hoja de selección ÚNICA con lista vertical y scroll.
// · La lista sale del <select> real de la pantalla (vendedores del backend); no se inventan nombres ni fotos.
// · «Seleccionar» aplica (dispara el mismo 'change' que ya escuchaba la pantalla). ✕ o tocar fuera cancela sin cambios.
// · Avatares: iniciales neutras (nunca retratos LEGO como identidad).
import { esc } from './core.js';

const iniciales = (n) => String(n || '').trim().split(/\s+/).slice(0, 2).map((p) => p[0] || '').join('').toUpperCase() || '·';
let abierto = null;
const TODOS_SVG = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="17" cy="9" r="2.6"/><path d="M15.5 14.2c2.4-.3 4.4 1.2 5 4.3"/></svg>';

function cerrar() { abierto?.remove(); abierto = null; document.documentElement.classList.remove('sp-open'); }

export function abrirSelectorVendedor(select) {
  if (!select) return;
  cerrar();
  let elegido = select.value;
  const opciones = [...select.options].map((o) => ({ v: o.value, t: o.textContent || 'Todos' }));
  const fila = (o) => `<button type="button" role="radio" class="sp-row ${o.v === elegido ? 'on' : ''}" data-sp-v="${esc(o.v)}" aria-checked="${o.v === elegido}">
      <span class="sp-av ${o.v ? '' : 'todos'}" aria-hidden="true">${o.v ? esc(iniciales(o.t)) : TODOS_SVG}</span><span class="sp-name">${esc(o.t)}</span><span class="sp-radio" aria-hidden="true"></span></button>`;
  const el = document.createElement('div');
  el.className = 'sp-back';
  el.innerHTML = `<section class="sp-sheet" role="dialog" aria-modal="true" aria-labelledby="spTitle">
    <header class="sp-head"><h2 id="spTitle">Seleccionar vendedor</h2><button type="button" class="sp-x" data-sp-cerrar aria-label="Cerrar sin cambios">✕</button></header>
    <div class="sp-list" role="radiogroup" aria-label="Vendedores">${opciones.map(fila).join('')}</div>
    <footer class="sp-foot"><button type="button" class="sp-ok" data-sp-ok>✓ Seleccionar</button></footer></section>`;
  el.addEventListener('click', (e) => {
    if (e.target === el || e.target.closest('[data-sp-cerrar]')) { cerrar(); return; }
    const r = e.target.closest('[data-sp-v]');
    if (r) { elegido = r.dataset.spV; el.querySelectorAll('.sp-row').forEach((b) => { const on = b === r; b.classList.toggle('on', on); b.setAttribute('aria-checked', String(on)); }); return; }
    if (e.target.closest('[data-sp-ok]')) {
      const cambio = select.value !== elegido; cerrar();
      if (cambio && select.isConnected) { select.value = elegido; select.dispatchEvent(new Event('change', { bubbles: true })); }
    }
  });
  document.body.appendChild(el); abierto = el; document.documentElement.classList.add('sp-open');
  el.querySelector('.sp-row.on')?.scrollIntoView?.({ block: 'nearest' });
  el.querySelector('.sp-row.on, .sp-row')?.focus?.();
}

if (typeof document !== 'undefined') {
  document.addEventListener('click', (e) => {
    const b = e.target.closest?.('[data-seller-picker]'); if (!b) return;
    e.preventDefault(); abrirSelectorVendedor(document.getElementById(b.dataset.sellerPicker));
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && abierto) cerrar(); });
  window.addEventListener('popstate', cerrar);
}
