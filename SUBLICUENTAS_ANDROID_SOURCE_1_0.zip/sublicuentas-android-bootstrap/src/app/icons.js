// R74 · Íconos SVG e imágenes de navegación (sin estado).

export const svg = (body, size=22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
export function icon(name, size=22) {
  const icons = {
    home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-6h5v6"/>',
    users:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.6-3.3 2.5-5 5.5-5s4.9 1.7 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.7c2.9-.6 5 .9 5.5 4.3"/>',
    renew:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
    catalog:'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
    more:'<circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
    search:'<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
    refresh:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
    box:'<path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7"/><path d="M12 11v10"/>',
    finance:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 9h8M8 13h3M8 17h8"/>',
    ticket:'<path d="M4 6h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4V6Z"/><path d="M12 8v8"/>',
    gift:'<rect x="4" y="10" width="16" height="10" rx="2"/><path d="M12 10v10M3 10h18v-3H3z"/><path d="M12 7c-1.5-4-6-4-6-1.5S9 7 12 7Zm0 0c1.5-4 6-4 6-1.5S15 7 12 7Z"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4.5 21c.8-4.4 3.3-6.5 7.5-6.5s6.7 2.1 7.5 6.5"/>',
    chevron:'<path d="m9 6 6 6-6 6"/>',
    back:'<path d="m15 6-6 6 6 6"/>',
    close:'<path d="M6 6l12 12M18 6 6 18"/>',
    phone:'<path d="M6.5 3.5 10 7l-2 3c1.4 2.8 3.2 4.6 6 6l3-2 3.5 3.5-2.2 3c-.7 1-2 1.4-3.2 1C8.6 19.4 4.6 15.4 2.5 8.9c-.4-1.2 0-2.5 1-3.2l3-2.2Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
    logout:'<path d="M10 4H5v16h5"/><path d="m14 8 4 4-4 4M18 12H9"/>',
    cloud:'<path d="M7 18h10a4 4 0 0 0 .6-8 6 6 0 0 0-11.5 1A3.5 3.5 0 0 0 7 18Z"/>',
    alert:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17h.01"/>',
    add:'<circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/>',
    eye:'<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/>',
  };
  return svg(icons[name] || icons.more, size);
}
export function metricIcon(name) {
  const icons = {
    calendar:`<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><rect x="4" y="9" width="40" height="34" rx="10" fill="#e2231a"/><rect x="9" y="18" width="30" height="20" rx="5" fill="#fff"/><rect x="12.5" y="22" width="6" height="6" rx="2" fill="#8f93da"/><rect x="21" y="22" width="6" height="6" rx="2" fill="#c48fd6"/><rect x="29.5" y="22" width="6" height="6" rx="2" fill="#c48fd6"/><rect x="12.5" y="29.5" width="6" height="6" rx="2" fill="#c48fd6"/><rect x="21" y="29.5" width="6" height="6" rx="2" fill="#e79bab"/><rect x="29.5" y="29.5" width="6" height="6" rx="2" fill="#f2b23c"/><rect x="14" y="4" width="5" height="10" rx="2.5" fill="#9aa0a6"/><rect x="29" y="4" width="5" height="10" rx="2.5" fill="#9aa0a6"/></svg>`,
    clock:`<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="24" cy="24" r="20" fill="#1f88e6"/><circle cx="24" cy="24" r="14.5" fill="#fff"/><path d="M24 15.5v9.2l6.4 3.6" stroke="#1f88e6" stroke-width="3.3" stroke-linecap="round" fill="none"/></svg>`,
    alert:`<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M24 5 45 41H3Z" fill="#f5a623"/><rect x="21.3" y="17" width="5.4" height="13" rx="2.7" fill="#fff"/><circle cx="24" cy="34.5" r="2.8" fill="#fff"/></svg>`,
    target:`<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="24" cy="24" r="19" fill="#e2231a"/><circle cx="24" cy="24" r="13.5" fill="#fff"/><circle cx="24" cy="24" r="8" fill="#e2231a"/><circle cx="24" cy="24" r="3" fill="#fff"/><path d="M35 8 24 24" stroke="#1f88e6" stroke-width="4" stroke-linecap="round"/><path d="M35 8 29.5 7.2 34.2 3Z" fill="#1f88e6"/></svg>`,
  };
  return icons[name] || '';
}
export const metricWave = () => `<svg class="mcard-wave" viewBox="0 0 100 32" preserveAspectRatio="none" aria-hidden="true"><path fill="currentColor" d="M0,16 C18,30 34,2 52,14 C70,26 84,6 100,16 L100,32 L0,32 Z"/></svg>`;
export const NAV_ICON_ASSET = { home:'nav-inicio.png', users:'nav-clientes.png', renew:'nav-cobros.png', ticket:'nav-tickets.png', more:'nav-mas.png' };
export function navIcon(key) {
  const asset = NAV_ICON_ASSET[key];
  if (!asset) return icon(key, 22);
  return `<img class="bottom-nav-icon" src="/assets/${asset}" alt="" aria-hidden="true">`;
}
/* ═════════════ NUEVA VENTA · ficha CRM (diseño R50) ═════════════ */
export const CRM_ICO = {
  user:'<circle cx="12" cy="8" r="4"/><path d="M4.5 21c.8-4.4 3.3-6.5 7.5-6.5s6.7 2.1 7.5 6.5"/>',
  phone:'<path d="M6.5 3.5 10 7l-2 3c1.4 2.8 3.2 4.6 6 6l3-2 3.5 3.5-2.2 3c-.7 1-2 1.4-3.2 1C8.6 19.4 4.6 15.4 2.5 8.9c-.4-1.2 0-2.5 1-3.2l3-2.2Z"/>',
  users:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.6-3.3 2.5-5 5.5-5s4.9 1.7 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.7c2.9-.6 5 .9 5.5 4.3"/>',
  store:'<path d="M4 9.5 5.5 4h13L20 9.5"/><path d="M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0"/><path d="M5.5 12v8h13v-8"/><path d="M10 20v-4.5h4V20"/>',
  box:'<path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7"/><path d="M12 11v10"/>',
  search:'<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
  eye:'<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/>',
  dollar:'<circle cx="12" cy="12" r="9"/><path d="M15 8.8c-.6-.9-1.7-1.4-3-1.4-1.8 0-3 .9-3 2.2 0 3 6 1.6 6 4.6 0 1.3-1.3 2.3-3.1 2.3-1.4 0-2.6-.6-3.2-1.6M12 5.5v13"/>',
  calendar:'<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M7.5 3v4M16.5 3v4M3.5 10h17M8 14h.01M12 14h.01M16 14h.01M8 17h.01M12 17h.01"/>',
  refresh:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8.5-8.5M16.5 6.5 19 9M14 9l2 2"/>',
  mail:'<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="m4 7 8 6 8-6"/>',
  link:'<path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/><path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/>',
  copy:'<rect x="8.5" y="8.5" width="12" height="12" rx="2.5"/><path d="M15.5 8.5V6a2.5 2.5 0 0 0-2.5-2.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>',
  doc:'<path d="M14 3.5H7A2.5 2.5 0 0 0 4.5 6v12A2.5 2.5 0 0 0 7 20.5h10a2.5 2.5 0 0 0 2.5-2.5V9L14 3.5Z"/><path d="M14 3.5V9h5.5M8.5 13h7M8.5 16.5h5"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  save:'<path d="M5 3.5h11l3.5 3.5v11A2.5 2.5 0 0 1 17 20.5H7A2.5 2.5 0 0 1 4.5 18V6"/><path d="M8 3.5v5h7v-5M8 20.5v-6h8v6"/>',
  send:'<path d="M21 3 10.5 13.5"/><path d="M21 3 14.5 21l-4-7.5L3 9.5 21 3Z"/>',
  list:'<path d="M9 6.5h11M9 12h11M9 17.5h11"/><circle cx="4.5" cy="6.5" r="1" fill="currentColor"/><circle cx="4.5" cy="12" r="1" fill="currentColor"/><circle cx="4.5" cy="17.5" r="1" fill="currentColor"/>',
  hash:'<path d="M9 3.5 7 20.5M17 3.5l-2 17M4 9h16.5M3.5 15H20"/>',
  tv:'<rect x="3" y="4.5" width="18" height="12" rx="2"/><path d="M8.5 20.5h7M12 16.5v4"/>',
  wa:'<path d="M20.5 11.7a8.5 8.5 0 0 1-12.6 7.5L3.5 20.5l1.3-4.3a8.5 8.5 0 1 1 15.7-4.5Z"/><path d="M9 8.5c.2 3.4 2.9 6.2 6.5 6.6l1-1.6-1.9-1-.9.8c-1-.4-1.9-1.3-2.4-2.4l.8-.9-.9-1.9-1.7.9"/>',
  close:'<path d="M6 6l12 12M18 6 6 18"/>',
  trash:'<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13"/>',
};
export function crmIco(name,size=18){ return svg(CRM_ICO[name]||'',size); }
