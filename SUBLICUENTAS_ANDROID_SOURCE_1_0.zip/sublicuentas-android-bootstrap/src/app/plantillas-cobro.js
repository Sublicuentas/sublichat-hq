// R196r · Plantillas de mensajes de cobro por parámetros (ocasión · tono · longitud).
// Biblioteca FINITA pero amplia: cada tono tiene sus propias aperturas, cierres y cortesías; la ocasión cambia
// la frase que introduce el detalle. Los datos (cliente, servicios, fecha, total) salen SIEMPRE de la ficha:
// las frases nunca inventan beneficios, descuentos, plazos ni métodos de pago.
import { chargePlatformName } from '../operations.js';
import { parseDateDMY } from '../data.js';

export const OCASIONES = [['renovacion', 'Renovación'], ['recordatorio', 'Recordatorio'], ['vencido', 'Servicio vencido'], ['agradecimiento', 'Agradecimiento']];
export const TONOS = [['amigable', 'Amigable'], ['formal', 'Formal'], ['entusiasta', 'Entusiasta'], ['directo', 'Directo'], ['cercano', 'Cercano']];
export const LONGITUDES = [['corta', 'Corta'], ['media', 'Media'], ['larga', 'Larga']];
export const PARAMS_DEFECTO = { ocasion: 'renovacion', tono: 'amigable', longitud: 'media' };

const APERTURAS = {
  amigable: ['🎬 Hola, {n}. *Que continúe su entretenimiento premium* ✨', '😊 ¡Hola, {n}! Pasamos a saludarle 👋', '🍿 {n}, *sus historias favoritas pueden continuar* ✨', '🌟 Hola, {n}. Gracias por seguir con nosotros 💙', '☀️ {n}, le escribimos con mucho gusto 😊', '🎞️ ¡Qué tal, {n}! Un mensajito rápido 📲', '🙌 {n}, que no se detenga lo que más disfruta 🎬', '🌈 Hola, {n}. *Su pantalla favorita le espera* ✨', '👋 {n}, un gusto saludarle otra vez 🙂', '🧡 Saludos, {n}. Aquí le dejamos su detalle 📝'],
  formal: ['📌 Estimado(a) {n}, reciba un cordial saludo.', '🗂️ Buen día, {n}. Le compartimos el estado de su servicio.', '📄 Estimado(a) {n}, le escribimos por su suscripción.', '🔔 {n}, le saludamos de parte de Sublicuentas.', '🗓️ Reciba un cordial saludo, {n}.', '📋 Estimado(a) {n}, le informamos lo siguiente.', '🤝 {n}, agradecemos su confianza en nuestro servicio.', '✉️ Buen día, {n}. Le contactamos por su cuenta.', '🏷️ Estimado(a) {n}, este es el detalle de su plan.', '📎 {n}, le hacemos llegar esta información.'],
  entusiasta: ['🎉 ¡Hola, {n}! *Otro mes de diversión le espera* 🍿', '🚀 ¡{n}, que siga la función! 🎬', '🔥 ¡Hola, {n}! *Lo mejor del entretenimiento sigue aquí* ✨', '🥳 ¡{n}! Su próxima temporada ya casi empieza 📺', '⭐ ¡Hola, {n}! *Seguimos con todo* 🎞️', '🎊 ¡{n}, a seguir disfrutando sin pausas! 🍿', '💥 ¡Hola, {n}! Que no pare la diversión 🎬', '🌟 ¡{n}! *Sus estrenos favoritos le esperan* ✨', '🎈 ¡Hola, {n}! Le traemos su renovación lista 🙌', '🏆 ¡{n}, usted es de nuestros clientes favoritos! ⭐'],
  directo: ['📍 {n}:', '🔹 Hola, {n}.', '📌 {n}, detalle rápido:', '⚡ {n}, en corto:', '🗒️ Hola, {n}. Resumen:', '🔸 {n}, su servicio:', '✅ Hola, {n}.', '🧾 {n}, le dejamos el dato:', '🕒 {n}, aviso breve:', '📲 Hola, {n}. Rapidito:'],
  cercano: ['🤗 ¡Hola, {n}! ¿Cómo le va?', '☕ {n}, espero que esté muy bien.', '💙 Hola, {n}. Siempre es un gusto escribirle.', '🙂 {n}, ¿qué tal su semana?', '🌺 ¡Hola, {n}! Espero que todo marche bien.', '🤝 {n}, gracias por estar con nosotros.', '🌙 Hola, {n}. Le escribo un momentito.', '🍀 {n}, le mando un saludo bonito.', '💬 ¡Hola, {n}! Le cuento rapidito.', '😄 {n}, qué gusto saludarle.'],
};
// Frase que introduce el detalle: depende de la ocasión (no cambia los datos).
const ENTRADAS = {
  renovacion: ['Su renovación:', 'Le compartimos su renovación:', 'Para continuar:', 'Detalle de su renovación:'],
  recordatorio: ['Le recordamos que', 'Solo para recordarle:', 'Recordatorio:', 'Para que no se le pase:'],
  vencido: ['Para reactivar su servicio:', 'Su servicio necesita renovación:', 'Para retomar su acceso:', 'Pendiente de renovar:'],
  agradecimiento: ['Gracias por su preferencia. Su renovación:', 'Agradecemos su confianza. Detalle:', 'Gracias por seguir con nosotros:', 'Con gratitud le recordamos:'],
};
const CUERPOS = ['{e} {d} · {m}.', '{e} {d}, total {m}.', '{e} {d}; renovación {m}.', '{e} {d} · valor {m}.', '{e} {d}. El total es {m}.', '{e} {d}; monto {m}.', '{e} {d} · {m} en total.', '{e} {d}, por {m}.'];
const CIERRES = {
  amigable: ['¿Desea renovar? ✅', '¿Renovamos hoy? 🍿', '¿Le ayudamos a renovar? 💫', '¿Seguimos disfrutando? 🎬', 'Quedamos atentos 😊', '¿Lo dejamos activo? ✨', 'Nos avisa y lo renovamos 🙌', '¿Continuamos? 💙'],
  formal: ['¿Desea confirmar la renovación?', 'Quedamos atentos a su confirmación.', 'Agradeceremos su respuesta.', '¿Procedemos con la renovación?', 'Estamos a sus órdenes.', 'Quedamos pendientes de su indicación.', '¿Nos confirma, por favor?', 'Saludos cordiales.'],
  entusiasta: ['¿Seguimos con la función? 🎬', '¡Un *SÍ* y lo dejamos listo! 🙌', '¿Renovamos de una vez? 🚀', '¡Vamos por otro mes! 🥳', '¿Le damos play otra vez? ▶️', '¡Avísenos y queda activo! ⚡', '¿Confirmamos? 🎉', '¡Que siga la diversión! ¿Renovamos? 🍿'],
  directo: ['¿Renovamos?', '¿Confirma?', 'Responda *SÍ* para renovar.', '¿Lo dejamos activo?', 'Quedo atento.', '¿Procedemos?', 'Avíseme para renovar.', '¿Seguimos?'],
  cercano: ['¿Le parece si lo renovamos? 🙂', 'Me avisa cuando guste 🤗', '¿Lo dejamos listo? 💙', 'Aquí estoy para ayudarle 🤝', '¿Seguimos juntos otro mes? 🌺', 'Cualquier cosita, me escribe ☕', '¿Le renuevo de una vez? 😊', 'Quedo pendiente de usted 🍀'],
};
// Solo en «Larga»: cortesía sin promesas (nada de beneficios, descuentos ni plazos).
const CORTESIAS = {
  amigable: ['Cualquier duda, con gusto le atendemos 🤝', 'Gracias por su confianza de siempre 🙏', 'Estamos para servirle 😊', 'Que tenga un excelente día ☀️'],
  formal: ['Para cualquier consulta, quedamos a su disposición.', 'Gracias por confiar en Sublicuentas.', 'Atentamente, Sublicuentas.', 'Le agradecemos su atención.'],
  entusiasta: ['¡Gracias por ser parte de Sublicuentas! 💙', '¡Estamos felices de tenerle con nosotros! 🎉', '¡Que disfrute mucho! 🍿', '¡Gracias por su confianza! ⭐'],
  directo: ['Gracias.', 'Quedo atento a su respuesta.', 'Saludos.', 'Gracias por su atención.'],
  cercano: ['Un abrazo y gracias por todo 💙', 'Que tenga un día muy bonito 🌺', 'Siempre es un gusto atenderle 🤗', 'Gracias por seguir con nosotros 🍀'],
};

const pick = (arr, k) => arr[((k % arr.length) + arr.length) % arr.length];
const okParam = (lista, v, def) => (lista.some(([id]) => id === v) ? v : def);
export function normalizarParams(p = {}) {
  return { ocasion: okParam(OCASIONES, p.ocasion, PARAMS_DEFECTO.ocasion), tono: okParam(TONOS, p.tono, PARAMS_DEFECTO.tono), longitud: okParam(LONGITUDES, p.longitud, PARAMS_DEFECTO.longitud) };
}

// Combinaciones reales (se muestra este número; nada de «infinitos»).
export function totalCombinaciones() {
  let total = 0;
  for (const [t] of TONOS) for (const [o] of OCASIONES) {
    const base = APERTURAS[t].length * ENTRADAS[o].length * CUERPOS.length * CIERRES[t].length;
    total += base /* corta: apertura+cuerpo+cierre en una línea */ + base /* media */ + base * CORTESIAS[t].length /* larga */;
  }
  return total;
}
export function combinacionesPorTono(params = {}) {
  const { ocasion, tono, longitud } = normalizarParams(params);
  const base = APERTURAS[tono].length * ENTRADAS[ocasion].length * CUERPOS.length * CIERRES[tono].length;
  return longitud === 'larga' ? base * CORTESIAS[tono].length : base;
}

const fmtL = (v) => `L${Number(v || 0).toLocaleString('es-HN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
function momento(raw = '', plural = false) {
  const date = parseDateDMY(raw);
  if (!date) return plural ? 'tienen fecha por confirmar' : 'tiene fecha por confirmar';
  const hoy = new Date(); hoy.setHours(12, 0, 0, 0); const d = new Date(date); d.setHours(12, 0, 0, 0);
  const diff = Math.round((d - hoy) / 86400000);
  const f = `*${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}*`;
  if (diff < 0) return plural ? `vencieron el ${f}` : `venció el ${f}`;
  if (diff === 0) return plural ? 'vencen *hoy*' : 'vence *hoy*';
  if (diff === 1) return plural ? 'vencen *mañana*' : 'vence *mañana*';
  return plural ? `renuevan el ${f}` : `renueva el ${f}`;
}
function servicios(group = {}) { return (Array.isArray(group.servicios) && group.servicios.length ? group.servicios : [group]).filter(Boolean); }
function etiquetaServicios(svcs = []) {
  if (svcs.length === 1) { const s = svcs[0] || {}; const q = Number(s.perfiles?.length || s.cantidadPerfiles || 1); return `${chargePlatformName(s.plataforma)}${q > 1 ? ` · ${q} perfiles` : ''}`; }
  const c = new Map(); for (const s of svcs) { const n = chargePlatformName(s?.plataforma); c.set(n, (c.get(n) || 0) + 1); }
  return [...c.entries()].map(([n, k]) => (k > 1 ? `${k} ${n}` : n)).join(' + ');
}
export function datosMensaje(group = {}) {
  const svcs = servicios(group);
  const total = Number(group.total ?? svcs.reduce((s, x) => s + Number(x.precio || 0), 0)) || 0;
  return { nombre: String(group.nombre || 'Cliente'), servicios: etiquetaServicios(svcs), momento: momento(group.fechaRenovacion || svcs[0]?.fechaRenovacion || '', svcs.length > 1), total: fmtL(total) };
}

// Mezcla de 32 bits: semillas consecutivas dan combinaciones lejanas (no «la siguiente de la lista»).
function mezclar(seed) { let x = (Number(seed) >>> 0) || 1; x ^= x << 13; x >>>= 0; x ^= x >>> 17; x ^= x << 5; x >>>= 0; return x; }
export function generarPlantilla(group = {}, params = {}, seed = 0) {
  const { ocasion, tono, longitud } = normalizarParams(params);
  const d = datosMensaje(group);
  let h = mezclar(seed + 0x9e37);
  const nx = (n) => { const v = h % n; h = mezclar(h + 0x632b); return v; };
  const ap = pick(APERTURAS[tono], nx(APERTURAS[tono].length)).replaceAll('{n}', `*${d.nombre}*`);
  const en = pick(ENTRADAS[ocasion], nx(ENTRADAS[ocasion].length));
  const det = `*${d.servicios}* ${d.momento}`;
  const cu = pick(CUERPOS, nx(CUERPOS.length)).replace('{e}', en).replace('{d}', det).replace('{m}', `*${d.total}*`);
  const ci = pick(CIERRES[tono], nx(CIERRES[tono].length));
  if (longitud === 'corta') return `${ap} ${cu} ${ci}`.replace(/\s+/g, ' ').trim();
  if (longitud === 'larga') return `${ap}\n${cu} ${ci}\n${pick(CORTESIAS[tono], nx(CORTESIAS[tono].length))}`;
  return `${ap}\n${cu} ${ci}`;
}
export const normalizarTexto = (t) => String(t || '').toLowerCase().replace(/\s+/g, ' ').trim();
export function semillaAleatoria() { try { const a = new Uint32Array(1); globalThis.crypto.getRandomValues(a); return a[0]; } catch (_) { return Math.floor(Math.random() * 4294967295); } }
// Siguiente plantilla que NO esté entre las usadas recientemente (por cliente/sesión).
export function siguientePlantilla(group = {}, params = {}, usados = [], semilla = semillaAleatoria()) {
  const vistos = new Set((usados || []).map(normalizarTexto));
  let s = semilla >>> 0; let texto = '';
  for (let i = 0; i < 60; i++) { texto = generarPlantilla(group, params, s); if (!vistos.has(normalizarTexto(texto))) return { texto, semilla: s }; s = mezclar(s + i + 1); }
  return { texto, semilla: s };
}
