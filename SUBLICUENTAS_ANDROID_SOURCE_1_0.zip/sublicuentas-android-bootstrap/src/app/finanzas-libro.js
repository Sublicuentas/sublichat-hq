// R104 · FINANZAS (libro mayor) dentro de Más > Control financiero — solo Sublicuentas y Relojes.
// Pestañas: Resumen · Bancos · Planilla · Movimientos · Cierre · Reportes (la vista anterior se conserva).
// Además: hoja de pago REAL al renovar (monto escrito + dónde pagó, o ajuste sin pago con motivo).
// El servidor (/api/finanzas) es la fuente de verdad: aquí solo se muestra y se arma el borrador.
import { validatePlanilla, PLANILLA_CONCEPTOS, money, estadoPago, repartoPagos } from './finanzas-reglas.js';
import { chargePlatformName } from '../operations.js'; // R192 · nombre legible de la plataforma

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const lps = (n) => { const v = money(n); return `L${v.toLocaleString('en-US', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 })}`; }; // R193 · F12: L763.10, nunca L763.1
const METHODS_KEY = 'sublicuentas-fin-metodos-v1';
function actorLabel(raw = '', origen = '') {
  const r = String(raw || '').trim();
  const k = r.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
  if (['naara', 'sublicuentas', 'sublicuentas2'].includes(k)) return 'Sublicuentas';
  if (['libni', 'daniela', 'relojes', 'finanzas'].includes(k)) return 'Relojes';
  // Socios ya vienen del backend con el nombre real; no convertirlos a una etiqueta genérica.
  return r;
}

export function isLibroUser(identity) { return ['sublicuentas', 'relojes'].includes(identity); }
export function cachedMethods() { try { return JSON.parse(localStorage.getItem(METHODS_KEY) || '[]'); } catch (_) { return []; } }
function rememberMethods(list) { try { localStorage.setItem(METHODS_KEY, JSON.stringify((list || []).map(({ id, nombre, logoKey }) => ({ id, nombre, logoKey })))); } catch (_) {} }

export function initLibroState(state) {
  if (state.libro) return;
  state.libro = { tab: 'resumen', data: null, loading: false, error: '', pend: null, pendFiltro: '', abono: null, corr: null, fechaCorr: null, movs: null, movFiltro: { tipo: '', bancoId: '', texto: '', desde: '', hasta: '' }, draft: null, ajuste: null, sending: false };
}

// ---------------------------------------------------------------- carga
export async function loadLibro(ctx, { silent = false } = {}) {
  const L = ctx.state.libro;
  if (L.loading) return;
  L.loading = true; if (!silent) ctx.render();
  try {
    // R186 · el mes calendario de Honduras viene del servidor (misma consulta que el Excel del mes).
    const [r, mes] = await Promise.all([ctx.authPost('/api/finanzas', { accion: 'finanzas_resumen' }), ctx.authPost('/api/finanzas', { accion: 'finanzas_mes' }).catch(() => null)]);
    if (!r?.ok) throw new Error(r?.error || 'No se pudo leer Finanzas.');
    L.data = r; L.error = ''; rememberMethods(r.metodos);
    L.mes = mes?.ok ? mes : null;
  } catch (e) { L.error = e?.message || 'Sin conexión con Finanzas.'; }
  finally { L.loading = false; ctx.render(); }
}
// R192 · Editar sin saltar: la fila que se corrige/anula queda en el MISMO lugar de la pantalla. Se guarda un ancla
// (id del movimiento + su posición en pantalla) y después de cada repintado se devuelve el scroll; al recargar después de
// guardar, la lista vieja se conserva mientras llega la nueva (antes se vaciaba y la pantalla subía al inicio).
export function anclaMov(id) {
  const el = id ? document.querySelector(`[data-fl-row="${CSS.escape(id)}"]`) : null;
  return { id: id || '', top: el ? el.getBoundingClientRect().top : 0, y: window.scrollY || 0 };
}
export function restaurarAncla(a) {
  if (!a) return;
  const el = a.id ? document.querySelector(`[data-fl-row="${CSS.escape(a.id)}"]`) : null;
  if (el) { const delta = el.getBoundingClientRect().top - a.top; if (Math.abs(delta) > 1) window.scrollBy(0, delta); }
  else window.scrollTo(0, a.y);
}
function conAncla(ctx, a) { return { ...ctx, render: () => { ctx.render(); restaurarAncla(a); } }; }
async function loadMovs(ctx, { silent = false } = {}) {
  const L = ctx.state.libro;
  if (silent && L.movs && Array.isArray(L.movs.rows)) L.movs = { ...L.movs, refreshing: true };
  else { L.movs = { loading: true, rows: [] }; }
  ctx.render();
  try {
    const r = await ctx.authPost('/api/finanzas', { accion: 'finanzas_movimientos', ...L.movFiltro });
    if (!r?.ok) throw new Error(r?.error || 'No se pudieron leer los movimientos.');
    // Defensa adicional: servidores anteriores podían devolver también registros kind=venta.
    // Esos documentos representan "Ventas generadas", no dinero recibido y no deben verse
    // en Movimientos (ni como "Sin banco · venta"). Los datos siguen existiendo para Resumen/Auditoría.
    const rows = (r.movimientos || []).filter((m) => m?.kind !== 'venta' && String(m?.tipo || '').toLowerCase() !== 'venta');
    L.movs = { loading: false, rows, total: rows.length };
  } catch (e) { L.movs = silent && L.movs?.rows?.length ? { ...L.movs, refreshing: false, aviso: e?.message || 'No se pudo actualizar' } : { loading: false, rows: [], error: e?.message || 'Error' }; }
  ctx.render();
}

// ---------------------------------------------------------------- vistas
// R116: orden y estilo del render (Resumen, Planilla, Movimientos, Cierre, Reportes) + Pendientes y Bancos al final.
const TABS = [['resumen', 'Resumen'], ['planilla', 'Planilla'], ['movimientos', 'Movimientos'], ['cierre', 'Cierre'], ['reportes', 'Reportes'], ['pendientes', 'Pendientes'], ['bancos', 'Bancos']];
const FL_ICON = (n) => `/assets/finanzas/${n}.png`;
const TAB_ICON = { resumen: 'icon_resumen', planilla: 'icon_planilla', movimientos: 'icon_movimientos', cierre: 'icon_cierre', reportes: 'icon_reportes', pendientes: 'icon_pendiente_clientes', bancos: 'icon_bancos' };
export function bancoLogo(b = {}) {
  const t = `${b.id || ''} ${b.logoKey || ''} ${b.nombre || ''}`.toLowerCase();
  const k = /atl[aá]ntida/.test(t) ? 'banco_atlantida' : /bac|credomatic/.test(t) ? 'bac_credomatic' : /ficohsa/.test(t) ? 'ficohsa' : /tigo/.test(t) ? 'tigo_money' : /davivienda/.test(t) ? 'davivienda' : '';
  return k ? `<img class="fl-bank-logo" src="${FL_ICON(k)}" alt="">` : '<span class="fl-bank-logo fl-bank-generic">🏦</span>';
}
// Bancos SIEMPRE de mayor a menor saldo (dinámico).
export function bancosOrdenados(bancos = []) { return [...bancos].filter((b) => b.activado).sort((a, b) => Number(b.saldo || 0) - Number(a.saldo || 0) || String(a.nombre).localeCompare(String(b.nombre))); }

export function libroViewHtml(state, reportesHtml = '') {
  const L = state.libro;
  const tabs = `<nav class="fl-tabs fl-tabs2" role="tablist">${TABS.map(([k, t]) => `<button type="button" class="fl-tab ${L.tab === k ? 'on' : ''}" data-fl-tab="${k}"><img src="${FL_ICON(TAB_ICON[k])}" alt="">${t}</button>`).join('')}</nav>`;
  if (L.tab === 'reportes') return tabs + reportesHtml;
  if (!L.data) return tabs + `<section class="fl-card">${L.error ? `<p class="fl-err">⚠️ ${esc(L.error)}</p><button class="fl-btn" data-fl-reload>Reintentar</button>` : '<p class="fl-muted">Cargando finanzas…</p>'}</section>`;
  const body = { resumen: resumenHtml, bancos: bancosHtml, pendientes: pendientesHtml, planilla: planillaHtml, movimientos: movimientosHtml, cierre: cierreHtml }[L.tab] || resumenHtml;
  return tabs + (L.error ? `<p class="fl-err">⚠️ ${esc(L.error)}</p>` : '') + body(L);
}

const MESES_TXT = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
// R192 · RESUMEN = solo el MES CALENDARIO actual en hora de Honduras (01 → 01 del mes siguiente). El ciclo (que puede
// abarcar varios meses) vive en la pestaña Cierre. Cobrado, egresos, ventas generadas y pendientes van SEPARADOS.
// Ingresos por plataforma: cada pago único cuenta UNA vez (la suma es igual a «Ingresos cobrados»).
const ultimoDia = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
export function nombrePlataformaFin(p = '') { const t = String(p || '').trim(); if (!t || /^sin plataforma$/i.test(t)) return 'Sin plataforma'; if (/^Pago combinado/i.test(t)) return t; return /\s\+\s/.test(t) ? t.split(/\s\+\s/).map((x) => chargePlatformName(x)).join(' + ') : chargePlatformName(t); }
// R193 · Ingresos cobrados por PRODUCTO canónico (lo calcula el servidor; APK = Web = Excel). «Pendiente de clasificar»
// va FUERA del ranking pero dentro del total. Una persona revisa los alias ambiguos con motivo (queda auditado).
export const MOTIVO_PEND = Object.freeze({ pago_combinado_sin_desglose: 'Pago de varios servicios sin monto por servicio', sin_plataforma: 'Sin plataforma registrada', alias_ambiguo_netflix_vip: '«Netflix Premium VIP»: ¿Premium o VIP? (revisar)', no_reconocido: 'Etiqueta no reconocida', diferencia_sin_asignar: 'Parte del pago sin asignar', pago_parcial_varios_servicios: 'Abono parcial de varios servicios' });
export function productosHtml(m, { abierto = false, revisar = false, aliasBusy = '' } = {}) {
  const P = m.pendienteClasificar || { centavos: 0, monto: 0, pagos: 0, detalle: [] };
  const ok = m.conciliacion?.productosMasPendienteIgualIngresos !== false;
  const filas = (m.cobrosPorProducto || []).map((p) => `<li class="fl-plat"><span>${esc(p.plataforma)}${p.pagos ? ` <small>${p.pagos} pago${p.pagos === 1 ? '' : 's'}</small>` : ''}</span><b>${lps(p.monto)}</b></li>`).join('');
  const amb = (m.aliasRevisados || []).filter((a) => a.motivo === 'alias_ambiguo_netflix_vip' || a.motivo === 'no_reconocido');
  const cat = m.productosCatalogo || {};
  const opciones = Object.entries(cat).map(([id, n]) => `<option value="${esc(id)}">${esc(n)}</option>`).join('');
  const revisarHtml = revisar && amb.length ? `<div class="fl-alias">${amb.map((a, i) => `<div class="fl-alias-r"><b>${esc(a.original || '(vacío)')}</b><small>${esc(MOTIVO_PEND[a.motivo] || a.motivo)} · ${a.pagos} pago(s) · ${lps(a.monto)}</small>
      <select class="fl-input" id="flAlP${i}"><option value="">¿A qué producto corresponde?</option>${opciones}</select><input class="fl-input" id="flAlM${i}" placeholder="Evidencia (obligatorio): ej. revisé las fichas">
      <button class="fl-btn" data-fl-alias="${i}" ${aliasBusy ? 'disabled' : ''}>${aliasBusy === String(i) ? 'Guardando…' : 'Confirmar alias'}</button></div>`).join('')}<small class="fl-muted">Confirmar un alias no cambia montos ni movimientos: solo dice a qué producto pertenece esa etiqueta. Queda auditado.</small></div>` : '';
  return `<b class="fl-sub-t">Ingresos cobrados por producto</b>${filas ? `<ul class="fl-plats">${filas}</ul>` : '<p class="fl-muted">Sin cobros clasificados este mes.</p>'}
    ${P.centavos ? `<div class="fl-pend"><button class="fl-pend-cab" data-fl-pend aria-expanded="${abierto}"><span>Pendiente de clasificar <small>${P.pagos} pago(s) · fuera del ranking, sí en el total</small></span><b>${lps(P.monto)}</b><i>${abierto ? '▴' : '▾'}</i></button>
      ${abierto ? `<ul class="fl-pend-l">${(P.detalle || []).slice(0, 60).map((d) => `<li><span>${esc(d.cliente || 'Cliente')} · ${esc(d.fecha || '')}<small>${esc(d.original || '—')} — ${esc(MOTIVO_PEND[d.motivo] || d.motivo)}</small></span><b>${lps(d.monto)}</b></li>`).join('')}</ul>
      ${amb.length ? `<button class="fl-btn ghost" data-fl-revisar>${revisar ? 'Ocultar revisión de etiquetas' : `Revisar etiquetas ambiguas (${amb.length})`}</button>${revisarHtml}` : ''}` : ''}</div>` : ''}
    <p class="fl-muted fl-cuadre">${ok ? '✔ Productos + pendiente = ingresos cobrados' : '⚠️ No cuadra productos + pendiente con lo cobrado: revise Movimientos.'}</p>`;
}
export function mesHtml(m, busy = false, cartera = null, opts = {}) {
  if (!m) return '';
  const [y, mm] = String(m.periodo || '').split('-');
  const nombre = `${(MESES_TXT[Number(mm) - 1] || '').replace(/^./, (c) => c.toUpperCase())} ${y || ''}`;
  const rango = y && mm ? `01 ${MESES_TXT[Number(mm) - 1].slice(0, 3)} – ${ultimoDia(+y, +mm)} ${MESES_TXT[Number(mm) - 1].slice(0, 3)} ${y}` : '';
  const cobros = Array.isArray(m.cobrosPorPlataforma) ? m.cobrosPorPlataforma : null;
  const lista = (cobros || m.porPlataforma || []);
  const fila = (p) => `<li class="fl-plat"><span>${esc(nombrePlataformaFin(p.plataforma))}</span><b>${lps(p.monto)}</b></li>`;
  const pend = cartera ? Number(cartera.pendienteTotal || 0) : null;
  return `<section class="fl-card fl-c2 fl-mes" aria-label="Finanzas del mes">
    <div class="fl-row"><b class="fl-h2"><img src="${FL_ICON('icon_resumen')}" alt="">Este mes · ${esc(nombre)}</b><span class="fl-pill">hora de Honduras</span></div>
    ${rango ? `<p class="fl-muted fl-rango">${esc(rango)}</p>` : ''}
    <div class="fl-io"><div class="fl-in"><img src="${FL_ICON('icon_ingresos')}" alt=""><span>Ingresos cobrados<b>${lps(m.ingresos)}</b></span></div><div class="fl-out"><img src="${FL_ICON('icon_egresos')}" alt=""><span>Egresos<b>${lps(m.egresos)}</b></span></div></div>
    <ul class="fl-plats fl-plats-res">
      <li class="fl-plat"><span>Planilla / comisiones del mes</span><b class="fl-neg">−${lps(m.planilla || 0)}</b></li>
      <li class="fl-plat fl-plat-total"><span>Resultado del mes</span><b>${lps(m.resultado != null ? m.resultado : (Number(m.ingresos || 0) - Number(m.egresos || 0) - Number(m.planilla || 0)))}</b></li>
      <li class="fl-plat"><span>Ventas generadas <small>(valor vendido, no es efectivo)</small></span><b>${lps(m.ventasGeneradas || 0)}</b></li>
      ${pend != null ? `<li class="fl-plat fl-warn2"><span>Pendiente total hoy <small>(NO es dinero disponible)</small></span><b>${lps(pend)}</b></li>` : ''}
    </ul>
    <p class="fl-muted">${Number(m.pagosUnicos) || 0} pago${Number(m.pagosUnicos) === 1 ? '' : 's'} real${Number(m.pagosUnicos) === 1 ? '' : 'es'} · ${Number(m.serviciosRenovadosOVendidos) || 0} servicio(s) renovados o vendidos${m.anulados ? ` · ${m.anulados} anulado(s) fuera` : ''}</p>
    ${Array.isArray(m.cobrosPorProducto) ? productosHtml(m, opts) : lista.length ? `<b class="fl-sub-t">${cobros ? 'Ingresos cobrados por plataforma' : 'Ventas por plataforma'}</b><ul class="fl-plats">${lista.map(fila).join('')}</ul>` : ''}
    ${m.conciliacion && m.conciliacion.ingresosVsPagos === false ? '<p class="fl-err">⚠️ Los cobros por banco no cuadran con los pagos: revise Movimientos.</p>' : ''}
    <button class="fl-btn" data-fl-mes-xls ${busy ? 'disabled' : ''}>${busy ? 'Preparando Excel…' : '⬇️ Descargar Excel del mes'}</button>
  </section>`;
}

function resumenHtml(L) {
  const d = L.data, c = d.cartera || {};
  const bancos = bancosOrdenados(d.bancos || []).filter((b) => b.movimientos || !b.sinSaldoInicial || Number(b.saldo));
  const mes = L.mes ? mesHtml(L.mes, L.mesXlsBusy, c, { abierto: !!L.mesPend, revisar: !!L.mesRevisar, aliasBusy: L.aliasBusy || '' }) : `<section class="fl-card"><p class="fl-muted">Cargando el mes actual…</p></section>`;
  const fila = (ic, txt, val, cls = '') => `<div class="fl-r2"><img src="${FL_ICON(ic)}" alt=""><span>${txt}</span><b class="${cls}">${val}</b></div>`;
  return `${mes}
  <section class="fl-card fl-c2"><div class="fl-rows2 fl-box">${fila('icon_pendiente_clientes', 'Pendiente clientes', lps(c.pendienteClientes || 0), 'fl-neg')}${fila('icon_pendiente_vendedores', 'Pendiente vendedores', lps(c.pendienteVendedores || 0), 'fl-neg')}
    <div class="fl-r2 fl-warn2"><img src="${FL_ICON('icon_pendiente_total')}" alt=""><span>Pendiente total (NO es dinero disponible)</span><b>${lps(c.pendienteTotal || 0)}</b></div></div></section>
  <section class="fl-card fl-c2"><div class="fl-row"><b class="fl-h2"><img src="${FL_ICON('icon_bancos')}" alt="">Saldo real en bancos</b><b class="fl-big">${lps(d.totalBancos)}</b></div>
    ${bancos.map((b) => `<button type="button" class="fl-bank2" data-fl-tab="bancos">${bancoLogo(b)}<span>${esc(b.nombre)}</span><b>${lps(b.saldo)}</b><i>›</i></button>`).join('') || '<p class="fl-muted">Sin movimientos en bancos todavía.</p>'}
  </section>
  <p class="fl-muted">Meses anteriores y el ciclo completo: pestañas Cierre y Reportes.</p>
  <button class="fl-btn ghost" data-fl-reload>↻ Actualizar</button>`;
}

function bancosHtml(L) {
  const d = L.data;
  const rows = d.bancos.map((b) => {
    // R113: sin "saldo inicial": cada banco es un resumen de lo que entró y salió.
    const aj = L.ajuste === b.id ? `<div class="fl-inline col"><input class="fl-input" type="number" inputmode="decimal" placeholder="Ajuste (+ suma / − resta)" id="flAjMonto"><input class="fl-input" placeholder="Motivo del ajuste (obligatorio)" id="flAjMotivo"><div class="fl-inline"><button class="fl-btn" data-fl-aj-save="${esc(b.id)}">Guardar ajuste</button><button class="fl-btn ghost" data-fl-aj-cancel>Cancelar</button></div></div>` : '';
    return `<div class="fl-bankcard"><div class="fl-row"><b>${esc(b.nombre)}</b><b>${lps(b.saldo)}</b></div>
      <div class="fl-lines"><div><span>Ingresos</span><b class="fl-pos">+${lps(b.ingresos)}</b></div><div><span>Egresos</span><b class="fl-neg">−${lps(b.egresosOperativos)}</b></div>${b.planilla ? `<div><span>Planilla</span><b class="fl-neg">−${lps(b.planilla)}</b></div>` : ''}${b.ajustes || b.transferencias ? `<div><span>Ajustes / transferencias</span><b>${lps((b.ajustes || 0) + (b.transferencias || 0))}</b></div>` : ''}</div>
      <small class="fl-muted">${b.sinSaldoInicial ? `Desde ${esc(b.desde)} · ${b.movimientos} movimientos` : `Incluye saldo registrado ${lps(b.base)} (${esc(b.desde)})`}</small>
      ${aj || `<button class="fl-link" data-fl-aj="${esc(b.id)}">Ajuste de saldo…</button>`}</div>`;
  }).join('');
  const act = d.bancos.filter((b) => b.activado);
  const opts = act.map((b) => `<option value="${esc(b.id)}">${esc(b.nombre)} (${lps(b.saldo)})</option>`).join('');
  const transf = act.length >= 2 ? `<section class="fl-card"><b>⇄ Transferencia entre bancos</b><p class="fl-muted">Mover dinero de un banco a otro no es ingreso ni egreso: el total no cambia.</p>
    <div class="fl-inline wrap"><select class="fl-input" id="flTrO"><option value="">Desde…</option>${opts}</select><select class="fl-input" id="flTrD"><option value="">Hacia…</option>${opts}</select><input class="fl-input" id="flTrM" type="number" inputmode="decimal" placeholder="Monto"><input class="fl-input" id="flTrN" placeholder="Nota (opcional)"></div>
    <button class="fl-btn" id="flTrOk">Registrar transferencia</button></section>` : '';
  return `<section class="fl-card"><div class="fl-row"><b>Saldos por banco</b><b>${lps(d.totalBancos)}</b></div>${rows}</section>${transf}`;
}

// Finanzas nueva arranca el 01/10/2026: se sugiere ese día; después, el primer día del mes actual.
export function inicioSugerido(hoy = '') { const mes = String(hoy).slice(0, 7); return mes && mes > '2026-10' ? `${mes}-01` : '2026-10-01'; }
function pendientesHtml(L) {
  const d = L.data, P = L.pend, f = L.pendFiltro;
  const seg = `<div class="fl-seg three"><button class="${!f ? 'on' : ''}" data-fl-pf="">Todos</button><button class="${f === 'cliente' ? 'on' : ''}" data-fl-pf="cliente">Clientes</button><button class="${f === 'vendedor' ? 'on' : ''}" data-fl-pf="vendedor">Vendedores</button></div>`;
  const tot = d.cartera ? `<div class="fl-row"><b>Pendiente total</b><b class="fl-neg">${lps(d.cartera.pendienteTotal)}</b></div><p class="fl-muted">Clientes ${lps(d.cartera.pendienteClientes)} · Vendedores ${lps(d.cartera.pendienteVendedores)} · no suma a bancos ni al disponible hasta que se cobre.</p>` : '';
  const list = !P || P.loading ? '<p class="fl-muted">Cargando…</p>' : P.error ? `<p class="fl-err">${esc(P.error)}</p>` : !P.rows.length ? '<p class="fl-muted">✅ No hay pendientes de cobro.</p>' :
    P.rows.filter((c) => !f || c.deudorTipo === f).map((c) => `<div class="fl-bankcard"><div class="fl-row"><b>${c.deudorTipo === 'vendedor' ? '🧑‍💼' : '👤'} ${esc(c.deudorNombre || c.clienteNombre || '—')}</b><b class="fl-neg">${lps(c.saldoPendiente)}</b></div>
      <small class="fl-muted">${c.deudorTipo === 'vendedor' ? `Vendedor · cliente ${esc(c.clienteNombre || '')} · ` : ''}${c.tipoOrigen === 'compra' ? 'Compra' : 'Renovación'} ${esc(c.plataforma || '')} · total ${lps(c.montoTotalOperacion)} · recibido ${lps(money((c.montoRecibidoInicial || 0) + (c.montoRecibidoPosterior || 0)))} · ${esc(c.estado)}</small>
      ${L.abono?.cuentaId === c.id ? `<div class="fl-inline col"><input class="fl-input" type="number" inputmode="decimal" id="flAbM" placeholder="¿Cuánto pagó hoy? (máx. ${lps(c.saldoPendiente)})"><div class="fl-chips">${d.metodos.map((m) => `<button class="fl-chip ${L.abono.bancoId === m.id ? 'on' : ''}" data-fl-abb="${esc(m.id)}">${esc(m.nombre)}</button>`).join('')}</div><div class="fl-inline"><button class="fl-btn" id="flAbOk">Registrar abono</button><button class="fl-btn ghost" data-fl-abx>Cancelar</button></div></div>` : `<button class="fl-link" data-fl-ab="${esc(c.id)}">＋ Registrar pago / abono</button>`}</div>`).join('');
  return `<section class="fl-card">${tot}${seg}${list}</section>`;
}
async function loadPend(ctx) {
  const L = ctx.state.libro; L.pend = { loading: true, rows: [] }; ctx.render();
  try { const r = await ctx.authPost('/api/finanzas', { accion: 'listar_pendientes' }); if (!r?.ok) throw new Error(r?.error || 'No se pudo leer la cartera.'); L.pend = { rows: r.cuentas || [] }; if (L.data && r.cartera) L.data.cartera = r.cartera; }
  catch (e) { L.pend = { rows: [], error: e?.message || 'Error' }; }
  ctx.render();
}
// Corregir / anular: nunca se borra; pide motivo y el servidor crea la reversa.
function pedirMotivo(txt) { const m = window.prompt(`${txt}\n\nEscriba el motivo (obligatorio):`); return m && m.trim().length >= 4 ? m.trim() : (m === null ? null : ''); }

export function newDraft(today) { return { beneficiario: '', concepto: 'pago_planilla', descripcion: '', monto: '', fecha: today, asignaciones: {} }; }
function draftValidation(L) {
  const d = L.draft, data = L.data;
  const devuelto = d.corrigeAsignaciones || {}; // al corregir, el pago original vuelve a sus bancos antes de validar
  const bancos = data.bancos.map((b) => (devuelto[b.id] ? { ...b, saldo: money(b.saldo + devuelto[b.id]) } : b));
  return validatePlanilla({ montoTotal: Number(d.monto || 0), asignaciones: Object.entries(d.asignaciones).map(([bancoId, monto]) => ({ bancoId, monto: Number(monto || 0) })), bancos, disponibleCiclo: data.totales.resultado + (d.corrigeMonto || 0) });
}
function planillaHtml(L) {
  const data = L.data;
  if (!L.draft) {
    return `<section class="fl-card"><div class="fl-row"><b>Planilla / distribución</b><span class="fl-pill">Disponible ${lps(data.totales.resultado)}</span></div>
      <p class="fl-muted">Beneficiario, concepto y monto libres. Cada pago puede salir de uno o varios bancos.</p>
      <button class="fl-btn" data-fl-new-pay>＋ Nuevo pago</button></section>
      ${data.planillaPagos.length ? `<section class="fl-card"><b>Pagos del ciclo</b>${data.planillaPagos.map((p) => `<div class="fl-bank ${p.estado !== 'confirmado' ? 'fl-off' : ''}"><span>${esc(p.beneficiario)} · ${esc(p.conceptoLabel || '')}${p.estado !== 'confirmado' ? ` <i class="fl-pill warn">${esc(p.estado)}</i>` : ''}<small>${esc(p.fecha)} · ${(p.asignaciones || []).map((a) => `${esc(a.banco)} ${lps(a.monto)} (${lps(a.saldoAntes)} → ${lps(a.saldoDespues)})`).join(' + ')}${p.motivoAnulacion ? ` · motivo: ${esc(p.motivoAnulacion)}` : ''}</small>${p.estado === 'confirmado' ? `<span class="fl-acts"><button class="fl-link" data-fl-pc="${esc(p.id || p.planillaPagoId)}">Corregir</button><button class="fl-link danger" data-fl-pa="${esc(p.id || p.planillaPagoId)}">Anular</button></span>` : ''}</span><b>${lps(p.montoTotal)}</b></div>`).join('')}</section>` : ''}`;
  }
  const d = L.draft, v = draftValidation(L);
  const bancos = data.bancos.filter((b) => b.activado);
  return `<section class="fl-card"><div class="fl-row"><b>${d.corrigeA ? 'Corregir pago (se devuelve el original y se registra este)' : 'Nuevo pago (borrador)'}</b><span class="fl-pill">Disponible ${lps(data.totales.resultado + (d.corrigeMonto || 0))}</span></div>
    <label class="fl-label">Beneficiario<input class="fl-input" id="flBen" value="${esc(d.beneficiario)}" placeholder="Nombre (libre)" maxlength="80"></label>
    <label class="fl-label">Concepto<select class="fl-input" id="flCon">${Object.entries(PLANILLA_CONCEPTOS).map(([k, t]) => `<option value="${k}" ${d.concepto === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    <label class="fl-label" id="flDescWrap" ${d.concepto === 'otro_planilla' ? '' : 'hidden'}>Descripción<input class="fl-input" id="flDesc" value="${esc(d.descripcion)}" maxlength="160"></label>
    <div class="fl-inline"><label class="fl-label">Monto total<input class="fl-input" id="flMonto" type="number" inputmode="decimal" min="0" value="${esc(d.monto)}" placeholder="L"></label>
    <label class="fl-label">Fecha<input class="fl-input" id="flFecha" type="date" value="${esc(d.fecha)}"></label></div>
    <div class="fl-dist"><div class="fl-dist-h"><span>Banco</span><span>Antes</span><span>Tomar</span><span>Después</span></div>
    ${bancos.map((b) => `<div class="fl-dist-r"><span>${esc(b.nombre)}</span><span>${lps(b.saldo)}</span><input class="fl-input" type="number" inputmode="decimal" min="0" data-fl-take="${esc(b.id)}" value="${esc(d.asignaciones[b.id] || '')}" placeholder="0"><span data-fl-after="${esc(b.id)}">${lps(b.saldo - Number(d.asignaciones[b.id] || 0))}</span></div>`).join('')}</div>
    <p class="fl-status" id="flStatus">${statusText(v, d)}</p>
    <div class="fl-inline"><button class="fl-btn" id="flConfirm" ${v.ok && !L.sending ? '' : 'disabled'}>${L.sending ? 'Confirmando…' : 'Confirmar pago'}</button><button class="fl-btn ghost" data-fl-cancel-pay>Cancelar</button></div>
    <p class="fl-muted">Mientras no confirme, es solo un borrador: cancelar no cambia ningún saldo.</p></section>`;
}
function statusText(v, d) {
  if (!Number(d.monto)) return 'Escriba el monto total y cuánto tomar de cada banco.';
  if (v.ok) return `✅ Distribución completa: ${lps(v.asignado)}.`;
  return v.errors.map(esc).join('<br>');
}

function movimientosHtml(L) {
  const d = L.data, f = L.movFiltro, m = L.movs;
  const kinds = { '': 'Todos', ingreso: 'Ingresos', egreso: 'Egresos operativos', planilla: 'Planilla', ajuste: 'Ajustes', saldo_inicial: 'Saldos iniciales' };
  const list = !m ? '<p class="fl-muted">Toque “Buscar”.</p>' : m.loading ? '<p class="fl-muted">Cargando…</p>' : m.error ? `<p class="fl-err">${esc(m.error)}</p>` :
    (m.rows.length ? m.rows.map((r) => {
      const canEdit = !r.estadoFinanciero && !r.reversaDe && !r.planillaPagoId && ['ingreso', 'egreso', 'ajuste'].includes(r.kind);
      const grupo = (r.ids || []).length > 1; // R114: un solo pago de varios servicios
      const corr = canEdit && L.corr?.id === r.id ? `<span class="fl-inline col"><input class="fl-input" id="flCoM" type="number" inputmode="decimal" placeholder="Monto correcto" value="${esc(r.monto)}"><select class="fl-input" id="flCoB">${d.metodos.map((b) => `<option value="${esc(b.id)}" ${b.id === r.bancoId ? 'selected' : ''}>${esc(b.nombre)}</option>`).join('')}</select><input class="fl-input" id="flCoMo" placeholder="Motivo (obligatorio)"><span class="fl-inline"><button class="fl-btn" id="flCoOk">Guardar corrección</button><button class="fl-btn ghost" data-fl-cox>Cancelar</button></span></span>` : '';
      const fecha = canEdit && L.fechaCorr?.id === r.id ? `<span class="fl-inline col"><label class="fl-label">Fecha REAL del pago<input class="fl-input" id="flFeD" type="date" value="${esc(r.fecha || '')}" max="${esc(d.hoy)}"></label><input class="fl-input" id="flFeMo" placeholder="Motivo" value="Ajuste manual de fecha de pago"><small class="fl-muted">La fecha de renovación/corte del cliente es independiente. Aquí va el día en que el dinero realmente entró o salió.</small><span class="fl-inline"><button class="fl-btn" id="flFeOk">Guardar fecha</button><button class="fl-btn ghost" data-fl-fex>Cancelar</button></span></span>` : '';
      const acts = canEdit && !corr && !fecha ? (grupo ? `<span class="fl-acts"><button class="fl-link" data-fl-fe="${esc(r.id)}" data-fl-fe-ids="${esc(r.ids.join(','))}">Fecha</button><small class="fl-muted">Pago único de ${r.n} servicios</small></span>` : `<span class="fl-acts"><button class="fl-link" data-fl-co="${esc(r.id)}">Corregir</button><button class="fl-link" data-fl-fe="${esc(r.id)}">Fecha</button><button class="fl-link danger" data-fl-an="${esc(r.id)}">Anular</button></span>`) : '';
      return `<div class="fl-mov ${r.kind} ${r.estadoFinanciero || r.reversaDe ? 'fl-off' : ''} ${L.corr?.id === r.id || L.fechaCorr?.id === r.id ? 'fl-editando' : ''}" data-fl-row="${esc(r.id)}"><span><b>${esc(r.detalle || r.cliente || r.beneficiario || kinds[r.kind] || r.tipo)}</b><small>${esc(r.fecha)} · ${esc(r.banco)} · ${esc(kinds[r.kind] || r.kind)}${r.cliente ? ` · ${esc(r.cliente)}` : ''}${r.usuario ? ` · ${esc(actorLabel(r.usuario, r.origen))}` : ''}${r.origen ? ` · ${esc(r.origen)}` : ''}${r.estadoFinanciero ? ` · <i class="fl-pill warn">${esc(r.estadoFinanciero)}</i>` : ''}${r.reversaDe ? ' · reversa' : ''}</small>${corr}${fecha}${acts}</span><b>${['egreso', 'planilla'].includes(r.kind) ? '−' : ''}${lps(r.monto)}</b></div>`;
    }).join('') + (m.total > m.rows.length ? `<p class="fl-muted">Mostrando ${m.rows.length} de ${m.total}.</p>` : '') : '<p class="fl-muted">Sin movimientos con esos filtros.</p>');
  return `<section class="fl-card"><b>＋ Egreso operativo</b>
    <div class="fl-inline col"><input class="fl-input" id="flEgMot" placeholder="Concepto (proveedor, publicidad…)"><div class="fl-inline"><input class="fl-input" id="flEgMonto" type="number" inputmode="decimal" placeholder="Monto (L)"><select class="fl-input" id="flEgBanco"><option value="">¿De qué banco salió?</option>${d.metodos.map((b) => `<option value="${esc(b.id)}">${esc(b.nombre)}</option>`).join('')}</select></div><label class="fl-label">Fecha del egreso<input class="fl-input" type="date" id="flEgFecha" value="${esc(d.hoy)}" max="${esc(d.hoy)}"></label><button class="fl-btn" id="flEgSave">Guardar egreso</button></div></section>
  <section class="fl-card"><b>＋ Ingreso manual</b><p class="fl-muted">Para dinero que entró sin compra/renovación (las ventas se registran solas al vender o renovar).</p>
    <div class="fl-inline col"><input class="fl-input" id="flInDet" placeholder="Detalle o cliente"><div class="fl-inline"><input class="fl-input" id="flInMonto" type="number" inputmode="decimal" placeholder="Monto (L)"><select class="fl-input" id="flInBanco"><option value="">¿A qué banco entró?</option>${d.metodos.map((b) => `<option value="${esc(b.id)}">${esc(b.nombre)}</option>`).join('')}</select></div>
    <label class="fl-label">Fecha del ingreso<input class="fl-input" type="date" id="flInFecha" value="${esc(d.hoy)}" max="${esc(d.hoy)}"></label><button class="fl-btn" id="flInSave">Guardar ingreso</button></div></section>
  <section class="fl-card"><b>Movimientos</b>
    <div class="fl-inline wrap"><select class="fl-input" id="flMTipo">${Object.entries(kinds).map(([k, t]) => `<option value="${k}" ${f.tipo === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
    <select class="fl-input" id="flMBanco"><option value="">Todos los bancos</option>${d.metodos.map((b) => `<option value="${esc(b.id)}" ${f.bancoId === b.id ? 'selected' : ''}>${esc(b.nombre)}</option>`).join('')}<option value="sin_banco" ${f.bancoId === 'sin_banco' ? 'selected' : ''}>Sin banco</option></select>
    <input class="fl-input" type="date" id="flMDesde" value="${esc(f.desde)}"><input class="fl-input" type="date" id="flMHasta" value="${esc(f.hasta)}">
    <input class="fl-input" id="flMTexto" placeholder="Cliente, beneficiario, detalle…" value="${esc(f.texto)}"><button class="fl-btn" id="flMBuscar">Buscar</button></div>${list}</section>`;
}

// R192 · Estado del ciclo y conciliación con el cierre REAL guardado (finanzas_ciclos). El «Cierre de caja» del bot de Telegram
// es un reporte del día y nunca guardó un cierre: si el ciclo vigente empezó antes de este mes y no hay cierre al último día
// del mes anterior, se avisa (no se cierra solo) y se ofrece cerrarlo con confirmación.
export function conciliacionCiclo(d = {}) {
  const hoy = String(d.hoy || ''), ini = String(d.ciclo?.inicio || ''); if (!hoy || !ini) return null;
  const [y, m] = hoy.split('-').map(Number); const fin = new Date(Date.UTC(y, m - 1, 0)).toISOString().slice(0, 10);
  const cierres = Array.isArray(d.cierres) ? d.cierres : [];
  const cerrado = cierres.find((c) => c.estado !== 'abierto' && c.fechaFin === fin);
  return { fechaSugerida: ini <= fin ? fin : hoy, mesAnteriorAbierto: ini <= fin && !cerrado, ultimoDiaMesAnterior: fin, ultimo: cierres[0] || null };
}
const dmy = (ymd = '') => { const [a, b, c] = String(ymd).split('-'); return a && b && c ? `${c}/${b}/${a}` : ymd; };
function cierreHtml(L) {
  const d = L.data, t = d.totales, k = conciliacionCiclo(d) || {};
  const origen = (c) => c?.origenCanal === 'tg' ? 'Telegram' : c?.origenCanal === 'web' ? 'Web' : c?.origenCanal ? 'APK' : '';
  const finSel = L.cierreFin || d.hoy;
  return `${k.mesAnteriorAbierto ? `<section class="fl-card fl-alerta" role="alert"><b>⚠️ No hay cierre registrado al ${esc(dmy(k.ultimoDiaMesAnterior))}</b>
      <p class="fl-muted">El ciclo sigue abierto desde el ${esc(dmy(d.ciclo.inicio))}. En el sistema no existe ningún cierre de esa fecha: el «🧾 Cierre de caja» del bot de Telegram es un reporte del día y no cierra el ciclo. Nada se cerró solo y no se cambió ningún saldo.</p>
      <button class="fl-btn" data-fl-cierre-sug="${esc(k.ultimoDiaMesAnterior)}">Revisar cierre al ${esc(dmy(k.ultimoDiaMesAnterior))}</button></section>` : ''}
  <section class="fl-card fl-c2"><div class="fl-row"><b class="fl-h2"><img src="${FL_ICON('icon_cierre')}" alt="">Ciclo vigente</b><span class="fl-pill fl-pill-abierto">ABIERTO</span></div>
    <p class="fl-muted">Desde ${esc(dmy(d.ciclo?.inicio || ''))} · día ${esc(d.ciclo?.dias ?? '')}${d.ciclo?.ultimoCierreFin ? ` · último cierre ${esc(dmy(d.ciclo.ultimoCierreFin))}` : ''}</p>
    <div class="fl-lines"><div><span>Ingresos</span><b>${lps(t.ingresos)}</b></div><div><span>Egresos operativos</span><b>${lps(t.egresosOperativos)}</b></div>
    <div class="fl-sub"><span>Disponible antes de planilla</span><b>${lps(t.disponibleAntesPlanilla)}</b></div><div><span>Planilla / comisiones</span><b>${lps(t.planilla)}</b></div>
    <div class="fl-total"><span>Resultado final</span><b>${lps(t.resultado)}</b></div><div><span>Saldo retenido en bancos</span><b>${lps(d.totalBancos)}</b></div></div></section>
  <section class="fl-card" id="flCierreForm"><b>Cerrar ciclo</b><p class="fl-muted">Usted decide cuándo cerrar (día 8, 10, 15…). El cierre congela el periodo; los bancos conservan su saldo y empieza un ciclo nuevo. Lo mismo se ve en Sublichat Web y en el bot de Telegram.</p>
    <label class="fl-label">Cerrar desde (incluye este día)<input class="fl-input" type="date" id="flCierreIni" value="${esc(d.ciclo?.inicio || '')}" min="${esc(d.ciclo?.inicio || '')}" max="${esc(d.hoy)}"></label>
    <label class="fl-label">Cerrar hasta (incluye este día)<input class="fl-input" type="date" id="flCierreFin" value="${esc(finSel)}" min="${esc(d.ciclo?.inicio || '')}" max="${esc(d.hoy)}"></label>
    <label class="fl-label">Nota (opcional)<input class="fl-input" id="flCierreNota" maxlength="300"></label>
    <button class="fl-btn" id="flCierreOk" ${L.sending ? 'disabled' : ''}>Confirmar cierre</button></section>
  <section class="fl-card"><b>Cierres registrados</b>${d.cierres.length ? d.cierres.map((c) => `<div class="fl-bank fl-cierre-h"><span>${esc(dmy(c.fechaInicio))} → ${esc(dmy(c.fechaFin))} <i class="fl-pill fl-pill-cerrado">CERRADO</i><small>Ingresos ${lps(c.ingresos)} · Gastos ${lps(c.egresosOperativos)} · Planilla ${lps(c.planilla)} · por ${esc(c.cerradoPor)}${origen(c) ? ` · ${origen(c)}` : ''}</small></span><b>${lps(c.resultado)}</b></div>`).join('') : '<p class="fl-muted">Todavía no hay cierres guardados.</p>'}</section>`;
}

// ---------------------------------------------------------------- eventos
export function bindLibro(root, ctx) {
  const L = ctx.state.libro; if (!L || !root) return;
  const q = (s) => root.querySelector(s), qa = (s) => root.querySelectorAll(s);
  // R193 · pendiente de clasificar y revisión de alias (el servidor valida permiso, motivo y audita).
  q('[data-fl-pend]')?.addEventListener('click', () => { L.mesPend = !L.mesPend; ctx.render(); });
  q('[data-fl-revisar]')?.addEventListener('click', () => { L.mesRevisar = !L.mesRevisar; ctx.render(); });
  qa('[data-fl-alias]').forEach((b) => b.addEventListener('click', async () => {
    const i = b.dataset.flAlias, amb = (L.mes?.aliasRevisados || []).filter((a) => a.motivo === 'alias_ambiguo_netflix_vip' || a.motivo === 'no_reconocido'), a = amb[Number(i)];
    const productoId = document.getElementById(`flAlP${i}`)?.value || '', motivo = (document.getElementById(`flAlM${i}`)?.value || '').trim();
    if (!a || !productoId) { ctx.showToast?.('Elija el producto.'); return; }
    if (!motivo) { ctx.showToast?.('Escriba la evidencia (obligatorio).'); return; }
    L.aliasBusy = i; ctx.render();
    try {
      const r = await ctx.authPost('/api/finanzas', { accion: 'finanzas_alias_confirmar', alias: a.original, original: a.original, productoId, motivo, origen: 'apk' });
      if (!r?.ok) throw new Error(r?.error || 'No se pudo guardar.');
      const mes = await ctx.authPost('/api/finanzas', { accion: 'finanzas_mes', periodo: L.mes?.periodo || '' }); if (mes?.ok) L.mes = mes;
      ctx.showToast?.(`Alias confirmado: ${a.original} → ${r.producto}`);
    } catch (e) { ctx.showToast?.(e?.message || 'No se pudo guardar.'); }
    finally { L.aliasBusy = ''; ctx.render(); }
  }));
  q('[data-fl-mes-xls]')?.addEventListener('click', () => { if (typeof ctx.descargarExcelMes === 'function' && L.mes) ctx.descargarExcelMes(L.mes); }); // R186
  { const on = root.querySelector('.fl-tabs .fl-tab.on'); if (on && on.scrollIntoView) try { on.scrollIntoView({ inline: 'center', block: 'nearest' }); } catch (_) {} } // R119: la pestaña elegida queda visible
  qa('[data-fl-tab]').forEach((b) => b.addEventListener('click', () => { L.tab = b.dataset.flTab; if (L.tab === 'movimientos' && !L.movs && L.data) loadMovs(ctx); if (L.tab === 'pendientes' && L.data) loadPend(ctx); ctx.render(); }));
  // Pendientes / abonos
  qa('[data-fl-pf]').forEach((b) => b.addEventListener('click', () => { L.pendFiltro = b.dataset.flPf; ctx.render(); }));
  qa('[data-fl-ab]').forEach((b) => b.addEventListener('click', () => { L.abono = { cuentaId: b.dataset.flAb, bancoId: '', opId: ctx.newOperationId() }; ctx.render(); }));
  q('[data-fl-abx]')?.addEventListener('click', () => { L.abono = null; ctx.render(); });
  qa('[data-fl-abb]').forEach((b) => b.addEventListener('click', () => { const v = q('#flAbM')?.value; L.abono.bancoId = b.dataset.flAbb; L.abono.monto = v; ctx.render(); const i = q('#flAbM'); if (i && v) i.value = v; }));
  q('#flAbOk')?.addEventListener('click', async () => {
    const monto = Number(q('#flAbM')?.value || L.abono?.monto || 0);
    if (!(monto > 0)) return ctx.showToast('Escriba cuánto pagó.');
    if (!L.abono.bancoId) return ctx.showToast('Elija el banco donde entró.');
    if (await post({ accion: 'registrar_abono', cuentaId: L.abono.cuentaId, monto, bancoId: L.abono.bancoId, operationId: L.abono.opId }, '✅ Abono registrado.')) { L.abono = null; L.movs = null; await loadLibro(ctx, { silent: true }); loadPend(ctx); }
  });
  // Transferencia
  q('#flTrOk')?.addEventListener('click', async () => {
    const origenId = q('#flTrO')?.value, destinoId = q('#flTrD')?.value, monto = Number(q('#flTrM')?.value || 0);
    if (!origenId || !destinoId || origenId === destinoId || !(monto > 0)) return ctx.showToast('Elija dos bancos distintos y el monto.');
    if (!window.confirm(`¿Mover ${lps(monto)} entre bancos? El total no cambia.`)) return;
    if (await post({ accion: 'registrar_transferencia', origenId, destinoId, monto, nota: q('#flTrN')?.value || '', operationId: ctx.newOperationId() }, '✅ Transferencia registrada.')) loadLibro(ctx, { silent: true });
  });
  // Corregir / anular movimientos
  const enfocar = (sel) => { try { root.ownerDocument.querySelector(sel)?.focus({ preventScroll: true }); } catch (_) {} };
  qa('[data-fl-co]').forEach((b) => b.addEventListener('click', () => { const a = anclaMov(b.dataset.flCo); L.fechaCorr = null; L.corr = { id: b.dataset.flCo, opId: ctx.newOperationId() }; ctx.render(); restaurarAncla(a); enfocar('#flCoM'); }));
  q('[data-fl-cox]')?.addEventListener('click', () => { const a = anclaMov(L.corr?.id); L.corr = null; ctx.render(); restaurarAncla(a); });
  q('#flCoOk')?.addEventListener('click', async () => {
    const motivo = String(q('#flCoMo')?.value || '').trim(); if (motivo.length < 4) return ctx.showToast('Escriba el motivo de la corrección.');
    const a = anclaMov(L.corr.id), cx = conAncla(ctx, a);
    if (await post({ accion: 'corregir_movimiento', movimientoId: L.corr.id, monto: Number(q('#flCoM')?.value || 0), bancoId: q('#flCoB')?.value || '', motivo, operationId: L.corr.opId }, '✅ Corregido. El original queda en el historial.', a)) { L.corr = null; await loadLibro(cx, { silent: true }); await loadMovs(cx, { silent: true }); }
  });
  qa('[data-fl-fe]').forEach((b) => b.addEventListener('click', () => { const a = anclaMov(b.dataset.flFe); L.corr = null; L.fechaCorr = { id: b.dataset.flFe, ids: String(b.dataset.flFeIds || '').split(',').filter(Boolean) }; ctx.render(); restaurarAncla(a); enfocar('#flFeD'); }));
  q('[data-fl-fex]')?.addEventListener('click', () => { const a = anclaMov(L.fechaCorr?.id); L.fechaCorr = null; ctx.render(); restaurarAncla(a); });
  q('#flFeOk')?.addEventListener('click', async () => {
    const fechaPago = String(q('#flFeD')?.value || '').trim(), motivo = String(q('#flFeMo')?.value || '').trim() || 'Ajuste manual de fecha de pago';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaPago)) return ctx.showToast('Elija la fecha real del pago.');
    if (fechaPago > String(L.data?.hoy || '')) return ctx.showToast('La fecha del pago no puede ser futura.');
    const a = anclaMov(L.fechaCorr.id), cx = conAncla(ctx, a);
    if (await post({ accion: 'ajustar_fecha_movimiento', movimientoId: L.fechaCorr.id, ...((L.fechaCorr.ids || []).length > 1 ? { movimientoIds: L.fechaCorr.ids } : {}), fechaPago, motivo }, '✅ Fecha financiera ajustada.', a)) { L.fechaCorr = null; await loadLibro(cx, { silent: true }); await loadMovs(cx, { silent: true }); }
  });
  qa('[data-fl-an]').forEach((b) => b.addEventListener('click', async () => {
    const motivo = pedirMotivo('¿Anular este movimiento? Se crea una reversa y el original queda visible como ANULADO.'); if (motivo === null) return; if (!motivo) return ctx.showToast('El motivo es obligatorio.');
    const a = anclaMov(b.dataset.flAn), cx = conAncla(ctx, a);
    if (await post({ accion: 'anular_movimiento', movimientoId: b.dataset.flAn, motivo, operationId: ctx.newOperationId() }, '✅ Anulado.', a)) { await loadLibro(cx, { silent: true }); await loadMovs(cx, { silent: true }); }
  }));
  // Corregir / anular pagos de planilla
  qa('[data-fl-pa]').forEach((b) => b.addEventListener('click', async () => {
    const motivo = pedirMotivo('¿Anular este pago de planilla? Todos sus bancos recuperan el dinero.'); if (motivo === null) return; if (!motivo) return ctx.showToast('El motivo es obligatorio.');
    if (await post({ accion: 'anular_pago_planilla', planillaPagoId: b.dataset.flPa, motivo, operationId: ctx.newOperationId() }, '✅ Pago anulado.')) loadLibro(ctx, { silent: true });
  }));
  qa('[data-fl-pc]').forEach((b) => b.addEventListener('click', () => {
    const p = L.data.planillaPagos.find((x) => (x.id || x.planillaPagoId) === b.dataset.flPc); if (!p) return;
    const asig = {}; (p.asignaciones || []).forEach((a) => { asig[a.bancoId] = String(a.monto); });
    L.draft = { ...newDraft(p.fecha || L.data.hoy), beneficiario: p.beneficiario, concepto: p.concepto, descripcion: p.descripcion || '', monto: String(p.montoTotal), asignaciones: asig, corrigeA: b.dataset.flPc, corrigeMonto: Number(p.montoTotal || 0), corrigeAsignaciones: Object.fromEntries((p.asignaciones || []).map((a) => [a.bancoId, Number(a.monto)])), operationId: ctx.newOperationId() };
    ctx.render();
  }));
  qa('[data-fl-reload]').forEach((b) => b.addEventListener('click', () => loadLibro(ctx)));
  const post = async (body, okMsg, ancla = null) => {
    const pintar = () => { ctx.render(); if (ancla) restaurarAncla(ancla); };
    if (L.sending) return null; L.sending = true; pintar();
    try { const r = await ctx.authPost('/api/finanzas', { origen: 'apk', ...body }); if (!r?.ok) throw new Error(r?.error || 'No se pudo guardar.'); if (okMsg) ctx.showToast(okMsg); return r; }
    catch (e) { ctx.showToast(e?.message || 'Error'); return null; }
    finally { L.sending = false; pintar(); }
  };
  // Bancos
  qa('[data-fl-ini-save]').forEach((b) => b.addEventListener('click', async () => {
    const id = b.dataset.flIniSave, input = root.querySelector(`[data-fl-ini="${CSS.escape(id)}"]`); const raw = String(input?.value || '').trim();
    const desde = root.querySelector(`[data-fl-ini-desde="${CSS.escape(id)}"]`)?.value || L.data.hoy;
    if (raw === '' || !(Number(raw) >= 0)) return ctx.showToast('Escriba el saldo real del banco hoy (0 o más).');
    const banco = L.data.bancos.find((x) => x.id === id);
    if (!window.confirm(`¿Registrar ${lps(raw)} como saldo de ${banco?.nombre} al empezar el ${desde.split('-').reverse().join('/')}? Solo se hace una vez.`)) return;
    if (await post({ accion: 'registrar_saldo_inicial', bancoId: id, monto: Number(raw), desde }, 'Saldo inicial registrado.')) loadLibro(ctx, { silent: true });
  }));
  qa('[data-fl-aj]').forEach((b) => b.addEventListener('click', () => { L.ajuste = b.dataset.flAj; ctx.render(); }));
  q('[data-fl-aj-cancel]')?.addEventListener('click', () => { L.ajuste = null; ctx.render(); });
  qa('[data-fl-aj-save]').forEach((b) => b.addEventListener('click', async () => {
    const monto = Number(q('#flAjMonto')?.value || 0), motivo = String(q('#flAjMotivo')?.value || '').trim();
    if (!monto) return ctx.showToast('Escriba el ajuste (+ suma, − resta).');
    if (motivo.length < 4) return ctx.showToast('El ajuste necesita un motivo.');
    if (await post({ accion: 'registrar_ajuste_saldo', bancoId: b.dataset.flAjSave, monto, motivo, operationId: ctx.newOperationId() }, 'Ajuste guardado.')) { L.ajuste = null; loadLibro(ctx, { silent: true }); }
  }));
  // Planilla (borrador local, cálculo en vivo sin re-render para no perder el foco)
  q('[data-fl-new-pay]')?.addEventListener('click', () => { L.draft = newDraft(L.data.hoy); L.draft.operationId = ctx.newOperationId(); ctx.render(); });
  q('[data-fl-cancel-pay]')?.addEventListener('click', () => { L.draft = null; ctx.render(); });
  if (L.draft) {
    const d = L.draft;
    const refresh = () => {
      const v = draftValidation(L);
      for (const b of L.data.bancos) { const cell = root.querySelector(`[data-fl-after="${CSS.escape(b.id)}"]`); if (cell) { const after = b.saldo - Number(d.asignaciones[b.id] || 0); cell.textContent = lps(after); cell.classList.toggle('fl-neg', after < 0); } }
      const st = q('#flStatus'); if (st) { st.innerHTML = statusText(v, d); st.classList.toggle('ok', v.ok); }
      const btn = q('#flConfirm'); if (btn) btn.disabled = !v.ok || L.sending;
    };
    q('#flBen')?.addEventListener('input', (e) => { d.beneficiario = e.target.value; });
    q('#flCon')?.addEventListener('change', (e) => { d.concepto = e.target.value; const w = q('#flDescWrap'); if (w) w.hidden = d.concepto !== 'otro_planilla'; });
    q('#flDesc')?.addEventListener('input', (e) => { d.descripcion = e.target.value; });
    q('#flFecha')?.addEventListener('change', (e) => { d.fecha = e.target.value; });
    q('#flMonto')?.addEventListener('input', (e) => { d.monto = e.target.value; refresh(); });
    qa('[data-fl-take]').forEach((inp) => inp.addEventListener('input', () => { d.asignaciones[inp.dataset.flTake] = inp.value; refresh(); }));
    q('#flConfirm')?.addEventListener('click', async () => {
      const v = draftValidation(L); if (!v.ok) return refresh();
      if (!d.beneficiario.trim()) return ctx.showToast('Escriba el beneficiario.');
      if (d.concepto === 'otro_planilla' && d.descripcion.trim().length < 3) return ctx.showToast('“Otro” necesita una descripción.');
      const resumen = v.asignaciones.map((a) => `${a.banco}: ${lps(a.monto)} (${lps(a.saldoAntes)} → ${lps(a.saldoDespues)})`).join('\n');
      if (!window.confirm(`Pagar ${lps(d.monto)} a ${d.beneficiario}?\n\n${resumen}`)) return;
      let motivoCorr = '';
      if (d.corrigeA) { motivoCorr = pedirMotivo('Corrección del pago'); if (!motivoCorr) return ctx.showToast('El motivo es obligatorio.'); }
      const r = await post({ accion: d.corrigeA ? 'corregir_pago_planilla' : 'confirmar_pago_planilla', planillaPagoId: d.corrigeA || undefined, motivo: motivoCorr || undefined, beneficiario: d.beneficiario.trim(), concepto: d.concepto, descripcion: d.descripcion.trim(), montoTotal: Number(d.monto), fecha: d.fecha, asignaciones: v.asignaciones.map((a) => ({ bancoId: a.bancoId, monto: a.monto })), operationId: d.operationId }, `✅ Pago a ${d.beneficiario.trim()} confirmado.`);
      if (r) { L.draft = null; L.movs = null; loadLibro(ctx, { silent: true }); }
    });
  }
  // Movimientos + egreso operativo
  q('#flInSave')?.addEventListener('click', async () => { // R114: ingreso manual con fecha y banco
    const detalle = String(q('#flInDet')?.value || '').trim(), monto = Number(q('#flInMonto')?.value || 0), bancoId = q('#flInBanco')?.value || '', fecha = q('#flInFecha')?.value || '';
    if (!detalle || !(monto > 0)) return ctx.showToast('Escriba detalle y monto del ingreso.');
    if (!bancoId) return ctx.showToast('Elija a qué banco entró.');
    const banco = (L.data.metodos || []).find((m) => m.id === bancoId);
    const r = await post({ accion: 'registrar_cobro', detalle, clienteNombre: detalle, monto, bancoId, metodoPago: banco?.nombre || bancoId, ...(fecha ? { fecha, fechaPago: fecha } : {}), operationId: ctx.newOperationId() }, 'Ingreso guardado.');
    if (r) { L.movs = null; await loadLibro(ctx, { silent: true }); if (L.tab === 'movimientos') loadMovs(ctx); }
  });
  q('#flEgSave')?.addEventListener('click', async () => {
    const motivo = String(q('#flEgMot')?.value || '').trim(), monto = Number(q('#flEgMonto')?.value || 0), bancoId = q('#flEgBanco')?.value || '';
    if (!motivo || !(monto > 0)) return ctx.showToast('Escriba concepto y monto del egreso.');
    if (!bancoId) return ctx.showToast('Elija de qué banco salió.');
    const fechaEg = q('#flEgFecha')?.value || ''; // R114: fecha personalizada
    const r = await post({ accion: 'registrar_egreso', motivo, monto, bancoId, subtipo: 'egreso_operativo', ...(fechaEg ? { fecha: fechaEg, fechaPago: fechaEg } : {}), operationId: ctx.newOperationId() }, 'Egreso guardado.');
    if (r) { L.movs = null; await loadLibro(ctx, { silent: true }); if (L.tab === 'movimientos') loadMovs(ctx); }
  });
  q('#flMBuscar')?.addEventListener('click', () => {
    Object.assign(L.movFiltro, { tipo: q('#flMTipo')?.value || '', bancoId: q('#flMBanco')?.value || '', texto: q('#flMTexto')?.value || '', desde: q('#flMDesde')?.value || '', hasta: q('#flMHasta')?.value || '' });
    loadMovs(ctx);
  });
  // Cierre
  qa('[data-fl-cierre-sug]').forEach((b) => b.addEventListener('click', () => { L.cierreFin = b.dataset.flCierreSug; ctx.render(); try { root.querySelector('#flCierreForm')?.scrollIntoView({ block: 'start' }); root.querySelector('#flCierreFin')?.focus({ preventScroll: true }); } catch (_) {} }));
  q('#flCierreOk')?.addEventListener('click', async () => {
    const fechaFin = q('#flCierreFin')?.value || L.data.hoy, nota = q('#flCierreNota')?.value || '';
    const fechaInicio = q('#flCierreIni')?.value || L.data.ciclo?.inicio || ''; // R119: desde qué día
    if (!window.confirm(`¿Cerrar el ciclo ${dmy(fechaInicio)} → ${dmy(fechaFin)}?\nLos totales se calculan con los movimientos hasta ${dmy(fechaFin)}.\nLos bancos conservan su saldo y el ciclo nuevo empieza el día siguiente.`)) return;
    if (await post({ accion: 'guardar_cierre_ciclo', fechaInicio, fechaFin, nota, operationId: ctx.newOperationId() }, '✅ Ciclo cerrado. Empieza uno nuevo.')) { L.cierreFin = ''; loadLibro(ctx, { silent: true }); }
  });
}

// ---------------------------------------------------------------- hoja de pago: compra nueva y renovación (R108 · UX simplificada)
// La interfaz NO pide “Monto total + Recibido ahora”. Cada servicio elige un estado claro:
// PAGÓ      → un solo campo “Monto pagado”. Opcionalmente puede marcar “Quedó saldo pendiente”.
// PENDIENTE → un solo campo “Monto pendiente”. Internamente recibido=0.
// Si Pagó + saldo pendiente, el backend recibe un pago PARCIAL sin mostrar una tercera opción confusa.
// El contrato del backend NO cambia: siempre termina en {montoTotal, recibido, bancoId, responsable...}.
function rowPaymentState(s, key) {
  const m = s.montos[key] || (s.montos[key] = {});
  // Compatibilidad bidireccional con el contrato anterior {total, recibido}.
  // La UI nueva NO vuelve a mostrar esos dos campos, pero código/tests antiguos pueden seguir
  // alimentándolos sin romper compras ni renovaciones. Los datos modernos siempre tienen prioridad.
  const hasModern = m.estadoCobro != null || m.pagado != null || m.recibidoParcial != null || m.pendiente != null || m.tienePendiente != null;
  const hasLegacy = !!m._legacyInput || (!m._derivedCompat && (m.total != null || m.recibido != null));
  if (!hasModern && hasLegacy) {
    const total = Math.max(0, Math.round(Number(m.total || 0) * 100) / 100);
    const recibido = Math.max(0, Math.min(total || Number(m.recibido || 0), Math.round(Number(m.recibido || 0) * 100) / 100));
    const saldo = Math.max(0, Math.round((total - recibido) * 100) / 100);
    return { modo: recibido > 0 ? 'pagado' : 'pendiente', total, recibido, saldo, estado: saldo <= 0 ? 'pagado' : (recibido > 0 ? 'parcial' : 'pendiente') };
  }
  // Compatibilidad: si alguna hoja vieja dejó 'parcial', se interpreta como Pagó + saldo pendiente.
  const modo = m.estadoCobro === 'pendiente' ? 'pendiente' : 'pagado';
  if (m.estadoCobro === 'parcial') m.tienePendiente = true;
  let recibido = 0, saldo = 0;
  if (modo === 'pendiente') saldo = Number(m.pendiente || 0);
  else { recibido = Number(m.pagado ?? m.recibidoParcial ?? 0); saldo = m.tienePendiente ? Number(m.pendiente || 0) : 0; }
  const total = Math.max(0, Math.round((recibido + saldo) * 100) / 100);
  recibido = Math.max(0, Math.round(recibido * 100) / 100);
  saldo = Math.max(0, Math.round(saldo * 100) / 100);
  // Mantiene los campos históricos sincronizados sin convertirlos en la fuente principal.
  m.total = total;
  m.recibido = recibido;
  m._derivedCompat = true;
  return { modo, total, recibido, saldo, estado: saldo <= 0 ? 'pagado' : (recibido > 0 ? 'parcial' : 'pendiente') };
}
function sheetTotals(s) {
  return s.rows.map((r) => ({ ...r, ...rowPaymentState(s, r.key) }));
}
function paymentRowHtml(sheet, r) {
  const m = sheet.montos[r.key] || (sheet.montos[r.key] = {});
  const x = rowPaymentState(sheet, r.key);
  const chip = (mode, label) => `<button type="button" class="${x.modo === mode ? 'on' : ''}" data-rp-status="${mode}" data-rp-key="${esc(r.key)}">${label}</button>`;
  let fields = '';
  if (x.modo === 'pendiente') {
    fields = `<label class="fl-label">Monto pendiente<input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="L" data-rp-pendiente="${esc(r.key)}" value="${esc(m.pendiente ?? '')}"></label>`;
  } else {
    fields = `<label class="fl-label">Monto pagado<input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="L" data-rp-pagado="${esc(r.key)}" value="${esc(m.pagado ?? m.recibidoParcial ?? '')}"></label>
      <button type="button" class="fl-chip ${m.tienePendiente ? 'on' : ''}" data-rp-toggle-pending="${esc(r.key)}" style="margin-top:.55rem">${m.tienePendiente ? '✓ Quedó saldo pendiente' : '＋ Agregar saldo pendiente'}</button>
      ${m.tienePendiente ? `<label class="fl-label" style="margin-top:.55rem">Saldo pendiente<input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="L" data-rp-pendiente="${esc(r.key)}" value="${esc(m.pendiente ?? '')}"></label>` : ''}`;
  }
  const status = x.modo === 'pendiente'
    ? (x.saldo > 0 ? `🕒 Pendiente ${lps(x.saldo)}` : 'Escriba cuánto queda pendiente')
    : (x.recibido > 0 ? (x.saldo > 0 ? `◐ Pagó ${lps(x.recibido)} · pendiente ${lps(x.saldo)}` : `✅ Pagado ${lps(x.recibido)}`) : 'Escriba cuánto pagó');
  return `<div class="fl-bankcard"><b>${esc(r.label)}</b><p class="fl-label" style="margin:.55rem 0 .35rem">Estado del cobro</p><div class="fl-seg">${chip('pagado','✅ Pagó')}${chip('pendiente','🕒 Pendiente')}</div><div style="margin-top:.7rem">${fields}</div><small class="fl-muted" data-rp-estado="${esc(r.key)}">${status}</small>
    <!-- Compatibilidad interna R106/flujo legado. Permanecen ocultos: la UX visible sigue siendo Pagó/Pendiente. -->
    <input type="hidden" data-rp-total="${esc(r.key)}" value="${x.total > 0 ? esc(x.total) : ''}" aria-hidden="true">
    <input type="hidden" data-rp-recibido="${esc(r.key)}" value="${x.recibido > 0 ? esc(x.recibido) : ''}" aria-hidden="true">
  </div>`;
}
// R110 · Fecha del PAGO: el día que el dinero entró al banco (puede ser distinto a la fecha de corte/renovación).
function ymdLocal(d = new Date()) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
function diasAtras(n) { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() - n); return ymdLocal(d); }
function dmyCorto(ymd) { const [y, m, d] = String(ymd).split('-'); return `${d}/${m}`; }
export function fechaPagoHtml(sheet) {
  const hoy = diasAtras(0), sel = sheet.fechaPago || hoy;
  const chips = [[0, 'Hoy'], [1, 'Ayer'], [2, 'Antier']].map(([n, t]) => { const f = diasAtras(n); return `<button class="fl-chip ${sel === f ? 'on' : ''}" data-rp-fecha="${f}">${t} ${dmyCorto(f)}</button>`; }).join('');
  return `<p class="fl-label">📅 ¿Qué día entró el dinero?</p><div class="fl-chips">${chips}<input class="fl-input" type="date" id="rpFechaOtra" value="${esc(sel)}" max="${hoy}" min="${diasAtras(30)}" style="max-width:170px"></div>
    <p class="fl-muted">Es la fecha que queda en Finanzas. La fecha de renovación del cliente no cambia.</p>`;
}
// R121 · "Ya pagó por Socios": la compra de un socio ya dejó su ingreso en el libro; la ficha se amarra a ese pago
// y NO se registra otro. Solo se puede contra una compra de socio real que todavía no tenga su ficha.
export function pagoSocioTexto(p = {}, u = {}) { const f = String(p.fecha || ''); return [p.socio, u.servicio, u.perfil || p.clienteNombre, lps(p.monto), p.banco, f ? dmyCorto(f) : ''].filter(Boolean).join(' · '); }
function pagoSocioHtml(sheet) {
  if (sheet.sociosError) return `<p class="fl-err">${esc(sheet.sociosError)}</p><button type="button" class="fl-btn ghost" data-rp-socios-reload>Reintentar</button>`;
  if (!Array.isArray(sheet.socios)) return '<p class="fl-muted">Buscando compras de socios…</p>';
  const filas = sheet.socios.flatMap((p) => (p.productos || []).map((u) => ({ id: `${p.movimientoId}|${u.idx}`, p, u })));
  if (!filas.length) return '<p class="fl-muted">No hay compras de socios pendientes de ficha. Si el cliente pagó aparte, use <b>Con pago</b>.</p>';
  return `<p class="fl-label">¿Cuál compra de socio es?</p>${filas.map((f) => `<div class="fl-socio"><button type="button" class="fl-socio-pick ${sheet.socioSel === f.id ? 'on' : ''}" data-rp-socio="${esc(f.id)}">${sheet.socioSel === f.id ? '✅ ' : ''}${esc(pagoSocioTexto(f.p, f.u))}${f.u.restantes > 1 ? ` <small>(${f.u.restantes} sin ficha)</small>` : ''}</button><button type="button" class="fl-socio-done" data-rp-socio-lista="${esc(f.p.movimientoId)}">Ya tiene ficha</button></div>`).join('')}
    <p class="fl-muted">El socio ya pagó desde el Panel de Socios: la ficha se guarda amarrada a ese pago y <b>no se registra otro ingreso</b>.</p>`;
}
// Oct-2026 · Pago dividido: el cliente pagó en 2–4 bancos/métodos el mismo día. El servidor valida igual (repartoPagos).
function partesSuma(sheet, recibido) { const s = money((sheet.partes || []).reduce((a, p) => a + (Number(p.monto) || 0), 0)); const d = money(recibido - s); return `Suman ${lps(s)} de ${lps(recibido)}${d > 0 ? ` · faltan ${lps(d)}` : d < 0 ? ` · sobran ${lps(-d)}` : ' ✓'}`; }
function partesHtml(sheet, methods, recibido) {
  if (!Array.isArray(sheet.partes) || sheet.partes.length < 2) sheet.partes = [{ bancoId: sheet.bancoId || '', monto: '' }, { bancoId: '', monto: '' }];
  return `${sheet.partes.map((p, i) => `<div class="fl-parte"><label class="fl-label">Banco ${i + 1}<select class="fl-input" data-rp-parte-banco="${i}"><option value="">Elegir…</option>${methods.map((m) => `<option value="${esc(m.id)}" ${p.bancoId === m.id ? 'selected' : ''}>${esc(m.nombre)}</option>`).join('')}</select></label><label class="fl-label">Monto<input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="L" data-rp-parte-monto="${i}" value="${esc(p.monto)}"></label>${sheet.partes.length > 2 ? `<button type="button" class="fl-x" data-rp-parte-quitar="${i}" aria-label="Quitar banco ${i + 1}">✕</button>` : ''}</div>`).join('')}
    <small class="fl-muted" id="rpPartesSuma">${partesSuma(sheet, recibido)}</small>${sheet.partes.length < 4 ? '<button type="button" class="fl-link" data-rp-parte-mas>＋ Otro banco</button>' : ''}`;
}
export function validarPartes(partes = [], recibido = 0, methods = []) {
  const lista = (partes || []).filter((p) => p && (p.bancoId || Number(p.monto)));
  if (lista.length < 2) return { ok: false, error: 'Para pago dividido escriba al menos 2 bancos (o use “Un solo banco”).' };
  return repartoPagos(lista, recibido, methods.map((m) => ({ ...m, activo: m.activo !== false })));
}
// Reparte los bancos entre los servicios del cobro, en orden (casi siempre es uno solo).
export function repartirFilas(pagos = [], filas = []) {
  const q = pagos.map((p) => ({ ...p })), out = {};
  for (const f of filas) {
    let falta = money(f.recibido); const lista = [];
    while (falta > 0.009 && q.length) { const p = q[0], t = Math.min(p.monto, falta); const prev = lista.find((x) => x.bancoId === p.bancoId); if (prev) prev.monto = money(prev.monto + t); else lista.push({ bancoId: p.bancoId, monto: money(t) }); p.monto = money(p.monto - t); falta = money(falta - t); if (p.monto <= 0.009) q.shift(); }
    out[f.key] = lista;
  }
  return out;
}
export function renewPaySheetHtml(sheet, methods = []) {
  if (!sheet) return '';
  const ajuste = sheet.modo === 'ajuste', compra = sheet.tipo === 'compra', socio = compra && sheet.modo === 'socio';
  if (socio) return `<div class="fl-sheet-back"><section class="fl-sheet" role="dialog" aria-label="Información del pago">
    <div class="fl-row"><b>Compra nueva · ${esc(sheet.cliente)}</b><button class="fl-x" data-rp-close aria-label="Cerrar">✕</button></div>
    <p class="fl-muted">${esc(sheet.label)}</p>
    <div class="fl-seg"><button data-rp-modo="pago">💵 Con pago</button><button class="on" data-rp-modo="socio">🤝 Ya pagó por Socios</button></div>
    ${pagoSocioHtml(sheet)}
    <p class="fl-err" id="rpError" hidden style="margin:.65rem 0 0;font-weight:800"></p>
    <button class="fl-btn" id="rpConfirm">Guardar ficha sin otro ingreso</button></section></div>`;
  const t = sheetTotals(sheet);
  const recibido = t.reduce((a, r) => a + r.recibido, 0), saldo = t.reduce((a, r) => a + r.saldo, 0);
  return `<div class="fl-sheet-back"><section class="fl-sheet" role="dialog" aria-label="Información del pago">
    <div class="fl-row"><b>${compra ? 'Compra nueva' : 'Renovar'} · ${esc(sheet.cliente)}</b><button class="fl-x" data-rp-close aria-label="Cerrar">✕</button></div>
    <p class="fl-muted">${esc(sheet.label)}</p>
    ${compra ? '<div class="fl-seg"><button class="on" data-rp-modo="pago">💵 Con pago</button><button data-rp-modo="socio">🤝 Ya pagó por Socios</button></div>' : `<div class="fl-seg"><button class="${ajuste ? '' : 'on'}" data-rp-modo="pago">💵 Con pago</button><button class="${ajuste ? 'on' : ''}" data-rp-modo="ajuste">🛠 Ajuste sin pago</button></div>`}
    ${ajuste ? `<label class="fl-label">Motivo (garantía, cortesía, corrección…)<input class="fl-input" id="rpMotivo" value="${esc(sheet.motivo || '')}" maxlength="200"></label><p class="fl-muted">Mueve la fecha sin registrar ingreso ni pendiente. Queda auditado.</p>` : `
    ${t.map((r) => paymentRowHtml(sheet, r)).join('')}
    <div id="rpBancoBox" ${recibido > 0 ? '' : 'hidden'}><p class="fl-label">¿Dónde entró el dinero?</p>${sheet.dividido ? partesHtml(sheet, methods, recibido) : `<div class="fl-chips">${methods.map((m) => `<button class="fl-chip ${sheet.bancoId === m.id ? 'on' : ''}" data-rp-banco="${esc(m.id)}">${esc(m.nombre)}</button>`).join('') || '<p class="fl-err">No hay métodos de pago cargados. Abra Control financiero con internet una vez.</p>'}</div>`}
      <button type="button" class="fl-link" data-rp-dividir>${sheet.dividido ? '← Un solo banco' : '＋ Pagó en 2 bancos o métodos'}</button></div>
    <div id="rpRespBox" ${saldo > 0 ? '' : 'hidden'}><p class="fl-label">¿Quién debe el pendiente?</p><div class="fl-seg"><button class="${sheet.responsable !== 'vendedor' ? 'on' : ''}" data-rp-resp="cliente">👤 Cliente</button><button class="${sheet.responsable === 'vendedor' ? 'on' : ''}" data-rp-resp="vendedor">🧑‍💼 Vendedor</button></div>
    ${sheet.responsable === 'vendedor' ? `<label class="fl-label">Vendedor que tiene el dinero<input class="fl-input" id="rpVendedor" value="${esc(sheet.vendedor || '')}" maxlength="60"></label>` : ''}
    <p class="fl-muted">El pendiente NO suma a bancos ni al disponible hasta que se cobre.</p></div>`}
    ${ajuste ? '' : fechaPagoHtml(sheet)}
    <p class="fl-err" id="rpError" hidden style="margin:.65rem 0 0;font-weight:800"></p>
    <button class="fl-btn" id="rpConfirm">${ajuste ? 'Confirmar ajuste y mover fecha' : (compra ? 'Confirmar operación y guardar' : 'Confirmar y renovar')}</button></section></div>`;
}
export function bindRenewPay(ctx, onConfirm) {
  { const st = ctx.state.renewPay; if (st) {
    document.querySelectorAll('[data-rp-fecha]').forEach((b) => b.addEventListener('click', () => { st.fechaPago = b.dataset.rpFecha; ctx.render(); }));
    document.querySelector('#rpFechaOtra')?.addEventListener('change', (e) => { st.fechaPago = e.target.value || ''; ctx.render(); });
  } } // R110: fecha del pago
  const s = ctx.state.renewPay; if (!s) return;
  const q = (x) => document.querySelector(x), qa = (x) => document.querySelectorAll(x);
  const setError = (msg = '') => { const el = q('#rpError'); if (!el) return; el.textContent = msg; el.hidden = !msg; };
  const statusText = (r) => r.modo === 'pendiente'
    ? (r.saldo > 0 ? `🕒 Pendiente ${lps(r.saldo)}` : 'Escriba cuánto queda pendiente')
    : (r.recibido > 0 ? (r.saldo > 0 ? `◐ Pagó ${lps(r.recibido)} · pendiente ${lps(r.saldo)}` : `✅ Pagado ${lps(r.recibido)}`) : 'Escriba cuánto pagó');
  const refresh = () => {
    setError('');
    const t = sheetTotals(s);
    for (const r of t) { const el = q(`[data-rp-estado="${CSS.escape(r.key)}"]`); if (el) el.textContent = statusText(r); }
    const bb = q('#rpBancoBox'); if (bb) bb.hidden = !(t.reduce((a, r) => a + r.recibido, 0) > 0);
    const rb = q('#rpRespBox'); if (rb) rb.hidden = !(t.reduce((a, r) => a + r.saldo, 0) > 0);
  };
  const fail = (msg) => { setError(msg); const el = q('#rpError'); el?.scrollIntoView?.({ block:'nearest', behavior:'smooth' }); };
  q('[data-rp-close]')?.addEventListener('click', () => { ctx.state.renewPay = null; if (s.onCancel) s.onCancel(); ctx.render(); });
  // R121: lista de compras de socios sin ficha (se pide al servidor al entrar al modo y al quitar una).
  const cargarSocios = async () => {
    s.socios = null; s.sociosError = ''; ctx.render();
    try { const r = await ctx.authPost('/api/finanzas', { accion: 'listar_pagos_socios_sin_ficha' }); if (!r?.ok) throw new Error(r?.error || 'No se pudieron leer las compras de socios.'); s.socios = Array.isArray(r.pagos) ? r.pagos : []; }
    catch (e) { s.socios = []; s.sociosError = `⚠️ ${e?.message || 'Sin conexión'}. Las compras de socios se consultan con internet.`; }
    if (ctx.state.renewPay === s) ctx.render();
  };
  qa('[data-rp-modo]').forEach((b) => b.addEventListener('click', () => { s.modo = b.dataset.rpModo; if (s.modo === 'socio' && !Array.isArray(s.socios)) { cargarSocios(); return; } ctx.render(); }));
  q('[data-rp-socios-reload]')?.addEventListener('click', cargarSocios);
  qa('[data-rp-socio]').forEach((b) => b.addEventListener('click', () => { s.socioSel = b.dataset.rpSocio; ctx.render(); }));
  qa('[data-rp-socio-lista]').forEach((b) => b.addEventListener('click', async () => {
    if (b.dataset.seguro !== '1') { b.dataset.seguro = '1'; b.textContent = '¿Seguro? Tocar otra vez'; return; } // no mueve dinero: solo la quita de esta lista
    try { const r = await ctx.authPost('/api/finanzas', { accion: 'socio_ficha_lista', movimientoId: b.dataset.rpSocioLista, origen: 'apk' }); if (!r?.ok) throw new Error(r?.error || 'No se pudo actualizar.'); if (String(s.socioSel || '').startsWith(`${b.dataset.rpSocioLista}|`)) s.socioSel = ''; cargarSocios(); }
    catch (e) { fail(e?.message || 'No se pudo actualizar.'); }
  }));
  qa('[data-rp-banco]').forEach((b) => b.addEventListener('click', () => { s.bancoId = b.dataset.rpBanco; ctx.render(); }));
  q('[data-rp-dividir]')?.addEventListener('click', () => { s.dividido = !s.dividido; setError(''); ctx.render(); });
  qa('[data-rp-parte-banco]').forEach((el) => el.addEventListener('change', () => { s.partes[Number(el.dataset.rpParteBanco)].bancoId = el.value; setError(''); }));
  qa('[data-rp-parte-monto]').forEach((el) => el.addEventListener('input', () => { s.partes[Number(el.dataset.rpParteMonto)].monto = el.value; setError(''); const sm = q('#rpPartesSuma'); if (sm) sm.textContent = partesSuma(s, sheetTotals(s).reduce((a, r) => a + r.recibido, 0)); }));
  q('[data-rp-parte-mas]')?.addEventListener('click', () => { if (s.partes.length < 4) s.partes.push({ bancoId: '', monto: '' }); ctx.render(); });
  qa('[data-rp-parte-quitar]').forEach((b) => b.addEventListener('click', () => { if (s.partes.length > 2) s.partes.splice(Number(b.dataset.rpParteQuitar), 1); ctx.render(); }));
  qa('[data-rp-resp]').forEach((b) => b.addEventListener('click', () => { s.responsable = b.dataset.rpResp; ctx.render(); }));
  qa('[data-rp-status]').forEach((b) => b.addEventListener('click', () => { const m = (s.montos[b.dataset.rpKey] ||= {}); m.estadoCobro = b.dataset.rpStatus; if (m.estadoCobro === 'pendiente') m.tienePendiente = false; setError(''); ctx.render(); }));
  qa('[data-rp-toggle-pending]').forEach((b) => b.addEventListener('click', () => { const m = (s.montos[b.dataset.rpTogglePending] ||= {}); m.tienePendiente = !m.tienePendiente; setError(''); ctx.render(); }));
  // Puente legado invisible: acepta total/recibido de automatizaciones viejas y lo traduce al libro nuevo.
  qa('[data-rp-total]').forEach((i) => i.addEventListener('input', () => { const m = (s.montos[i.dataset.rpTotal] ||= {}); m.total = i.value; m._legacyInput = true; refresh(); }));
  qa('[data-rp-recibido]').forEach((i) => i.addEventListener('input', () => { const m = (s.montos[i.dataset.rpRecibido] ||= {}); m.recibido = i.value; m._legacyInput = true; refresh(); }));
  qa('[data-rp-pagado]').forEach((i) => i.addEventListener('input', () => { const m = (s.montos[i.dataset.rpPagado] ||= {}); m.pagado = i.value; m._legacyInput = false; refresh(); }));
  qa('[data-rp-pendiente]').forEach((i) => i.addEventListener('input', () => { const m = (s.montos[i.dataset.rpPendiente] ||= {}); m.pendiente = i.value; m._legacyInput = false; refresh(); }));
  q('#rpMotivo')?.addEventListener('input', (e) => { s.motivo = e.target.value; });
  q('#rpVendedor')?.addEventListener('input', (e) => { s.vendedor = e.target.value; });
  q('#rpConfirm')?.addEventListener('click', () => {
    if (s.modo === 'ajuste') { if (String(s.motivo || '').trim().length < 4) return fail('Escriba el motivo del ajuste.'); return onConfirm(s); }
    if (s.tipo === 'compra' && s.modo === 'socio') { // R121
      const [movimientoId, idx] = String(s.socioSel || '').split('|'); const p = (s.socios || []).find((x) => x.movimientoId === movimientoId); const u = (p?.productos || []).find((x) => String(x.idx) === String(idx));
      if (!p || !u) return fail('Elija cuál compra de socio corresponde a esta ficha.');
      s.pagoSocio = { movimientoId, productoIdx: Number(idx) || 0 }; s.socioTexto = pagoSocioTexto(p, u); setError(''); return onConfirm(s);
    }
    const t = sheetTotals(s);
    for (const r of t) {
      if (r.modo === 'pagado' && !(r.recibido > 0)) return fail(`Escriba cuánto pagó (${r.label}).`);
      if (r.modo === 'pagado' && (s.montos[r.key]?.tienePendiente) && !(r.saldo > 0)) return fail(`Escriba el saldo pendiente (${r.label}).`);
      if (r.modo === 'pendiente' && !(r.saldo > 0)) return fail(`Escriba cuánto queda pendiente (${r.label}).`);
    }
    const recTotal = t.reduce((a, r) => a + r.recibido, 0);
    s.pagos = null; s.pagosPorFila = null;
    if (recTotal > 0 && s.dividido) { const v = validarPartes(s.partes, recTotal, ctx.state?.libro?.data?.metodos || cachedMethods()); if (!v.ok) return fail(v.error); s.pagos = v.pagos; s.pagosPorFila = repartirFilas(v.pagos, t); }
    if (recTotal > 0 && !s.pagos && !s.bancoId) return fail('Elija el banco o método donde entró el dinero.');
    if (t.some((r) => r.saldo > 0) && s.responsable === 'vendedor' && !String(s.vendedor || '').trim()) return fail('Escriba el vendedor que tiene el dinero.');
    setError(''); onConfirm(s);
  });
}
// Cuerpo para /api/finanzas registrar_operacion_pago (mismo contrato en APK, bot y web).
export function operacionPagoBody(s, key, extra = {}) {
  if (s.tipo === 'compra' && s.modo === 'socio' && s.pagoSocio) return { pagoSocio: { movimientoId: s.pagoSocio.movimientoId, productoIdx: s.pagoSocio.productoIdx }, origen: 'apk', ...extra }; // R121: sin ingreso nuevo
  const m = rowPaymentState(s, key), pp = (s.pagosPorFila || {})[key]; // Oct-2026 · pago en 2+ bancos
  return { accion: 'registrar_operacion_pago', tipoOrigen: s.tipo === 'compra' ? 'compra' : 'renovacion', montoTotal: Number(m.total || 0), recibido: Number(m.recibido || 0), bancoId: Number(m.recibido || 0) > 0 ? (pp && pp[0] ? pp[0].bancoId : (s.bancoId || '')) : '', ...(pp && pp.length > 1 ? { pagos: pp } : {}), responsable: s.responsable === 'vendedor' ? 'vendedor' : 'cliente', vendedorNombre: s.responsable === 'vendedor' ? String(s.vendedor || '').trim() : '', origen: 'apk', fechaPago: s.fechaPago || ymdLocal(), ...extra };
}

// R186 · Renovación múltiple: UN pago con el monto de cada servicio (asignaciones). Suma exacta en centavos.
export function pagoLoteBody(s, extra = {}) {
  let total = 0, recibido = 0; const porBanco = {}; const montos = {};
  for (const r of s.rows || []) {
    const m = rowPaymentState(s, r.key); const t = Math.round(Number(m.total || 0) * 100), rc = Math.round(Number(m.recibido || 0) * 100);
    montos[r.key] = t / 100; total += t; recibido += rc;
    for (const p of ((s.pagosPorFila || {})[r.key] || [])) porBanco[p.bancoId] = (porBanco[p.bancoId] || 0) + Math.round(Number(p.monto || 0) * 100);
  }
  const pagos = Object.entries(porBanco).filter(([, c]) => c > 0).map(([bancoId, c]) => ({ bancoId, monto: c / 100 }));
  return { montos, pago: { montoTotal: total / 100, recibido: recibido / 100, bancoId: recibido > 0 ? (pagos[0]?.bancoId || s.bancoId || '') : '', ...(pagos.length > 1 ? { pagos } : {}), responsable: s.responsable, vendedorNombre: s.vendedor, fechaPago: s.fechaPago || '', origen: 'apk', ...extra } };
}
