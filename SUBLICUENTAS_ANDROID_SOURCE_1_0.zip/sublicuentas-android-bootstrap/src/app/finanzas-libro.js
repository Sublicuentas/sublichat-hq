// R104 · FINANZAS (libro mayor) dentro de Más > Control financiero — solo Sublicuentas y Relojes.
// Pestañas: Resumen · Bancos · Planilla · Movimientos · Cierre · Reportes (la vista anterior se conserva).
// Además: hoja de pago REAL al renovar (monto escrito + dónde pagó, o ajuste sin pago con motivo).
// El servidor (/api/finanzas) es la fuente de verdad: aquí solo se muestra y se arma el borrador.
import { validatePlanilla, PLANILLA_CONCEPTOS, money } from './finanzas-reglas.js';

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const lps = (n) => `Lps. ${money(n).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
const METHODS_KEY = 'sublicuentas-fin-metodos-v1';

export function isLibroUser(identity) { return ['sublicuentas', 'relojes'].includes(identity); }
export function cachedMethods() { try { return JSON.parse(localStorage.getItem(METHODS_KEY) || '[]'); } catch (_) { return []; } }
function rememberMethods(list) { try { localStorage.setItem(METHODS_KEY, JSON.stringify((list || []).map(({ id, nombre, logoKey }) => ({ id, nombre, logoKey })))); } catch (_) {} }

export function initLibroState(state) {
  if (state.libro) return;
  state.libro = { tab: 'resumen', data: null, loading: false, error: '', movs: null, movFiltro: { tipo: '', bancoId: '', texto: '', desde: '', hasta: '' }, draft: null, ajuste: null, sending: false };
}

// ---------------------------------------------------------------- carga
export async function loadLibro(ctx, { silent = false } = {}) {
  const L = ctx.state.libro;
  if (L.loading) return;
  L.loading = true; if (!silent) ctx.render();
  try {
    const r = await ctx.authPost('/api/finanzas', { accion: 'finanzas_resumen' });
    if (!r?.ok) throw new Error(r?.error || 'No se pudo leer Finanzas.');
    L.data = r; L.error = ''; rememberMethods(r.metodos);
  } catch (e) { L.error = e?.message || 'Sin conexión con Finanzas.'; }
  finally { L.loading = false; ctx.render(); }
}
async function loadMovs(ctx) {
  const L = ctx.state.libro;
  L.movs = { loading: true, rows: [] }; ctx.render();
  try {
    const r = await ctx.authPost('/api/finanzas', { accion: 'finanzas_movimientos', ...L.movFiltro });
    if (!r?.ok) throw new Error(r?.error || 'No se pudieron leer los movimientos.');
    L.movs = { loading: false, rows: r.movimientos || [], total: r.total || 0 };
  } catch (e) { L.movs = { loading: false, rows: [], error: e?.message || 'Error' }; }
  ctx.render();
}

// ---------------------------------------------------------------- vistas
const TABS = [['resumen', 'Resumen'], ['bancos', 'Bancos'], ['planilla', 'Planilla'], ['movimientos', 'Movimientos'], ['cierre', 'Cierre'], ['reportes', 'Reportes']];

export function libroViewHtml(state, reportesHtml = '') {
  const L = state.libro;
  const tabs = `<nav class="fl-tabs" role="tablist">${TABS.map(([k, t]) => `<button type="button" class="fl-tab ${L.tab === k ? 'on' : ''}" data-fl-tab="${k}">${t}</button>`).join('')}</nav>`;
  if (L.tab === 'reportes') return tabs + reportesHtml;
  if (!L.data) return tabs + `<section class="fl-card">${L.error ? `<p class="fl-err">⚠️ ${esc(L.error)}</p><button class="fl-btn" data-fl-reload>Reintentar</button>` : '<p class="fl-muted">Cargando finanzas…</p>'}</section>`;
  const body = { resumen: resumenHtml, bancos: bancosHtml, planilla: planillaHtml, movimientos: movimientosHtml, cierre: cierreHtml }[L.tab] || resumenHtml;
  return tabs + (L.error ? `<p class="fl-err">⚠️ ${esc(L.error)}</p>` : '') + body(L);
}

function resumenHtml(L) {
  const d = L.data, t = d.totales;
  const aviso = d.ciclo.diasDesdeUltimoCierre != null ? `<p class="fl-muted">Último cierre: ${esc(d.ciclo.ultimoCierreFin)} · hace ${d.ciclo.diasDesdeUltimoCierre} día${d.ciclo.diasDesdeUltimoCierre === 1 ? '' : 's'}.</p>` : '';
  const sinActivar = d.bancos.filter((b) => !b.activado).length;
  return `<section class="fl-card">
    <div class="fl-row"><b>Ciclo abierto</b><span class="fl-pill">desde ${esc(d.ciclo.inicio)} · día ${d.ciclo.dias}</span></div>${aviso}
    <div class="fl-lines">
      <div><span>Ingresos</span><b class="fl-pos">${lps(t.ingresos)}</b></div>
      <div><span>Egresos operativos</span><b class="fl-neg">− ${lps(t.egresosOperativos)}</b></div>
      <div class="fl-sub"><span>Disponible antes de planilla</span><b>${lps(t.disponibleAntesPlanilla)}</b></div>
      <div><span>Planilla / comisiones</span><b class="fl-neg">− ${lps(t.planilla)}</b></div>
      <div class="fl-total"><span>Resultado después de planilla</span><b>${lps(t.resultado)}</b></div>
    </div></section>
  <section class="fl-card"><div class="fl-row"><b>Saldo real en bancos</b><b>${lps(d.totalBancos)}</b></div>
    ${d.bancos.filter((b) => b.activado).map((b) => `<div class="fl-bank"><span>${esc(b.nombre)}</span><b>${lps(b.saldo)}</b></div>`).join('') || '<p class="fl-muted">Ningún banco activado todavía.</p>'}
    ${sinActivar ? `<p class="fl-muted">${sinActivar} banco${sinActivar === 1 ? '' : 's'} sin saldo inicial · regístrelo en la pestaña <b>Bancos</b>.</p>` : ''}</section>
  ${d.planillaPagos.length ? `<section class="fl-card"><b>Planilla de este ciclo</b>${d.planillaPagos.map((p) => `<div class="fl-bank"><span>${esc(p.beneficiario)} · ${esc(p.conceptoLabel || '')}<small>${(p.asignaciones || []).map((a) => `${esc(a.banco)} ${lps(a.monto)}`).join(' + ')}</small></span><b>${lps(p.montoTotal)}</b></div>`).join('')}</section>` : ''}
  <button class="fl-btn ghost" data-fl-reload>↻ Actualizar</button>`;
}

function bancosHtml(L) {
  const d = L.data;
  const rows = d.bancos.map((b) => {
    if (!b.activado) return `<div class="fl-bankcard"><div class="fl-row"><b>${esc(b.nombre)}</b><span class="fl-pill warn">Sin saldo inicial</span></div>
      <div class="fl-inline"><input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="Saldo real hoy (Lps.)" data-fl-ini="${esc(b.id)}"><button class="fl-btn" data-fl-ini-save="${esc(b.id)}">Registrar</button></div>
      <p class="fl-muted">Se registra una sola vez. Después solo se corrige con un ajuste con motivo.</p></div>`;
    const aj = L.ajuste === b.id ? `<div class="fl-inline col"><input class="fl-input" type="number" inputmode="decimal" placeholder="Ajuste (+ suma / − resta)" id="flAjMonto"><input class="fl-input" placeholder="Motivo del ajuste (obligatorio)" id="flAjMotivo"><div class="fl-inline"><button class="fl-btn" data-fl-aj-save="${esc(b.id)}">Guardar ajuste</button><button class="fl-btn ghost" data-fl-aj-cancel>Cancelar</button></div></div>` : '';
    return `<div class="fl-bankcard"><div class="fl-row"><b>${esc(b.nombre)}</b><b>${lps(b.saldo)}</b></div>
      <small class="fl-muted">Base ${lps(b.base)} desde ${esc(b.desde)} · +${lps(b.ingresos)} · −${lps(b.egresosOperativos)} gastos · −${lps(b.planilla)} planilla${b.ajustes ? ` · ajustes ${lps(b.ajustes)}` : ''}</small>
      ${aj || `<button class="fl-link" data-fl-aj="${esc(b.id)}">Ajuste de saldo…</button>`}</div>`;
  }).join('');
  return `<section class="fl-card"><div class="fl-row"><b>Saldos por banco</b><b>${lps(d.totalBancos)}</b></div>${rows}</section>`;
}

export function newDraft(today) { return { beneficiario: '', concepto: 'pago_planilla', descripcion: '', monto: '', fecha: today, asignaciones: {} }; }
function draftValidation(L) {
  const d = L.draft, data = L.data;
  return validatePlanilla({ montoTotal: Number(d.monto || 0), asignaciones: Object.entries(d.asignaciones).map(([bancoId, monto]) => ({ bancoId, monto: Number(monto || 0) })), bancos: data.bancos, disponibleCiclo: data.totales.resultado });
}
function planillaHtml(L) {
  const data = L.data;
  if (!L.draft) {
    return `<section class="fl-card"><div class="fl-row"><b>Planilla / distribución</b><span class="fl-pill">Disponible ${lps(data.totales.resultado)}</span></div>
      <p class="fl-muted">Beneficiario, concepto y monto libres. Cada pago puede salir de uno o varios bancos.</p>
      <button class="fl-btn" data-fl-new-pay>＋ Nuevo pago</button></section>
      ${data.planillaPagos.length ? `<section class="fl-card"><b>Pagos confirmados del ciclo</b>${data.planillaPagos.map((p) => `<div class="fl-bank"><span>${esc(p.beneficiario)} · ${esc(p.conceptoLabel || '')}<small>${esc(p.fecha)} · ${(p.asignaciones || []).map((a) => `${esc(a.banco)} ${lps(a.monto)} (${lps(a.saldoAntes)} → ${lps(a.saldoDespues)})`).join(' + ')}</small></span><b>${lps(p.montoTotal)}</b></div>`).join('')}</section>` : ''}`;
  }
  const d = L.draft, v = draftValidation(L);
  const bancos = data.bancos.filter((b) => b.activado);
  return `<section class="fl-card"><div class="fl-row"><b>Nuevo pago (borrador)</b><span class="fl-pill">Disponible ${lps(data.totales.resultado)}</span></div>
    <label class="fl-label">Beneficiario<input class="fl-input" id="flBen" value="${esc(d.beneficiario)}" placeholder="Nombre (libre)" maxlength="80"></label>
    <label class="fl-label">Concepto<select class="fl-input" id="flCon">${Object.entries(PLANILLA_CONCEPTOS).map(([k, t]) => `<option value="${k}" ${d.concepto === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    <label class="fl-label" id="flDescWrap" ${d.concepto === 'otro_planilla' ? '' : 'hidden'}>Descripción<input class="fl-input" id="flDesc" value="${esc(d.descripcion)}" maxlength="160"></label>
    <div class="fl-inline"><label class="fl-label">Monto total<input class="fl-input" id="flMonto" type="number" inputmode="decimal" min="0" value="${esc(d.monto)}" placeholder="Lps."></label>
    <label class="fl-label">Fecha<input class="fl-input" id="flFecha" type="date" value="${esc(d.fecha)}"></label></div>
    <div class="fl-dist"><div class="fl-dist-h"><span>Banco</span><span>Antes</span><span>Tomar</span><span>Después</span></div>
    ${bancos.map((b) => `<div class="fl-dist-r"><span>${esc(b.nombre)}</span><span>${lps(b.saldo)}</span><input class="fl-input" type="number" inputmode="decimal" min="0" data-fl-take="${esc(b.id)}" value="${esc(d.asignaciones[b.id] || '')}" placeholder="0"><span data-fl-after="${esc(b.id)}">${lps(b.saldo - Number(d.asignaciones[b.id] || 0))}</span></div>`).join('')}</div>
    <p class="fl-status" id="flStatus">${statusText(v, d)}</p>
    <div class="fl-inline"><button class="fl-btn" id="flConfirm" ${v.ok && !L.sending ? '' : 'disabled'}>${L.sending ? 'Confirmando…' : 'Confirmar pago'}</button><button class="fl-btn ghost" data-fl-cancel-pay>Cancelar</button></div>
    <p class="fl-muted">Mientras no confirme, es solo un borrador: cancelar no cambia ningún saldo.</p></section>`;
}
function statusText(v, d) {
  if (!Number(d.monto)) return 'Escriba el monto total y cuánto tomar de cada banco.';
  if (v.ok) return `✅ Distribución completa: ${lps(v.asignado)}.`;
  return v.errors.map(esc).join('<br>');
}

function movimientosHtml(L) {
  const d = L.data, f = L.movFiltro, m = L.movs;
  const kinds = { '': 'Todos', ingreso: 'Ingresos', egreso: 'Egresos operativos', planilla: 'Planilla', ajuste: 'Ajustes', saldo_inicial: 'Saldos iniciales' };
  const list = !m ? '<p class="fl-muted">Toque “Buscar”.</p>' : m.loading ? '<p class="fl-muted">Cargando…</p>' : m.error ? `<p class="fl-err">${esc(m.error)}</p>` :
    (m.rows.length ? m.rows.map((r) => `<div class="fl-mov ${r.kind}"><span><b>${esc(r.detalle || r.cliente || r.beneficiario || kinds[r.kind] || r.tipo)}</b><small>${esc(r.fecha)} · ${esc(r.banco)} · ${esc(kinds[r.kind] || r.kind)}${r.cliente ? ` · ${esc(r.cliente)}` : ''}${r.usuario ? ` · ${esc(r.usuario)}` : ''}${r.origen ? ` · ${esc(r.origen)}` : ''}</small></span><b>${['egreso', 'planilla'].includes(r.kind) ? '−' : ''}${lps(r.monto)}</b></div>`).join('') + (m.total > m.rows.length ? `<p class="fl-muted">Mostrando ${m.rows.length} de ${m.total}.</p>` : '') : '<p class="fl-muted">Sin movimientos con esos filtros.</p>');
  return `<section class="fl-card"><b>＋ Egreso operativo</b>
    <div class="fl-inline col"><input class="fl-input" id="flEgMot" placeholder="Concepto (proveedor, publicidad…)"><div class="fl-inline"><input class="fl-input" id="flEgMonto" type="number" inputmode="decimal" placeholder="Monto Lps."><select class="fl-input" id="flEgBanco"><option value="">¿De qué banco salió?</option>${d.metodos.map((b) => `<option value="${esc(b.id)}">${esc(b.nombre)}</option>`).join('')}</select></div><button class="fl-btn" id="flEgSave">Guardar egreso</button></div></section>
  <section class="fl-card"><b>Movimientos</b>
    <div class="fl-inline wrap"><select class="fl-input" id="flMTipo">${Object.entries(kinds).map(([k, t]) => `<option value="${k}" ${f.tipo === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
    <select class="fl-input" id="flMBanco"><option value="">Todos los bancos</option>${d.metodos.map((b) => `<option value="${esc(b.id)}" ${f.bancoId === b.id ? 'selected' : ''}>${esc(b.nombre)}</option>`).join('')}<option value="sin_banco" ${f.bancoId === 'sin_banco' ? 'selected' : ''}>Sin banco</option></select>
    <input class="fl-input" type="date" id="flMDesde" value="${esc(f.desde)}"><input class="fl-input" type="date" id="flMHasta" value="${esc(f.hasta)}">
    <input class="fl-input" id="flMTexto" placeholder="Cliente, beneficiario, detalle…" value="${esc(f.texto)}"><button class="fl-btn" id="flMBuscar">Buscar</button></div>${list}</section>`;
}

function cierreHtml(L) {
  const d = L.data, t = d.totales;
  return `<section class="fl-card"><b>Cerrar ciclo</b><p class="fl-muted">Usted decide cuándo cerrar (día 8, 10, 15…). El cierre congela el periodo; los bancos conservan su saldo y empieza un ciclo nuevo.</p>
    <div class="fl-lines"><div><span>Inicio</span><b>${esc(d.ciclo.inicio)}</b></div><div><span>Ingresos</span><b>${lps(t.ingresos)}</b></div><div><span>Egresos operativos</span><b>${lps(t.egresosOperativos)}</b></div>
    <div class="fl-sub"><span>Disponible antes de planilla</span><b>${lps(t.disponibleAntesPlanilla)}</b></div><div><span>Planilla / comisiones</span><b>${lps(t.planilla)}</b></div>
    <div class="fl-total"><span>Resultado final</span><b>${lps(t.resultado)}</b></div><div><span>Saldo retenido en bancos</span><b>${lps(d.totalBancos)}</b></div></div>
    <label class="fl-label">Cerrar hasta (incluye este día)<input class="fl-input" type="date" id="flCierreFin" value="${esc(d.hoy)}" max="${esc(d.hoy)}"></label>
    <label class="fl-label">Nota (opcional)<input class="fl-input" id="flCierreNota" maxlength="300"></label>
    <button class="fl-btn" id="flCierreOk" ${L.sending ? 'disabled' : ''}>Confirmar cierre</button></section>
  ${d.cierres.length ? `<section class="fl-card"><b>Cierres anteriores</b>${d.cierres.map((c) => `<div class="fl-bank"><span>${esc(c.fechaInicio)} → ${esc(c.fechaFin)}<small>Ingresos ${lps(c.ingresos)} · Gastos ${lps(c.egresosOperativos)} · Planilla ${lps(c.planilla)} · por ${esc(c.cerradoPor)}</small></span><b>${lps(c.resultado)}</b></div>`).join('')}</section>` : ''}`;
}

// ---------------------------------------------------------------- eventos
export function bindLibro(root, ctx) {
  const L = ctx.state.libro; if (!L || !root) return;
  const q = (s) => root.querySelector(s), qa = (s) => root.querySelectorAll(s);
  qa('[data-fl-tab]').forEach((b) => b.addEventListener('click', () => { L.tab = b.dataset.flTab; if (L.tab === 'movimientos' && !L.movs && L.data) loadMovs(ctx); ctx.render(); }));
  qa('[data-fl-reload]').forEach((b) => b.addEventListener('click', () => loadLibro(ctx)));
  const post = async (body, okMsg) => {
    if (L.sending) return null; L.sending = true; ctx.render();
    try { const r = await ctx.authPost('/api/finanzas', { origen: 'apk', ...body }); if (!r?.ok) throw new Error(r?.error || 'No se pudo guardar.'); if (okMsg) ctx.showToast(okMsg); return r; }
    catch (e) { ctx.showToast(e?.message || 'Error'); return null; }
    finally { L.sending = false; ctx.render(); }
  };
  // Bancos
  qa('[data-fl-ini-save]').forEach((b) => b.addEventListener('click', async () => {
    const id = b.dataset.flIniSave, input = root.querySelector(`[data-fl-ini="${CSS.escape(id)}"]`); const raw = String(input?.value || '').trim();
    if (raw === '' || !(Number(raw) >= 0)) return ctx.showToast('Escriba el saldo real del banco hoy (0 o más).');
    const banco = L.data.bancos.find((x) => x.id === id);
    if (!window.confirm(`¿Registrar ${lps(raw)} como saldo inicial de ${banco?.nombre}? Solo se hace una vez.`)) return;
    if (await post({ accion: 'registrar_saldo_inicial', bancoId: id, monto: Number(raw) }, 'Saldo inicial registrado.')) loadLibro(ctx, { silent: true });
  }));
  qa('[data-fl-aj]').forEach((b) => b.addEventListener('click', () => { L.ajuste = b.dataset.flAj; ctx.render(); }));
  q('[data-fl-aj-cancel]')?.addEventListener('click', () => { L.ajuste = null; ctx.render(); });
  qa('[data-fl-aj-save]').forEach((b) => b.addEventListener('click', async () => {
    const monto = Number(q('#flAjMonto')?.value || 0), motivo = String(q('#flAjMotivo')?.value || '').trim();
    if (!monto) return ctx.showToast('Escriba el ajuste (+ suma, − resta).');
    if (motivo.length < 4) return ctx.showToast('El ajuste necesita un motivo.');
    if (await post({ accion: 'registrar_ajuste_saldo', bancoId: b.dataset.flAjSave, monto, motivo, operationId: ctx.newOperationId() }, 'Ajuste guardado.')) { L.ajuste = null; loadLibro(ctx, { silent: true }); }
  }));
  // Planilla (borrador local, cálculo en vivo sin re-render para no perder el foco)
  q('[data-fl-new-pay]')?.addEventListener('click', () => { L.draft = newDraft(L.data.hoy); L.draft.operationId = ctx.newOperationId(); ctx.render(); });
  q('[data-fl-cancel-pay]')?.addEventListener('click', () => { L.draft = null; ctx.render(); });
  if (L.draft) {
    const d = L.draft;
    const refresh = () => {
      const v = draftValidation(L);
      for (const b of L.data.bancos) { const cell = root.querySelector(`[data-fl-after="${CSS.escape(b.id)}"]`); if (cell) { const after = b.saldo - Number(d.asignaciones[b.id] || 0); cell.textContent = lps(after); cell.classList.toggle('fl-neg', after < 0); } }
      const st = q('#flStatus'); if (st) { st.innerHTML = statusText(v, d); st.classList.toggle('ok', v.ok); }
      const btn = q('#flConfirm'); if (btn) btn.disabled = !v.ok || L.sending;
    };
    q('#flBen')?.addEventListener('input', (e) => { d.beneficiario = e.target.value; });
    q('#flCon')?.addEventListener('change', (e) => { d.concepto = e.target.value; const w = q('#flDescWrap'); if (w) w.hidden = d.concepto !== 'otro_planilla'; });
    q('#flDesc')?.addEventListener('input', (e) => { d.descripcion = e.target.value; });
    q('#flFecha')?.addEventListener('change', (e) => { d.fecha = e.target.value; });
    q('#flMonto')?.addEventListener('input', (e) => { d.monto = e.target.value; refresh(); });
    qa('[data-fl-take]').forEach((inp) => inp.addEventListener('input', () => { d.asignaciones[inp.dataset.flTake] = inp.value; refresh(); }));
    q('#flConfirm')?.addEventListener('click', async () => {
      const v = draftValidation(L); if (!v.ok) return refresh();
      if (!d.beneficiario.trim()) return ctx.showToast('Escriba el beneficiario.');
      if (d.concepto === 'otro_planilla' && d.descripcion.trim().length < 3) return ctx.showToast('“Otro” necesita una descripción.');
      const resumen = v.asignaciones.map((a) => `${a.banco}: ${lps(a.monto)} (${lps(a.saldoAntes)} → ${lps(a.saldoDespues)})`).join('\n');
      if (!window.confirm(`Pagar ${lps(d.monto)} a ${d.beneficiario}?\n\n${resumen}`)) return;
      const r = await post({ accion: 'confirmar_pago_planilla', beneficiario: d.beneficiario.trim(), concepto: d.concepto, descripcion: d.descripcion.trim(), montoTotal: Number(d.monto), fecha: d.fecha, asignaciones: v.asignaciones.map((a) => ({ bancoId: a.bancoId, monto: a.monto })), operationId: d.operationId }, `✅ Pago a ${d.beneficiario.trim()} confirmado.`);
      if (r) { L.draft = null; L.movs = null; loadLibro(ctx, { silent: true }); }
    });
  }
  // Movimientos + egreso operativo
  q('#flEgSave')?.addEventListener('click', async () => {
    const motivo = String(q('#flEgMot')?.value || '').trim(), monto = Number(q('#flEgMonto')?.value || 0), bancoId = q('#flEgBanco')?.value || '';
    if (!motivo || !(monto > 0)) return ctx.showToast('Escriba concepto y monto del egreso.');
    if (!bancoId) return ctx.showToast('Elija de qué banco salió.');
    const r = await post({ accion: 'registrar_egreso', motivo, monto, bancoId, subtipo: 'egreso_operativo', operationId: ctx.newOperationId() }, 'Egreso guardado.');
    if (r) { L.movs = null; await loadLibro(ctx, { silent: true }); if (L.tab === 'movimientos') loadMovs(ctx); }
  });
  q('#flMBuscar')?.addEventListener('click', () => {
    Object.assign(L.movFiltro, { tipo: q('#flMTipo')?.value || '', bancoId: q('#flMBanco')?.value || '', texto: q('#flMTexto')?.value || '', desde: q('#flMDesde')?.value || '', hasta: q('#flMHasta')?.value || '' });
    loadMovs(ctx);
  });
  // Cierre
  q('#flCierreOk')?.addEventListener('click', async () => {
    const fechaFin = q('#flCierreFin')?.value || L.data.hoy, nota = q('#flCierreNota')?.value || '';
    if (!window.confirm(`¿Cerrar el ciclo ${L.data.ciclo.inicio} → ${fechaFin}?\nResultado: ${lps(L.data.totales.resultado)}\nLos bancos conservan su saldo.`)) return;
    if (await post({ accion: 'guardar_cierre_ciclo', fechaFin, nota, operationId: ctx.newOperationId() }, '✅ Ciclo cerrado. Empieza uno nuevo.')) loadLibro(ctx, { silent: true });
  });
}

// ---------------------------------------------------------------- hoja de pago al renovar
// rows: [{key,label}] · methods: [{id,nombre}] · pago: {modo, montos:{}, bancoId, motivo}
export function renewPaySheetHtml(sheet, methods = []) {
  if (!sheet) return '';
  const ajuste = sheet.modo === 'ajuste';
  return `<div class="fl-sheet-back"><section class="fl-sheet" role="dialog" aria-label="Pago de la renovación">
    <div class="fl-row"><b>Renovar · ${esc(sheet.cliente)}</b><button class="fl-x" data-rp-close aria-label="Cerrar">✕</button></div>
    <p class="fl-muted">${esc(sheet.label)}</p>
    <div class="fl-seg"><button class="${ajuste ? '' : 'on'}" data-rp-modo="pago">💵 Pagó</button><button class="${ajuste ? 'on' : ''}" data-rp-modo="ajuste">🛠 Ajuste sin pago</button></div>
    ${ajuste ? `<label class="fl-label">Motivo (garantía, cortesía, corrección…)<input class="fl-input" id="rpMotivo" value="${esc(sheet.motivo || '')}" maxlength="200"></label><p class="fl-muted">Mueve la fecha sin registrar ingreso. Queda auditado.</p>` : `
    ${sheet.rows.map((r) => `<label class="fl-label">¿Cuánto pagó? · ${esc(r.label)}<input class="fl-input" type="number" inputmode="decimal" min="0" placeholder="Lps." data-rp-monto="${esc(r.key)}" value="${esc(sheet.montos[r.key] || '')}"></label>`).join('')}
    <p class="fl-label">¿Dónde pagó?</p><div class="fl-chips">${methods.map((m) => `<button class="fl-chip ${sheet.bancoId === m.id ? 'on' : ''}" data-rp-banco="${esc(m.id)}">${esc(m.nombre)}</button>`).join('') || '<p class="fl-err">No hay métodos de pago cargados. Abra Control financiero con internet una vez.</p>'}</div>`}
    <button class="fl-btn" id="rpConfirm">${ajuste ? 'Confirmar ajuste y mover fecha' : 'Confirmar pago y renovar'}</button></section></div>`;
}
export function bindRenewPay(ctx, onConfirm) {
  const s = ctx.state.renewPay; if (!s) return;
  const q = (x) => document.querySelector(x), qa = (x) => document.querySelectorAll(x);
  q('[data-rp-close]')?.addEventListener('click', () => { ctx.state.renewPay = null; ctx.render(); });
  qa('[data-rp-modo]').forEach((b) => b.addEventListener('click', () => { s.modo = b.dataset.rpModo; ctx.render(); }));
  qa('[data-rp-banco]').forEach((b) => b.addEventListener('click', () => { s.bancoId = b.dataset.rpBanco; ctx.render(); }));
  qa('[data-rp-monto]').forEach((i) => i.addEventListener('input', () => { s.montos[i.dataset.rpMonto] = i.value; }));
  q('#rpMotivo')?.addEventListener('input', (e) => { s.motivo = e.target.value; });
  q('#rpConfirm')?.addEventListener('click', () => {
    if (s.modo === 'ajuste') { if (String(s.motivo || '').trim().length < 4) return ctx.showToast('Escriba el motivo del ajuste.'); }
    else {
      for (const r of s.rows) if (!(Number(s.montos[r.key]) > 0)) return ctx.showToast(`Escriba cuánto pagó (${r.label}).`);
      if (!s.bancoId) return ctx.showToast('Elija dónde pagó.');
    }
    onConfirm(s);
  });
}
