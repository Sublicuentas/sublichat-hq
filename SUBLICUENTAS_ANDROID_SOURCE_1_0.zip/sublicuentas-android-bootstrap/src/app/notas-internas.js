// src/app/notas-internas.js · Oct-2026 · Nota interna (cliente y servicio) visible para el personal en la APK.
// Es un campo SEPARADO de fichaTexto: nunca entra en entregas, cobros ni en el portal del cliente.
// Se edita desde Sublichat Web (Clientes → Cobro → Notas internas); aquí solo se muestra.
import { state, esc } from './core.js';

function notaHtml(titulo, n) {
  const texto = String(n?.texto || '').trim();
  if (!texto) return '';
  const quien = [n.actualizadoPor, n.actualizadoAt ? new Date(n.actualizadoAt).toLocaleString('es-HN') : ''].filter(Boolean).join(' · ');
  return `<div class="crm2-nota"><b>📝 ${esc(titulo)}</b><p>${esc(texto)}</p>${quien ? `<small>Nota interna · ${esc(quien)}</small>` : ''}</div>`;
}

export function crmNotasInternasHtml(d = {}) {
  const id = String(d.savedClientId || d.clienteId || '');
  if (!id) return '';
  const cliente = (state.clients || []).find(c => String(c?.id || '') === id);
  if (!cliente) return '';
  const servicio = (Array.isArray(cliente.servicios) ? cliente.servicios : []).find(s => d.compraId && String(s?.compraId || '') === String(d.compraId));
  const html = notaHtml('Nota interna del cliente', cliente.notaInterna) + notaHtml('Nota interna de este servicio', servicio?.notaInterna);
  return html ? `<section class="panel crm2-notas" aria-label="Notas internas (no las ve el cliente)">${html}</section>` : '';
}
