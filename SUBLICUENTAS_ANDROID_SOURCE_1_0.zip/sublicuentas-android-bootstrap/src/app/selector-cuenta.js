// src/app/selector-cuenta.js · Oct-2026 · Selector de cuenta de Bodega en la ficha CRM (sacado de main.js, regla R74 < 2000 líneas).
// Muestra correo, ocupados/capacidad y libres; la cuenta más vacía primero con badge "RECOMENDADA".
// No aplica el badge a cuentas completas (se asignan cuenta → cliente: Disponible/Asignada).
import { state, esc, showToast } from './core.js';
import { platformLabel } from '../operations.js';
import { platformCanon, inventoryStats, inventoryEmptiestFirst, planHboTexto } from '../screens2.js';

function crmFamiliaCuenta(v=''){ const c=platformCanon(v).replace(/^hbomax(standard|platinum)$/,'hbomax'); return /^disney/.test(c)?'disney':c; } // R196v
export function crmToggleAccountPicker(index){
  const box=document.querySelector(`[data-acc-list="${index}"]`); if(!box)return;
  if(!box.hidden){box.hidden=true;return;}
  const plat=document.querySelector('#crmPlataforma')?.value||state.crmDraft?.plataforma||'';
  const fam=crmFamiliaCuenta(plat);
  const cuentaCompleta=document.querySelector('#crmCategoria')?.value==='cuentas_completas';
  // R196v · HBO: solo cuentas del MISMO plan; completa = cuenta vacía; nunca una cuenta ya vendida completa.
  const planVenta=(String(plat).toLowerCase().replace(/[^a-z]/g,'').match(/^hbomax(standard|platinum)$/)||[])[1]||'';
  const hboOk=it=>{ if(fam!=='hbomax')return true; if(planVenta&&String(it.planHbo||'')!==planVenta)return false; const cs=Array.isArray(it.clientes)?it.clientes:[]; if(cs.some(c=>c&&c.cuentaCompleta===true))return false; return cuentaCompleta?inventoryStats(it).used===0:true; };
  const list=(state.inventory||[]).filter(it=>hboOk(it)&&crmFamiliaCuenta(it.plataforma)===fam&&String(it.estado||'activa').toLowerCase()!=='suspendida'&&!['suspendido','revision'].includes(String(it.estadoBodega||'').toLowerCase()) /* R196u · VIP suspendida/en revisión no se vende */).sort(inventoryEmptiestFirst);
  if(!list.length){box.innerHTML=`<p class="muted note">No hay cuentas de ${esc(platformLabel(plat)||'esta plataforma')} en Bodega.</p>`;box.hidden=false;return;}
  const rec=list.find(it=>{const s=inventoryStats(it);return s.free>0&&s.cap>1;});
  box.innerHTML=`<div class="crm2-acc-table"><b>Cuenta</b><b>Uso</b><b>Libres</b><b>Estado</b>${list.map((it,i)=>{const s=inventoryStats(it);const esRec=!cuentaCompleta&&it===rec;
    const estado=s.over?'⚠️ Sobreasignada':(s.free<=0?(s.cap===1?'Asignada':'Llena'):(esRec?'⭐ RECOMENDADA':'Disponible'));
    return `<button type="button" data-acc-pick="${i}" ${s.free>0?'':'disabled'} class="${esRec?'rec':''}">${esc(it.correo||'—')}${String(it.plataforma||'').toLowerCase()==='hbomax'?`<small class="inv-plan">${esc(planHboTexto(it).split(' ')[0]==='Plan'?'Sin plan':planHboTexto(it).split(' ')[0])}</small>`:''}</button><span>${s.used} / ${s.cap}</span><span>${s.free}</span><span class="${esRec?'rec':''}">${estado}</span>`;}).join('')}</div>`;
  box.hidden=false;
  box.querySelectorAll('[data-acc-pick]').forEach(b=>b.addEventListener('click',()=>{
    const it=list[Number(b.dataset.accPick)]; if(!it)return;
    const node=document.querySelector(`[data-crm-profile="${index}"]`); if(!node)return;
    const email=node.querySelector('[data-p-email]'); if(email){email.value=it.correo||'';email.dispatchEvent(new Event('input',{bubbles:true}));}
    const pass=node.querySelector('[data-p-password]'); if(pass&&it.clave){pass.value=it.clave;pass.dispatchEvent(new Event('input',{bubbles:true}));}
    box.hidden=true;
    const s=inventoryStats(it); showToast(`📦 ${it.correo} · ${s.used}/${s.cap} ocupados · ${s.free} libre${s.free===1?'':'s'}`);
  }));
}

