// src/app/selector-cuenta.js · Oct-2026 · Selector de cuenta de Bodega en la ficha CRM (sacado de main.js, regla R74 < 2000 líneas).
// Muestra correo, ocupados/capacidad y libres; la cuenta más vacía primero con badge "RECOMENDADA".
// No aplica el badge a cuentas completas (se asignan cuenta → cliente: Disponible/Asignada).
import { state, esc, showToast } from './core.js';
import { platformLabel } from '../operations.js';
import { platformCanon, inventoryStats, inventoryEmptiestFirst } from '../screens2.js';

function crmFamiliaCuenta(v=''){ const c=platformCanon(v); return /^disney/.test(c)?'disney':c; }
export function crmToggleAccountPicker(index){
  const box=document.querySelector(`[data-acc-list="${index}"]`); if(!box)return;
  if(!box.hidden){box.hidden=true;return;}
  const plat=document.querySelector('#crmPlataforma')?.value||state.crmDraft?.plataforma||'';
  const fam=crmFamiliaCuenta(plat);
  const cuentaCompleta=document.querySelector('#crmCategoria')?.value==='cuentas_completas';
  const list=(state.inventory||[]).filter(it=>crmFamiliaCuenta(it.plataforma)===fam&&String(it.estado||'activa').toLowerCase()!=='suspendida').sort(inventoryEmptiestFirst);
  if(!list.length){box.innerHTML=`<p class="muted note">No hay cuentas de ${esc(platformLabel(plat)||'esta plataforma')} en Bodega.</p>`;box.hidden=false;return;}
  const rec=list.find(it=>{const s=inventoryStats(it);return s.free>0&&s.cap>1;});
  box.innerHTML=`<div class="crm2-acc-table"><b>Cuenta</b><b>Uso</b><b>Libres</b><b>Estado</b>${list.map((it,i)=>{const s=inventoryStats(it);const esRec=!cuentaCompleta&&it===rec;
    const estado=s.over?'⚠️ Sobreasignada':(s.free<=0?(s.cap===1?'Asignada':'Llena'):(esRec?'⭐ RECOMENDADA':'Disponible'));
    return `<button type="button" data-acc-pick="${i}" ${s.free>0?'':'disabled'} class="${esRec?'rec':''}">${esc(it.correo||'—')}</button><span>${s.used} / ${s.cap}</span><span>${s.free}</span><span class="${esRec?'rec':''}">${estado}</span>`;}).join('')}</div>`;
  box.hidden=false;
  box.querySelectorAll('[data-acc-pick]').forEach(b=>b.addEventListener('click',()=>{
    const it=list[Number(b.dataset.accPick)]; if(!it)return;
    const node=document.querySelector(`[data-crm-profile="${index}"]`); if(!node)return;
    const email=node.querySelector('[data-p-email]'); if(email){email.value=it.correo||'';email.dispatchEvent(new Event('input',{bubbles:true}));}
    const pass=node.querySelector('[data-p-password]'); if(pass&&it.clave){pass.value=it.clave;pass.dispatchEvent(new Event('input',{bubbles:true}));}
    box.hidden=true;
    const s=inventoryStats(it); showToast(`📦 ${it.correo} · ${s.used}/${s.cap} ocupados · ${s.free} libre${s.free===1?'':'s'}`);
  }));
}

