// R209 · Inicio › Gestión comercial en la APK.
// Es la MISMA pantalla de Sublichat Web (comercial-web.js, copia fiel en public/): un solo código para las reglas de
// vencidos, fidelizar, potenciales, biblioteca, seguimiento y rendimiento. Usa la sesión de la APK (authPost →
// /api/comercial, que repite TODA la autorización). No envía mensajes: abre WhatsApp y el usuario confirma.
// Sin conexión no se registra nada (no hay envío ni registro sin red).
import { authPost } from '../api.js';
import { sinRed } from './offline-consulta.js';
import { state, esc, ui } from './core.js';
import { operatorIdentity } from '../data.js';

export const COMERCIAL_WEB_VERSION = '20261128-r210';
export function canComercial() { return ['sublicuentas', 'relojes', 'geisell'].includes(operatorIdentity(state.session?.role || '', state.session?.usuario || '')); }

async function post(body = {}) {
  const lectura = ['panel', 'lista', 'ficha', 'plantillas', 'reporte'].includes(body.accion);
  if (sinRed()) throw new Error(lectura ? 'Sin conexión: Gestión comercial necesita internet para mostrar datos al día.' : 'Sin conexión: no se registró nada. Inténtelo con internet.');
  let r;
  try { r = await authPost('/api/comercial', { ...body, origen: 'android' }); }
  catch (e) { throw new Error(e?.data?.error || (Number(e?.status) === 403 ? 'Su usuario no tiene Gestión comercial. Sublicuentas lo activa en Permisos.' : e?.message || 'Sin conexión')); }
  if (!r || r.ok === false) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
let carga = null;
function cargarWeb(doc = document) {
  const w = doc.defaultView || window;
  w.ComercialConfig = { embebida: true, origen: 'android', post, abrir: (u) => ui.openLink(u) };
  if (w.SublichatComercial?.open) return Promise.resolve(w.SublichatComercial);
  if (carga) return carga;
  carga = new Promise((ok, mal) => {
    if (!doc.getElementById('gcCss')) { const l = doc.createElement('link'); l.id = 'gcCss'; l.rel = 'stylesheet'; l.href = `/comercial-web.css?v=${COMERCIAL_WEB_VERSION}`; doc.head.appendChild(l); }
    const sc = doc.createElement('script'); sc.src = `/comercial-web.js?v=${COMERCIAL_WEB_VERSION}`; sc.async = true;
    sc.onload = () => (w.SublichatComercial?.open ? ok(w.SublichatComercial) : mal(new Error('Gestión comercial no se pudo iniciar.')));
    sc.onerror = () => { carga = null; mal(new Error('No se pudo cargar Gestión comercial. Revise la conexión.')); };
    doc.head.appendChild(sc);
  });
  return carga;
}
export function cerrarComercial() {
  const ov = document.getElementById('gcApk'); if (ov) ov.remove();
  document.documentElement.classList.remove('gc-apk-on');
  if (state.subview === 'comercial') { state.subview = null; state.active = 'inicio'; ui.render(); }
}
export async function abrirComercial() {
  let ov = document.getElementById('gcApk');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'gcApk'; ov.className = 'gc-apk'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Gestión comercial');
    ov.innerHTML = `<header class="gc-apk-top"><button type="button" class="gc-apk-volver" data-gc-apk-cerrar aria-label="Volver a Inicio">‹ Inicio</button></header>
      <section id="screen-comercial" class="active"><div id="rbac-comercial"><div class="loading-card"><span class="spinner"></span><strong>Abriendo Gestión comercial…</strong></div></div></section>`;
    document.body.appendChild(ov); document.documentElement.classList.add('gc-apk-on');
    ov.querySelector('[data-gc-apk-cerrar]').addEventListener('click', cerrarComercial);
  }
  try { const S = await cargarWeb(); S.open(); }
  catch (e) { const h = document.getElementById('rbac-comercial'); if (h) { h.innerHTML = `<div class="error-box"><span>${esc(e.message)}</span></div><button type="button" class="se-btn" data-gc-reintentar>Reintentar</button>`; h.querySelector('[data-gc-reintentar]')?.addEventListener('click', abrirComercial); } }
}
export function comercialView() {
  if (!canComercial()) return ui.subPage('Gestión comercial', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene Gestión comercial</strong></div>');
  return ui.subPage('Gestión comercial', 'Fidelización, seguimiento y crecimiento', '<div class="loading-card"><span class="spinner"></span><strong>Abriendo Gestión comercial…</strong></div>');
}
export function bindComercial() {
  if (state.subview !== 'comercial' || !canComercial()) return;
  if (!document.getElementById('gcApk')) abrirComercial();
}
