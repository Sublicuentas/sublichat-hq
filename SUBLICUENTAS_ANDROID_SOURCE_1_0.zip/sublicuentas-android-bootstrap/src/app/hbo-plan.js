// R196z3 · HBO Standard / Platinum en la APK: al abrir la cuenta se confirma plan y capacidad con el servidor (misma regla que
// Web y Telegram: api/_hbo-planes.js). Sublicuentas puede cambiar el plan o «Editar capacidad». Otra capacidad distinta del
// predeterminado (Standard 3 · Platinum 5) se guarda como EXCEPCIÓN de esa cuenta, previa confirmación. Nunca se saca,
// mueve ni desactiva a un cliente: si quedarían más ocupados, se ofrece conservarlos.
import { hboPlanApk } from '../api.js';

const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function aplicarLocal(state, id, r) { // la lista del teléfono queda igual que el servidor
  const it = (state.inventory || []).find((x) => String(x.id || x.docId) === id); if (!it || !r) return;
  if (r.plan) it.planHbo = r.plan; if (r.capacidad) { it.capacidad = r.capacidad; it.disponibles = Math.max(0, r.capacidad - (r.ocupados || 0)); it.disp = it.disponibles; }
  it.capacidadPersonalizada = !!r.personalizada;
}

export async function montarHboPlan(host, d, state) {
  const id = String(d.raw.id || d.id || ''); const tx = host.querySelector('[data-hbo-texto]'), acc = host.querySelector('[data-hbo-acc]');
  let r;
  try { r = await hboPlanApk({ inventarioId: id, modo: 'ver' }); } catch (e) { if (acc) acc.innerHTML = `<p class="inv-nota warn">Sin confirmar con Sublichat: ${esc(e?.message || e)}</p>`; return; }
  if (!r || r.ok === false) { if (acc) acc.innerHTML = `<p class="inv-nota warn">${esc(r?.error || 'No se pudo confirmar el plan.')}</p>`; return; }
  aplicarLocal(state, id, r);
  if (tx) tx.textContent = r.etiqueta || '';
  if (!acc) return;
  const nota = r.personalizada ? `<p class="inv-nota">Predeterminado de ${esc(r.nombrePlan)}: ${esc(r.capacidadPlan)}. Esta cuenta: ${esc(r.capacidad)}${r.excepcion ? ' (excepción confirmada)' : ' (sin excepción registrada)'}.</p>` : '';
  acc.innerHTML = nota + (r.puedeEditar ? `<div class="sr-actions hbo-plan-acc"><button type="button" class="sr-btn ghost" data-hbo-set="platinum" ${r.plan === 'platinum' ? 'disabled' : ''}>Platinum</button><button type="button" class="sr-btn ghost" data-hbo-set="standard" ${r.plan === 'standard' ? 'disabled' : ''}>Standard</button>${r.plan ? '<button type="button" class="sr-btn ghost" data-hbo-cap>Editar capacidad</button>' : ''}</div>` : '');
  const enviar = async (body) => {
    let x = await hboPlanApk({ inventarioId: id, ...body });
    if (x && x.ok === false && (x.code === 'requiere_excepcion' || x.code === 'sobreocupacion') && x.capacidadSugerida) {
      if (!window.confirm(`${x.error}\n\n¿Confirmar capacidad excepcional de ${x.capacidadSugerida} para esta cuenta? No se elimina ningún cliente.`)) return;
      x = await hboPlanApk({ inventarioId: id, ...body, plan: body.plan || x.plan || undefined, capacidad: x.capacidadSugerida, autorizarExcepcion: true, motivo: 'Confirmado en la app' });
    }
    if (!x || x.ok === false) { window.alert(x?.error || 'No se pudo guardar.'); return; }
    await montarHboPlan(host, d, state);
  };
  acc.querySelectorAll('[data-hbo-set]').forEach((b) => b.addEventListener('click', () => { const plan = b.dataset.hboSet; if (window.confirm(`¿Cambiar esta cuenta a HBO ${plan === 'platinum' ? 'Platinum' : 'Standard'}?`)) enviar({ modo: 'plan', plan }); }));
  acc.querySelector('[data-hbo-cap]')?.addEventListener('click', () => { const v = window.prompt('Nueva capacidad (perfiles). Standard trae 3 y Platinum 5; otro número queda como excepción de esta cuenta:'); if (v != null && String(v).trim()) enviar({ modo: 'capacidad', capacidad: Number(v) }); });
}
