// R189 · Más › Sala de Juntas en la APK (PDF «Sublichat 5 puntos», bloque 05). NO es otra sala ni otra base de datos:
// lee y responde con /api/sala-juntas (el mismo servidor de SubliStudio 3D en Sublichat Web, que repite TODA la autorización)
// y para entrar a la sala 3D abre la MISMA sala web (/?sala=<id>) en el navegador del teléfono (Chrome), que sí trae
// WebGL + audio WebRTC + permisos de micrófono. La APK no guarda tokens de LiveKit ni manda tokens en la URL: en el
// navegador se entra con el login normal de Sublichat y el servidor entrega el token temporal de audio (token_tiempo_real).
// La APK no pide micrófono ni cámara; los pide la sala, y solo cuando la persona los activa.
import { authPost, API_BASE } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';

export const ESTADOS = Object.freeze({ borrador: 'Borrador', programada: 'Programada', en_curso: 'En curso', finalizada: 'Concluida', cancelada: 'Cancelada' });
export function canSala() { return ['sublicuentas', 'relojes', 'geisell'].includes(operatorIdentity(state.session?.role || '', state.session?.usuario || '')); }
export function sjState() { if (!state.sj) state.sj = { data: null, actas: null, abierta: '', confirmarEntrada: '', cargando: false, error: '', guardando: '' }; return state.sj; }
export function urlSala(id) { return /^[A-Za-z0-9_-]{6,60}$/.test(String(id || '')) ? `${API_BASE}/?sala=${encodeURIComponent(id)}` : ''; }

async function sala(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/sala-juntas', { accion, origen: 'android', ...extra }); }
  catch (e) { throw new Error(e?.data?.error || (Number(e?.status) === 403 ? 'Su usuario no tiene la Sala de Juntas. Sublicuentas lo activa en Permisos.' : e?.message || 'Sin conexión')); }
  if (!r || r.ok === false) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
export async function sjCargar() {
  const s = sjState(); s.cargando = true; s.error = ''; ui.render();
  try { const [p, a] = await Promise.all([sala('panel'), sala('actas').catch(() => ({ actas: [] }))]); s.data = p; s.actas = a.actas || []; }
  catch (e) { s.error = e.message; }
  s.cargando = false; if (state.subview === 'sala-juntas') ui.render();
}

const fechaTxt = (r) => r.fecha ? `${r.fecha} · ${r.hora}` : 'Sin fecha';
const INV = { aceptada: 'Confirmó', rechazada: 'No asistirá', pendiente: 'Pendiente' };
function reunionHtml(r, d, s) {
  const yo = d.yo?.id, abierta = s.abierta === r.id, miInv = r.invitaciones?.[yo]?.estado || 'pendiente';
  const nombres = Object.fromEntries((d.fundadoras || []).map((f) => [f.id, f.nombre]));
  const acta = (s.actas || []).find((a) => a.reunionId === r.id);
  const puedeEntrar = ['programada', 'en_curso'].includes(r.estado);
  const detalle = abierta ? `
    <div class="sj-m-det">
      ${(r.agenda || []).length ? `<small><b>Agenda:</b> ${r.agenda.map((x) => esc(typeof x === 'string' ? x : x?.titulo || '')).join(' · ')}</small>` : ''}
      <b>Participantes e invitaciones</b>
      ${(r.participantes || []).map((u) => `<small>${esc(nombres[u] || u)} · ${esc(INV[r.invitaciones?.[u]?.estado] || 'Pendiente')}</small>`).join('')}
      ${acta ? `<small><b>Acuerdos:</b> ${acta.acuerdos} · pendientes ${acta.pendientes}</small>` : ''}
      ${r.avisos ? `<small><b>Avisos de Telegram:</b> enviados ${r.avisos.enviado} · pendientes ${r.avisos.pendiente} · fallidos ${r.avisos.fallido}${(r.avisos.fallas || []).length ? ` (${r.avisos.fallas.map((f) => esc(`${nombres[f.usuario] || f.usuario}: ${f.error || f.motivo || 'error'}`)).join(' · ')})` : ''}</small>` : ''}
      ${puedeEntrar && r.estado === 'programada' ? `<div class="baul-acc"><button type="button" class="se-btn ${miInv === 'aceptada' ? '' : 'ghost'}" data-sj-rsvp="aceptada" data-id="${esc(r.id)}">Asistiré</button><button type="button" class="se-btn ${miInv === 'rechazada' ? '' : 'ghost'}" data-sj-rsvp="rechazada" data-id="${esc(r.id)}">No asistiré</button></div>` : ''}
      ${puedeEntrar ? (s.confirmarEntrada === r.id
        ? `<div class="sj-m-aviso"><b>Antes de entrar</b><small>La sala 3D se abre en Chrome, con su sesión normal de Sublichat. El micrófono y la cámara solo se encienden cuando usted lo permite en la sala; la grabación siempre pide confirmación.</small><div class="baul-acc"><button type="button" class="se-btn" data-sj-abrir="${esc(r.id)}">Entrar a la sala 3D</button><button type="button" class="se-btn ghost" data-sj-cancelar>Cancelar</button></div></div>`
        : `<button type="button" class="se-btn" data-sj-entrar="${esc(r.id)}">🎙️ Entrar a la sala</button>`) : ''}
    </div>` : '';
  return `<article class="se-card sj-m-reu"><button type="button" class="sj-m-cab" data-sj-ver="${esc(r.id)}"><b>${esc(r.titulo || 'Reunión')}</b><small>${esc(fechaTxt(r))} · ${r.duracionMin || 60} min</small><span class="sj-m-est e-${esc(r.estado)}">${esc(ESTADOS[r.estado] || r.estado)}</span></button>${detalle}</article>`;
}

export function salaView() {
  const s = sjState();
  if (!canSala()) return ui.subPage('Sala de Juntas', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene la Sala de Juntas</strong></div>');
  if (s.data === null && !s.cargando && !s.error) setTimeout(sjCargar, 0);
  const d = s.data;
  let cuerpo = '';
  if (s.cargando && !d) cuerpo = '<div class="loading-card"><span class="spinner"></span><strong>Cargando reuniones…</strong></div>';
  else if (s.error && !d) cuerpo = `<div class="error-box"><span>${esc(s.error)}</span></div>`;
  else if (d) {
    const lista = (d.reuniones || []).filter((r) => r.estado !== 'borrador' || d.permisos?.crear);
    const proximas = lista.filter((r) => ['programada', 'en_curso'].includes(r.estado)).sort((a, b) => a.inicioMs - b.inicioMs);
    const pasadas = lista.filter((r) => !['programada', 'en_curso'].includes(r.estado)).slice(0, 15);
    cuerpo = `${s.error ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}
      <p class="baul-aviso">${esc(d.yo?.nombre || '')}${d.permisos?.crear ? ' · Anfitriona: convoca, edita y aprueba ingresos desde la sala web.' : ''}${d.tiempoReal ? '' : ' · El audio en tiempo real todavía no está configurado.'}</p>
      <b class="sj-m-tit">Próximas</b>${proximas.length ? proximas.map((r) => reunionHtml(r, d, s)).join('') : '<div class="empty-state"><strong>Sin reuniones próximas</strong></div>'}
      ${pasadas.length ? `<b class="sj-m-tit">Concluidas y canceladas</b>${pasadas.map((r) => reunionHtml(r, d, s)).join('')}` : ''}`;
  }
  return ui.subPage('Sala de Juntas', 'SubliStudio 3D · la misma sala de Sublichat Web', `<section class="se-wrap">${cuerpo}<button type="button" class="se-btn ghost" data-sj-recargar>Actualizar</button></section>`);
}

export function bindSala() {
  if (state.subview !== 'sala-juntas') return;
  const s = sjState(), qa = (x) => document.querySelectorAll(x);
  qa('[data-sj-ver]').forEach((b) => b.addEventListener('click', () => { s.abierta = s.abierta === b.dataset.sjVer ? '' : b.dataset.sjVer; s.confirmarEntrada = ''; ui.render(); }));
  qa('[data-sj-recargar]').forEach((b) => b.addEventListener('click', sjCargar));
  qa('[data-sj-entrar]').forEach((b) => b.addEventListener('click', () => { s.confirmarEntrada = b.dataset.sjEntrar; ui.render(); }));
  qa('[data-sj-cancelar]').forEach((b) => b.addEventListener('click', () => { s.confirmarEntrada = ''; ui.render(); }));
  qa('[data-sj-abrir]').forEach((b) => b.addEventListener('click', () => { const u = urlSala(b.dataset.sjAbrir); s.confirmarEntrada = ''; if (u) ui.openLink(u); }));
  qa('[data-sj-rsvp]').forEach((b) => b.addEventListener('click', async () => {
    try { await sala('rsvp', { id: b.dataset.id, respuesta: b.dataset.sjRsvp }); showToast?.(b.dataset.sjRsvp === 'aceptada' ? 'Asistencia confirmada' : 'Respuesta enviada'); await sjCargar(); }
    catch (e) { s.error = e.message; ui.render(); }
  }));
}
