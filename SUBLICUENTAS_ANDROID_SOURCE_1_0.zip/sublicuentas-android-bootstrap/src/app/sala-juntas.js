// Más › Sala de Juntas en la APK.
// R194 · Al tocar «Sala de Juntas» se abre DIRECTO la interfaz completa de SubliStudio 3D (la misma de Sublichat Web):
//   reuniones, convocatorias, antesala, sala 3D, avatar, escenarios, actas, grabaciones y permisos. Ya no hay una pantalla
//   preliminar propia de la APK: la sala es UNA sola (no se duplica código).
// · Los archivos de la sala (sala-juntas.js, sala-3d.js, sala-vivo.js, escenarios.js, avatar-glb.js, modelos 3D) viajan como
//   copia fiel en public/ y se cargan en esta misma vista (sin Chrome, sin URL externa).
// · Usa la sesión vigente de la APK (authPost → /api/sala-juntas, que repite TODA la autorización): no hay segundo login.
// · LiveKit: el servidor entrega un token temporal solo de esa reunión; la APK no guarda ninguna clave.
// · Micrófono/cámara: los pide la sala al activarlos (Android pregunta el permiso en ese momento).
import { authPost } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';
import { guardarGrabacion } from './sala-grabacion-apk.js';

export function canSala() { return ['sublicuentas', 'relojes', 'geisell'].includes(operatorIdentity(state.session?.role || '', state.session?.usuario || '')); }
export const VISTAS_INTERNAS = Object.freeze(['inicio', 'antesala', 'personaje', 'escenarios', 'nueva', 'historial', 'acta']);
export const SALA_WEB_VERSION = '20261111-r196j';

async function sala(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/sala-juntas', { accion, origen: 'android', ...extra }); }
  catch (e) { throw new Error(e?.data?.error || (Number(e?.status) === 403 ? 'Su usuario no tiene la Sala de Juntas. Sublicuentas lo activa en Permisos.' : e?.message || 'Sin conexión')); }
  if (!r || r.ok === false) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}

let cargaWeb = null;
async function descargarVideo(url, nombre) {
  const { Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) { const a = document.createElement('a'); a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove(); return; }
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  showToast?.('Descargando el video…');
  await Filesystem.downloadFile({ url, path: `Sublichat/${nombre}`, directory: Directory.Documents, recursive: true });
  showToast?.(`Video guardado en Documentos/Sublichat/${nombre}`);
}
export function configSalaWeb() {
  return { embebida: true, origen: 'android', post: (body) => { const { accion, ...rest } = body || {}; return sala(accion, rest); }, descargar: descargarVideo, guardarGrabacion: (r, base) => guardarGrabacion(r, base),
    alCambiarVista: () => { const ov = document.getElementById('sjApk'); if (ov) ov.scrollTop = 0; } };
}
export function cargarSalaWeb(doc = document) {
  const w = doc.defaultView || window;
  w.SalaJuntasConfig = configSalaWeb();
  if (w.SublichatSala?.abrir) return Promise.resolve(w.SublichatSala);
  if (cargaWeb) return cargaWeb;
  cargaWeb = new Promise((ok, mal) => {
    const sc = doc.createElement('script'); sc.src = `/sala-juntas.js?v=${SALA_WEB_VERSION}`; sc.async = true;
    sc.onload = () => (w.SublichatSala?.abrir ? ok(w.SublichatSala) : mal(new Error('La sala no se pudo iniciar.')));
    sc.onerror = () => { cargaWeb = null; mal(new Error('No se pudo cargar la sala 3D. Revise la conexión y vuelva a intentar.')); };
    doc.head.appendChild(sc);
  });
  return cargaWeb;
}

// «‹ Más» cierra la sala (libera micrófono, LiveKit y 3D) y vuelve a Más, sin pasar por ninguna pantalla intermedia.
export function cerrarSalaInterna() {
  const ov = document.getElementById('sjApk');
  try { window.SublichatSala?.cerrar?.(); } catch (_) {}
  if (ov) ov.remove();
  document.documentElement.classList.remove('sj-apk-on');
  if (state.subview === 'sala-juntas') { state.subview = null; state.active = 'mas'; ui.render(); }
}
export async function abrirSalaInterna(vista = 'inicio', id = '') {
  if (!VISTAS_INTERNAS.includes(vista)) return;
  let ov = document.getElementById('sjApk');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'sjApk'; ov.className = 'sj-apk'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Sala de Juntas');
    ov.innerHTML = `<header class="sj-apk-top"><button type="button" class="sj-apk-volver" data-sj-apk-cerrar aria-label="Volver a Más">‹ Más</button></header>
      <section id="screen-sala-juntas" class="active sj-pantalla"><div id="rbac-sala-juntas"><div class="loading-card"><span class="spinner"></span><strong>Abriendo SubliStudio 3D…</strong></div></div></section>`;
    document.body.appendChild(ov); document.documentElement.classList.add('sj-apk-on');
    ov.querySelector('[data-sj-apk-cerrar]').addEventListener('click', cerrarSalaInterna);
  }
  try { const S = await cargarSalaWeb(); await S.abrir(vista, id); }
  catch (e) {
    const h = document.getElementById('rbac-sala-juntas');
    if (h) {
      h.innerHTML = `<div class="error-box"><span>${esc(e.message)}</span></div><button type="button" class="se-btn" data-sj-reintentar>Reintentar</button>`;
      h.querySelector('[data-sj-reintentar]')?.addEventListener('click', () => abrirSalaInterna(vista, id));
    }
  }
}

// La subvista solo existe para el permiso y como respaldo mientras se monta la sala completa encima.
export function salaView() {
  if (!canSala()) return ui.subPage('Sala de Juntas', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene la Sala de Juntas</strong></div>');
  return ui.subPage('Sala de Juntas', 'SubliStudio 3D', '<div class="loading-card"><span class="spinner"></span><strong>Abriendo SubliStudio 3D…</strong></div>');
}

export function bindSala() {
  if (state.subview !== 'sala-juntas' || !canSala()) return;
  if (!document.getElementById('sjApk')) abrirSalaInterna('inicio');
}
