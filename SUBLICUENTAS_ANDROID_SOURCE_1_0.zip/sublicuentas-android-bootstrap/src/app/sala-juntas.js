// R189 · Más › Sala de Juntas en la APK. R193 (PDF «Corrección urgente Sala 3D»): la sala 3D se abre DENTRO de la APK.
// · Es la MISMA sala de Sublichat Web: los archivos de la sala (sala-juntas.js, sala-3d.js, sala-vivo.js, escenarios.js,
//   avatar-glb.js, modelos 3D) viajan como copia fiel en public/ y se cargan en esta misma vista (sin Chrome, sin URL externa).
// · Usa la sesión vigente de la APK (authPost → /api/sala-juntas, que repite TODA la autorización): no hay segundo login.
// · LiveKit: el servidor entrega un token temporal solo de esa reunión; la APK no guarda ninguna clave.
// · Micrófono/cámara: los pide la sala al activarlos (Android pregunta el permiso en ese momento).
import { authPost } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';

export const ESTADOS = Object.freeze({ borrador: 'Borrador', programada: 'Programada', en_curso: 'En curso', finalizada: 'Concluida', cancelada: 'Cancelada' });
export function canSala() { return ['sublicuentas', 'relojes', 'geisell'].includes(operatorIdentity(state.session?.role || '', state.session?.usuario || '')); }
export function sjState() { if (!state.sj) state.sj = { data: null, actas: null, abierta: '', confirmarEntrada: '', cargando: false, error: '', guardando: '' }; return state.sj; }
export const VISTAS_INTERNAS = Object.freeze(['inicio', 'antesala', 'personaje', 'escenarios', 'nueva', 'historial', 'acta']);
export const SALA_WEB_VERSION = '20261107-r193';
const COLOR = { naara: '#E2231A', libni: '#2879C7', geisell: '#159B62' };
function avatarHtml(id, nombre, av) {
  const mini = av && /^data:image\/(webp|jpeg|png);base64,/.test(av.miniatura || '') ? av.miniatura : '';
  return `<span class="sj-m-av" style="--c:${COLOR[id] || '#475569'}">${mini ? `<img src="${mini}" alt="">` : esc(String(nombre || id || '?').charAt(0).toUpperCase())}</span>`;
}

async function sala(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/sala-juntas', { accion, origen: 'android', ...extra }); }
  catch (e) { throw new Error(e?.data?.error || (Number(e?.status) === 403 ? 'Su usuario no tiene la Sala de Juntas. Sublicuentas lo activa en Permisos.' : e?.message || 'Sin conexión')); }
  if (!r || r.ok === false) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
export async function sjCargar() {
  const s = sjState(); s.cargando = true; s.error = ''; ui.render();
  try { const [p, a] = await Promise.all([sala('panel'), sala('actas').catch(() => ({ actas: [] }))]); s.data = p; s.actas = a.actas || []; }
  catch (e) { s.error = e.message; }
  s.cargando = false; if (state.subview === 'sala-juntas') ui.render();
}

const fechaTxt = (r) => r.fecha ? `${r.fecha} · ${r.hora}` : 'Sin fecha';
const INV = { aceptada: 'Confirmó', rechazada: 'No asistirá', pendiente: 'Pendiente' };
function reunionHtml(r, d, s) {
  const yo = d.yo?.id, abierta = s.abierta === r.id, miInv = r.invitaciones?.[yo]?.estado || 'pendiente';
  const nombres = Object.fromEntries((d.fundadoras || []).map((f) => [f.id, f.nombre]));
  const acta = (s.actas || []).find((a) => a.reunionId === r.id);
  const puedeEntrar = ['programada', 'en_curso'].includes(r.estado);
  const sol = s.solicitudes?.[r.id];
  const esperando = r.estado === 'en_curso' && !d.permisos?.moderar && sol && sol.estado === 'pendiente';
  const detalle = abierta ? `
    <div class="sj-m-det">
      <figure class="sj-m-esc"><img src="/assets/sala/sala-escenario-c.webp" alt="Sala SubliStudio 3D"><figcaption>Sala 3D real · escenario ${esc(r.escenario || 'sala-c')}${r.anfitrion ? ` · anfitriona ${esc(nombres[r.anfitrion] || r.anfitrion)}` : ''}</figcaption></figure>
      <div class="sj-m-parts">${(r.participantes || []).map((u) => `<span class="sj-m-part">${avatarHtml(u, nombres[u], d.avatares?.[u])}<small>${esc(nombres[u] || u)}</small></span>`).join('')}</div>
      ${esperando ? '<p class="sj-m-espera" role="status">⏳ Esperando autorización de la anfitriona para entrar.</p>' : ''}
      ${(r.agenda || []).length ? `<small><b>Agenda:</b> ${r.agenda.map((x) => esc(typeof x === 'string' ? x : x?.titulo || '')).join(' · ')}</small>` : ''}
      <b>Participantes e invitaciones</b>
      ${(r.participantes || []).map((u) => `<small>${esc(nombres[u] || u)} · ${esc(INV[r.invitaciones?.[u]?.estado] || 'Pendiente')}</small>`).join('')}
      ${acta ? `<small><b>Acuerdos:</b> ${acta.acuerdos} · pendientes ${acta.pendientes}</small>` : ''}
      ${r.avisos ? `<small><b>Avisos de Telegram:</b> enviados ${r.avisos.enviado} · pendientes ${r.avisos.pendiente} · fallidos ${r.avisos.fallido}${(r.avisos.fallas || []).length ? ` (${r.avisos.fallas.map((f) => esc(`${nombres[f.usuario] || f.usuario}: ${f.error || f.motivo || 'error'}`)).join(' · ')})` : ''}</small>` : ''}
      ${puedeEntrar && r.estado === 'programada' ? `<div class="baul-acc"><button type="button" class="se-btn ${miInv === 'aceptada' ? '' : 'ghost'}" data-sj-rsvp="aceptada" data-id="${esc(r.id)}">Asistiré</button><button type="button" class="se-btn ${miInv === 'rechazada' ? '' : 'ghost'}" data-sj-rsvp="rechazada" data-id="${esc(r.id)}">No asistiré</button></div>` : ''}
      ${puedeEntrar ? `<button type="button" class="se-btn sj-m-entrar" data-sj-interna="antesala" data-id="${esc(r.id)}">Entrar en la APK</button><small class="sj-m-nota">Se abre aquí mismo: antesala con prueba de micrófono y luego la sala 3D. Si la reunión ya empezó, la anfitriona aprueba su ingreso.</small>` : ''}
      ${r.estado === 'finalizada' ? `<button type="button" class="se-btn ghost" data-sj-interna="acta" data-id="${esc(r.id)}">Acta y grabaciones</button>` : ''}
    </div>` : '';
  return `<article class="se-card sj-m-reu"><button type="button" class="sj-m-cab" data-sj-ver="${esc(r.id)}"><b>${esc(r.titulo || 'Reunión')}</b><small>${esc(fechaTxt(r))} · ${r.duracionMin || 60} min</small><span class="sj-m-est e-${esc(r.estado)}">${esc(ESTADOS[r.estado] || r.estado)}</span></button>${detalle}</article>`;
}

// ---------- R193 · Sala web embebida (vista interna a pantalla completa) ----------
let cargaWeb = null;
async function descargarVideo(url, nombre) {
  const { Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) { const a = document.createElement('a'); a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove(); return; }
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  showToast?.('Descargando el video…');
  await Filesystem.downloadFile({ url, path: `Sublichat/${nombre}`, directory: Directory.Documents, recursive: true });
  showToast?.(`Video guardado en Documentos/Sublichat/${nombre}`);
}
export function configSalaWeb() {
  return { embebida: true, origen: 'android', post: (body) => { const { accion, ...rest } = body || {}; return sala(accion, rest); }, descargar: descargarVideo,
    alCambiarVista: () => { const ov = document.getElementById('sjApk'); if (ov) ov.scrollTop = 0; } };
}
export function cargarSalaWeb(doc = document) {
  const w = doc.defaultView || window;
  w.SalaJuntasConfig = configSalaWeb();
  if (w.SublichatSala?.abrir) return Promise.resolve(w.SublichatSala);
  if (cargaWeb) return cargaWeb;
  cargaWeb = new Promise((ok, mal) => {
    const sc = doc.createElement('script'); sc.src = `/sala-juntas.js?v=${SALA_WEB_VERSION}`; sc.async = true;
    sc.onload = () => (w.SublichatSala?.abrir ? ok(w.SublichatSala) : mal(new Error('La sala no se pudo iniciar.')));
    sc.onerror = () => { cargaWeb = null; mal(new Error('No se pudo cargar la sala 3D.')); };
    doc.head.appendChild(sc);
  });
  return cargaWeb;
}
export function cerrarSalaInterna() {
  const ov = document.getElementById('sjApk'); if (!ov) return;
  try { window.SublichatSala?.cerrar?.(); } catch (_) {}
  ov.remove(); document.documentElement.classList.remove('sj-apk-on');
  if (state.subview === 'sala-juntas') sjCargar();
}
export async function abrirSalaInterna(vista = 'inicio', id = '') {
  if (!VISTAS_INTERNAS.includes(vista)) return;
  let ov = document.getElementById('sjApk');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'sjApk'; ov.className = 'sj-apk'; ov.setAttribute('role', 'dialog'); ov.setAttribute('aria-label', 'Sala de Juntas');
    ov.innerHTML = `<header class="sj-apk-top"><button type="button" class="sj-apk-volver" data-sj-apk-cerrar>‹ Volver</button><b>Sala de Juntas · SubliStudio 3D</b></header>
      <section id="screen-sala-juntas" class="active sj-pantalla"><div id="rbac-sala-juntas"><div class="loading-card"><span class="spinner"></span><strong>Abriendo la sala…</strong></div></div></section>`;
    document.body.appendChild(ov); document.documentElement.classList.add('sj-apk-on');
    ov.querySelector('[data-sj-apk-cerrar]').addEventListener('click', cerrarSalaInterna);
  }
  try { const S = await cargarSalaWeb(); await S.abrir(vista, id); }
  catch (e) { const h = document.getElementById('rbac-sala-juntas'); if (h) h.innerHTML = `<div class="error-box"><span>${esc(e.message)}</span></div>`; }
}

export function salaView() {
  const s = sjState();
  if (!canSala()) return ui.subPage('Sala de Juntas', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene la Sala de Juntas</strong></div>');
  if (s.data === null && !s.cargando && !s.error) setTimeout(sjCargar, 0);
  const d = s.data;
  let cuerpo = '';
  if (s.cargando && !d) cuerpo = '<div class="loading-card"><span class="spinner"></span><strong>Cargando reuniones…</strong></div>';
  else if (s.error && !d) cuerpo = `<div class="error-box"><span>${esc(s.error)}</span></div>`;
  else if (d) {
    const lista = (d.reuniones || []).filter((r) => r.estado !== 'borrador' || d.permisos?.crear);
    const proximas = lista.filter((r) => ['programada', 'en_curso'].includes(r.estado)).sort((a, b) => a.inicioMs - b.inicioMs);
    const pasadas = lista.filter((r) => !['programada', 'en_curso'].includes(r.estado)).slice(0, 15);
    cuerpo = `${s.error ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}
      <article class="se-card sj-m-mi"><div class="sj-m-mi-cab">${avatarHtml(d.yo?.id, d.yo?.nombre, d.avatares?.[d.yo?.id])}<span><b>Mi avatar · Escenarios</b><small>Ver y editar sin reunión. Es el mismo personaje de Sublichat Web.</small></span></div>
        <div class="baul-acc"><button type="button" class="se-btn ghost" data-sj-interna="personaje">Mi avatar</button><button type="button" class="se-btn ghost" data-sj-interna="escenarios">Ver salas</button></div></article>
      ${d.tiempoReal ? '' : '<p class="baul-aviso">El audio en tiempo real todavía no está configurado en el servidor.</p>'}
      <b class="sj-m-tit">Próximas y en curso</b>${proximas.length ? proximas.map((r) => reunionHtml(r, d, s)).join('') : '<div class="empty-state"><strong>Sin reuniones próximas</strong><small>Cuando Naara convoque, aparecerá aquí con su invitación.</small></div>'}
      <article class="se-card sj-m-acc"><b>Acciones según permisos</b>
        <div class="baul-acc">${d.permisos?.crear ? '<button type="button" class="se-btn ghost" data-sj-interna="nueva">Programar reunión</button>' : ''}<button type="button" class="se-btn ghost" data-sj-interna="inicio">Agenda completa</button><button type="button" class="se-btn ghost" data-sj-interna="historial">Historial, actas y grabaciones</button></div>
        <small>${d.permisos?.moderar ? 'Usted es anfitriona: inicia la sala, aprueba ingresos y graba (con aviso a todas).' : 'Entra a las reuniones a las que la invitan; si ya empezaron, la anfitriona aprueba su ingreso.'}${d.grabacionServidor ? '' : ' · Grabación en servidor: pendiente de configurar.'}</small></article>
      ${pasadas.length ? `<b class="sj-m-tit">Concluidas y canceladas</b>${pasadas.map((r) => reunionHtml(r, d, s)).join('')}` : ''}`;
  }
  return ui.subPage('Sala de Juntas', 'Reuniones, salas y avatar', `<section class="se-wrap">${cuerpo}<button type="button" class="se-btn ghost" data-sj-recargar>Actualizar</button></section>`);
}

export function bindSala() {
  if (state.subview !== 'sala-juntas') return;
  const s = sjState(), qa = (x) => document.querySelectorAll(x);
  qa('[data-sj-ver]').forEach((b) => b.addEventListener('click', () => {
    s.abierta = s.abierta === b.dataset.sjVer ? '' : b.dataset.sjVer; s.confirmarEntrada = ''; ui.render();
    const r = (s.data?.reuniones || []).find((x) => x.id === s.abierta);
    if (r && r.estado === 'en_curso' && !s.data?.permisos?.moderar) sala('solicitud_estado', { id: r.id }).then((j) => { s.solicitudes = { ...(s.solicitudes || {}), [r.id]: j.solicitud }; if (state.subview === 'sala-juntas') ui.render(); }).catch(() => {});
  }));
  qa('[data-sj-interna]').forEach((b) => b.addEventListener('click', () => abrirSalaInterna(b.dataset.sjInterna, b.dataset.id || '')));
  qa('[data-sj-recargar]').forEach((b) => b.addEventListener('click', sjCargar));
  qa('[data-sj-rsvp]').forEach((b) => b.addEventListener('click', async () => {
    try { await sala('rsvp', { id: b.dataset.id, respuesta: b.dataset.sjRsvp }); showToast?.(b.dataset.sjRsvp === 'aceptada' ? 'Asistencia confirmada' : 'Respuesta enviada'); await sjCargar(); }
    catch (e) { s.error = e.message; ui.render(); }
  }));
}
