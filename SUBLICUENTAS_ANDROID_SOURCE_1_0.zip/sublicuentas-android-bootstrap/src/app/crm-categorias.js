// src/app/crm-categorias.js · R112 — selector de categorías del formulario de compra (APK).
import { CRM_PLATFORMS, esc } from './core.js';
import { CATEGORIAS, ORDEN_CATEGORIAS, CUENTA_COMPLETA_PLATAFORMAS, clasificarServicio } from './catalogo-categorias.js';
// R112 · Categorías (mismo contrato que web y bot): primero la categoría y después solo sus plataformas.
export function crmCategoriaDraft(d={}) { return d.categoria || clasificarServicio({plataforma:d.plataforma,tipoVenta:d.tipoVenta}).categoria; }
export function crmPlataformasDeCategoria(cat) {
  if (cat==='cuentas_completas') return CRM_PLATFORMS.filter(([v])=>CUENTA_COMPLETA_PLATAFORMAS.includes(v));
  return CRM_PLATFORMS.filter(([v])=>clasificarServicio({plataforma:v}).categoria===cat);
}
export function crmCategoriasHtml(d) {
  const cat=crmCategoriaDraft(d);
  return `<input type="hidden" id="crmCategoria" value="${esc(cat)}"><div class="crm-cats" role="tablist" aria-label="Categoría">${ORDEN_CATEGORIAS.map(k=>`<button type="button" class="crm-cat ${cat===k?'on':''}" data-crm-cat="${k}">${CATEGORIAS[k].emoji} ${CATEGORIAS[k].label}</button>`).join('')}</div>${cat==='cuentas_completas'?'<p class="crm-cat-note">🔐 Cuenta completa: solo <b>correo + clave + precio</b>. Sin PIN ni perfiles.</p>':''}`;
}

// Todas las plataformas en el select, pero solo se VEN las de la categoría elegida (el valor guardado siempre existe).
export function crmOpcionesPlataforma(d = {}) {
  const visibles = new Set(crmPlataformasDeCategoria(crmCategoriaDraft(d)).map(([v]) => v));
  return CRM_PLATFORMS.map(([value, label]) => `<option value="${value}" ${d.plataforma === value ? 'selected' : ''} ${visibles.has(value) || d.plataforma === value ? '' : 'hidden'}>${label}</option>`).join('');
}
// Al cambiar de plataforma: si sigue en Cuentas completas y se permite, se queda; si no, toma la categoría de la plataforma.
export function crmCategoriaParaPlataforma(d = {}, value = '') {
  const actual = crmCategoriaDraft(d);
  if (actual === 'cuentas_completas' && CUENTA_COMPLETA_PLATAFORMAS.includes(value)) return 'cuentas_completas';
  return clasificarServicio({ plataforma: value }).categoria;
}
