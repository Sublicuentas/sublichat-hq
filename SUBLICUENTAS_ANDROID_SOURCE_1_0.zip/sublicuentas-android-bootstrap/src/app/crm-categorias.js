// src/app/crm-categorias.js · R112 — selector de categorías del formulario de compra (APK).
import { CRM_PLATFORMS, esc, crmPlanHbo } from './core.js';
// R196v · HBO Standard / Platinum: en Perfiles «· 3 / · 5 perfiles», en Cuentas completas «· cuenta completa». «HBO Max» genérico
// (venta anterior sin plan) solo aparece al editar esa venta: no se ofrece para ventas nuevas.
const ccBase = (v) => (crmPlanHbo(v) ? 'hbomax' : v);
const etiquetaHbo = (v, label, cat) => { const p = crmPlanHbo(v); if (!p) return label; return cat === 'cuentas_completas' ? `HBO ${p === 'platinum' ? 'Platinum' : 'Standard'} · cuenta completa` : label; };
import { CATEGORIAS, ORDEN_CATEGORIAS, CUENTA_COMPLETA_PLATAFORMAS, clasificarServicio } from './catalogo-categorias.js';
// R112 · Categorías (mismo contrato que web y bot): primero la categoría y después solo sus plataformas.
export function crmCategoriaDraft(d={}) { return d.categoria || clasificarServicio({plataforma:d.plataforma,tipoVenta:d.tipoVenta}).categoria; }
export function crmPlataformasDeCategoria(cat) {
  if (cat==='cuentas_completas') return CRM_PLATFORMS.filter(([v])=>v!=='hbomax'&&CUENTA_COMPLETA_PLATAFORMAS.includes(ccBase(v)));
  return CRM_PLATFORMS.filter(([v])=>v!=='hbomax'&&clasificarServicio({plataforma:v}).categoria===cat);
}
export function crmCategoriasHtml(d) {
  const cat=crmCategoriaDraft(d);
  return `<input type="hidden" id="crmCategoria" value="${esc(cat)}"><div class="crm-cats" role="tablist" aria-label="Categoría">${ORDEN_CATEGORIAS.map(k=>`<button type="button" class="crm-cat ${cat===k?'on':''}" data-crm-cat="${k}">${CATEGORIAS[k].emoji} ${CATEGORIAS[k].label}</button>`).join('')}</div>${cat==='cuentas_completas'?'<p class="crm-cat-note">🔐 Cuenta completa: solo <b>correo + clave + precio</b>. Sin PIN ni perfiles.</p>':''}`;
}

// Todas las plataformas en el select, pero solo se VEN las de la categoría elegida (el valor guardado siempre existe).
export function crmOpcionesPlataforma(d = {}) {
  const cat = crmCategoriaDraft(d); const visibles = new Set(crmPlataformasDeCategoria(cat).map(([v]) => v));
  return CRM_PLATFORMS.map(([value, label]) => `<option value="${value}" ${d.plataforma === value ? 'selected' : ''} ${visibles.has(value) || d.plataforma === value ? '' : 'hidden'}>${etiquetaHbo(value, label, cat)}</option>`).join('');
}
// Al cambiar de plataforma: si sigue en Cuentas completas y se permite, se queda; si no, toma la categoría de la plataforma.
// R196v · al editar: una venta HBO con plan abre en su opción «HBO Standard/Platinum»; sin plan queda «HBO Max (venta anterior)».
export function crmPlataformaConPlan(base = '', s = {}) { return base === 'hbomax' && ['standard', 'platinum'].includes(String(s.planHbo || '')) ? `hbomax_${s.planHbo}` : base; }
export function crmCategoriaParaPlataforma(d = {}, value = '') {
  const actual = crmCategoriaDraft(d);
  if (actual === 'cuentas_completas' && CUENTA_COMPLETA_PLATAFORMAS.includes(ccBase(value))) return 'cuentas_completas';
  return clasificarServicio({ plataforma: value }).categoria;
}
