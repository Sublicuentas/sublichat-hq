// R196r · Acciones del cliente: respuesta visual inmediata y operaciones sin bloqueo ni doble toque.
import { state } from './core.js';

// Deja pintar el toque (fila marcada) antes del redibujo pesado de la app.
export const nextPaint = () => new Promise((r) => { const raf = globalThis.requestAnimationFrame; if (typeof raf === 'function') raf(() => setTimeout(r, 0)); else setTimeout(r, 0); });
export function scrollRenewTo(sel) { setTimeout(() => document.querySelector(sel)?.scrollIntoView?.({ block: 'start' }), 30); }

export const URL_TIMEOUT_MS = 12000;
// «Acceso URL y variantes»: abre al instante una hoja de carga; el enlace llega después (o error con Reintentar).
export async function abrirUrlCliente(row, { render, showToast, ensureClientLinks, rowBeneficiaryKey }) {
  if (!row?.clienteId) { showToast('Esta ficha no tiene ID de cliente.'); return; }
  if (state.clientActionUrlBusy) return; // sin doble solicitud por toques rápidos
  const key = state.clientActionKey; const token = (state.clientActionUrlToken || 0) + 1;
  state.clientActionUrlToken = token; state.clientActionUrlBusy = true;
  state.clientActionMode = 'url-loading'; state.clientActionError = ''; render();
  const vigente = () => state.clientActionUrlToken === token && state.clientActionKey === key && state.clientActionMode === 'url-loading';
  try {
    const result = await Promise.race([ensureClientLinks(row.clienteId, rowBeneficiaryKey(row)), new Promise((_, rej) => setTimeout(() => rej(Object.assign(new Error(`El servidor tardó más de ${URL_TIMEOUT_MS / 1000} s.`), { timeout: true })), URL_TIMEOUT_MS))]);
    if (!vigente()) return; // se canceló o se cerró: no se reabre nada
    if (!result?.ok) throw new Error(result?.error || 'No se pudo recuperar el enlace.');
    const relative = String(result.linkPublico || '').trim();
    state.clientActionLink = relative.startsWith('http') ? relative : `https://sublichat.capuchino.lat${relative.startsWith('/') ? '' : '/'}${relative}`;
    state.clientActionMode = 'url'; state.clientActionUrlVariant = 0; render();
  } catch (error) { if (vigente()) { state.clientActionMode = 'url-error'; state.clientActionError = error?.message || 'No se pudo abrir la ficha URL.'; render(); } }
  finally { if (state.clientActionUrlToken === token) state.clientActionUrlBusy = false; }
}
