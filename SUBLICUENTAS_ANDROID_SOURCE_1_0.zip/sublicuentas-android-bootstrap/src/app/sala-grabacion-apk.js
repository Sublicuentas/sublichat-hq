// R196j · Grabación en el teléfono (paridad con la web). La sala graba con MediaRecorder del WebView y entrega el video aquí.
// Se escribe por partes (3 MB) para no llenar la memoria y queda en Documentos/Sublichat; luego se abre «Compartir».
const nombreLimpio = (s) => String(s || 'reunion').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_').slice(0, 60) || 'reunion';
async function aBase64(blob) {
  const buf = new Uint8Array(await blob.arrayBuffer()); let s = '';
  for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return btoa(s);
}
export async function guardarGrabacion({ blob, extension }, base, deps = {}) {
  if (!blob || !blob.size) throw new Error('La grabación quedó vacía.');
  const nombre = `${nombreLimpio(base)}.${extension === 'mp4' ? 'mp4' : 'webm'}`;
  const { Capacitor } = deps.Capacitor ? deps : await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = nombre; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 60000); return 'Descargas'; }
  const { Filesystem, Directory } = deps.Filesystem ? deps : await import('@capacitor/filesystem');
  const PARTE = 3 * 1024 * 1024; // múltiplo de 3: cada parte en base64 se puede anexar sin romper el archivo
  const escribir = async (directory, path) => {
    for (let i = 0; i < blob.size; i += PARTE) {
      const data = await aBase64(blob.slice(i, i + PARTE));
      if (i === 0) await Filesystem.writeFile({ path, data, directory, recursive: true });
      else await Filesystem.appendFile({ path, data, directory });
    }
    return (await Filesystem.getUri({ path, directory })).uri;
  };
  let uri, donde;
  try { uri = await escribir(Directory.Documents, `Sublichat/${nombre}`); donde = `Documentos/Sublichat/${nombre}`; }
  catch (_) { uri = await escribir(Directory.Data, `grabaciones/${nombre}`); donde = 'la carpeta de la app (Grabaciones)'; }
  try { const { Share } = deps.Share ? deps : await import('@capacitor/share'); await Share.share({ title: nombre, files: [uri], dialogTitle: 'Guardar o enviar la grabación' }); } catch (_) { /* cerrar «Compartir» no es error */ }
  return donde;
}
