// R210 · Pelis y estrenos › «Recomendaciones del día» y «Cartelera y estrenos» en la APK.
// Es el MISMO módulo de Sublichat Web (pelis-rec.js, copia fiel en public/). Usa la sesión de la APK (authPost → /api/tmdb).
// La selección es del día (hora de Honduras) y se guarda en el teléfono: si no hay red, se ve la de hoy ya descargada;
// un fallo de recomendaciones nunca bloquea el buscador de títulos.
import { authPost } from '../api.js';
import { state } from './core.js';

export const PELIS_REC_VERSION = '20261128-r210';
let carga = null;
function cargarModulo(doc = document) {
  const w = doc.defaultView || window;
  if (w.SublichatPelisRec?.montar) return Promise.resolve(w.SublichatPelisRec);
  if (carga) return carga;
  carga = new Promise((ok, mal) => {
    if (!doc.getElementById('plrCss')) { const l = doc.createElement('link'); l.id = 'plrCss'; l.rel = 'stylesheet'; l.href = `/pelis-rec.css?v=${PELIS_REC_VERSION}`; doc.head.appendChild(l); }
    const sc = doc.createElement('script'); sc.src = `/pelis-rec.js?v=${PELIS_REC_VERSION}`; sc.async = true;
    sc.onload = () => (w.SublichatPelisRec?.montar ? ok(w.SublichatPelisRec) : mal(new Error('No se pudo iniciar.')));
    sc.onerror = () => { carga = null; mal(new Error('No se pudieron cargar las recomendaciones. Revise la conexión.')); };
    doc.head.appendChild(sc);
  });
  return carga;
}
async function post(body) {
  try { return await authPost('/api/tmdb', body); }
  catch (e) { return { error: e?.data?.error || e?.message || 'Sin conexión' }; }
}
export function bindPelisRec() {
  if (state.subview !== 'pelis') return;
  const el = document.getElementById('plRec'); if (!el) return;
  cargarModulo().then((M) => M.montar(document.getElementById('plRec'), { post, actualizado: () => document.getElementById('plUpd') }))
    .catch((e) => { const h = document.getElementById('plRec'); if (h) h.innerHTML = `<div class="error-box"><span>${String(e.message).replace(/[<>&]/g, '')}</span></div>`; });
}
