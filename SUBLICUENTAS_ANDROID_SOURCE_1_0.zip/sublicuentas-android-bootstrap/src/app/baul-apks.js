// R187 · Más › Baúl de APKs (PDF «Sublichat 5 puntos», bloque 02). Mismo directorio que Sublichat Web y el bot:
// lo sirve /api/inventario (accion baulApks) desde Firestore configuracion_tv_digital/baul_apks.
// · Consulta: plataforma → dispositivo → enlaces con «Copiar» (URL y código) y «Abrir» (solo https).
// · Sublicuentas/Relojes (editores): desactivar/activar y editar URL, código y nota. El SERVIDOR valida y audita;
//   ocultar botones no es la seguridad. Eliminar se hace desde la Web (doble confirmación).
// · URLs de CONEXIÓN de TV Digital: aparte del Baúl. Desactivar no rompe a los clientes que ya la tienen.
// Nada de URLs, códigos ni dispositivos inventados: si el servidor no responde, se muestra el error, no una lista fija.
import { authPost } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';

const ident = () => operatorIdentity(state.session?.role || '', state.session?.usuario || '');
export function canBaul() { return ['sublicuentas', 'relojes', 'geisell'].includes(ident()); }
export function bState() { if (!state.baul) state.baul = { data: null, urls: null, cargando: false, error: '', plat: '', disp: '', editar: '', tab: 'baul' }; return state.baul; }
export function resetBaul() { state.baul = null; }

async function inv(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/inventario', { accion, ...extra }); }
  catch (e) { throw new Error(Number(e?.status) === 403 ? (e?.data?.error || 'Su usuario no tiene acceso al Baúl de APKs.') : (e?.data?.error || e?.message || 'Sin conexión')); }
  if (!r || r.ok === false || r.error) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
export async function baulCargar() {
  const s = bState(); s.cargando = true; s.error = ''; ui.render();
  try {
    const [b, u] = await Promise.all([inv('baulApks'), inv('tvUrlsHistorial').catch(() => null)]);
    s.data = b; s.urls = u; if (!s.plat) s.plat = b.plataformas?.[0]?.id || '';
  } catch (e) { s.error = e?.message || 'Sin conexión'; }
  s.cargando = false; if (state.subview === 'baul-apks') ui.render();
}

export function enlaceHtml(e, editor = false, editando = false) {
  const http = /^https:\/\//i.test(e.url || '');
  const acciones = [
    e.url ? `<button type="button" class="se-btn ghost" data-baul-copiar="${esc(e.url)}">Copiar URL</button>` : '',
    e.codigo ? `<button type="button" class="se-btn ghost" data-baul-copiar="${esc(e.codigo)}">Copiar código</button>` : '',
    http ? `<button type="button" class="se-btn ghost" data-baul-abrir="${esc(e.url)}">Abrir</button>` : '',
    editor ? `<button type="button" class="se-btn ghost" data-baul-editar="${esc(e.id)}">Editar</button><button type="button" class="se-btn ghost" data-baul-activar="${esc(e.id)}" data-activo="${e.activo === false ? '1' : '0'}">${e.activo === false ? 'Activar' : 'Desactivar'}</button>` : '',
  ].join('');
  const form = editando ? `<div class="baul-form"><input class="se-input" id="baulUrl" type="url" inputmode="url" value="${esc(e.url || '')}" placeholder="https://…"><input class="se-input" id="baulCodigo" inputmode="numeric" value="${esc(e.codigo || '')}" placeholder="Código Downloader (solo números)"><input class="se-input" id="baulNota" value="${esc(e.nota || '')}" placeholder="Nota"><div class="baul-acc"><button type="button" class="se-btn" data-baul-guardar="${esc(e.id)}">Guardar</button><button type="button" class="se-btn ghost" data-baul-cancelar>Cancelar</button></div></div>` : '';
  return `<article class="se-card baul-enlace${e.activo === false ? ' off' : ''}">
    <b>${esc(e.app || e.appId)} · ${esc(e.metodoTxt || e.metodo)}${e.activo === false ? ' · desactivado' : ''}</b>
    ${e.url ? `<code class="baul-url">${esc(e.url)}</code>` : e.metodo === 'tv_store' ? '<small>Buscar en la tienda del TV (sin enlace).</small>' : ''}
    ${e.codigo ? `<small>Código Downloader: <strong>${esc(e.codigo)}</strong></small>` : ''}
    ${editor && e.codigoPendiente ? `<small>Código por confirmar: ${esc(e.codigoPendiente)} (no se entrega)</small>` : ''}
    ${e.costoExterno?.texto ? `<small>💲 ${esc(e.costoExterno.texto)}</small>` : ''}
    ${e.nota ? `<small>${esc(e.nota)}</small>` : ''}
    <div class="baul-acc">${acciones}</div>${form}</article>`;
}
function urlsHtml(s, editor) {
  const urls = s.urls?.urls || {};
  const filas = Object.entries(urls).map(([k, v]) => `<article class="se-card baul-enlace${v.activo === false ? ' off' : ''}"><b>${esc(v.nombre)}${v.activo === false ? ' · desactivada' : ''}</b><code class="baul-url">${esc(v.url)}</code>
    <div class="baul-acc"><button type="button" class="se-btn ghost" data-baul-copiar="${esc(v.url)}">Copiar</button>${editor ? `<button type="button" class="se-btn ghost" data-baul-urltv="${esc(k)}" data-activo="${v.activo === false ? '1' : '0'}">${v.activo === false ? 'Activar' : 'Desactivar'}</button>` : ''}</div></article>`).join('');
  return `${filas || '<div class="empty-state"><strong>Sin URLs</strong></div>'}<small class="baul-aviso">Desactivar una URL de conexión solo la quita para entregas nuevas: los clientes que ya la tienen no se tocan. Editar y eliminar: Sublichat Web → Bodega → URLs TV Digital.</small>`;
}

export function baulView() {
  const s = bState();
  if (!canBaul()) return ui.subPage('Baúl de APKs', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene el Baúl de APKs</strong></div>');
  if (s.data === null && !s.cargando && !s.error) setTimeout(baulCargar, 0);
  const d = s.data, editor = !!d?.editor;
  const tabs = `<div class="se-filtros"><button type="button" class="se-chip ${s.tab === 'baul' ? 'on' : ''}" data-baul-tab="baul">Aplicaciones</button><button type="button" class="se-chip ${s.tab === 'urls' ? 'on' : ''}" data-baul-tab="urls">URLs de conexión</button></div>`;
  let cuerpo = '';
  if (s.cargando && !d) cuerpo = '<div class="loading-card"><span class="spinner"></span><strong>Cargando Baúl…</strong></div>';
  else if (s.error && !d) cuerpo = `<div class="error-box"><span>${esc(s.error)}</span></div>`;
  else if (d && s.tab === 'urls') cuerpo = urlsHtml(s, editor);
  else if (d) {
    const vista = (d.vistas || []).find((v) => v.plataforma === s.plat) || { dispositivos: [] };
    const disp = vista.dispositivos.find((x) => x.id === s.disp) || vista.dispositivos[0];
    cuerpo = `<div class="se-filtros">${(d.plataformas || []).map((p) => `<button type="button" class="se-chip ${p.id === s.plat ? 'on' : ''}" data-baul-plat="${esc(p.id)}">${esc(p.nombre)}</button>`).join('')}</div>
      <div class="se-filtros">${vista.dispositivos.map((x) => `<button type="button" class="se-chip ${disp && x.id === disp.id ? 'on' : ''}" data-baul-disp="${esc(x.id)}">${esc(x.nombre)} · ${x.enlaces.length}</button>`).join('')}</div>
      ${disp ? disp.enlaces.map((e) => enlaceHtml(e, editor, s.editar === e.id)).join('') : '<div class="empty-state"><strong>Sin enlaces para esta plataforma</strong></div>'}
      <small class="baul-aviso">${esc(d.aviso || '')}</small>`;
  }
  return ui.subPage('Baúl de APKs', 'TV Digital · igual que en la web y el bot', `<section class="se-wrap">${tabs}${s.error && d ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}${cuerpo}<button type="button" class="se-btn ghost" data-baul-recargar>Actualizar</button></section>`);
}

async function accion(fn, ok) {
  const s = bState();
  try { await fn(); s.error = ''; s.editar = ''; showToast?.(ok); await baulCargar(); }
  catch (e) { s.error = e?.message || 'No se pudo guardar.'; ui.render(); }
}
export function bindBaul() {
  if (state.subview !== 'baul-apks') return;
  const s = bState(), qa = (x) => document.querySelectorAll(x), val = (id) => document.getElementById(id)?.value ?? '';
  qa('[data-baul-tab]').forEach((b) => b.addEventListener('click', () => { s.tab = b.dataset.baulTab; ui.render(); }));
  qa('[data-baul-plat]').forEach((b) => b.addEventListener('click', () => { s.plat = b.dataset.baulPlat; s.disp = ''; s.editar = ''; ui.render(); }));
  qa('[data-baul-disp]').forEach((b) => b.addEventListener('click', () => { s.disp = b.dataset.baulDisp; s.editar = ''; ui.render(); }));
  qa('[data-baul-copiar]').forEach((b) => b.addEventListener('click', () => ui.copy(b.dataset.baulCopiar)));
  qa('[data-baul-abrir]').forEach((b) => b.addEventListener('click', () => ui.openLink(b.dataset.baulAbrir)));
  qa('[data-baul-recargar]').forEach((b) => b.addEventListener('click', baulCargar));
  qa('[data-baul-editar]').forEach((b) => b.addEventListener('click', () => { s.editar = b.dataset.baulEditar; ui.render(); }));
  qa('[data-baul-cancelar]').forEach((b) => b.addEventListener('click', () => { s.editar = ''; ui.render(); }));
  qa('[data-baul-activar]').forEach((b) => b.addEventListener('click', () => accion(() => inv('baulActivarEnlace', { id: b.dataset.baulActivar, activo: b.dataset.activo === '1' }), b.dataset.activo === '1' ? 'Enlace activado' : 'Enlace desactivado')));
  qa('[data-baul-urltv]').forEach((b) => b.addEventListener('click', () => accion(() => inv('activarTvUrl', { proveedor: b.dataset.baulUrltv, activo: b.dataset.activo === '1' }), b.dataset.activo === '1' ? 'URL activada' : 'URL desactivada (clientes actuales intactos)')));
  qa('[data-baul-guardar]').forEach((b) => b.addEventListener('click', () => {
    const e = (s.data?.enlaces || []).find((x) => x.id === b.dataset.baulGuardar);
    if (!e) { s.error = 'Ese enlace ya no existe. Actualice.'; ui.render(); return; }
    accion(() => inv('baulGuardarEnlace', { enlace: { ...e, url: val('baulUrl').trim(), codigo: val('baulCodigo').trim(), nota: val('baulNota').trim() } }), 'Enlace guardado');
  }));
}
