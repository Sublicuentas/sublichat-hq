// R187 · R192 · Más › Baúl de APKs (PDF «Sublichat APK correcciones», P2). Mismo directorio que Sublichat Web y el bot:
// lo sirve /api/inventario (accion baulApks) desde Firestore configuracion_tv_digital/baul_apks.
// Navegación en TRES niveles: 1) plataforma (logo) → 2) dispositivos con apps registradas → 3) app(s) de instalación.
// En el nivel 3: «Copiar instrucciones completas» y «Enviar al cliente» (abre Compartir de Android: la persona elige
// WhatsApp y confirma; nunca se envía solo). El mensaje lo arma el SERVIDOR desde el mismo registro (igual en bot y Web).
// Código y enlace solo cuando corresponden; la URL técnica la ve solo el personal autorizado.
// Sublicuentas/Relojes (editores): editar URL/código/nota y activar/desactivar; el servidor valida y audita.
// Nada de URLs, códigos ni dispositivos inventados: si el servidor no responde, se muestra el error, no una lista fija.
// R196m · Mensaje corto de UN dispositivo (lo arma el servidor). Vista previa legible + «Copiar instrucciones» (el portapapeles
// lleva el texto final con *negritas* de WhatsApp, sin encabezados internos). Si falta enlace o código: «No configurado» y
// no se puede copiar. Logo de cada plataforma o aviso visible si no carga (nunca un recuadro vacío).
import { Share } from '@capacitor/share';
import { authPost } from '../api.js';
import { state, esc, ui, showToast } from './core.js';
import { operatorIdentity } from '../data.js';
import { platformLogoFile } from '../screens2.js';

const ident = () => operatorIdentity(state.session?.role || '', state.session?.usuario || '');
export function canBaul() { return ['sublicuentas', 'relojes', 'geisell'].includes(ident()); }
export function bState() { if (!state.baul) state.baul = { data: null, urls: null, cargando: false, error: '', plat: '', disp: '', editar: '', tab: 'baul' }; return state.baul; }
export function resetBaul() { state.baul = null; }

// Logos que YA existen en la app (catálogo). Lion TV y Nanotech todavía no tienen logo autorizado: marcador con su inicial.
// R194 · Logos: el MISMO catálogo de logos de toda la APK (screens2.platformLogoFile), así Lion TV y Nanotech salen con
// el logo que el sistema ya usa para ellas (CRM, Control Maestro, acceso) y no con una letra.
export const LOGOS_TV = Object.freeze(Object.fromEntries(['liontv', 'icomplay', 'latintv', 'oleada', 'stellatv', 'evoutouch'].map((id) => [id, `/assets/plataformas/${platformLogoFile(id)}.webp`])));
const ICONO_DISP = Object.freeze({ android_tv: '📺', fire_tv: '🔥', android_movil: '📱', smart_tv: '🖥️', iphone: '', pc: '💻' });
const icoDisp = (id) => ICONO_DISP[id] || '📲';

async function inv(accion, extra = {}) {
  let r;
  try { r = await authPost('/api/inventario', { accion, ...extra }); }
  catch (e) { throw new Error(Number(e?.status) === 403 ? (e?.data?.error || 'Su usuario no tiene acceso al Baúl de APKs.') : (e?.data?.error || e?.message || 'Sin conexión')); }
  if (!r || r.ok === false || r.error) throw new Error(r?.error || 'No se pudo completar.');
  return r;
}
export async function baulCargar() {
  const s = bState(); s.cargando = true; s.error = ''; ui.render();
  try {
    const [b, u] = await Promise.all([inv('baulApks'), inv('tvUrlsHistorial').catch(() => null)]);
    s.data = b; s.urls = u;
  } catch (e) { s.error = e?.message || 'Sin conexión'; }
  s.cargando = false; if (state.subview === 'baul-apks') ui.render();
}

const logoDe = (p) => LOGOS_TV[p.id] || (platformLogoFile(p.id || p.nombre) ? `/assets/plataformas/${platformLogoFile(p.id || p.nombre)}.webp` : '');
const faltaLogo = (p) => `<span class="baul-ini" aria-hidden="true">${esc((p.nombre || '?').charAt(0))}</span><small class="baul-falta-logo">Falta logo</small>`;
const logoHtml = (p) => logoDe(p) ? `<img src="${logoDe(p)}" alt="${esc(p.nombre || '')}" loading="lazy" data-baul-logo="${esc(p.nombre || '?')}">` : faltaLogo(p);
// Vista previa: *negrita* de WhatsApp → negrita en pantalla (el texto copiado conserva los asteriscos).
export const vistaWhatsApp = (txt) => esc(txt).replace(/\*([^*\n]+)\*/g, '<b>$1</b>');
function nivelPlataformas(d) {
  return `<p class="baul-paso">Paso 1 de 3 · elija la plataforma</p><div class="baul-grid">${(d.plataformas || []).map((p) => {
    const v = (d.vistas || []).find((x) => x.plataforma === p.id) || { dispositivos: [] };
    return `<button type="button" class="baul-plat" data-baul-plat="${esc(p.id)}"><span class="baul-logo">${logoHtml(p)}</span><b>${esc(p.nombre)}</b><small>${v.dispositivos.length} dispositivo${v.dispositivos.length === 1 ? '' : 's'}</small></button>`;
  }).join('')}</div>`;
}
function nivelDispositivos(d, vista, p) {
  return `<p class="baul-paso">Paso 2 de 3 · ${esc(p.nombre)} · elija el dispositivo del cliente</p>
    ${vista.dispositivos.length ? `<div class="baul-disps">${vista.dispositivos.map((x) => `<button type="button" class="baul-disp" data-baul-disp="${esc(x.id)}"><span aria-hidden="true">${icoDisp(x.id)}</span><b>${esc(x.nombre)}</b><small>${x.enlaces.length} ${x.enlaces.length === 1 ? 'opción' : 'opciones'}</small><i aria-hidden="true">›</i></button>`).join('')}</div>`
      : '<div class="empty-state"><strong>Sin dispositivos registrados para esta plataforma</strong></div>'}`;
}
export function enlaceHtml(e, editor = false, editando = false, n = 1, total = 1) {
  const https = /^https:\/\//i.test(e.url || '');
  const ios = e.dispositivo === 'iphone';
  const form = editando ? `<div class="baul-form"><input class="se-input" id="baulUrl" type="url" inputmode="url" value="${esc(e.url || '')}" placeholder="https://…"><input class="se-input" id="baulCodigo" inputmode="numeric" value="${esc(e.codigo || '')}" placeholder="Código Downloader (solo números)"><input class="se-input" id="baulNota" value="${esc(e.nota || '')}" placeholder="Nota"><div class="baul-acc"><button type="button" class="se-btn" data-baul-guardar="${esc(e.id)}">Guardar</button><button type="button" class="se-btn ghost" data-baul-cancelar>Cancelar</button></div></div>` : '';
  return `<article class="se-card baul-enlace${e.activo === false ? ' off' : ''}" data-baul-enlace="${esc(e.id)}">
    <b class="baul-app">${total > 1 ? `<span class="baul-op">Opción ${n}</span>` : ''}${esc(e.app || e.appId)}${e.activo === false ? ' · desactivado' : ''}</b>
    <small>Método: ${esc(e.codigo && ['android_tv', 'fire_tv', 'android_movil'].includes(e.dispositivo) ? 'Con Downloader' : (e.metodoTxt || e.metodo))}</small>
    ${e.metodo === 'tv_store' ? '<small>Buscar en la tienda del TV (sin enlace).</small>' : ''}
    ${ios ? '<small class="baul-ios">No instalar archivos APK en iPhone: solo App Store o web.</small>' : ''}
    ${e.codigo ? `<small>Código Downloader: <strong>${esc(e.codigo)}</strong></small>` : ''}
    ${editor && e.url ? `<code class="baul-url" title="Visible solo para personal autorizado">${esc(e.url)}</code>` : ''}
    ${editor && e.codigoPendiente ? `<small>Código por confirmar: ${esc(e.codigoPendiente)} (no se entrega)</small>` : ''}
    ${e.costoExterno?.texto ? `<p class="baul-costo"><b>Nota de costo:</b> ${esc(e.costoExterno.texto)}</p>` : ''}
    ${e.nota && editor ? `<small>${esc(e.nota)}</small>` : ''}
    ${e.mensaje ? `<div class="baul-msg" aria-label="Vista previa del mensaje"><div class="baul-prev">${vistaWhatsApp(e.mensaje)}</div></div>`
      : `<div class="baul-falta" role="alert"><b>No configurado</b><span>${esc(e.faltante || 'Faltan datos de instalación')}.${editor ? ' Complételo con «Editar».' : ' Avise a un administrador.'}</span></div>`}
    <div class="baul-acc baul-acc-pri">${e.mensaje ? `<button type="button" class="se-btn" data-baul-copiar-msg="${esc(e.id)}">Copiar instrucciones</button><button type="button" class="se-btn baul-enviar" data-baul-enviar="${esc(e.id)}">Enviar al cliente</button>` : ''}</div>
    <div class="baul-acc">${e.codigo ? `<button type="button" class="se-btn ghost" data-baul-copiar="${esc(e.codigo)}">Copiar código</button>` : ''}${editor && e.url ? `<button type="button" class="se-btn ghost" data-baul-copiar="${esc(e.url)}">Copiar enlace</button>` : ''}${https ? `<button type="button" class="se-btn ghost" data-baul-abrir="${esc(e.url)}">Abrir</button>` : ''}
      ${editor ? `<button type="button" class="se-btn ghost" data-baul-editar="${esc(e.id)}">Editar</button><button type="button" class="se-btn ghost" data-baul-activar="${esc(e.id)}" data-activo="${e.activo === false ? '1' : '0'}">${e.activo === false ? 'Activar' : 'Desactivar'}</button>` : ''}</div>${form}</article>`;
}
function nivelApps(d, vista, p, disp, s) {
  const editor = !!d.editor;
  if (!disp) return '<div class="empty-state"><strong>No disponible para este dispositivo</strong></div>';
  return `<p class="baul-paso">Paso 3 de 3 · ${esc(p.nombre)} › ${esc(disp.nombre)}</p>${disp.enlaces.map((e, i) => enlaceHtml(e, editor, s.editar === e.id, i + 1, disp.enlaces.length)).join('')}
    <small class="baul-aviso">${esc(d.aviso || '')}</small>`;
}
function urlsHtml(s, editor) {
  const urls = s.urls?.urls || {};
  const filas = Object.entries(urls).map(([k, v]) => `<article class="se-card baul-enlace${v.activo === false ? ' off' : ''}"><b>${esc(v.nombre)}${v.activo === false ? ' · desactivada' : ''}</b><code class="baul-url">${esc(v.url)}</code>
    <div class="baul-acc"><button type="button" class="se-btn ghost" data-baul-copiar="${esc(v.url)}">Copiar</button>${editor ? `<button type="button" class="se-btn ghost" data-baul-urltv="${esc(k)}" data-activo="${v.activo === false ? '1' : '0'}">${v.activo === false ? 'Activar' : 'Desactivar'}</button>` : ''}</div></article>`).join('');
  return `${filas || '<div class="empty-state"><strong>Sin URLs</strong></div>'}<small class="baul-aviso">Desactivar una URL de conexión solo la quita para entregas nuevas: los clientes que ya la tienen no se tocan. Editar y eliminar: Sublichat Web → Bodega → URLs TV Digital.</small>`;
}

export function baulView() {
  const s = bState();
  if (!canBaul()) return ui.subPage('Baúl de APKs', 'No disponible', '<div class="empty-state"><strong>Su usuario no tiene el Baúl de APKs</strong></div>');
  if (s.data === null && !s.cargando && !s.error) setTimeout(baulCargar, 0);
  const d = s.data, editor = !!d?.editor;
  let cuerpo = '', titulo = 'Baúl de APKs', sub = 'Primero la plataforma, luego el dispositivo';
  if (s.cargando && !d) cuerpo = '<div class="loading-card"><span class="spinner"></span><strong>Cargando Baúl…</strong></div>';
  else if (s.error && !d) cuerpo = `<div class="error-box"><span>${esc(s.error)}</span></div>`;
  else if (d && s.tab === 'urls') { titulo = 'URLs de conexión'; sub = 'TV Digital · aparte del Baúl'; cuerpo = `<button type="button" class="se-btn ghost baul-volver" data-baul-tab="baul">‹ Aplicaciones</button>${urlsHtml(s, editor)}`; }
  else if (d) {
    const p = (d.plataformas || []).find((x) => x.id === s.plat);
    const vista = p ? ((d.vistas || []).find((v) => v.plataforma === p.id) || { dispositivos: [] }) : null;
    const disp = vista && s.disp ? vista.dispositivos.find((x) => x.id === s.disp) : null;
    if (!p) cuerpo = `${nivelPlataformas(d)}<button type="button" class="se-btn ghost" data-baul-tab="urls">URLs de conexión de TV Digital</button>`;
    else if (!s.disp) { titulo = p.nombre; cuerpo = `<button type="button" class="se-btn ghost baul-volver" data-baul-atras="plat">‹ Plataformas</button>${nivelDispositivos(d, vista, p)}`; }
    else { titulo = `${p.nombre} › ${disp?.nombre || 'Dispositivo'}`; cuerpo = `<button type="button" class="se-btn ghost baul-volver" data-baul-atras="disp">‹ Dispositivos de ${esc(p.nombre)}</button>${nivelApps(d, vista, p, disp, s)}`; }
  }
  return ui.subPage(titulo, sub, `<section class="se-wrap baul-wrap">${s.error && d ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}${cuerpo}<button type="button" class="se-btn ghost" data-baul-recargar>Actualizar</button></section>`);
}

async function accion(fn, ok) {
  const s = bState();
  try { await fn(); s.error = ''; s.editar = ''; showToast?.(ok); await baulCargar(); }
  catch (e) { s.error = e?.message || 'No se pudo guardar.'; ui.render(); }
}
function enlaceActual(id) {
  const s = bState(); const v = (s.data?.vistas || []).find((x) => x.plataforma === s.plat);
  return v ? v.dispositivos.flatMap((x) => x.enlaces).find((x) => x.id === id) : null;
}
export async function compartirMensaje(texto) {
  try { await Share.share({ title: 'Instalación', text: texto, dialogTitle: 'Enviar al cliente' }); return true; }
  catch (e) { if (/cancel/i.test(String(e?.message || e))) return false; ui.copy(texto); showToast?.('No se pudo abrir Compartir: el mensaje quedó copiado.'); return false; }
}
export function bindBaul() {
  if (state.subview !== 'baul-apks') return;
  const s = bState(), qa = (x) => document.querySelectorAll(x), val = (id) => document.getElementById(id)?.value ?? '';
  const arriba = () => { try { window.scrollTo(0, 0); } catch (_) {} };
  qa('[data-baul-tab]').forEach((b) => b.addEventListener('click', () => { s.tab = b.dataset.baulTab; s.plat = ''; s.disp = ''; ui.render(); arriba(); }));
  qa('[data-baul-plat]').forEach((b) => b.addEventListener('click', () => { s.plat = b.dataset.baulPlat; s.disp = ''; s.editar = ''; ui.render(); arriba(); }));
  qa('[data-baul-disp]').forEach((b) => b.addEventListener('click', () => { s.disp = b.dataset.baulDisp; s.editar = ''; ui.render(); arriba(); }));
  qa('[data-baul-atras]').forEach((b) => b.addEventListener('click', () => { if (b.dataset.baulAtras === 'disp') s.disp = ''; else { s.plat = ''; s.disp = ''; } s.editar = ''; ui.render(); arriba(); }));
  qa('[data-baul-copiar]').forEach((b) => b.addEventListener('click', () => ui.copy(b.dataset.baulCopiar)));
  qa('img[data-baul-logo]').forEach((im) => im.addEventListener('error', () => { const sp = document.createElement('small'); sp.className = 'baul-falta-logo'; sp.textContent = `Falta logo: ${im.dataset.baulLogo}`; im.replaceWith(sp); }, { once: true }));
  qa('[data-baul-copiar-msg]').forEach((b) => b.addEventListener('click', () => { const e = enlaceActual(b.dataset.baulCopiarMsg); if (e?.mensaje) ui.copy(e.mensaje, 'Instrucciones copiadas.'); }));
  qa('[data-baul-enviar]').forEach((b) => b.addEventListener('click', () => { const e = enlaceActual(b.dataset.baulEnviar); if (e?.mensaje) compartirMensaje(e.mensaje); }));
  qa('[data-baul-abrir]').forEach((b) => b.addEventListener('click', () => ui.openLink(b.dataset.baulAbrir)));
  qa('[data-baul-recargar]').forEach((b) => b.addEventListener('click', baulCargar));
  qa('[data-baul-editar]').forEach((b) => b.addEventListener('click', () => { s.editar = b.dataset.baulEditar; ui.render(); }));
  qa('[data-baul-cancelar]').forEach((b) => b.addEventListener('click', () => { s.editar = ''; ui.render(); }));
  qa('[data-baul-activar]').forEach((b) => b.addEventListener('click', () => accion(() => inv('baulActivarEnlace', { id: b.dataset.baulActivar, activo: b.dataset.activo === '1' }), b.dataset.activo === '1' ? 'Enlace activado' : 'Enlace desactivado')));
  qa('[data-baul-urltv]').forEach((b) => b.addEventListener('click', () => accion(() => inv('activarTvUrl', { proveedor: b.dataset.baulUrltv, activo: b.dataset.activo === '1' }), b.dataset.activo === '1' ? 'URL activada' : 'URL desactivada (clientes actuales intactos)')));
  qa('[data-baul-guardar]').forEach((b) => b.addEventListener('click', () => {
    const e = (s.data?.enlaces || []).find((x) => x.id === b.dataset.baulGuardar);
    if (!e) { s.error = 'Ese enlace ya no existe. Actualice.'; ui.render(); return; }
    accion(() => inv('baulGuardarEnlace', { enlace: { ...e, url: val('baulUrl').trim(), codigo: val('baulCodigo').trim(), nota: val('baulNota').trim() } }), 'Enlace guardado');
  }));
}
