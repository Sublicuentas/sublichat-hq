# src/app — módulos de la app (R74)

`main.js` era un solo archivo de 2,300+ líneas. Desde el R74 el núcleo y varias pantallas viven aquí:

| Archivo | Qué tiene |
|---|---|
| `core.js` | `state` (estado global), `ui.render`, `esc`, tema, permisos (`cap`), `allRows`, navegación (`navTabs`), `showToast`, datos base del CRM |
| `icons.js` | Íconos SVG, íconos de métricas y de la barra inferior |
| `frases.js` | Frase motivadora del día |
| `inicio.js` | Pantalla Inicio (tarjetas Hoy / Próximos / Vencidos) |
| `cobros.js` | Pantalla Cobros y hoja de Cobro y renovación |
| `avisos.js` | Recordatorios de cobro (notificaciones) y widget de la pantalla de inicio |

Reglas:
- Las pantallas importan de `core.js`; nunca de `main.js`.
- Para redibujar se usa `ui.render()` (main.js lo conecta al arrancar).
- Lo que sigue en `main.js` se irá moviendo aquí por pantalla en próximas entregas.
