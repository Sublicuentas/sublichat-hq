// R74 · Pantalla Inicio.
import { dashboardSummary, formatDateShort, roleLabel, roleModules } from '../data.js';
import { state, allRows, esc, avatarMarkup } from './core.js';
import { renewalGroups } from './cobros.js';
import { mottoHtml, dailyPhrase } from './frases.js';
import { metricIcon, metricWave, icon } from './icons.js';

export function syncPill() {
  const cfg = state.sync==='online' ? ['sync-ok',state.syncLabel||'Sincronizado'] : state.sync==='syncing' ? ['syncing','Actualizando…'] : state.sync==='partial' ? ['sync-warn',state.syncLabel||'Parcial'] : state.sync==='offline' ? ['sync-warn','Sin conexión'] : ['','Listo'];
  return `<span class="sync-pill ${cfg[0]}"><i></i>${cfg[1]}</span>`;
}
export function dashboardView() {
  const rows = allRows();
  const summary = dashboardSummary(rows, new Date());
  // R70: las tarjetas de Inicio abren Cobros → cuentan EXACTAMENTE lo mismo que Cobros (clientes por fecha, sin filtro de vendedor).
  { const keep=state.renewSeller; state.renewSeller=''; try { const g={hoy:renewalGroups('hoy'),proximo:renewalGroups('proximo'),vencidos:renewalGroups('vencidos')}; summary.hoy=g.hoy.length; summary.proximo={count:g.proximo.length,label:g.proximo.length?formatDateShort(g.proximo[0].fechaRenovacion):'—'}; summary.vencidos=g.vencidos.length; } finally { state.renewSeller=keep; } }
  const firstName = String(state.profile?.nombre || state.session?.usuario || 'Sublicuentas').split(/\s+/)[0];
  const tool=(tone,asset,open,title)=>`<button class="home-tool-card ${tone}" data-open="${open}" aria-label="${title}"><img class="home-card-art" src="/assets/${asset}" alt="${title}"></button>`;
  return `<section class="visual-home-hero">
      <div class="visual-home-brand"><img class="visual-brand-logo-mini" src="/assets/sublicuentas-logo-oficial.png" alt="Sublicuentas"><h1>Hola, ${esc(firstName)}</h1>${mottoHtml(dailyPhrase())}</div>
      <div class="visual-home-actions"><button class="visual-bell" data-open="tickets" aria-label="Tickets y avisos"><svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M24 8c-6.6 0-10.8 4.9-10.8 11v6.4L10 30.6v2.4h28v-2.4l-3.2-5.2V19c0-6.1-4.2-11-10.8-11Z" fill="#0d3ba6"/><path d="M20 34a4 4 0 0 0 8 0Z" fill="#0d3ba6"/><circle cx="35" cy="12" r="6" fill="#e2231a"/></svg></button><button class="avatar-btn" data-open="perfil">${avatarMarkup()}</button></div>
      <div class="visual-sync">${syncPill()}<span>${esc(roleLabel(state.session?.role, state.session?.usuario))}</span><b>›</b></div>
      <img class="visual-bot" src="/assets/sublirobot-oficial.png" alt="Sublibot">
    </section>
    <section class="visual-metrics">
      <button class="mcard mcard-today" data-renew-filter="hoy"><span class="mcard-icon">${metricIcon('calendar')}</span><span class="mcard-copy"><em>Vencen hoy</em><strong>${summary.hoy}</strong></span>${metricWave()}</button>
      <button class="mcard mcard-next" data-renew-filter="proximo"><span class="mcard-icon">${metricIcon('clock')}</span><span class="mcard-copy"><em>Próximos</em><small>${esc(summary.proximo.label)}</small><strong>${summary.proximo.count}</strong></span>${metricWave()}</button>
      <button class="mcard mcard-expired" data-renew-filter="vencidos"><span class="mcard-icon">${metricIcon('alert')}</span><span class="mcard-copy"><em>Vencidos</em><strong>${summary.vencidos}</strong></span>${metricWave()}</button>
    </section>
    <section class="visual-workspace">
      <div class="section-head"><div><p class="eyebrow">HERRAMIENTAS</p><h2>Su espacio de trabajo</h2></div><button class="icon-btn" id="refreshData" aria-label="Actualizar datos">${icon('refresh')}</button></div>
      <div class="visual-module-grid">
        ${roleModules(state.session?.role || '', state.session?.usuario || '').home.map(id=>({aula:['tool-aula','10_aula_de_clases.png','aula','Aula de clases'],finanzas:['tool-finance','11_control_financiero.png','finanzas','Control financiero'],materia:['tool-brain','12_materia_cerebral.png','materia','Materia cerebral'],clientes:['tool-clients','13_clientes.png','clientes','Clientes'],tickets:['tool-tickets','15_tickets_y_avisos.png','tickets','Tickets y avisos']}[id])).filter(Boolean).map(t=>tool(...t)).join('')}
      </div>
    </section>
    ${state.errors.clients?`<div class="error-box">${icon('alert',18)}<span>Clientes: ${esc(state.errors.clients)}</span></div>`:''}`;
}
