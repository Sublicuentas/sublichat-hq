// R74 · Pantalla Inicio.
import { dashboardSummary, formatDateShort, roleLabel, roleModules, roleCapabilities } from '../data.js';
import { MAS_MODULES } from '../screens.js';
import { state, allRows, esc, avatarMarkup } from './core.js';
import { renewalGroups } from './cobros.js';
import { mottoHtml, dailyPhrase } from './frases.js';
import { metricIcon, metricWave, icon } from './icons.js';

export function syncPill() {
  const cfg = state.sync==='online' ? ['sync-ok',state.syncLabel||'Sincronizado'] : state.sync==='syncing' ? ['syncing','Actualizando…'] : state.sync==='partial' ? ['sync-warn',state.syncLabel||'Parcial'] : state.sync==='offline' ? ['sync-warn','Sin conexión'] : ['','Listo'];
  return `<span class="sync-pill ${cfg[0]}"><i></i>${cfg[1]}</span>`;
}
export function dashboardView() {
  const rows = allRows();
  const summary = dashboardSummary(rows, new Date());
  // R70: las tarjetas de Inicio abren Cobros → cuentan EXACTAMENTE lo mismo que Cobros (clientes por fecha, sin filtro de vendedor).
  { const keep=state.renewSeller; state.renewSeller=''; try { const g={hoy:renewalGroups('hoy'),proximo:renewalGroups('proximo'),vencidos:renewalGroups('vencidos')}; summary.hoy=g.hoy.length; summary.proximo={count:g.proximo.length,label:g.proximo.length?formatDateShort(g.proximo[0].fechaRenovacion):'—'}; summary.vencidos=g.vencidos.length; } finally { state.renewSeller=keep; } }
  const firstName = saludoNombre(); // R196s
    return `<section class="visual-home-hero">
      <div class="visual-home-brand"><img class="visual-brand-logo-mini" src="/assets/sublicuentas-logo-oficial.png" alt="Sublicuentas"><h1>Hola, ${esc(firstName)}</h1>${mottoHtml(dailyPhrase())}</div>
      <div class="visual-home-actions"><button class="visual-bell" data-open="tickets" aria-label="Tickets y avisos"><svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M24 8c-6.6 0-10.8 4.9-10.8 11v6.4L10 30.6v2.4h28v-2.4l-3.2-5.2V19c0-6.1-4.2-11-10.8-11Z" fill="#0d3ba6"/><path d="M20 34a4 4 0 0 0 8 0Z" fill="#0d3ba6"/><circle cx="35" cy="12" r="6" fill="#e2231a"/></svg></button><button class="avatar-btn" data-open="perfil">${avatarMarkup()}</button></div>
      <div class="visual-sync">${syncPill()}<span>${esc(roleLabel(state.session?.role, state.session?.usuario))}</span><b>›</b></div>
      <img class="visual-bot" src="/assets/sublirobot-oficial.png" alt="Sublibot">
    </section>
    <section class="visual-metrics">
      <button class="mcard mcard-today" data-renew-filter="hoy"><span class="mcard-icon">${metricIcon('calendar')}</span><span class="mcard-copy"><em>Vencen hoy</em><strong>${summary.hoy}</strong></span>${metricWave()}</button>
      <button class="mcard mcard-next" data-renew-filter="proximo"><span class="mcard-icon">${metricIcon('clock')}</span><span class="mcard-copy"><em>Próximos</em>${summary.proximo.count&&summary.proximo.label&&summary.proximo.label!=='—'?`<small>${esc(summary.proximo.label)}</small>`:''}<strong>${summary.proximo.count}</strong></span>${metricWave()}</button>
      <button class="mcard mcard-expired" data-renew-filter="vencidos"><span class="mcard-icon">${metricIcon('alert')}</span><span class="mcard-copy"><em>Vencidos</em><strong>${summary.vencidos}</strong></span>${metricWave()}</button>
    </section>
    <section class="visual-workspace">
      <div class="section-head"><div><p class="eyebrow">HERRAMIENTAS</p><h2>Su espacio de trabajo</h2></div><button class="icon-btn" id="refreshData" aria-label="Actualizar datos">${icon('refresh')}</button></div>
      <div class="visual-module-grid home-v1-grid">${homeModules(state.session?.role || '', state.session?.usuario || '').map((id, i, all) => homeCard(id, all.length % 2 === 1 && i === all.length - 1)).join('')}</div>
    </section>
    ${state.errors.clients?`<div class="error-box">${icon('alert',18)}<span>Clientes: ${esc(state.errors.clients)}</span></div>`:''}`;
}

// R196s · Inicio «variante 1»: mismo diseño y Sublirobot para todos; las tarjetas salen SOLO de los accesos que ya tiene
// el usuario (roleModules/roleCapabilities, los mismos de Más y de la barra). Nada nuevo se concede aquí; el servidor
// vuelve a validar cada módulo. Orden aprobado: Sala de juntas · Control financiero · Control maestro · Clientes · Tickets.
const HOME_CARDS = {
  'sala-juntas': { t: 'Sala de juntas', s: 'Programa reuniones y convocatorias', tone: 'hv-blue' },
  finanzas: { t: 'Control financiero', s: 'Cobros, movimientos y reportes', img: '11_control_financiero.png', art: 1, tone: 'hv-yellow' },
  'control-maestro': { t: 'Control maestro', s: 'Cuentas y estado', img: 'mas/mas-control-maestro.png', tone: 'hv-lila' },
  clientes: { t: 'Clientes', s: 'Cartera y renovaciones', img: '13_clientes.png', art: 1, tone: 'hv-lila' },
  tickets: { t: 'Tickets y avisos', s: 'Soporte, novedades y comunicados', img: '15_tickets_y_avisos.png', art: 1, tone: 'hv-rosa' },
  aula: { t: 'Aula de clases', s: 'Formación y progreso', img: '10_aula_de_clases.png', art: 1, tone: 'hv-blue' },
  materia: { t: 'Materia cerebral', s: 'Juegos y ranking', img: '12_materia_cerebral.png', art: 1, tone: 'hv-rosa' },
};
export function homeModules(role = '', usuario = '') {
  const m = roleModules(role, usuario), caps = roleCapabilities(role, usuario);
  const tiene = (id) => m.tabs.includes(id) || m.more.includes(id) || (id === 'control-maestro' && caps.controlMaestro) || (id === 'finanzas' && caps.finanzas);
  const out = ['sala-juntas', 'finanzas', 'control-maestro', 'clientes', 'tickets'].filter(tiene);
  for (const extra of ['aula', 'materia']) if (out.length < 4 && tiene(extra)) out.push(extra); // sin huecos: solo accesos que ya tiene
  return out;
}
function homeCard(id, ancha) {
  const c = HOME_CARDS[id]; if (!c) return '';
  const ico = c.img ? `<img class="${c.art ? 'hv-art' : ''}" src="/assets/${c.img}" alt="" loading="lazy">` : (MAS_MODULES[id]?.svg || '');
  return `<button type="button" class="hv-card ${c.tone}${ancha ? ' wide' : ''}" data-open="${id}" aria-label="${esc(c.t)}"><span class="hv-ico">${ico}</span><span class="hv-txt"><b>${esc(c.t)}</b><small>${esc(c.s)}</small></span><span class="hv-chev" aria-hidden="true">›</span></button>`;
}
// R196s · «Hola, <nombre>»: las fundadoras siempre por su nombre de marca (nunca el nombre personal); los demás, su perfil.
function saludoNombre() {
  const marca = roleLabel(state.session?.role, state.session?.usuario);
  if (['Sublicuentas', 'Relojes'].includes(marca)) return marca;
  if (marca.startsWith('Geisell')) return 'Geisell';
  const n = String(state.profile?.nombre || state.session?.usuario || '').trim().split(/[\s._-]+/)[0] || 'equipo';
  return /^(naara|libni)$/i.test(n) ? 'Sublicuentas' : n.charAt(0).toUpperCase() + n.slice(1);
}
