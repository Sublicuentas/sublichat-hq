// R74 · Núcleo compartido de la app: estado global, utilidades y datos base.
// Todas las pantallas importan de aquí. `ui.render` lo conecta main.js al arrancar.
import { getSession } from '../api.js';
import { calcInitialState, loadCalcPrices } from '../calculadora.js';
import { roleCapabilities, operatorIdentity, serviceRowsFromClients, canonicalSeller, roleModules } from '../data.js';
import { icon } from './icons.js';
// main.js conecta estas funciones al arrancar (las pantallas en src/app/ no importan main.js).
export const ui = { render: () => {}, subPage: (t, s, c) => c, copy: () => {}, whatsapp: () => {}, openLink: () => {} };

export const BUILD_NUMBER = String(import.meta.env.VITE_BUILD_NUMBER || '1');
export const CRM_PLATFORMS = [
  ['netflix','Netflix Premium'], ['vipnetflix','⭐ Netflix Premium VIP'], ['disneyp','Disney Premium'], ['disneys','Disney Premium sin ESPN'],
  ['hbomax','HBO Max'], ['primevideo','Prime Video'], ['crunchyroll','Crunchyroll'], ['paramount','Paramount+'], ['vix','ViX+'],
  ['appletv','Apple TV'], ['universal','Universal+'], ['spotify','Spotify Premium'], ['youtube','YouTube Premium'], ['deezer','Deezer Premium HiFi'],
  ['canva','Canva · 1 mes'], ['gemini','Gemini Pro'], ['chatgpt','ChatGPT'], ['duolingo','Duolingo'], ['viki','Viki Rakuten'], ['office','Office 365'], ['office2021','Office 2021'], ['adobeexpress','Adobe Express'],
  ['windows10','Windows 10'], ['windows11','Windows 11'], ['eset','ESET NOD32 · 1 año / 1 dispositivo'], ['stellatv','Stella TV'], ['oleada','Oleada TV'],
  ['latintv','LatinTV'], ['liontv','LionTV'], ['evoutouch','Nanotech']
];
export const CRM_NO_PIN = new Set(['vipnetflix','spotify','deezer','youtube','office','paramount','vix','canva','gemini','chatgpt','duolingo','stellatv','oleada','latintv','liontv','evoutouch','evoutouch1','evoutouch2','evoutouch3','evoutouch4','viki','windows10','windows11','adobeexpress','eset']);
export const CRM_NO_PASSWORD = new Set(['canva','gemini','chatgpt','duolingo','adobeexpress']);
export const CRM_NO_EMAIL = new Set(['windows10','windows11','eset']);
export const CRM_DEVICE = new Set(['netflix','disneyp','disneys','hbomax','vix','universal','primevideo']);
// R53: la app arranca SIEMPRE en claro. Oscuro o "Predeterminado del sistema" solo si el usuario los elige
// en Perfil (antes el valor por defecto era "sistema" y en teléfonos en modo oscuro salía todo oscuro).
export function initialTheme() {
  try {
    if (localStorage.getItem('sublicuentas-theme-v2') !== '1') {
      const prev=localStorage.getItem('sublicuentas-theme');
      localStorage.setItem('sublicuentas-theme', prev==='dark'?'dark':'light');
      localStorage.setItem('sublicuentas-theme-v2','1');
    }
    const t=localStorage.getItem('sublicuentas-theme');
    return ['light','dark','system'].includes(t)?t:'light';
  } catch(_) { return 'light'; }
}
export const state = {
  active:'inicio',
  subview:null,
  theme:initialTheme(),
  session:getSession(),
  loading:false,
  sync:'idle',
  clients:[],
  inventory:[],
  finances:[],
  catalog:null,
  tickets:null,
  ticketsLoaded:false,
  ticketRecipients:[],
  ticketNoticeMode:'all',
  ticketNoticeDestinos:[],
  ticketImage:'',
  ticketNoticeImage:'',
  ticketReplyFor:'',
  ticketReplyImage:'',
  raffles:null,
  controlInventory:null,
  academia:null,
  academiaLesson:null,
  academiaCat:'Todos',
  academiaSel:{},
  academiaAvatar:null, academiaMascot:null, academiaSettings:false, aulaDraft:null, aulaSaving:false,
  clientFiltersOpen:true, clientSort:'recientes',
  subliCat:'', subliSugOffset:0, subliMenuOpen:false, moviesMenuOpen:false,
  rafflesTab:'sorteos', raffleStatus:null, raffleBusy:false,
  juegos:{screen:'hub', resumen:null, resumenError:'', rankingScope:'general', ranking:{}, rankingLoading:false, rankingError:'', gameCode:null, engine:null, timeLimitSec:0, deadlineAt:0, timeUp:false, paused:false, pausedRemaining:0, result:null},
  calc:calcInitialState(), calcPrices:loadCalcPrices(localStorage),
  ticketsTab:'avisos', ticketQuery:'', ticketStatusFilter:'', ticketFiltersOpen:false, ticketHistoryOpen:false, ticketExpanded:{}, ticketThreadOpen:{}, ticketDraft:{},
  invQuery:'', invPlat:'', invSort:'recientes', invCupo:'', invFiltersOpen:false,
  renewSeller:'', ticketsFetching:false, ticketsSig:'', ticketReplyText:'', backTo:'',
  movieQuery:'', movieResults:null, movieLoading:false, movieError:'',
  matchMode:'hoy', matchQuery:'', matches:null, matchMeta:null, matchLoading:false, matchError:'',
  subliMessages:[], subliLoading:false,
  finPeriod:'mes', finDesde:'', finHasta:'', finTipo:'todos', finShown:60, finBusy:false, finParsedFor:null, finParsed:[],
  profile:null,
  profileEditing:false,
  profileAvatarDraft:'',
  whatsappChooser:false, whatsappPickOnly:false,
  whatsappText:'',
  whatsappPhone:'',
  crmDraft:null,
  renewGroupKey:'',
  renewSelection:[],
  splash:true,
  renewManage:false,
  renewMessage:'',
  renewMessageVariant:0,
  renewMessageHistory:[],
  crmUrlVariant:0, crmSheet:'', crmClientQuery:'', crmFichaOpen:false, crmSaving:false,
  search:'',
  clientStatusFilter:'vigentes',
  clientSellerFilter:'',
  clientPlatformFilter:'',
  clientLimit:100,
  clientActionKey:'',
  clientActionMode:'menu',
  clientActionLink:'',
  clientActionUrlVariant:0,
  renewFilter:'hoy',
  selectedClientId:'',
  renewKey:'',
  toast:'',
  errors:{},
};
export function esc(value='') {
  return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
export const DARK_MQ = typeof window!=='undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
export function effectiveTheme() { return state.theme==='dark' || (state.theme==='system' && !!DARK_MQ?.matches) ? 'dark' : 'light'; }
export function applyTheme() {
  const root=document.documentElement; root.dataset.theme = state.theme;
  const dark=effectiveTheme()==='dark';
  root.classList.toggle('theme-dark', dark);
  const meta=document.querySelector('meta[name="theme-color"]'); if(meta)meta.setAttribute('content', dark?'#0b0d12':'#f7fbfe');
}
try { DARK_MQ?.addEventListener?.('change', ()=>{ if(state.theme==='system') applyTheme(); }); } catch(_) {}
export function cap() { return roleCapabilities(state.session?.role || '', state.session?.usuario || ''); }
export function todayISO() { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
export function todayDMY() { const [y,m,d]=todayISO().split('-'); return `${d}/${m}/${y}`; }
export function datePlusDaysDMY(days=30) { const d=new Date(); d.setHours(12,0,0,0); d.setDate(d.getDate()+Number(days||0)); return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`; }
export function crmSeller() { const id=operatorIdentity(state.session?.role || '', state.session?.usuario || ''); return id==='relojes' ? 'Relojes' : id==='sublicuentas' ? 'Sublicuentas' : ''; }
export function crmRuleKey(value='') { return String(value||'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,''); }
export function crmRules(value='') { const key=crmRuleKey(value); return { key, email:!CRM_NO_EMAIL.has(key), password:!CRM_NO_PASSWORD.has(key), pin:!CRM_NO_PIN.has(key), device:CRM_DEVICE.has(key) }; }
export function rowKey(row) { return `${row.clienteId}|${row.compraId || ''}|${row.servicioIndex}`; }
export function allRows() {
  const rows=serviceRowsFromClients(state.clients);
  const identity=operatorIdentity(state.session?.role || '', state.session?.usuario || '');
  return identity==='geisell' ? rows.filter(row=>canonicalSeller(row?.vendedor)==='geisell') : rows; // R69: incluye registros viejos "Geissel"
}
export function clientName(client) { return client?.nombrePerfil || client?.nombre || 'Cliente'; }
export function avatarMarkup() {
  const avatar = state.profile?.avatar || '';
  if (avatar) return `<img src="${esc(avatar)}" class="avatar-img" alt="Perfil">`;
  return `<div class="avatar-fallback">${icon('user',22)}</div>`;
}
export function showToast(message) {
  state.toast = message;
  ui.render();
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>{ state.toast=''; ui.render(); }, 3200);
}
export const NAV_META={inicio:['Inicio','home'],clientes:['Clientes','users'],cobros:['Cobros','renew'],tickets:['Tickets','ticket'],mas:['Más','more']};
export function navTabs() {
  return roleModules(state.session?.role || '', state.session?.usuario || '').tabs.map(id=>[id,...NAV_META[id]]);
}
export function hasCobrosTab() { return navTabs().some(t=>t[0]==='cobros'); }
