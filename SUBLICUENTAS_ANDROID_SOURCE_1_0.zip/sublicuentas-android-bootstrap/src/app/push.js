// Fase 2 · Oct-2026 · Notificaciones push (FCM) con @capacitor/push-notifications.
// - Solo se activa si la APK se compiló con google-services.json (VITE_PUSH_ENABLED=1 lo pone el workflow
//   cuando existe el secreto GOOGLE_SERVICES_JSON). Sin eso, Firebase no está inicializado y register()
//   cerraría la app: por eso no se llama.
// - Pide permiso (Android 13+), registra el token DESPUÉS del login y lo guarda en el backend por
//   usuario/dispositivo (/api/mobile-core · action:'push'). Al cerrar sesión se da de baja.
// - El aviso NUNCA trae correos, claves ni PIN: solo título, texto corto y a dónde abrir.
// - Los recordatorios de cobro (7 AM / 7 PM) siguen siendo locales (recordatorios.js): no se duplica.
// Sin imports de la app: así se puede probar sola (la sesión llega por getSession).

export const PUSH_CHANNEL = 'sublichat_avisos';
const TOKEN_KEY = 'sublichat-push-token-v1';
const PUSH = { listo: false, usuario: '', estado: 'apagado', authPost: null, prefSig: '' };

export function pushHabilitado() {
  try { return String(import.meta.env?.VITE_PUSH_ENABLED || '') === '1'; } catch (_) { return false; }
}
// Igual que notificationsPlugin(): el plugin se devuelve envuelto ({ PN }), nunca suelto desde un async.
async function pushPlugin() {
  if (!pushHabilitado()) return null;
  try {
    const { Capacitor } = await import('@capacitor/core');
    if (!Capacitor?.isNativePlatform?.()) return null;
    const m = await import('@capacitor/push-notifications');
    return m.PushNotifications ? { PN: m.PushNotifications } : null;
  } catch (_) { return null; }
}
function guardarToken(t) { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch (_) {} }
function tokenGuardado() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (_) { return ''; } }
export function pushEstado() { return PUSH.estado; }
// Teléfono con push activo (también al abrir la app antes de que termine de registrarse): el aviso de cobros
// 7 AM / 7 PM llega del servidor y la APK NO programa el suyo, para que no lleguen dos.
export function pushActivo() { return pushHabilitado() && (PUSH.estado === 'activo' || !!tokenGuardado()); }
// Interruptor "Recordatorios de cobro": se guarda en el servidor para este teléfono.
export async function pushPreferencias(pref = {}) {
  const token = tokenGuardado();
  if (!PUSH.authPost || !token) return;
  const sig = JSON.stringify(pref);
  if (sig === PUSH.prefSig) return;
  PUSH.prefSig = sig;
  try { await PUSH.authPost('/api/mobile-core', { action: 'push', op: 'preferencias', token, ...pref }); } catch (_) { PUSH.prefSig = ''; }
}

// Se llama cada vez que hay sesión (después del login y al abrir la app). Es idempotente.
export async function pushIniciar({ authPost, getSession = () => null, appBuild = '', onAbrir = () => {}, onAviso = () => {}, onActivo = () => {}, preferencias = () => ({}) } = {}) {
  PUSH.authPost = authPost;
  const usuario = String(getSession()?.usuario || '');
  if (!usuario) return;
  const PN = (await pushPlugin())?.PN;
  if (!PN) { PUSH.estado = pushHabilitado() ? 'web' : 'apagado'; return; }
  if (!PUSH.listo) {
    PUSH.listo = true;
    try { await PN.createChannel({ id: PUSH_CHANNEL, name: 'Avisos de Sublichat', description: 'Tickets, avisos y cambios importantes', importance: 4, visibility: 1, vibration: true }); } catch (_) {}
    PN.addListener('registration', async (ev) => {
      const token = String(ev?.value || '');
      const ses = getSession();
      if (!token || !ses?.usuario) return;
      try {
        const pref = preferencias() || {};
        await authPost('/api/mobile-core', { action: 'push', op: 'registrar', token, appBuild: String(appBuild || ''), ...pref });
        guardarToken(token); PUSH.estado = 'activo'; PUSH.usuario = String(ses.usuario); PUSH.prefSig = JSON.stringify(pref);
        try { onActivo(); } catch (_) {}
      } catch (_) { PUSH.estado = 'error'; }
    });
    PN.addListener('registrationError', () => { PUSH.estado = 'error'; });
    // App abierta: se muestra como aviso dentro de la app (Android no la pinta solo en primer plano).
    PN.addListener('pushNotificationReceived', (n) => { try { onAviso(n?.title || 'Sublichat', n?.body || '', n?.data || {}); } catch (_) {} });
    // App cerrada o en segundo plano: al tocar la notificación se abre donde corresponde.
    PN.addListener('pushNotificationActionPerformed', (a) => { try { onAbrir(a?.notification?.data || {}); } catch (_) {} });
  }
  if (PUSH.usuario === usuario && PUSH.estado === 'activo') return;
  let perm = await PN.checkPermissions().catch(() => ({ receive: 'denied' }));
  if (perm.receive === 'prompt' || perm.receive === 'prompt-with-rationale') perm = await PN.requestPermissions().catch(() => ({ receive: 'denied' }));
  if (perm.receive !== 'granted') { PUSH.estado = 'sin-permiso'; return; }
  await PN.register().catch(() => { PUSH.estado = 'error'; });
}

// Cerrar sesión: el backend borra el token de este teléfono (ya no le llegan avisos de ese usuario).
// Se usa el idToken que todavía está en memoria porque la sesión se borra enseguida.
export function pushBaja({ apiBase = '', session = null } = {}) {
  const token = tokenGuardado();
  guardarToken('');
  PUSH.usuario = ''; PUSH.estado = 'apagado';
  if (!token || !session?.idToken) return;
  try {
    fetch(`${apiBase}/api/mobile-core`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.idToken}` }, body: JSON.stringify({ action: 'push', op: 'baja', token }) }).catch(() => {});
  } catch (_) {}
}

// A dónde lleva una notificación al tocarla (solo destinos conocidos).
export function pushDestino(data = {}) {
  const ir = String(data.ir || '');
  if (ir === 'tickets') return { active: 'mas', subview: 'tickets', ticketsTab: data.tab === 'tickets' ? 'tickets' : 'avisos' };
  if (ir === 'clientes') return { active: 'clientes', subview: null };
  if (ir === 'renovar') return { active: 'renovar', subview: null, renewFilter: ['hoy', 'proximo', 'vencidos'].includes(data.tab) ? data.tab : 'hoy' };
  return { active: 'inicio', subview: null };
}
