// src/app/entrega-plataforma.js = COPIA FIEL (ESM) de Sublichat HQ api/_entrega-plataforma.js · R188
// (Gemini / Duolingo / ChatGPT) y dispositivo POR SERVICIO. Configuración central y VERSIONADA: Web, URL del cliente, APK y bot
// leen de aquí (copias fieles: bot lib_entrega_plataforma.js, APK src/app/entrega-plataforma.js). Un aviso se busca por la
// plataforma EXACTA (clave canónica): nunca se hereda a otra app (HBO ≠ Netflix ≠ Prime).
// CommonJS a propósito (igual que _tv-digital.js).

const VERSION = "2026-11-15.1"; // R196u · AutoCAD (invitación) y Eleven Reader (correo + contraseña)

// Avisos que van en la ficha Y en la URL personalizada.
const AVISOS = Object.freeze({
  netflix: [{ id: "netflix_hogar_15", destacado: false, titulo: "Aviso de sistema · Netflix",
    texto: "Es posible que en 15 días o más el sistema solicite un código temporal de hogar. Cuando le aparezca, notifíquenos y se lo daremos al instante." }],
  hbomax: [{ id: "hbo_codigo_hogar", destacado: false, titulo: "Código de hogar · HBO Max",
    texto: "HBO Max puede pedir un código de hogar en cualquier momento, incluso apenas inicie sesión. Si le aparece, escríbanos y le ayudamos a ingresarlo." }],
  primevideo: [{ id: "prime_solo_app", destacado: true, titulo: "Importante",
    texto: "Solo disponible para la aplicación Prime Video. Prohibido ingresar en Amazon." }],
  // R196u · AutoCAD se entrega por INVITACIÓN al correo del cliente (no es un código KEY).
  autocad: [{ id: "autocad_invitacion", destacado: false, titulo: "Cómo activar Autodesk AutoCAD",
    texto: "1) Abra el correo de invitación de Autodesk que llegó al correo indicado (revise también Spam o Promociones).\n2) Toque «Aceptar invitación».\n3) Inicie sesión en Autodesk con ese mismo correo (si no tiene cuenta, créela con ese correo).\n4) Descargue AutoCAD desde su cuenta Autodesk. Si no le llegó la invitación, escríbanos." }],
});

function norm(v) { return String(v == null ? "" : v).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]/g, ""); }
// Clave canónica SOLO para avisos/modalidad (no reemplaza a canonPlat de cada sistema).
function clavePlataforma(plataforma) {
  const p = norm(plataforma);
  if (!p) return "";
  if (p.includes("netflix") && p.includes("vip")) return "vipnetflix";
  if (p === "vipnetflix" || p.startsWith("netflix")) return p === "vipnetflix" ? "vipnetflix" : "netflix";
  if (p.startsWith("hbo") || p === "max") return "hbomax";
  if (p.startsWith("prime") || p === "amazonprime") return "primevideo";
  if (p.startsWith("crunchy")) return "crunchyroll";
  if (p.startsWith("gemini")) return "gemini";
  if (p.startsWith("duolingo")) return "duolingo";
  if (p.startsWith("chatgpt")) return "chatgpt";
  if (p.includes("autocad") || p.startsWith("autodesk")) return "autocad"; // R196u
  if (p.startsWith("eleven")) return "elevenreader"; // R196u
  return p;
}
function avisosPara(plataforma) { return (AVISOS[clavePlataforma(plataforma)] || []).map((a) => ({ ...a, version: VERSION })); }
// Texto para fichas de WhatsApp (Markdown de WhatsApp: *negrita*).
function avisosTexto(plataforma) {
  return avisosPara(plataforma).map((a) => a.destacado ? `*⚠️ ${a.titulo}: ${a.texto}*` : `⚠️ ${a.titulo}:\n${a.texto}`).join("\n\n");
}

// ── Modalidad de acceso ──
//   ChatGPT: cuenta entregada por Sublicuentas → correo + contraseña.
//   Gemini / Duolingo: «proveedor» (cuenta de Sublicuentas: correo + contraseña) o «correo_cliente» (correo propio del cliente:
//   la contraseña NO se pide, NO se guarda y NO se muestra). Registros anteriores sin modalidad = correo del cliente (como hasta hoy).
const MODALIDADES = Object.freeze({ proveedor: "Cuenta entregada por Sublicuentas", correo_cliente: "Correo propio del cliente" });
function usaModalidad(plataforma) { return ["gemini", "duolingo"].includes(clavePlataforma(plataforma)); }
function modalidadAcceso(plataforma, servicio = {}) {
  const k = clavePlataforma(plataforma);
  if (k === "chatgpt") return "proveedor";
  if (k === "gemini" || k === "duolingo") return servicio && servicio.modalidadAcceso === "proveedor" ? "proveedor" : "correo_cliente";
  return "";
}
// true/false = esta regla manda; null = sigue la regla de siempre de cada sistema.
function claveSegunModalidad(plataforma, servicio = {}) {
  const m = modalidadAcceso(plataforma, servicio);
  if (m === "proveedor") return true;
  if (m === "correo_cliente") return false;
  return null;
}

// ── R196u · Productos nuevos (PDF v2.0 · 07) ──
//   AutoCAD (Software): entrega por INVITACIÓN al correo del cliente. Correo obligatorio; contraseña OPCIONAL: no se pide, solo
//   se guarda y se muestra si Sublicuentas de verdad entrega credenciales además de la invitación.
//   Eleven Reader (Música): correo + contraseña, ambos en la ficha. Sin PIN. Sin proveedor ni costo fijo inventado.
const ESTADOS_INVITACION = Object.freeze({ pendiente: "Pendiente de enviar", enviada: "Invitación enviada", aceptada: "Invitación aceptada" });
function entregaPorInvitacion(plataforma) { return clavePlataforma(plataforma) === "autocad"; }
function claveOpcional(plataforma) { return clavePlataforma(plataforma) === "autocad"; }
function estadoInvitacion(servicio = {}) { const e = String((servicio && servicio.estadoInvitacion) || ""); return ESTADOS_INVITACION[e] ? e : "pendiente"; } // sin dato = pendiente (no se afirma que ya se envió)
function estadoInvitacionTexto(servicio = {}) { return ESTADOS_INVITACION[estadoInvitacion(servicio)]; }
// Líneas de la ficha de entrega de AutoCAD (WhatsApp). La contraseña solo aparece si está registrada.
function fichaInvitacionLineas(servicio = {}, { markdown = true } = {}) {
  const b = (t) => (markdown ? `*${t}*` : t);
  const correo = String(servicio.correo || servicio.email || "").trim();
  const clave = String(servicio.clave || "").trim();
  const e = String((servicio && servicio.estadoInvitacion) || "");
  return [
    `📧 ${b("Correo invitado:")} ${correo || "—"}`,
    ...(ESTADOS_INVITACION[e] ? [`📌 ${b("Estado:")} ${ESTADOS_INVITACION[e]}`] : []),
    ...(clave ? [`🔑 ${b("Contraseña:")} ${clave}`] : []),
  ];
}

// ── Dispositivo por SERVICIO ──
const EQUIPOS = Object.freeze({
  android_tv: "Android TV / TV Box", fire_tv: "Fire TV / Fire Stick", android_movil: "Celular / tableta Android",
  smart_tv: "Smart TV Samsung / LG", iphone: "iPhone / iPad", pc: "PC / Laptop",
});
const FAMILIA_TV = [["stellatv", "stellatv"], ["stella", "stellatv"], ["oleada", "oleada"], ["latintv", "latintv"], ["liontv", "liontv"], ["evoutouch", "evoutouch"], ["nanotech", "evoutouch"], ["icomplay", "icomplay"]];
function familiaTv(plataforma) { const p = norm(plataforma); const f = FAMILIA_TV.find(([pre]) => p.startsWith(pre)); return f ? f[1] : ""; }
// Equipos permitidos para una plataforma de TV Digital = los que tienen al menos un enlace ACTIVO en el Baúl (no se inventan).
function equiposPermitidos(plataforma, baulVistas = null) {
  const fam = familiaTv(plataforma); if (!fam) return [];
  const vista = Array.isArray(baulVistas) ? baulVistas.find((v) => v && v.plataforma === fam) : null;
  if (vista) return (vista.dispositivos || []).filter((d) => (d.enlaces || []).length && EQUIPOS[d.id]).map((d) => d.id);
  return Object.keys(EQUIPOS).filter((k) => !(fam === "stellatv" && ["iphone", "pc"].includes(k)));
}
// Normaliza lo que llega al guardar: "" (sin elegir) o un id permitido; cualquier otro valor es error (no se adivina).
function validarEquipoTv(plataforma, valor, baulVistas = null) {
  const v = String(valor == null ? "" : valor).trim();
  if (!v) return "";
  if (!familiaTv(plataforma)) return "";
  if (!equiposPermitidos(plataforma, baulVistas).includes(v)) throw new Error(`Ese dispositivo no está disponible para esta plataforma: ${EQUIPOS[v] || v}.`);
  return v;
}
// Lo que se muestra como «Dispositivo registrado» (ficha y URL). Siempre del SERVICIO (o del perfil), nunca del cliente global.
function etiquetaDispositivo(servicio = {}, perfil = null) {
  const fam = familiaTv(servicio.plataforma);
  if (fam) return EQUIPOS[servicio.equipoTv] || "Pendiente de seleccionar";
  const k = clavePlataforma(servicio.plataforma);
  if (!["netflix", "disneyp", "disneys", "hbomax", "vix", "universal", "primevideo"].includes(k) && !/^disney/.test(k)) return "";
  const d = String((perfil && perfil.dispositivo != null && perfil.dispositivo !== "" ? perfil.dispositivo : servicio.dispositivo) || "");
  const roku = d === "tv" && ((perfil && perfil.esRoku === true) || (!perfil && servicio.esRoku === true));
  return d === "tv" ? (roku ? "TV (Roku)" : "TV") : d === "cel" ? "Celular" : "Pendiente de seleccionar";
}

export { VERSION, AVISOS, MODALIDADES, EQUIPOS, clavePlataforma, avisosPara, avisosTexto, usaModalidad, modalidadAcceso, claveSegunModalidad, familiaTv, equiposPermitidos, validarEquipoTv, etiquetaDispositivo, ESTADOS_INVITACION, entregaPorInvitacion, claveOpcional, estadoInvitacion, estadoInvitacionTexto, fichaInvitacionLineas };
