// R101 · MODO SIN CONEXIÓN (solo Sublicuentas y Relojes)
// 1) Copia COMPLETA cifrada: clientes, inventario (con claves), finanzas y perfil.
//    Va cifrada con AES-GCM 256; la llave vive en el Android Keystore (almacén seguro de R69),
//    nunca en localStorage. El caché normal de R69 (sin secretos) sigue igual para todos.
// 2) Cola de cambios: fichas (venta/perfil), renovaciones con su cobro y egresos hechos sin señal
//    quedan en cola cifrada y se suben solos, en orden, al volver la conexión.
//    Cada cambio lleva su operationId fijo: el servidor nunca lo aplica dos veces.
// Cerrar sesión borra la copia, la cola y la llave.
import { secureStore, isNetworkError as apiNetErr } from '../api.js';
import { operatorIdentity } from '../data.js';

const DB_NAME = 'sublicuentas-offline-r101';
const STORE = 'vault';
const KEY_NAME = 'offline_key_v1';
const ALLOWED = new Set(['sublicuentas', 'relojes']);

let keyPromise = null;
const enc = new TextEncoder();
const dec = new TextDecoder();
const norm = (u = '') => String(u || '').trim().toLowerCase();

export function offlineAllowed(session) {
  return !!session && ALLOWED.has(operatorIdentity(session.role || '', session.usuario || ''));
}
export function offlineSupported() {
  return typeof indexedDB !== 'undefined' && !!globalThis.crypto?.subtle;
}

function b64(buf) { const b = new Uint8Array(buf); let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s); }
function unb64(str = '') { const s = atob(str); const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; }

function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => { if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idb(mode, fn) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode); const req = fn(tx.objectStore(STORE));
      tx.oncomplete = () => resolve(req?.result); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
    });
  } finally { db.close(); }
}

// Llave AES en el Keystore. Si no existe, se crea una sola vez.
async function getKey() {
  if (!keyPromise) keyPromise = (async () => {
    const st = await secureStore();
    let raw = await st.get(KEY_NAME);
    if (!raw) { raw = b64(crypto.getRandomValues(new Uint8Array(32))); await st.set(KEY_NAME, raw); }
    return crypto.subtle.importKey('raw', unb64(raw), { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']);
  })().catch((e) => { keyPromise = null; throw e; });
  return keyPromise;
}
async function seal(obj) {
  const key = await getKey(); const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj)));
  return { iv: b64(iv), ct: b64(ct), at: Date.now() };
}
async function open(box) {
  if (!box?.iv || !box?.ct) return null;
  const key = await getKey();
  return JSON.parse(dec.decode(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(box.iv) }, key, unb64(box.ct))));
}

export async function saveSnapshot(usuario, data) {
  if (!offlineSupported()) return false;
  const box = await seal({ ...data, usuario: norm(usuario) });
  await idb('readwrite', (s) => s.put(box, `snap:${norm(usuario)}`));
  return true;
}
export async function loadSnapshot(usuario) {
  if (!offlineSupported()) return null;
  try {
    const box = await idb('readonly', (s) => s.get(`snap:${norm(usuario)}`));
    const data = await open(box);
    return data && data.usuario === norm(usuario) ? data : null;
  } catch (_) { return null; }
}
export async function saveQueue(usuario, items = []) {
  if (!offlineSupported()) return false;
  const box = await seal({ items });
  await idb('readwrite', (s) => s.put(box, `queue:${norm(usuario)}`));
  return true;
}
export async function loadQueue(usuario) {
  if (!offlineSupported()) return [];
  try {
    const data = await open(await idb('readonly', (s) => s.get(`queue:${norm(usuario)}`)));
    return Array.isArray(data?.items) ? data.items : [];
  } catch (_) { return []; }
}
// Cerrar sesión: se borra copia, cola y llave (sin la llave, lo cifrado ya no se puede abrir).
export async function wipeOffline() {
  keyPromise = null;
  try { const st = await secureStore(); await st.remove(KEY_NAME); } catch (_) {}
  try { await new Promise((res) => { const r = indexedDB.deleteDatabase(DB_NAME); r.onsuccess = r.onerror = r.onblocked = () => res(); }); } catch (_) {}
}

// Error de red real (sin señal / servidor inalcanzable), no un rechazo del servidor.
export function isOfflineError(e) {
  if (!e) return false;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return true;
  if (apiNetErr(e)) return true;
  if (e?.status) return [502, 503, 504].includes(Number(e.status));
  return /unable to resolve|unknownhost|unreachable|host|socket|sin conexi|internet|offline|abort/i.test(String(e?.message || ''));
}
