// R196v · Netflix Hogar EN VIVO en la APK (PDF «Netflix Hogar y HBO Standard/Platinum» · 01/02/14).
// Al abrir el detalle de una cuenta madre se pregunta al servidor (misma consulta que Web y Telegram). Si cambió, se corrige
// también la copia local para que la lista y el cliente no vuelvan a mostrar el dato anterior. Sin red: «sin confirmar».
import { loadHogar } from '../api.js';
import { hogarConsultaVista } from '../screens2.js';

export async function refrescarHogarDetalle(host, d, state) {
  const id = String(d.raw.id || d.id || '');
  const tx = host.querySelector('[data-hogar-texto]'), nt = host.querySelector('[data-hogar-nota]');
  try {
    const r = await loadHogar(id); const v = hogarConsultaVista(r);
    if (r && r.ok !== false && r.aplica !== false) { const it = (state.inventory || []).find((x) => String(x.id) === id); if (it) { if (r.hogarDoc) it.hogar = r.hogarDoc; else delete it.hogar; } }
    if (tx && v.texto) tx.textContent = v.texto;
    if (nt) { nt.textContent = v.nota; nt.classList.toggle('warn', !!v.incidencia); }
  } catch (e) {
    const v = hogarConsultaVista(null, String(e?.message || e));
    if (nt) { nt.textContent = v.nota; nt.classList.add('warn'); }
  }
}
