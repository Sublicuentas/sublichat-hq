// R210 · Finanzas › Pendientes: pago individual o masivo con FECHA REAL, conciliación con pagos ya registrados y
// vista previa (solo lectura) por vendedor y período de origen, incluida la regla del 50 % de Geisell.
// Nada se aplica sin confirmación; el servidor valida permisos, saldos, duplicados y lo hace en una transacción.
import { money } from './finanzas-reglas.js';

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const lps = (n) => { const v = money(n); return `L${v.toLocaleString('en-US', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 })}`; };
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
export function periodoDe(c) { const m = String(c.fechaOperacion || c.fechaPago || c.createdAt || '').match(/^(\d{4})-(\d{2})/); return m ? `${m[1]}-${m[2]}` : ''; }
export const periodoTxt = (p) => { const [y, m] = String(p).split('-'); return y && m ? `${MESES[+m - 1]} ${y}` : 'sin fecha'; };
const hoyHN = () => new Date().toLocaleDateString('en-CA', { timeZone: 'America/Tegucigalpa' });

export function seleccion(L) { if (!L.sel) L.sel = {}; const rows = (L.pend?.rows || []).filter((c) => L.sel[c.id]); return { rows, total: money(rows.reduce((a, c) => a + money(c.saldoPendiente), 0)) }; }

// Casilla por obligación (se pinta dentro de cada tarjeta de Pendientes)
export function casilla(L, c) { return `<label class="fl-sel"><input type="checkbox" data-fl-sel="${esc(c.id)}" ${L.sel?.[c.id] ? 'checked' : ''} aria-label="Seleccionar"><span>${esc(periodoTxt(periodoDe(c)))}</span></label>`; }

// Filtro por período de origen (sobre lo ya cargado)
export function filtroPeriodo(L) {
  const ps = [...new Set((L.pend?.rows || []).map(periodoDe).filter(Boolean))].sort();
  if (ps.length < 2) return '';
  return `<div class="fl-chips">${[''].concat(ps).map((p) => `<button class="fl-chip ${(L.pendPeriodo || '') === p ? 'on' : ''}" data-fl-per="${esc(p)}">${p ? esc(periodoTxt(p)) : 'Todos los meses'}</button>`).join('')}</div>`;
}

export function masivoHtml(L, d) {
  const { rows, total } = seleccion(L), M = L.masivo;
  let h = '';
  if (rows.length && !M) h += `<div class="fl-selbar"><span><b>${rows.length}</b> seleccionada${rows.length === 1 ? '' : 's'} · <b>${lps(total)}</b></span><button class="fl-btn" data-fl-mas-abrir>${rows.length > 1 ? 'Registrar pago masivo' : 'Registrar pago'}</button><button class="fl-btn ghost" data-fl-mas-limpiar>Quitar</button></div>`;
  if (M && !M.resultado) {
    const deudores = new Set(rows.map((c) => `${c.deudorTipo}|${c.deudorNombre}`));
    const cand = (M.previa?.grupos || []).flatMap((g) => g.posiblesPagos || []);
    h += `<section class="fl-card fl-masivo"><b>${rows.length > 1 ? 'Pago masivo' : 'Registrar pago'} · ${esc(rows[0]?.deudorNombre || '')}</b>
      ${deudores.size > 1 ? '<p class="fl-err">Elija obligaciones de un solo cliente o vendedor por pago.</p>' : ''}
      <p class="fl-muted">${rows.length} obligación(es) · ${[...new Set(rows.map((c) => periodoTxt(periodoDe(c))))].join(', ')} · seleccionado ${lps(total)}</p>
      <label class="fl-label">Fecha REAL del pago<input class="fl-input" type="date" id="flMasF" value="${esc(M.fecha || hoyHN())}" max="${hoyHN()}"></label>
      <label class="fl-label">Importe recibido<input class="fl-input" type="number" inputmode="decimal" id="flMasM" value="${esc(M.monto ?? total)}" min="0" max="${total}"></label>
      <div class="fl-seg"><button class="${M.modo !== 'vincular' ? 'on' : ''}" data-fl-mas-modo="nuevo">Entró a un banco</button><button class="${M.modo === 'vincular' ? 'on' : ''}" data-fl-mas-modo="vincular">Ya está registrado</button></div>
      ${M.modo === 'vincular'
        ? (M.cargandoPrevia ? '<p class="fl-muted"><span class="spinner"></span> Buscando pagos ya registrados…</p>' : cand.length ? `<p class="fl-muted">Se vincula al movimiento existente: NO se crea otro ingreso.</p><div class="fl-chips">${cand.map((m) => `<button class="fl-chip ${M.vincular === m.movimientoId ? 'on' : ''}" data-fl-mas-vinc="${esc(m.movimientoId)}">${esc(m.fecha)} · ${lps(m.monto)}${m.banco ? ' · ' + esc(m.banco) : ''}</button>`).join('')}</div>` : '<p class="fl-muted">No se encontró un pago registrado sin vincular para este deudor. Use «Entró a un banco».</p>')
        : `<div class="fl-chips">${(d.metodos || []).map((m) => `<button class="fl-chip ${M.bancoId === m.id ? 'on' : ''}" data-fl-mas-banco="${esc(m.id)}">${esc(m.nombre)}</button>`).join('')}</div>`}
      <label class="fl-label">Referencia (opcional)<input class="fl-input" id="flMasR" value="${esc(M.referencia || '')}" maxlength="80"></label>
      <label class="fl-label">Observaciones (opcional)<input class="fl-input" id="flMasO" value="${esc(M.obs || '')}" maxlength="300"></label>
      <p class="fl-muted">Se aplica a lo más antiguo primero. Si el importe es menor, el resto queda pendiente. La fecha del registro no reemplaza la fecha real.</p>
      <div class="fl-inline"><button class="fl-btn" data-fl-mas-ok ${L.sending || deudores.size > 1 ? 'disabled' : ''}>Confirmar pago</button><button class="fl-btn ghost" data-fl-mas-cancel>Cancelar</button></div></section>`;
  }
  if (M?.resultado) {
    const r = M.resultado;
    h += `<section class="fl-card fl-masivo ok"><b>✅ ${r.duplicado ? 'Ese pago ya estaba registrado (no se repitió).' : r.vinculado ? 'Pago conciliado con el movimiento existente' : 'Pago registrado'}</b>
      <p class="fl-muted">${lps(r.monto)} · pago real ${esc(r.fechaPagoEfectiva || '')}${r.parcial ? ' · pago parcial' : ''}</p>
      ${(r.resultados || []).map((x) => `<div class="fl-row"><span>${esc(periodoTxt(x.periodo))} · ${lps(x.antes)} → ${lps(x.queda)}</span><i class="fl-pill ${x.queda <= 0 ? '' : 'warn'}">${esc(x.aplica > 0 ? (x.queda <= 0 ? 'pagado' : 'parcial') : 'sin cambio')}</i></div>`).join('')}
      <button class="fl-btn ghost" data-fl-mas-cerrar>Listo</button></section>`;
  }
  return h;
}

// Vista previa SOLO LECTURA (administración): por vendedor y período + regla del 50 % de Geisell
export function previaHtml(L) {
  const V = L.previa;
  if (!V) return '<button class="fl-btn ghost" data-fl-previa>Vista previa de obligaciones (solo lectura)</button>';
  if (V.cargando) return '<p class="fl-muted"><span class="spinner"></span> Armando la vista previa…</p>';
  if (V.error) return `<div class="fl-err">${esc(V.error)} <button class="fl-btn ghost" data-fl-previa>Reintentar</button></div>`;
  const grupos = (V.grupos || []).map((g) => `<div class="fl-bankcard"><div class="fl-row"><b>${g.deudorTipo === 'vendedor' ? '🧑‍💼' : '👤'} ${esc(g.deudorNombre)}</b><b class="fl-neg">${lps(g.total)}</b></div>
    ${g.periodos.map((p) => `<small class="fl-muted">${esc(periodoTxt(p.periodo))}: ${p.cuentas.length} obligación(es) · ${lps(p.total)}</small>`).join('<br>')}
    ${g.posiblesPagos.length ? `<p class="fl-warn">Posibles pagos ya registrados sin vincular: ${g.posiblesPagos.map((m) => `${esc(m.fecha)} ${lps(m.monto)}`).join(' · ')}. Concílielos con «Ya está registrado»; no se suman otra vez.</p>` : ''}</div>`).join('');
  const G = V.geisell;
  const gei = G && G.filas.length ? `<section class="fl-card"><b>Regla del 50 % de Geisell · VISTA PREVIA</b><p class="fl-muted">No cambia ningún saldo. Obligación = base × 50 %; pendiente = obligación − pagos (nunca negativo). Los registros que ya están al 50 % no se dividen otra vez.</p>
    <div class="fl-row"><span>Base elegible</span><b>${lps(G.totales.base)}</b></div><div class="fl-row"><span>Obligación 50 %</span><b>${lps(G.totales.obligacion)}</b></div><div class="fl-row"><span>Pagos aplicados</span><b>${lps(G.totales.pagado)}</b></div>
    <div class="fl-row"><span>Saldo actual</span><b>${lps(G.totales.saldoActual)}</b></div><div class="fl-row"><span>Saldo con la regla</span><b class="fl-neg">${lps(G.totales.saldoPropuesto)}</b></div>
    <p class="fl-warn">Para aplicarla falta que Sublicuentas confirme:<br>${G.preguntas.map((q) => '• ' + esc(q)).join('<br>')}</p></section>` : '';
  return `<section class="fl-card"><div class="fl-row"><b>Vista previa (solo lectura)</b><b>${lps(V.total)}</b></div>${grupos || '<p class="fl-muted">Sin obligaciones pendientes.</p>'}<button class="fl-btn ghost" data-fl-previa-cerrar>Cerrar vista previa</button></section>${gei}`;
}

export function bindMasivo(root, ctx, L, { post, recargar }) {
  const q = (s) => root.querySelector(s), qa = (s) => root.querySelectorAll(s);
  const guardar = () => { const M = L.masivo; if (!M) return; M.fecha = q('#flMasF')?.value || M.fecha; const mv = q('#flMasM')?.value; if (mv != null) M.monto = mv; M.referencia = q('#flMasR')?.value ?? M.referencia; M.obs = q('#flMasO')?.value ?? M.obs; };
  qa('[data-fl-sel]').forEach((b) => b.addEventListener('change', () => { L.sel = L.sel || {}; L.sel[b.dataset.flSel] = b.checked; ctx.render(); }));
  qa('[data-fl-per]').forEach((b) => b.addEventListener('click', () => { L.pendPeriodo = b.dataset.flPer; ctx.render(); }));
  q('[data-fl-mas-limpiar]')?.addEventListener('click', () => { L.sel = {}; ctx.render(); });
  q('[data-fl-mas-abrir]')?.addEventListener('click', () => { L.masivo = { opId: ctx.newOperationId(), modo: 'nuevo', bancoId: '', fecha: hoyHN() }; ctx.render(); });
  q('[data-fl-mas-cancel]')?.addEventListener('click', () => { L.masivo = null; ctx.render(); });
  q('[data-fl-mas-cerrar]')?.addEventListener('click', () => { L.masivo = null; L.sel = {}; recargar(); });
  qa('[data-fl-mas-banco]').forEach((b) => b.addEventListener('click', () => { guardar(); L.masivo.bancoId = b.dataset.flMasBanco; ctx.render(); }));
  qa('[data-fl-mas-vinc]').forEach((b) => b.addEventListener('click', () => { guardar(); L.masivo.vincular = b.dataset.flMasVinc; ctx.render(); }));
  qa('[data-fl-mas-modo]').forEach((b) => b.addEventListener('click', async () => {
    guardar(); const M = L.masivo; M.modo = b.dataset.flMasModo;
    if (M.modo === 'vincular' && !M.previa) {
      M.cargandoPrevia = true; ctx.render();
      const deudor = seleccion(L).rows[0]?.deudorId || seleccion(L).rows[0]?.deudorNombre || '';
      try { const r = await ctx.authPost('/api/finanzas', { accion: 'listar_obligaciones_previa', deudor }); M.previa = r?.ok ? r : { grupos: [] }; } catch (_) { M.previa = { grupos: [] }; }
      M.cargandoPrevia = false;
    }
    ctx.render();
  }));
  q('[data-fl-mas-ok]')?.addEventListener('click', async () => {
    guardar(); const M = L.masivo, { rows, total } = seleccion(L), monto = Number(M.monto || 0);
    if (!rows.length) return ctx.showToast('Elija al menos una obligación.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(M.fecha || '')) return ctx.showToast('Escriba la fecha real del pago.');
    if (!(monto > 0) || monto > total + 0.001) return ctx.showToast(`El importe debe ser mayor que L0 y no pasar de ${lps(total)}.`);
    if (M.modo === 'vincular' ? !M.vincular : !M.bancoId) return ctx.showToast(M.modo === 'vincular' ? 'Elija el pago ya registrado.' : 'Elija el banco donde entró el pago.');
    const r = await post({ accion: 'registrar_pago_masivo', cuentas: rows.map((c) => c.id), monto, fechaPago: M.fecha, ...(M.modo === 'vincular' ? { vincularMovimientoId: M.vincular } : { bancoId: M.bancoId }), referencia: M.referencia || '', observaciones: M.obs || '', operationId: M.opId }, '');
    if (r) { M.resultado = r; ctx.render(); }
  });
  q('[data-fl-previa]')?.addEventListener('click', async () => {
    L.previa = { cargando: true }; ctx.render();
    try { const r = await ctx.authPost('/api/finanzas', { accion: 'listar_obligaciones_previa' }); if (!r?.ok) throw new Error(r?.error || 'No se pudo armar la vista previa.'); L.previa = r; }
    catch (e) { L.previa = { error: e?.message || 'No se pudo armar la vista previa.' }; }
    ctx.render();
  });
  q('[data-fl-previa-cerrar]')?.addEventListener('click', () => { L.previa = null; ctx.render(); });
}
