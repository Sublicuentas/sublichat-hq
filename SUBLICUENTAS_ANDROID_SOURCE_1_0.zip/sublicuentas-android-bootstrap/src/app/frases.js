// R74 · Frase motivadora del día (misma lógica que Sublichat web).
import { esc } from './core.js';

// Frase motivadora del día -- misma fuente y misma lógica que Sublichat HQ (web):
// rota por fecha, misma frase todo el día, cambia al siguiente.
export const FRASES=[
  ['🚀','Hoy se vende, se cobra y *se celebra*.'],
  ['💪','Cada cobro de hoy es un *paso* hacia tu meta.'],
  ['🔥','Tu negocio no se detiene: ¡*tú tampoco*!'],
  ['🌟','Sonríe: hoy vas a cerrar *más ventas*.'],
  ['🎯','Enfoque + constancia = *resultados*.'],
  ['☕','Un café, una sonrisa y a *renovar cuentas*.'],
  ['🏆','Los campeones cobran *a tiempo*.'],
  ['😎','Hoy te toca brillar, *jefe*.'],
  ['💸','Cliente bien atendido, cliente que *regresa*.'],
  ['🌈','Después de cada renovación viene *un buen día*.'],
  ['⚡','Rápido, amable y confiable: *así se vende*.'],
  ['🎉','¡Vamos con todo! Hoy *sí se puede*.'],
  ['🤝','Un buen trato vale más que *mil anuncios*.'],
  ['🧠','Piensa en grande y cobra *a tiempo*.'],
  ['🌞','Nuevo día, nuevos clientes, *nuevas ganancias*.'],
  ['📈','Pequeños pasos, *grandes resultados*.'],
  ['🥇','Hoy vas por el *primer lugar*.'],
  ['💙','Trata bien a tu cliente y él *hará el resto*.'],
  ['🛠️','Los problemas son *oportunidades* disfrazadas.'],
  ['🍀','La suerte le sonríe a quien *trabaja duro*.'],
  ['🔔','¡Suena la campana! Hoy toca *renovar y ganar*.'],
  ['🌱','Lo que hoy siembras, *mañana lo cobras*.'],
  ['🙌','Gracias por hacer que todo *funcione*.'],
  ['✨','Tu actitud es tu *mejor plan de ventas*.'],
  ['🧩','Cada cliente es una pieza de *tu gran plan*.'],
  ['🎶','Pon buena música y *vende con ganas*.'],
  ['🦸','Hoy tú eres *el héroe del día*.'],
  ['📞','Una llamada a tiempo *salva* una renovación.'],
  ['💡','Buena idea + acción = *negocio*.'],
  ['🚦','Luz verde: hoy todo *fluye*.'],
  ['🎁','Sorprende a un cliente hoy: *vale oro*.'],
  ['🧡','Lo haces mejor de lo que crees, *sigue así*.'],
  ['🌄','Las mejores ventas empiezan *temprano*.'],
  ['🥳','¡Meta a la vista! Falta *poquito*.'],
  ['🔑','La clave del éxito se llama *constancia*.'],
  ['🦁','Con buen servicio *nadie te para*.'],
  ['🍉','Trabaja con ganas, descansa *con más ganas*.'],
  ['🎈','Cada "gracias" de un cliente *cuenta doble*.'],
  ['🏅','Hoy también *vas ganando*.'],
  ['🌻','Buena vibra, buenas ventas, *buen día*.'],
];
export function mottoHtml(f) {
  const [emoji,text]=Array.isArray(f)?f:['✨',String(f||'')];
  return `<div class="visual-motto"><i>${emoji}</i><span>${esc(text).replace(/\*([^*]+)\*/g,'<em>$1</em>')}</span></div>`;
}
export function dailyPhrase() {
  const start = new Date(2026,0,1);
  const dias = Math.floor((new Date() - start) / 86400000);
  const idx = ((dias % FRASES.length) + FRASES.length) % FRASES.length;
  return FRASES[idx];
}
