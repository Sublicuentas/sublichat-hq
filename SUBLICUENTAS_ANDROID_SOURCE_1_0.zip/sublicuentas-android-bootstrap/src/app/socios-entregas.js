// Oct-2026 · "Pedidos de socios": entregas por servicio desde la APK (igual que Sublichat HQ → Catálogo Socios → 📦 Entregas).
// Preparar → Vincular ficha → Revisar → Publicar. Doble toque no duplica (opId estable por formulario).
// La ficha que se amarró al PAGO del socio ("Ya pagó por Socios" al guardar el CRM) viene sugerida para su servicio.
// Habla con /api/revendedores-admin (puente de Sublichat → Panel API) con el mismo usuario y candado que la web.
// El código opcional se manda una sola vez al servidor, que lo cifra; la APK no lo guarda.
import { authPost, newOperationId } from '../api.js';
import { state, esc, cap, ui, showToast } from './core.js';

const AVISO = { pendiente: 'Aviso pendiente', procesando: 'Enviando aviso…', aceptado: 'Aceptado por Telegram', fallido: 'Falló el aviso', incierto: 'Resultado incierto', sin_vinculo: 'Socio sin Telegram', desconocido: '—' };
const ENT = { borrador: 'Borrador', publicada: 'Publicada', revocada: 'Acceso revocado' };
const FILTROS = [['pendientes', 'Por entregar'], ['parcial', 'Parciales'], ['entregado', 'Entregados'], ['todos', 'Todos']];
const ERR = { ya_publicada_use_actualizar: 'Ya está publicada: use “Actualizar entrega”.', ficha_de_otro_socio: 'Esa ficha no es de este socio ni está amarrada a este pago.', cifrado_no_configurado: 'Falta ENTREGAS_CODIGOS_KEY en Render: no se puede guardar el código.', pedido_cancelado: 'El pedido está cancelado.', socio_sin_telegram: 'El socio no tiene Telegram vinculado.', falta_motivo: 'Escriba el motivo.', socio_no_verificado: 'El socio del pedido no está registrado.' };

export function canSociosEntregas() { return Boolean(cap().catalogo); } // solo Sublicuentas (mismo candado que la web)
export function seState() { if (!state.se) state.se = { lista: null, filtro: 'pendientes', q: '', cargando: false, error: '', abierto: '', d: null, forms: {}, abrirIdx: null }; return state.se; }
export function resetSociosEntregas() { state.se = null; document.getElementById('seOferta')?.remove(); }

async function puente(ruta, { metodo = 'GET', params = {}, datos = undefined } = {}) {
  let r;
  try { r = await authPost('/api/revendedores-admin', { apk: true, ruta, metodo, params, ...(datos ? { datos } : {}), ...(metodo === 'GET' || ruta.endsWith('vista-previa') ? { accion: 'leer' } : {}) }); }
  catch (e) { const c = e?.data?.error; const x = new Error(ERR[c] || (c === 'sin_permiso' || Number(e?.status) === 403 ? 'Su usuario no tiene permiso para entregas de socios.' : e?.message || 'Sin conexión')); x.code = c; throw x; }
  if (r && r.ok === false && r.error) { const e = new Error(ERR[r.error] || r.error); e.code = r.error; throw e; }
  return r;
}
const fecha = (v) => { if (!v) return '—'; const d = new Date(typeof v === 'number' ? v : v._seconds ? v._seconds * 1000 : v.seconds ? v.seconds * 1000 : v); return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString('es-HN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); };
const lps = (v) => `L${Number(v || 0).toLocaleString('en-US')}`;
const ref = (id) => String(id || '').slice(-6).toUpperCase();
function estadoPedido(p) {
  if (String(p.estado || '').toLowerCase() === 'cancelado') return ['off', 'Cancelado'];
  const e = p.entregaResumen || {};
  if (e.estado === 'entregado') return ['ok', 'Entregado al socio'];
  if (e.estado === 'parcial') return ['work', e.texto || 'Entrega parcial'];
  return ['warn', 'Por entregar'];
}

export async function seCargarLista() {
  const s = seState(); s.cargando = true; s.error = ''; ui.render();
  try { const r = await puente('compras', { params: { limit: 160 } }); s.lista = Array.isArray(r) ? r : (r?.items || r?.compras || []); }
  catch (e) { s.error = e?.message || 'Sin conexión'; s.lista = s.lista || []; }
  s.cargando = false; if (state.subview === 'socios-entregas') ui.render();
}
async function seCargarPedido(compraId) {
  const s = seState(); s.abierto = compraId; s.d = null; s.error = ''; ui.render();
  try {
    s.d = await puente('entregas', { params: { compraId } });
    if (s.abrirIdx != null) { const r = s.d.renglones[s.abrirIdx]; s.abrirIdx = null; if (r && r.entrega?.estado !== 'publicada') abrirForm(r, 'publicar'); }
  } catch (e) { s.d = { error: e?.message || 'No se pudo abrir el pedido.' }; }
  if (state.subview === 'socios-entregas') ui.render();
}
function abrirForm(r, modo) {
  const s = seState(), e = r.entrega, fp = r.fichaPagada;
  s.forms[r.renglonId] = { modo, opId: newOperationId().replace(/[^A-Za-z0-9_-]/g, ''), q: '', resultados: null, preview: null,
    ficha: e?.ficha ? { clienteId: e.ficha.clienteId, servicioCompraId: e.ficha.servicioCompraId, servicioIndex: e.ficha.servicioIndex } : fp ? { clienteId: fp.clienteId, servicioCompraId: fp.servicioCompraId } : null,
    fichaTxt: e?.fichaResumen ? `${e.fichaResumen.cliente} · ${e.fichaResumen.plataforma}` : fp ? `${fp.clienteNombre} · ${fp.plataforma}` : '', fichaDelPago: !e?.ficha && !!fp,
    portalAutorizado: e ? !!e.portalAutorizado : !!fp, codigo: '', codigoAutorizado: !!e?.codigoAutorizado, quitarCodigo: false, notaSocio: e?.notaSocio || '', mensajeCliente: e?.mensajeCliente || '', motivo: '', avisar: true };
}

/* ───────── vistas ───────── */
export function sociosEntregasView() {
  const s = seState();
  if (!canSociosEntregas()) return ui.subPage('Pedidos de socios', 'No disponible', '<div class="empty-state"><strong>Solo para Sublicuentas</strong></div>');
  if (s.abierto) return ui.subPage(`Pedido #${ref(s.abierto)}`, 'Entregas por servicio', pedidoHtml(s));
  if (s.lista === null && !s.cargando) setTimeout(seCargarLista, 0);
  const cuenta = (k) => (s.lista || []).filter((p) => filtra(p, k)).length;
  const q = s.q.trim().toLowerCase();
  const lista = (s.lista || []).filter((p) => filtra(p, s.filtro) && (!q || [ref(p.id), p.socio, p.cliente, ...(p.productos || []).map((x) => x.servicio)].join(' ').toLowerCase().includes(q)));
  return ui.subPage('Pedidos de socios', 'Entregas al socio · igual que en la web', `<section class="se-wrap">
    <div class="se-filtros">${FILTROS.map(([k, l]) => `<button type="button" class="se-chip ${s.filtro === k ? 'on' : ''}" data-se-filtro="${k}">${l}${k !== 'todos' && s.lista ? ` · ${cuenta(k)}` : ''}</button>`).join('')}</div>
    <input class="se-input" id="seBuscar" type="search" placeholder="Buscar socio, cliente, # o servicio" value="${esc(s.q)}">
    ${s.error ? `<div class="error-box"><span>${esc(s.error)}</span></div>` : ''}
    ${s.cargando && !s.lista ? '<div class="loading-card"><span class="spinner"></span><strong>Cargando pedidos…</strong></div>' : lista.length ? lista.map(itemHtml).join('') : '<div class="empty-state"><strong>Sin pedidos en este filtro</strong></div>'}
    <button type="button" class="se-btn ghost" data-se-recargar>Actualizar</button></section>`);
}
function filtra(p, k) {
  const [c] = estadoPedido(p);
  if (k === 'pendientes') return c === 'warn' || c === 'work';
  if (k === 'parcial') return c === 'work';
  if (k === 'entregado') return c === 'ok';
  return true;
}
function itemHtml(p) {
  const [c, l] = estadoPedido(p), cli = p.clientePrincipal ? `${p.clientePrincipal.nombre || ''} ${p.clientePrincipal.apellido || ''}`.trim() : p.cliente;
  return `<button type="button" class="se-item" data-se-abrir="${esc(p.id)}"><div><b>#${esc(ref(p.id))} · ${esc(cli || 'Cliente')}</b><small>${esc(p.socio || p.socio_norm || '')} · ${esc((p.productos || []).map((x) => x.servicio).join(' + ') || p.servicio)}</small><small>${fecha(p.ts || p.createdAt)} · ${lps(p.monto)}${p.pagoRevision ? ' · ⚠️ comprobante repetido' : ''}</small></div><span class="se-pill ${c}">${esc(l)}</span></button>`;
}
function pedidoHtml(s) {
  const volver = '<button type="button" class="se-link" data-se-volver>← Pedidos de socios</button>';
  if (!s.d) return `${volver}<div class="loading-card"><span class="spinner"></span><strong>Abriendo pedido…</strong></div>`;
  if (s.d.error) return `${volver}<div class="error-box"><span>${esc(s.d.error)}</span></div>`;
  const d = s.d;
  return `${volver}<section class="se-card"><b>Socio ${esc(d.socio)}</b> · Cliente <b>${esc(d.cliente || '—')}</b><br><small>Telegram: ${d.telegram === 'vinculado' ? 'vinculado' : 'sin vincular'} · Pago ${lps(d.pago.monto)}${d.pago.banco ? ' · ' + esc(d.pago.banco) : ''}${d.pago.revision ? ' · <b class="se-warn">⚠️ posible comprobante repetido</b>' : ''}</small>
    <p><span class="se-pill ${d.resumen.estado === 'entregado' ? 'ok' : d.resumen.estado === 'parcial' ? 'work' : 'warn'}">${esc(d.resumen.texto)}</span></p>
    <small class="se-muted">“Entregado” solo cuando se publica la entrega. Cada servicio se entrega por separado.</small></section>
    ${d.renglones.map(renglonHtml).join('')}`;
}
function renglonHtml(r) {
  const s = seState(), e = r.entrega, f = s.forms[r.renglonId];
  const datos = [r.datos.dispositivo, r.datos.correo, r.datos.detalle, r.datos.notas ? `Nota: ${r.datos.notas}` : ''].filter(Boolean).join(' · ');
  return `<article class="se-card" data-se-rid="${esc(r.renglonId)}"><div class="se-row"><div><b>${esc(r.servicio)}</b><small>Para ${esc(r.clienteNombre || '—')}${datos ? ' · ' + esc(datos) : ''}</small></div><span class="se-pill ${e?.estado === 'publicada' ? 'ok' : e?.estado === 'revocada' ? 'off' : 'warn'}">${e ? esc(ENT[e.estado] || e.estado) + (e.version ? ` v${e.version}` : '') : 'Sin entrega'}</span></div>
    ${r.fichaPagada && !e ? `<small class="se-ok">🤝 Ficha amarrada al pago del socio: ${esc(r.fichaPagada.clienteNombre)} · ${esc(r.fichaPagada.plataforma)}</small>` : ''}
    ${e ? `<small class="se-muted">${e.publicadaAt ? 'Publicada ' + fecha(e.publicadaAt) : ''}${e.fichaResumen ? ` · Ficha ${esc(e.fichaResumen.cliente)} / ${esc(e.fichaResumen.plataforma)}` : ' · Sin ficha'} · ${e.visto ? `Visto por el socio (v${e.visto.version})` : 'Sin abrir por el socio'}${e.revocadaAt ? ` · Revocada: ${esc(e.motivoRevocacion)}` : ''}</small>
      ${e.avisos?.length ? `<div class="se-avisos">${e.avisos.map((a) => `<span class="se-pill ${a.estado === 'aceptado' ? 'ok' : 'off'}">v${a.version}${a.reenvio ? ' r' + a.reenvio : ''}: ${esc(AVISO[a.estado] || a.estado)}</span>`).join('')}</div>` : ''}` : ''}
    ${!f ? `<div class="se-acciones">${e?.estado === 'publicada' ? `<button type="button" class="se-btn" data-se-form="actualizar">Actualizar entrega</button><button type="button" class="se-btn ghost" data-se-reenviar="${esc(e.id)}">Reenviar aviso</button><button type="button" class="se-btn ghost danger" data-se-revocar="${esc(e.id)}">Revocar acceso</button>`
      : `<button type="button" class="se-btn primary" data-se-form="publicar">${e?.estado === 'borrador' ? 'Continuar borrador' : e?.estado === 'revocada' ? 'Volver a publicar' : 'Preparar entrega'}</button>`}</div>` : formHtml(r, f)}</article>`;
}
function fichasHtml(f) {
  if (!f.resultados) return '';
  if (!f.resultados.length) return '<small class="se-muted">Sin fichas de este socio con ese nombre.</small>';
  return f.resultados.map((c) => c.servicios.map((x) => `<button type="button" class="se-ficha" data-se-ficha="${esc(c.clienteId)}|${esc(x.compraId)}|${x.index}" data-txt="${esc(`${c.nombre} · ${x.plataforma}${x.vence ? ' · vence ' + x.vence : ''}`)}"><b>${esc(c.nombre)}</b> · ${esc(x.plataforma)}${x.vence ? ` · vence ${esc(x.vence)}` : ''}</button>`).join('')).join('');
}
function formHtml(r, f) {
  const e = r.entrega, p = f.preview;
  return `<div class="se-form">
    <label class="se-label">1. Ficha de Sublichat</label>
    ${f.ficha ? `<div class="se-sel">${f.fichaDelPago ? '🤝 ' : '✅ '}${esc(f.fichaTxt)}${f.fichaDelPago ? '<small>Amarrada al pago del socio</small>' : ''}<button type="button" class="se-link" data-se-sinficha>Cambiar</button></div>`
      : `<input class="se-input" data-se-f="q" type="search" placeholder="Buscar cliente del socio" value="${esc(f.q)}"><div data-se-res>${fichasHtml(f)}</div><small class="se-muted">Sin ficha: el socio ve la entrega sin portal.</small>`}
    <label class="se-check"><input type="checkbox" data-se-f="portalAutorizado" ${f.portalAutorizado ? 'checked' : ''} ${f.ficha ? '' : 'disabled'}> Mostrar “Abrir portal del cliente” al socio</label>
    <label class="se-label">Código (opcional · se guarda cifrado)<input class="se-input" type="password" autocomplete="off" data-se-f="codigo" value="${esc(f.codigo)}" placeholder="${e?.codigoGuardado ? 'Código guardado · escriba solo para cambiarlo' : 'Solo si aplica'}"></label>
    ${e?.codigoGuardado ? `<label class="se-check"><input type="checkbox" data-se-f="quitarCodigo" ${f.quitarCodigo ? 'checked' : ''}> Quitar el código guardado</label>` : ''}
    <label class="se-check"><input type="checkbox" data-se-f="codigoAutorizado" ${f.codigoAutorizado ? 'checked' : ''}> Autorizar que el socio vea el código</label>
    <label class="se-label">Nota para el socio<textarea class="se-input" rows="2" maxlength="600" data-se-f="notaSocio">${esc(f.notaSocio)}</textarea></label>
    <label class="se-label">Mensaje para el cliente (el socio lo copia)<textarea class="se-input" rows="3" maxlength="1500" data-se-f="mensajeCliente">${esc(f.mensajeCliente)}</textarea></label>
    ${f.modo === 'actualizar' ? `<label class="se-label">Motivo de la actualización *<input class="se-input" maxlength="300" data-se-f="motivo" value="${esc(f.motivo)}"></label><label class="se-check"><input type="checkbox" data-se-f="avisar" ${f.avisar ? 'checked' : ''}> Avisar del cambio por Telegram</label>` : ''}
    ${p ? `<div class="se-preview"><b>Vista previa · lo que verá ${esc(p.socio.nombre)}</b><br>${esc(p.verSocio.pedido)} · ${esc(p.verSocio.cliente)} · ${esc(p.verSocio.servicio)}${p.verSocio.vence ? ' · vence ' + esc(p.verSocio.vence) : ''}<br>Portal: ${esc(p.verSocio.portal)}<br>Código: ${esc(p.verSocio.codigo)}${p.telegram ? `<pre>${esc(p.telegram.replace(/<[^>]+>/g, ''))}\n[Ver entrega en mi panel]</pre>` : '<br>Sin Telegram: queda solo en el panel.'}</div>` : ''}
    <p class="se-err" data-se-msg></p>
    <div class="se-acciones"><button type="button" class="se-btn ghost" data-se-cancelar>Cancelar</button>${f.modo !== 'actualizar' ? '<button type="button" class="se-btn ghost" data-se-guardar="borrador">Guardar borrador</button>' : ''}<button type="button" class="se-btn" data-se-revisar>Revisar</button>
      <button type="button" class="se-btn primary" data-se-guardar="${f.modo}" ${p ? '' : 'disabled'}>${f.modo === 'actualizar' ? 'Actualizar entrega' : 'Publicar al socio'}</button></div></div>`;
}

/* ───────── eventos ───────── */
function payload(rid, accion) {
  const f = seState().forms[rid];
  return { accion, compraId: seState().abierto, renglonId: rid, opId: f.opId, ficha: f.ficha || null, portalAutorizado: !!f.portalAutorizado, codigo: f.codigo || '', quitarCodigo: !!f.quitarCodigo, codigoAutorizado: !!f.codigoAutorizado, notaSocio: f.notaSocio, mensajeCliente: f.mensajeCliente, motivo: f.motivo, avisar: !!f.avisar };
}
let fichaTimer = null;
export function bindSociosEntregas() {
  if (state.subview !== 'socios-entregas') return;
  const s = seState(), q = (x) => document.querySelector(x), qa = (x) => document.querySelectorAll(x);
  qa('[data-se-filtro]').forEach((b) => b.addEventListener('click', () => { s.filtro = b.dataset.seFiltro; ui.render(); }));
  q('#seBuscar')?.addEventListener('input', (ev) => { s.q = ev.target.value; const pos = ev.target.selectionStart; ui.render(); const i = q('#seBuscar'); if (i) { i.focus(); try { i.setSelectionRange(pos, pos); } catch (_) {} } });
  q('[data-se-recargar]')?.addEventListener('click', seCargarLista);
  qa('[data-se-abrir]').forEach((b) => b.addEventListener('click', () => { window.scrollTo(0, 0); seCargarPedido(b.dataset.seAbrir); }));
  q('[data-se-volver]')?.addEventListener('click', () => { s.abierto = ''; s.d = null; s.forms = {}; ui.render(); seCargarLista(); });
  qa('[data-se-rid]').forEach((card) => {
    const rid = card.dataset.seRid, r = s.d?.renglones?.find((x) => x.renglonId === rid), f = s.forms[rid];
    const msg = (t) => { const el = card.querySelector('[data-se-msg]'); if (el) el.textContent = t; };
    card.querySelector('[data-se-form]')?.addEventListener('click', (ev) => { abrirForm(r, ev.currentTarget.dataset.seForm); ui.render(); });
    card.querySelectorAll('[data-se-f]').forEach((i) => i.addEventListener(i.type === 'checkbox' ? 'change' : 'input', () => {
      const k = i.dataset.seF; f[k] = i.type === 'checkbox' ? i.checked : i.value;
      if (k !== 'q' && f.preview) { f.preview = null; const b = card.querySelector('[data-se-guardar="' + f.modo + '"]'); if (b) b.disabled = true; card.querySelector('.se-preview')?.remove(); }
      if (k === 'q') { clearTimeout(fichaTimer); fichaTimer = setTimeout(async () => { try { const d = await puente('entregas/fichas', { params: { q: f.q, socio: s.d.socio } }); f.resultados = d.items || []; } catch (_) { f.resultados = []; } const box = card.querySelector('[data-se-res]'); if (box) box.innerHTML = fichasHtml(f); }, 400); }
    }));
    card.addEventListener('click', async (ev) => {
      const t = ev.target.closest('[data-se-ficha]');
      if (t && f) { const [clienteId, servicioCompraId, ix] = t.dataset.seFicha.split('|'); Object.assign(f, { ficha: { clienteId, servicioCompraId, servicioIndex: Number(ix) }, fichaTxt: t.dataset.txt, fichaDelPago: false, resultados: null, preview: null, portalAutorizado: true }); ui.render(); }
    });
    card.querySelector('[data-se-sinficha]')?.addEventListener('click', () => { Object.assign(f, { ficha: null, fichaTxt: '', fichaDelPago: false, portalAutorizado: false, preview: null }); ui.render(); });
    card.querySelector('[data-se-cancelar]')?.addEventListener('click', () => { delete s.forms[rid]; ui.render(); });
    card.querySelector('[data-se-revisar]')?.addEventListener('click', async (ev) => {
      ev.currentTarget.disabled = true;
      try { f.preview = await puente('entregas/vista-previa', { metodo: 'POST', datos: payload(rid, f.modo) }); ui.render(); }
      catch (e) { ev.currentTarget.disabled = false; msg(e.message); }
    });
    card.querySelectorAll('[data-se-guardar]').forEach((b) => b.addEventListener('click', async () => {
      const accion = b.dataset.seGuardar;
      if (accion === 'actualizar' && !String(f.motivo || '').trim()) { msg('Escriba el motivo de la actualización.'); return; }
      b.disabled = true; b.textContent = accion === 'borrador' ? 'Guardando…' : 'Publicando…';
      try {
        const r2 = await puente('entregas/guardar', { metodo: 'POST', datos: payload(rid, accion) });
        delete s.forms[rid];
        showToast(accion === 'borrador' ? 'Borrador guardado: no se publicó ni avisó.' : `✅ Entrega ${accion === 'actualizar' ? 'actualizada' : 'publicada'} (v${r2.version}). ${r2.aviso === 'sin_vinculo' ? 'El socio la verá en su panel (sin Telegram).' : 'Aviso de Telegram en cola.'}`);
        await seCargarPedido(s.abierto);
      } catch (e) { b.disabled = false; b.textContent = accion === 'borrador' ? 'Guardar borrador' : accion === 'actualizar' ? 'Actualizar entrega' : 'Publicar al socio'; msg(e.message); }
    }));
    card.querySelector('[data-se-reenviar]')?.addEventListener('click', async (ev) => {
      if (!window.confirm('¿Reenviar el aviso de Telegram? No crea otra compra ni cambia la fecha original.')) return;
      ev.currentTarget.disabled = true;
      try { await puente(`entregas/${ev.currentTarget.dataset.seReenviar}/reenviar`, { metodo: 'POST', datos: { opId: newOperationId().replace(/[^A-Za-z0-9_-]/g, '') } }); await seCargarPedido(s.abierto); }
      catch (e) { showToast(e.message); ui.render(); }
    });
    card.querySelector('[data-se-revocar]')?.addEventListener('click', async (ev) => {
      const motivo = window.prompt('Motivo para revocar (queda en el historial). No cancela el servicio ni borra mensajes ya enviados:');
      if (!motivo || !motivo.trim()) return;
      try { await puente(`entregas/${ev.currentTarget.dataset.seRevocar}/revocar`, { metodo: 'POST', datos: { motivo } }); await seCargarPedido(s.abierto); }
      catch (e) { showToast(e.message); }
    });
  });
}

// Al guardar el CRM con "Ya pagó por Socios": ofrecer publicar la entrega de ESE servicio con la ficha recién amarrada.
export function sociosOfrecerEntrega(pagoSocio) {
  if (!canSociosEntregas() || typeof document === 'undefined') return;
  const compraId = String(pagoSocio?.movimientoId || '').replace(/^socio_compra_/, '').replace(/_cobro$/, '');
  if (!compraId || compraId === String(pagoSocio?.movimientoId || '')) return;
  document.getElementById('seOferta')?.remove();
  const el = document.createElement('div'); el.id = 'seOferta'; el.className = 'se-oferta'; el.setAttribute('role', 'dialog');
  el.innerHTML = `<b>🤝 Ficha amarrada al pago del socio</b><span>Pedido #${esc(ref(compraId))}. ¿Publicar ahora la entrega al socio?</span><div><button type="button" class="se-btn ghost" data-x>Después</button><button type="button" class="se-btn primary" data-ir>Publicar entrega</button></div>`;
  el.querySelector('[data-x]').addEventListener('click', () => el.remove());
  el.querySelector('[data-ir]').addEventListener('click', () => {
    el.remove(); const s = seState(); s.forms = {}; s.abrirIdx = Number(pagoSocio.productoIdx) || 0;
    state.active = 'mas'; state.subview = 'socios-entregas'; ui.render(); seCargarPedido(compraId);
  });
  document.body.appendChild(el);
}
