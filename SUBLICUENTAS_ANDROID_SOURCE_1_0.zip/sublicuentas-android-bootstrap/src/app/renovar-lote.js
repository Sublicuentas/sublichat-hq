// R186 · Renovación de varios servicios en UNA operación del servidor + Excel del mes a Descargas.
// Sale de main.js (límite de 2000 líneas, R74). Recibe todo lo que necesita por ctx: no guarda estado propio.
import { pagoLoteBody } from './finanzas-libro.js';
import { guardarEnDescargas } from '../finanzas-file.js';

// R186 · Excel del mes (misma consulta que la tarjeta "Este mes") → directo a Descargas, sin "Compartir".
export async function descargarExcelMes(ctx,mes){
  const {state,render,showToast,authPost}=ctx;
  const L=state.libro; if(!mes||L.mesXlsBusy)return; L.mesXlsBusy=true; render();
  try{
    const desde=new Date(`${mes.desde}T12:00:00`), hasta=new Date(`${mes.hasta}T12:00:00`);
    const out=await (await import('./excel-saiyajin.js')).exportarSaiyajin({authPost,saveAndShareXlsx:(nombre,buf)=>guardarEnDescargas(`finanzas_${mes.periodo}.xlsx`,buf),scope:'rango',range:{desde,hasta},mes});
    showToast(`⬇️ Excel guardado en ${out?.guardadoEn||'Descargas'}`);
  }catch(e){showToast(e?.message||'No se pudo descargar el Excel.');}
  finally{L.mesXlsBusy=false;render();}
}

// R186 · En línea y con duración (+31 días, 1/2/3/6/12 meses): UNA operación en el servidor para todos los servicios marcados:
// el servidor calcula cada fecha desde SU vencimiento, guarda todo o nada y registra UN pago con el monto de cada servicio.
export function loteLineas(rows,options){
  const dur=options.months?{unidad:'meses',cantidad:Number(options.months)}:{unidad:'dias',cantidad:Math.max(1,Number(options.days||30))};
  return rows.map(r=>({compraId:r.compraId||r.raw?.compraId||'',servicioIndex:Number.isInteger(Number(r.servicioIndex))?Number(r.servicioIndex):null,plataforma:String(r.plataforma||''),correo:String(r.correo||''),duracion:dur,periodos:Number(r._periodos||1),monto:0}));
}
export async function renovarLoteApk(ctx,g,rows,options,pago){
  const {state,render,showToast,authPost,newOperationId,realClientId,persistCoreCache,loadCoreData,crmPlatformLabel,isOfflineError}=ctx;
  const clienteId=realClientId(rows[0]?.clienteId);
  const lineas=loteLineas(rows,options);
  if(pago&&pago.modo!=='ajuste'){const b=pagoLoteBody(pago,{operationId:pago.opLote||newOperationId()});pago.opLote=b.pago.operationId;lineas.forEach((l,i)=>{l.monto=Number(b.montos[`s${i}`]||0);l.montoEsperado=Number(b.montos[`s${i}`]||0);});var pagoBody=b.pago;}
  const body={accion:'renovar_lote',clienteId,lineas,origen:'apk',confirmarAtraso:true,operationId:pago?.opLote||newOperationId(),...(pagoBody?{pago:pagoBody}:{}),...(pago?.modo==='ajuste'?{ajusteAdministrativo:true,motivoAjuste:pago.motivo}:{})};
  state.mutating=true;render();
  let r=null;
  for(let i=0;i<2;i++){ try{r=await authPost('/api/renovar',body);break;}catch(e){r={ok:false,error:e?.message||'Sin conexión'};if(isOfflineError(e))break;} } // reintento con el MISMO operationId: no duplica
  state.mutating=false;
  if(!r?.ok){render();showToast(`⚠️ No se renovó nada: ${r?.error||'error'} (todo o nada)`);return false;}
  for(const x of (r.lineas||[])){const row=rows.find(a=>(x.compraId&&(a.compraId||a.raw?.compraId)===x.compraId)||Number(a.servicioIndex)===Number(x.servicioIndex));if(row?.raw)row.raw.fechaRenovacion=x.fechaNueva;}
  persistCoreCache();
  state.renewGroupKey='';state.renewSelection=[];state.renewManage=false;state.renewMessage='';render();
  showToast(`✅ ${r.duplicado?'Ya estaba registrada':'Confirmado por el servidor'}: ${(r.lineas||[]).map(x=>`${crmPlatformLabel(x.plataforma)||x.plataforma} → ${x.fechaNueva}`).join(' · ')}${r.pagoOperacion?` · 💵 un solo cobro L${r.total}`:''}`);
  loadCoreData({force:true});
  return true;
}
// Devuelve true si la renovación se manejó aquí (o el usuario canceló); false = seguir con el flujo anterior.
export async function intentarLote(ctx,{g,rows,options,pago,label}){
  const {state,render,authPost,realClientId,crmPlatformLabel,libroUser,libroMethods,initLibroState,loadLibro,libroCtx,canOffline,deviceOffline}=ctx;
  const enLinea=!(canOffline()&&deviceOffline());
  if(enLinea&&!options.exactDate&&realClientId(rows[0]?.clienteId)&&rows.every(r=>realClientId(r.clienteId)===realClientId(rows[0].clienteId))){
    if(pago){if(!pago.lote)return false;state.renewPay=null;await renovarLoteApk(ctx,g,rows,options,pago);return true;} // hoja del flujo anterior → flujo anterior
    // Vista previa del servidor (no escribe): fechas reales y aviso si sigue vencido.
    let vista=null; try{vista=await authPost('/api/renovar',{accion:'renovar_lote',soloVista:true,clienteId:realClientId(rows[0].clienteId),lineas:loteLineas(rows,options)});}catch(_){}
    if(vista?.ok&&vista.vista===true&&Array.isArray(vista.lineas)){
      const atrasados=(vista.lineas||[]).filter(x=>x.sigueVencida);
      if(atrasados.length){
        const n=window.prompt(`${atrasados.map(x=>`${crmPlatformLabel(x.plataforma)||x.plataforma}: vencía ${x.fechaAnterior} → ${x.fechaNueva}`).join('\n')}\n\nSigue vencido aun después de renovar. La fecha NO se adelanta al día del pago.\n¿Cuántos periodos cobra? (1 a 24)`,'1');
        if(n===null)return true;
        const k=Math.max(1,Math.min(24,parseInt(n,10)||1));
        rows.forEach((r,i)=>{if(vista.lineas[i]?.sigueVencida)r._periodos=k;});
        try{vista=await authPost('/api/renovar',{accion:'renovar_lote',soloVista:true,clienteId:realClientId(rows[0].clienteId),lineas:loteLineas(rows,options)});}catch(_){}
      }
      // R196n · cada fila trae el precio REGISTRADO en su ficha (del servidor): se cobra UN solo total, no un monto por servicio.
      const filas=(vista?.lineas||[]).map((x,i)=>({key:`s${i}`,nombre:crmPlatformLabel(x.plataforma)||x.plataforma,precio:Number.isFinite(Number(x.precioRegistrado))&&x.precioRegistrado!==null?Number(x.precioRegistrado):null,label:`${crmPlatformLabel(x.plataforma)||x.plataforma} · vence ${x.fechaAnterior||'—'} → nuevo ${x.fechaNueva}${x.periodos>1?` (${x.periodos} periodos)`:''}`}));
      if(libroUser()){
        state.renewPay={options,lote:true,unTotal:true,precios:{},cobrado:null,dif:'',ajMotivo:'',cliente:g.nombre,label:`${rows.length} servicio${rows.length===1?'':'s'} ${label} · 1 solo pago`,tipo:'renovacion',rows:filas,montos:{},bancoId:'',responsable:'cliente',vendedor:rows[0]?.vendedor||'',modo:'pago',motivo:''};
        if(!libroMethods().length){initLibroState(state);loadLibro(libroCtx(),{silent:true});} render();return true;
      }
      if(!window.confirm(`Renovar ${rows.length} servicio${rows.length===1?'':'s'} de ${g.nombre}?\n\n${filas.map(f=>f.label).join('\n')}`))return true;
      await renovarLoteApk(ctx,g,rows,options,null);return true;
    }
    // Servidor anterior (sin renovar_lote): sigue el flujo de siempre.
  }
  return false;
}
