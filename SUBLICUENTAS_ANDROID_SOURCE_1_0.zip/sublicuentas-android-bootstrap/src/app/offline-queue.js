// R101 · Motor del modo sin conexión (sacado de main.js para mantenerlo bajo 2000 líneas, regla R74).
// main.js conecta `hooks` al arrancar: lastOk (marcas de sincronización), render y reload.
import { state, esc, showToast } from './core.js';
import { authPost } from '../api.js';
import { parseDateDMY } from '../data.js';
import { offlineAllowed, offlineSupported, saveSnapshot, loadSnapshot, saveQueue, loadQueue, isOfflineError } from './offline.js';
export const hooks = { lastOk: () => ({}), render: () => {}, reload: () => {} };
// Copia completa CIFRADA (llave en el Keystore) + cola de cambios hechos sin señal.
state.pendingOps=[]; state.failedOps=[]; state.offlineSyncedAt=0;
export const canOffline=()=>offlineSupported()&&offlineAllowed(state.session);
export const deviceOffline=()=>typeof navigator!=='undefined'&&navigator.onLine===false;
let snapTimer=null;
export function persistOfflineSnapshot() {
  if (!canOffline()) return;
  clearTimeout(snapTimer);
  const usuario=state.session.usuario;
  snapTimer=setTimeout(()=>{
    if (!state.session||state.session.usuario!==usuario) return;
    saveSnapshot(usuario,{clients:state.clients||[],inventory:state.inventory||[],finances:state.finances||[],profile:state.profile||null,syncedAt:state.offlineSyncedAt||0})
      .catch(e=>console.warn('[offline] no se pudo guardar la copia:',e?.message||e));
  },1500);
}
export async function restoreOffline() {
  if (!canOffline()) return false;
  const usuario=state.session.usuario;
  const [snap,queue]=await Promise.all([loadSnapshot(usuario),loadQueue(usuario)]);
  if (!state.session||state.session.usuario!==usuario) return false;
  state.pendingOps=queue;
  if (!snap) return false;
  // Solo rellena lo que el servidor todavía no trajo en esta sesión (nunca pisa datos frescos).
  if (!hooks.lastOk().clients&&Array.isArray(snap.clients)&&snap.clients.length) state.clients=snap.clients;
  if (!hooks.lastOk().inventory&&Array.isArray(snap.inventory)) state.inventory=snap.inventory;
  if (!hooks.lastOk().finances&&Array.isArray(snap.finances)) state.finances=snap.finances;
  if (!hooks.lastOk().profile&&snap.profile) state.profile=snap.profile;
  state.offlineSyncedAt=Number(snap.syncedAt||0);
  return true;
}
export async function enqueueOp(op) {
  const item={createdAt:Date.now(),...op};
  state.pendingOps=[...(state.pendingOps||[]),item];
  await saveQueue(state.session.usuario,state.pendingOps);
  persistOfflineSnapshot();
  return item;
}
export function dmyPlusDays(dmy='',days=30) {
  const base=parseDateDMY(dmy)||(()=>{const d=new Date();d.setHours(12,0,0,0);return d;})();
  const d=new Date(base); d.setDate(d.getDate()+Number(days||0));
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}
export const realClientId=id=>String(id||'').startsWith('local_')?'':String(id||'');
function opConfirmed(op,r) {
  if (!r||r.ok===false||r.error) return false;
  if (op.kind==='ficha') return r.guardadoEnFirebase===true||Boolean(r.clienteId);
  if (op.kind==='renovacion') return r.verified===true||r.ok===true;
  return true;
}
let flushing=false;
export async function flushQueue() {
  if (flushing||!state.session||!canOffline()||deviceOffline()) return;
  const usuario=state.session.usuario;
  let queue=await loadQueue(usuario);
  if (!queue.length) { state.pendingOps=[]; return; }
  flushing=true; let ok=0, touchedFinance=false;
  try {
    while (queue.length) {
      const op=queue[0];
      try {
        const r=await authPost(op.path,op.body);
        if (!opConfirmed(op,r)) throw Object.assign(new Error(r?.error||'El servidor no confirmó el cambio.'),{status:200});
        ok+=1; if (op.path==='/api/finanzas') touchedFinance=true;
      } catch (e) {
        if (isOfflineError(e)||e?.updateRequired||(Number(e?.status)===409&&e?.data?.retryable)) break; // queda en cola, se reintenta luego
        state.failedOps=[...(state.failedOps||[]),{label:op.label,error:e?.message||'Error'}];
      }
      queue=queue.slice(1);
      if (!state.session||state.session.usuario!==usuario) return;
      state.pendingOps=queue; await saveQueue(usuario,queue); hooks.render();
    }
  } finally { flushing=false; }
  if (ok) {
    showToast(`✅ ${ok} cambio${ok===1?'':'s'} hecho${ok===1?'':'s'} sin conexión ya se guardaron.`);
    hooks.reload(touchedFinance?['clients','finances']:['clients']);
  }
}
if (typeof window!=='undefined') window.addEventListener?.('online',()=>setTimeout(()=>{ if(state.session){ flushQueue(); hooks.reload(['clients']); } },1500));
const flushTimer=setInterval(()=>{ if(state.session&&(state.pendingOps||[]).length&&!deviceOffline())flushQueue(); },30000);
flushTimer?.unref?.();
// Lo creado sin señal se ve de una vez en la app (marcado como pendiente).
export function applyLocalFicha(payload) {
  const servicio={...payload.servicio,_pendiente:true};
  const clients=[...(state.clients||[])];
  const tel=v=>String(v||'').replace(/\D/g,'').slice(-8);
  const nm=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  let idx=payload.clienteId?clients.findIndex(c=>String(c.id)===String(payload.clienteId)):-1;
  if (idx<0) idx=clients.findIndex(c=>nm(c.nombrePerfil||c.nombre)===nm(payload.cliente?.nombrePerfil)&&tel(c.telefono)===tel(payload.cliente?.telefono));
  if (idx<0) { const id=`local_${servicio.compraId}`; clients.unshift({id,nombrePerfil:payload.cliente?.nombrePerfil||'',telefono:payload.cliente?.telefono||'',vendedor:payload.cliente?.vendedor||'',servicios:[servicio],_pendiente:true}); state.clients=clients; return id; }
  const c={...clients[idx]}; const servs=[...(c.servicios||[])];
  const si=servs.findIndex(x=>String(x?.compraId||'')===String(servicio.compraId));
  if (si>=0) servs[si]=servicio; else servs.push(servicio);
  c.servicios=servs; clients[idx]=c; state.clients=clients; return c.id;
}
export function offlineSyncText(ms=0) {
  if (!ms) return 'sin fecha';
  const d=new Date(ms); return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')} ${`${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`}`;
}
export function offlineBanners() {
  if (!state.session) return '';
  const pend=(state.pendingOps||[]).length, failed=state.failedOps||[];
  let html='';
  if (pend) html+=`<div class="offline-banner ${deviceOffline()||state.sync==='offline'?'':'sync'}" role="status">${deviceOffline()||state.sync==='offline'?'📴 <b>Sin conexión</b>':'⏳ <b>Subiendo</b>'} · ${pend} cambio${pend===1?'':'s'} en cola${state.offlineSyncedAt?` · datos del ${esc(offlineSyncText(state.offlineSyncedAt))}`:''}<button type="button" id="offlineRetry">Reintentar</button></div>`;
  if (failed.length) html+=`<div class="offline-banner failed" role="alert">⚠️ <b>${failed.length} cambio${failed.length===1?'':'s'} no se pudo guardar:</b> ${failed.map(f=>`${esc(f.label)} (${esc(f.error)})`).join(' · ')}<button type="button" id="offlineFailedOk">Entendido</button></div>`;
  return html;
}
