// R101 · Motor del modo sin conexión (sacado de main.js para mantenerlo bajo 2000 líneas, regla R74).
// main.js conecta `hooks` al arrancar: lastOk (marcas de sincronización), render y reload.
import { state, esc, showToast } from './core.js';
import { authPost } from '../api.js';
import { parseDateDMY, telefonoClave } from '../data.js';
import { offlineAllowed, offlineSupported, saveSnapshot, loadSnapshot, saveQueue, loadQueue, isOfflineError, saveBox, loadBox } from './offline.js';
import { avisoCuentasHtml, avisoVistaHtml } from './offline-consulta.js'; // R198b · R198d
export const hooks = { lastOk: () => ({}), render: () => {}, reload: () => {} };
// Copia completa CIFRADA (llave en el Keystore) + cola de cambios hechos sin señal.
state.pendingOps=[]; state.failedOps=[]; state.offlineSyncedAt=0;
export const canOffline=()=>offlineSupported()&&offlineAllowed(state.session);
export const deviceOffline=()=>typeof navigator!=='undefined'&&navigator.onLine===false;
let snapTimer=null;
export function persistOfflineSnapshot() {
  if (!canOffline()) return;
  clearTimeout(snapTimer);
  const usuario=state.session.usuario;
  snapTimer=setTimeout(()=>{
    if (!state.session||state.session.usuario!==usuario) return;
    saveSnapshot(usuario,{clients:state.clients||[],inventory:state.inventory||[],finances:state.finances||[],profile:state.profile||null,syncedAt:state.offlineSyncedAt||0})
      .catch(e=>console.warn('[offline] no se pudo guardar la copia:',e?.message||e));
  },1500);
}
export async function restoreOffline() {
  if (!canOffline()) return false;
  const usuario=state.session.usuario;
  const [snap,queue]=await Promise.all([loadSnapshot(usuario),loadQueue(usuario)]);
  if (!state.session||state.session.usuario!==usuario) return false;
  state.pendingOps=queue.map(o=>o.estado==='enviando'?{...o,estado:'pendiente'}:o); // corte a mitad del envío / reinicio: se reintenta con el MISMO operationId
  await cargarHistorial(usuario);
  if (!snap) return false;
  // Solo rellena lo que el servidor todavía no trajo en esta sesión (nunca pisa datos frescos).
  if (!hooks.lastOk().clients&&Array.isArray(snap.clients)&&snap.clients.length) state.clients=snap.clients;
  if (!hooks.lastOk().inventory&&Array.isArray(snap.inventory)) state.inventory=snap.inventory;
  if (!hooks.lastOk().finances&&Array.isArray(snap.finances)) state.finances=snap.finances;
  if (!hooks.lastOk().profile&&snap.profile) state.profile=snap.profile;
  state.offlineSyncedAt=Number(snap.syncedAt||0);
  return true;
}
// R198c · Fase 3 (PDF «modo offline completo»): cada cambio sin señal lleva su versión esperada para que el SERVIDOR detecte
// conflictos al reconectar (colaOffline: fecha distinta → no renueva doble; ficha editada desde Web/TG → no la pisa;
// cuenta sin cupo → no vende doble). Estados verificables: pendiente · enviando · confirmado (con ID del servidor) ·
// rechazado · requiere revisión. El historial queda CIFRADO en el teléfono (últimos 60) y sobrevive a reinicios.
const CAJA_HIST='cola_historial_v1';
state.opsHistorial=[];
export const ESTADOS_OP=Object.freeze({pendiente:'Pendiente',enviando:'Enviando',confirmado:'Confirmado',rechazado:'Rechazado',revision:'Requiere revisión'});
async function cargarHistorial(usuario) { const h=await loadBox(usuario,CAJA_HIST).catch(()=>null); if(state.session?.usuario===usuario) state.opsHistorial=Array.isArray(h?.data)?h.data:[]; }
async function anotar(usuario,op,estado,extra={}) {
  const fila={id:String(op?.body?.operationId||op?.id||''),label:op?.label||op?.kind||'Cambio',kind:op?.kind||'',estado,at:Date.now(),creadoAt:op?.createdAt||0,...extra};
  state.opsHistorial=[fila,...(state.opsHistorial||[]).filter(x=>x.id!==fila.id)].slice(0,60);
  await saveBox(usuario,CAJA_HIST,state.opsHistorial).catch(()=>false);
}
function servicioLocal(clienteId,compraId) {
  const c=(state.clients||[]).find(x=>String(x?.id||'')===String(clienteId||'')); if(!c||!compraId) return null;
  return (c.servicios||[]).find(sv=>String(sv?.compraId||'')===String(compraId))||null;
}
export function prepararCuerpoCola(op, pendientes=[]) {
  const body={...(op.body||{})};
  if (op.path!=='/api/renovar') return body;
  body.colaOffline=true;
  const compraId=String(body.compraId||body.servicio?.compraId||'');
  const encadenada=compraId&&pendientes.some(p=>String(p?.body?.compraId||p?.body?.servicio?.compraId||'')===compraId);
  if (body.accion==='renovar'&&!('fechaEsperada' in body)) body.fechaEsperada=String(body.fechaActual||''); // la fecha que vio el teléfono
  if (body.accion==='ficha_upsert'&&!encadenada) { const sv=servicioLocal(body.clienteId,compraId); if(sv&&sv.updatedAt&&!sv._pendiente) body.esperado={servicioUpdatedAt:String(sv.updatedAt)}; }
  return body;
}
export async function enqueueOp(op) {
  const item={createdAt:Date.now(),estado:'pendiente',intentos:0,...op,body:prepararCuerpoCola(op,state.pendingOps||[])};
  state.pendingOps=[...(state.pendingOps||[]),item];
  await saveQueue(state.session.usuario,state.pendingOps);
  await anotar(state.session.usuario,item,'pendiente');
  persistOfflineSnapshot();
  return item;
}
export function dmyPlusDays(dmy='',days=30) {
  const base=parseDateDMY(dmy)||(()=>{const d=new Date();d.setHours(12,0,0,0);return d;})();
  const d=new Date(base); d.setDate(d.getDate()+Number(days||0));
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}
export const realClientId=id=>String(id||'').startsWith('local_')?'':String(id||'');
const idServidor=(r={})=>String(r.movimientoId||r.operacionId||r.compraId||r.clienteId||r.pagoOperacion?.operacionId||r.fechaNueva||r.id||'').slice(0,80);
function opConfirmed(op,r) {
  if (!r||r.ok===false||r.error) return false;
  if (op.kind==='ficha') return r.guardadoEnFirebase===true||Boolean(r.clienteId);
  if (op.kind==='renovacion') return r.verified===true||r.ok===true;
  return true;
}
let flushing=false;
export async function flushQueue() {
  if (flushing||!state.session||!canOffline()||deviceOffline()) return;
  const usuario=state.session.usuario;
  let queue=await loadQueue(usuario);
  if (!queue.length) { state.pendingOps=[]; return; }
  flushing=true; let ok=0, touchedFinance=false;
  try {
    while (queue.length) {
      const op={...queue[0],estado:'enviando',intentos:(Number(queue[0].intentos)||0)+1};
      queue=[op,...queue.slice(1)]; state.pendingOps=queue; await saveQueue(usuario,queue); hooks.render(); // «Enviando» queda guardado: si se corta, se reintenta igual
      try {
        const r=await authPost(op.path,op.body);
        if (r?.conflicto) throw Object.assign(new Error(r.error||'Conflicto con el servidor.'),{conflicto:r.conflicto,status:200});
        if (!opConfirmed(op,r)) throw Object.assign(new Error(r?.error||'El servidor no confirmó el cambio.'),{status:200});
        ok+=1; if (op.path==='/api/finanzas') touchedFinance=true;
        await anotar(usuario,op,'confirmado',{serverId:idServidor(r)});
      } catch (e) {
        if (isOfflineError(e)||e?.updateRequired||(Number(e?.status)===409&&e?.data?.retryable)) { queue=[{...op,estado:'pendiente'},...queue.slice(1)]; state.pendingOps=queue; await saveQueue(usuario,queue); break; } // queda en cola, se reintenta luego
        const conf=e?.conflicto||e?.data?.conflicto||null; if(conf&&!e.conflicto)e.conflicto=conf; // authPost puede lanzar con la respuesta en e.data
        const estado=conf?'revision':'rechazado';
        state.failedOps=[...(state.failedOps||[]),{label:op.label,error:e?.message||'Error',estado}];
        await anotar(usuario,op,estado,{error:String(e?.message||'Error').slice(0,300),conflicto:e?.conflicto?.codigo||''});
      }
      queue=queue.slice(1);
      if (!state.session||state.session.usuario!==usuario) return;
      state.pendingOps=queue; await saveQueue(usuario,queue); hooks.render();
    }
  } finally { flushing=false; }
  if (ok) {
    showToast(`✅ ${ok} cambio${ok===1?'':'s'} hecho${ok===1?'':'s'} sin conexión ya se guardaron.`);
    hooks.reload(touchedFinance?['clients','finances']:['clients']);
  }
}
if (typeof window!=='undefined') window.addEventListener?.('online',()=>setTimeout(()=>{ if(state.session){ flushQueue(); hooks.reload(['clients']); } },1500));
if (typeof window!=='undefined') { window.addEventListener?.('offline',()=>hooks.render()); window.addEventListener?.('online',()=>hooks.render()); } // R198 · la banda aparece/desaparece al instante
const flushTimer=setInterval(()=>{ if(state.session&&(state.pendingOps||[]).length&&!deviceOffline())flushQueue(); },30000);
flushTimer?.unref?.();
// Lo creado sin señal se ve de una vez en la app (marcado como pendiente).
export function applyLocalFicha(payload) {
  const servicio={...payload.servicio,_pendiente:true};
  const clients=[...(state.clients||[])];
  const tel=v=>telefonoClave(v);
  const nm=v=>String(v||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  let idx=payload.clienteId?clients.findIndex(c=>String(c.id)===String(payload.clienteId)):-1;
  if (idx<0) idx=clients.findIndex(c=>nm(c.nombrePerfil||c.nombre)===nm(payload.cliente?.nombrePerfil)&&tel(c.telefono)===tel(payload.cliente?.telefono));
  if (idx<0) { const id=`local_${servicio.compraId}`; clients.unshift({id,nombrePerfil:payload.cliente?.nombrePerfil||'',telefono:payload.cliente?.telefono||'',vendedor:payload.cliente?.vendedor||'',servicios:[servicio],_pendiente:true}); state.clients=clients; return id; }
  const c={...clients[idx]}; const servs=[...(c.servicios||[])];
  const si=servs.findIndex(x=>String(x?.compraId||'')===String(servicio.compraId));
  if (si>=0) servs[si]=servicio; else servs.push(servicio);
  c.servicios=servs; clients[idx]=c; state.clients=clients; return c.id;
}
export function offlineSyncText(ms=0) {
  if (!ms) return 'sin fecha';
  const d=new Date(ms); return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')} ${`${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`}`;
}
const horaOp=(ms)=>{ if(!ms) return ''; const d=new Date(ms), p2=n=>String(n).padStart(2,'0'); return `${p2(d.getDate())}/${p2(d.getMonth()+1)} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
// Historial local verificable: lo pendiente (estado real de la cola) + lo ya resuelto (confirmado con ID, rechazado, revisión).
export function historialColaHtml() {
  const pend=(state.pendingOps||[]).map(o=>({label:o.label||o.kind,estado:o.estado||'pendiente',at:o.createdAt,intentos:o.intentos}));
  const pendIds=new Set((state.pendingOps||[]).map(o=>String(o?.body?.operationId||'')));
  const hechos=(state.opsHistorial||[]).filter(h=>!pendIds.has(h.id)&&h.estado!=='pendiente').slice(0,15);
  if (!pend.length&&!hechos.length) return '';
  const fila=(x)=>`<span class="op-${esc(x.estado)}"><b>${esc(ESTADOS_OP[x.estado]||x.estado)}</b> · ${esc(x.label||'Cambio')}${x.at?` · ${esc(horaOp(x.at))}`:''}${x.serverId?` · ID ${esc(x.serverId)}`:''}${x.error?` · ${esc(x.error)}`:''}${x.intentos>1?` · intento ${x.intentos}`:''}</span>`;
  return `<details class="offline-pend"><summary>${pend.length?`Ver pendientes (${pend.length})`:'Historial de cambios sin conexión'}</summary>${pend.map(fila).join('')}${hechos.map(fila).join('')}</details>`;
}
export function offlineBanners() {
  if (!state.session) return '';
  const pend=(state.pendingOps||[]).length, failed=state.failedOps||[];
  let html='';
  if (deviceOffline()||state.sync==='offline') {
    const d=state.offlineSyncedAt?new Date(state.offlineSyncedAt):null, p2=n=>String(n).padStart(2,'0');
    const cuando=d?`${p2(d.getDate())}/${p2(d.getMonth()+1)}/${d.getFullYear()}, ${p2(d.getHours())}:${p2(d.getMinutes())}`:'sin copia en este equipo';
    html+=`<div class="offline-band" role="status"><b>SIN CONEXIÓN</b><small>Trabajando con datos guardados · Última sincronización: ${esc(cuando)}${pend?` · Pendientes de sincronizar: ${pend} (no confirmados por el servidor)`:''}</small>${avisoCuentasHtml()}${avisoVistaHtml()}${historialColaHtml()}<button type="button" id="offlineRetry">Reintentar</button></div>`;
  }
  else if (pend) html+=`<div class="offline-band sube" role="status"><b>SUBIENDO CAMBIOS</b><small>${pend} cambio${pend===1?'':'s'} hecho${pend===1?'':'s'} sin conexión · se confirman uno por uno con el servidor</small>${historialColaHtml()}<button type="button" id="offlineRetry">Reintentar</button></div>`;
  if (failed.length) html+=`<div class="offline-banner failed" role="alert">⚠️ <b>${failed.length} cambio${failed.length===1?'':'s'} sin aplicar:</b> ${failed.map(f=>`<b>${esc(ESTADOS_OP[f.estado]||'Rechazado')}</b> · ${esc(f.label)} (${esc(f.error)})`).join(' · ')}<button type="button" id="offlineFailedOk">Entendido</button></div>`;
  return html;
}
