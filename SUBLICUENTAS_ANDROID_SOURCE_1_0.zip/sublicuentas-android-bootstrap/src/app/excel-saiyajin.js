// src/app/excel-saiyajin.js · R117 — Excel "nivel Saiyajin" en la APK.
// Mismo formato que el reporte del bot (franja roja, subtítulo negro, encabezados negros, moneda "Lps", filas alternas,
// filtros y totales) y MISMA data: /api/finanzas → finanzas_reporte (libro mayor central). No calcula nada aparte.
const C = { rojo: 'FFE2231A', negro: 'FF0A0A1A', blanco: 'FFFFFFFF', zebra: 'FFF4F6F8', verde: 'FF16A34A', verdeClaro: 'FFE6F4EA', rojoClaro: 'FFFCE8E6', beige: 'FFFFF7ED' };
const MONEY = '"Lps " #,##0.00';
const BORDE = { top: { style: 'thin', color: { argb: 'FFE7E9EF' } }, left: { style: 'thin', color: { argb: 'FFE7E9EF' } }, bottom: { style: 'thin', color: { argb: 'FFE7E9EF' } }, right: { style: 'thin', color: { argb: 'FFE7E9EF' } } };
const dmy = (ymd = '') => { const [y, m, d] = String(ymd).split('-'); return d ? `${d}/${m}/${y}` : String(ymd || ''); };
const fill = (cell, argb) => { cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb } }; };

function titulo(ws, t, sub, cols) {
  ws.addRow([]);
  const r1 = ws.addRow([t]); r1.height = 32; ws.mergeCells(r1.number, 1, r1.number, cols);
  fill(r1.getCell(1), C.rojo); r1.getCell(1).font = { bold: true, size: 16, color: { argb: C.blanco } }; r1.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
  const r2 = ws.addRow([sub]); r2.height = 22; ws.mergeCells(r2.number, 1, r2.number, cols);
  fill(r2.getCell(1), C.negro); r2.getCell(1).font = { bold: true, size: 10, color: { argb: C.blanco } }; r2.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
  ws.addRow([]);
}
function hoja(wb, nombre, t, sub, headers, widths, rows, money = [], totalCols = []) {
  const ws = wb.addWorksheet(nombre);
  ws.columns = widths.map((width) => ({ width }));
  titulo(ws, t, sub, headers.length);
  const h = ws.addRow(headers); h.height = 24;
  h.eachCell((c) => { fill(c, C.negro); c.font = { bold: true, color: { argb: C.blanco } }; c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true }; c.border = BORDE; });
  const first = ws.rowCount + 1;
  rows.forEach((vals, i) => {
    const r = ws.addRow(vals);
    r.eachCell({ includeEmpty: true }, (c) => { c.border = BORDE; if (i % 2) fill(c, C.zebra); });
    money.forEach((k) => { r.getCell(k).numFmt = MONEY; });
  });
  if (rows.length && totalCols.length) {
    const last = ws.rowCount, t2 = ws.addRow(headers.map((_, i) => (i === 0 ? 'TOTAL' : '')));
    totalCols.forEach((k) => { const L = String.fromCharCode(64 + k); t2.getCell(k).value = { formula: `SUM(${L}${first}:${L}${last})`, result: rows.reduce((a, r) => a + Number(r[k - 1] || 0), 0) }; t2.getCell(k).numFmt = MONEY; });
    t2.eachCell({ includeEmpty: true }, (c) => { fill(c, C.verde); c.font = { bold: true, color: { argb: C.blanco } }; c.border = BORDE; });
  }
  ws.views = [{ state: 'frozen', ySplit: first - 1 }];
  ws.autoFilter = { from: { row: first - 1, column: 1 }, to: { row: first - 1, column: headers.length } };
  return ws;
}

export function buildSaiyajinWorkbook(ExcelJS, d = {}) {
  const wb = new ExcelJS.Workbook(); wb.creator = 'Sublichat APK'; wb.created = new Date();
  const sub = `Período ${dmy(d.desde)} al ${dmy(d.hasta)} · generado desde la APK`;
  const t = d.totales || {}, cart = d.cartera || {};
  // Resumen
  const res = wb.addWorksheet('Resumen'); res.columns = [{ width: 4 }, { width: 38 }, { width: 20 }, { width: 4 }, { width: 46 }];
  titulo(res, 'REPORTE FINANCIERO · SUBLICUENTAS', sub, 5);
  const pend = Number(cart.pendienteClientes || 0) + Number(cart.pendienteVendedores || 0);
  [['Ventas generadas', t.ventasGeneradas, 'Valor acordado (no es efectivo)'], ['Dinero real recibido', t.ingresos, 'Cobros y abonos que sí entraron a bancos', C.verdeClaro],
    ['Egresos operativos', t.egresosOperativos, 'Gastos (sin planilla)', C.rojoClaro], ['Disponible antes de planilla', t.disponibleAntesPlanilla, 'Ingresos − egresos operativos'],
    ['Planilla / comisiones', t.planilla, 'Pagos confirmados'], ['Resultado después de planilla', t.resultado, 'Disponible − planilla'],
    ['Pendiente clientes (hoy)', cart.pendienteClientes, 'NO suma a bancos'], ['Pendiente vendedores (hoy)', cart.pendienteVendedores, 'NO suma a bancos'],
    ['Pendiente total (NO es dinero disponible)', pend, 'Cartera por cobrar', C.beige], ['Saldo real en bancos (hoy)', d.totalBancos, 'Bancos de mayor a menor en la hoja Bancos']]
    .forEach(([l, v, x, bg]) => { const r = res.addRow(['', l, Number(v || 0), '', x]); r.getCell(3).numFmt = MONEY; [2, 3, 5].forEach((k) => { r.getCell(k).border = BORDE; if (bg) fill(r.getCell(k), bg); }); r.getCell(2).font = { bold: true }; });
  // Ingresos (un pago por cliente) y egresos
  hoja(wb, 'Ingresos', 'DETALLE DE INGRESOS', `${sub} · ${(d.ingresos || []).length} pagos`, ['Fecha', 'Plataforma', 'Monto', 'Banco', 'Usuario', 'Detalle', 'Categoría'], [12, 30, 14, 18, 22, 32, 24],
    (d.ingresos || []).map((m) => [dmy(m.fecha), m.plataforma || '—', Number(m.monto || 0), m.banco || '', m.usuario || '', m.cliente || m.detalle || m.socio || '', m.categoriaLabel || '']), [3], [3]);
  hoja(wb, 'Egresos', 'DETALLE DE EGRESOS OPERATIVOS', sub, ['Fecha', 'Concepto', 'Monto', 'Banco', 'Usuario'], [12, 38, 14, 18, 22],
    (d.egresos || []).map((m) => [dmy(m.fecha), m.detalle || '', Number(m.monto || 0), m.banco || '', m.usuario || '']), [3], [3]);
  // Bancos: de mayor a menor saldo
  hoja(wb, 'Bancos', 'SALDO REAL POR BANCO (HOY)', 'Ordenado de mayor a menor saldo', ['Banco', 'Ingresos', 'Egresos', 'Planilla', 'Ajustes / transferencias', 'Saldo'], [22, 14, 14, 14, 20, 16],
    [...(d.saldos || [])].filter((b) => b.activado).sort((a, b) => Number(b.saldo || 0) - Number(a.saldo || 0)).map((b) => [b.nombre, b.ingresos, b.egresosOperativos, b.planilla, Number(b.ajustes || 0) + Number(b.transferencias || 0), b.saldo]), [2, 3, 4, 5, 6], [6]);
  // Planilla y distribución
  hoja(wb, 'Planilla', 'PLANILLA / COMISIONES', sub, ['Fecha', 'Beneficiario', 'Concepto', 'Monto total', 'Confirmó'], [12, 24, 24, 14, 16],
    (d.planillaPagos || []).map((p) => [dmy(p.fecha), p.beneficiario, p.conceptoLabel || p.concepto, Number(p.montoTotal || 0), p.registradoPor || '']), [4], [4]);
  const dist = []; for (const p of d.planillaPagos || []) for (const a of p.asignaciones || []) dist.push([dmy(p.fecha), p.beneficiario, a.banco || a.bancoId, Number(a.monto || 0), Number(a.saldoAntes || 0), Number(a.saldoDespues || 0)]);
  hoja(wb, 'Distribución Planilla', 'DISTRIBUCIÓN DE PLANILLA POR BANCO', sub, ['Fecha', 'Beneficiario', 'Banco', 'Monto tomado', 'Saldo antes', 'Saldo después'], [12, 24, 20, 14, 14, 14], dist, [4, 5, 6], [4]);
  // Pendientes (no es efectivo)
  hoja(wb, 'Pendientes Cobro', 'PENDIENTES DE COBRO (CLIENTES / VENDEDORES)', 'Estado actual · NO es dinero disponible', ['Tipo', 'Deudor', 'Origen', 'Plataforma', 'Total', 'Saldo', 'Estado'], [12, 24, 14, 22, 13, 13, 12],
    (cart.cuentas || []).map((c) => [c.deudorTipo === 'vendedor' ? 'Vendedor' : 'Cliente', c.deudorNombre || '', c.tipoOrigen === 'compra' ? 'Compra' : 'Renovación', c.plataforma || '', Number(c.montoTotalOperacion || 0), Number(c.saldoPendiente || 0), String(c.estado || '').toUpperCase()]), [5, 6], [6]);
  hoja(wb, 'Cierres', 'CIERRES DE CICLO', sub, ['Inicio', 'Fin', 'Ingresos', 'Egresos', 'Planilla', 'Resultado', 'Cerrado por'], [12, 12, 14, 14, 14, 14, 16],
    (d.cierres || []).map((c) => [dmy(c.fechaInicio), dmy(c.fechaFin), c.ingresos, c.egresosOperativos, c.planilla, c.resultado, c.cerradoPor || '']), [3, 4, 5, 6]);
  return wb;
}

function aYmd(v) {
  if (v instanceof Date && !Number.isNaN(v.getTime())) return `${v.getFullYear()}-${String(v.getMonth() + 1).padStart(2, '0')}-${String(v.getDate()).padStart(2, '0')}`;
  const s = String(v || ''); const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s.slice(0, 10) : '';
}
// Exporta el Saiyajin: pide la data al servidor, arma el libro y lo GUARDA en el teléfono (compartir es opcional).
export async function exportarSaiyajin({ authPost, saveAndShareXlsx, scope = 'todo', range = {} }) {
  const body = { accion: 'finanzas_reporte', ...(scope === 'todo' ? {} : { desde: aYmd(range.desde), hasta: aYmd(range.hasta) }) };
  const data = await authPost('/api/finanzas', body);
  if (!data?.ok) throw new Error(data?.error || 'No se pudo leer Finanzas para el Excel.');
  const mod = await import('exceljs/dist/exceljs.min.js'); const ExcelJS = mod.default || mod;
  const wb = buildSaiyajinWorkbook(ExcelJS, data);
  const nombre = `finanzas_saiyajin_${String(data.desde).split('-').reverse().join('-')}_${String(data.hasta).split('-').reverse().join('-')}.xlsx`;
  return saveAndShareXlsx(nombre, await wb.xlsx.writeBuffer());
}
