// R155 · Oct-2026 · La ficha guardada es una "foto" del día de la entrega. Si después se cambia correo/clave/PIN
// o se renueva, esa foto queda vieja: solo se usa si todavía tiene TODOS los datos actuales; si no, la APK
// arma la ficha de nuevo con los datos al día (igual que la Web).
export function crmFichaVigente(d) {
  const txt = String(d?.fichaTexto || '');
  if (!txt.trim()) return false;
  const vals = [String(d.fechaRenovacion || '').trim()];
  (d.perfiles || []).forEach((p) => vals.push(String(p.correo || '').trim(), String(p.clave || '').trim(), String(p.pinPerfil || '').trim()));
  return vals.filter((v) => v && v !== '—').every((v) => txt.includes(v));
}
// Deja el borrador sin ficha guardada si quedó vieja (la pantalla la vuelve a armar sola).
export function fichaAlDia(d) { if (d && d.fichaTexto && !crmFichaVigente(d)) d.fichaTexto = ''; return d; }
