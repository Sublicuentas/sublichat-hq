// Motores puros de los 3 juegos (sin DOM, sin temporizadores reales): reciben estado + acción, devuelven
// el nuevo estado. La pantalla (juegos.js) solo pinta este estado y llama a estas funciones ante cada toque.
import { HANGMAN_WORDS, WORDSEARCH_SETS, MEMORY_SYMBOLS } from './juegos-data.js';

const shuffle = (arr, rnd = Math.random) => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; } return a; };
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

/* ═════════════════════ PARES DE CARTAS (MEMORY_PAIRS) ═════════════════════ */
export function memoryCreate(pairCount = 12, rnd = Math.random) {
  const symbols = shuffle(MEMORY_SYMBOLS, rnd).slice(0, pairCount);
  const cards = shuffle(symbols.flatMap((s, i) => [{ symbol: s, pairId: i }, { symbol: s, pairId: i }]), rnd).map((c, i) => ({ ...c, id: i, matched: false }));
  return { cards, flipped: [], pairsFound: 0, moves: 0, combo: 0, maxCombo: 0, pending: false, startedAt: Date.now(), finishedAt: null };
}
export function memoryFlip(state, index) {
  if (state.pending || state.finishedAt) return state;
  const card = state.cards[index];
  if (!card || card.matched || state.flipped.includes(index)) return state;
  const flipped = [...state.flipped, index];
  if (flipped.length < 2) return { ...state, flipped };
  const [a, b] = flipped; const match = state.cards[a].symbol === state.cards[b].symbol;
  const moves = state.moves + 1;
  if (match) {
    const combo = state.combo + 1; const maxCombo = Math.max(state.maxCombo, combo);
    const cards = state.cards.map((c, i) => (i === a || i === b ? { ...c, matched: true } : c));
    const pairsFound = state.pairsFound + 1;
    const finishedAt = pairsFound === state.cards.length / 2 ? Date.now() : null;
    return { ...state, cards, flipped: [], moves, combo, maxCombo, pairsFound, finishedAt };
  }
  return { ...state, flipped, moves, combo: 0, pending: true }; // se resuelve (oculta) con memoryResolveMismatch tras una pausa visual
}
export function memoryResolveMismatch(state) { return state.pending ? { ...state, flipped: [], pending: false } : state; }
export function memorySubmission(state, timeLimitSec = 120) {
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { pairsFound: state.pairsFound, moves: Math.max(state.cards.length / 2, state.moves), maxCombo: state.maxCombo, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

/* ═════════════════════ EL AHORCADO (HANGMAN) ═════════════════════ */
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
export function hangmanCreate(rounds = 5, maxErrors = 7, maxHints = 2, rnd = Math.random) {
  const pool = shuffle(HANGMAN_WORDS, rnd).slice(0, rounds);
  return {
    rounds: pool.map(p => ({ word: norm(p.word), category: p.category, clue: p.clue, guessed: [], wrong: [], solved: false, gaveUp: false })),
    roundIndex: 0, maxErrors, hintsUsed: 0, maxHints, startedAt: Date.now(), finishedAt: null,
  };
}
export function hangmanGuess(state, letterRaw) {
  const letter = norm(letterRaw).slice(0, 1);
  if (!/^[A-Z]$/.test(letter) || state.finishedAt) return state;
  const round = state.rounds[state.roundIndex]; if (!round || round.solved || round.gaveUp) return state;
  if (round.guessed.includes(letter) || round.wrong.includes(letter)) return state;
  const hit = round.word.includes(letter);
  const nRound = hit
    ? { ...round, guessed: [...round.guessed, letter] }
    : { ...round, wrong: [...round.wrong, letter] };
  nRound.solved = [...nRound.word].every(ch => nRound.guessed.includes(ch));
  nRound.gaveUp = !nRound.solved && nRound.wrong.length >= state.maxErrors;
  const rounds = state.rounds.map((r, i) => (i === state.roundIndex ? nRound : r));
  const done = nRound.solved || nRound.gaveUp;
  const isLast = state.roundIndex === state.rounds.length - 1;
  const roundIndex = done && !isLast ? state.roundIndex + 1 : state.roundIndex;
  const finishedAt = done && isLast ? Date.now() : null;
  return { ...state, rounds, roundIndex, finishedAt };
}
export function hangmanHint(state) {
  if (state.hintsUsed >= state.maxHints || state.finishedAt) return state;
  const round = state.rounds[state.roundIndex]; if (!round || round.solved || round.gaveUp) return state;
  const missing = [...new Set([...round.word])].find(ch => !round.guessed.includes(ch)); if (!missing) return state;
  return hangmanGuess({ ...state, hintsUsed: state.hintsUsed + 1 }, missing);
}
export function hangmanSubmission(state, timeLimitSec = 180) {
  const solvedWords = state.rounds.filter(r => r.solved).length;
  const totalWrongLetters = state.rounds.reduce((t, r) => t + r.wrong.length, 0);
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { solvedWords, totalWrongLetters, hintsUsed: state.hintsUsed, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

/* ═════════════════════ SOPA DE LETRAS (WORD_SEARCH) ═════════════════════ */
const DIRS = [[0, 1], [1, 0], [1, 1], [1, -1], [0, -1], [-1, 0], [-1, -1], [-1, 1]]; // incluye reversa (spec: palabras invertidas)
function tryBuildGrid(size, words, rnd) {
  const grid = Array.from({ length: size }, () => Array(size).fill(''));
  const placed = [];
  // Las palabras más largas son las más difíciles de encajar: se colocan primero, con la rejilla más vacía.
  const ordered = words.slice().sort((a, b) => b.word.length - a.word.length);
  for (const { word, category } of ordered) {
    const w = word; let ok = false;
    for (let attempt = 0; attempt < 400 && !ok; attempt++) {
      const [dr, dc] = DIRS[Math.floor(rnd() * DIRS.length)];
      const r0 = Math.floor(rnd() * size), c0 = Math.floor(rnd() * size);
      const r1 = r0 + dr * (w.length - 1), c1 = c0 + dc * (w.length - 1);
      if (r1 < 0 || r1 >= size || c1 < 0 || c1 >= size) continue;
      let fits = true;
      for (let i = 0; i < w.length; i++) { const cell = grid[r0 + dr * i][c0 + dc * i]; if (cell && cell !== w[i]) { fits = false; break; } }
      if (!fits) continue;
      for (let i = 0; i < w.length; i++) grid[r0 + dr * i][c0 + dc * i] = w[i];
      placed.push({ id: `w${placed.length}`, word: w, category, start: [r0, c0], end: [r1, c1], found: false });
      ok = true;
    }
    if (!ok) return null; // esta rejilla no alcanzó: se reintenta completa (ver wordSearchCreate)
  }
  return { grid, placed };
}
export function wordSearchCreate(size = 12, setIndex = 0, rnd = Math.random) {
  const set = WORDSEARCH_SETS[setIndex % WORDSEARCH_SETS.length];
  const words = set.words.map(w => ({ word: norm(w.word), category: w.category }));
  let built = null;
  for (let round = 0; round < 12 && !built; round++) built = tryBuildGrid(size, words, rnd);
  if (!built) { // muy improbable (12 intentos de rejilla completa); nunca se entrega un tablero con palabras faltantes
    const bigger = tryBuildGrid(size + 2, words, rnd);
    built = bigger || { grid: Array.from({ length: size }, () => Array(size).fill('A')), placed: [] };
    if (bigger) size += 2;
  }
  const { grid, placed } = built;
  // El orden en pantalla sigue siendo el original (no el de longitud) para que la lista de "palabras a encontrar" no salte.
  const placedById = new Map(placed.map(p => [p.word, p]));
  const orderedForDisplay = words.map(w => placedById.get(w.word)).filter(Boolean);
  const ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) if (!grid[r][c]) grid[r][c] = ABC[Math.floor(rnd() * ABC.length)];
  return { size, grid, words: orderedForDisplay, selectStart: null, wrongSelections: 0, hintsUsed: 0, combo: 0, maxCombo: 0, startedAt: Date.now(), finishedAt: null };
}
const sameLine = (r0, c0, r1, c1) => { const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0); return (dr === 0 || dc === 0 || Math.abs(r1 - r0) === Math.abs(c1 - c0)); };
export function wordSearchSelect(state, r, c) {
  if (state.finishedAt) return state;
  if (!state.selectStart) return { ...state, selectStart: [r, c] };
  const [r0, c0] = state.selectStart;
  if (r0 === r && c0 === c) return { ...state, selectStart: null };
  if (!sameLine(r0, c0, r, c)) return { ...state, selectStart: [r, c] }; // reinicia selección con el nuevo punto
  const dr = Math.sign(r - r0), dc = Math.sign(c - c0);
  const len = Math.max(Math.abs(r - r0), Math.abs(c - c0)) + 1;
  const cells = Array.from({ length: len }, (_, i) => [r0 + dr * i, c0 + dc * i]);
  const text = cells.map(([rr, cc]) => state.grid[rr][cc]).join('');
  const rev = [...text].reverse().join('');
  const hit = state.words.find(w => !w.found && (w.word === text || w.word === rev));
  if (hit) {
    const words = state.words.map(w => (w.id === hit.id ? { ...w, found: true, cells } : w));
    const combo = state.combo + 1; const maxCombo = Math.max(state.maxCombo, combo);
    const finishedAt = words.every(w => w.found) ? Date.now() : null;
    return { ...state, words, selectStart: null, combo, maxCombo, finishedAt };
  }
  return { ...state, selectStart: null, wrongSelections: state.wrongSelections + 1, combo: 0 };
}
export function wordSearchHint(state) {
  if (state.finishedAt) return state;
  const target = state.words.find(w => !w.found); if (!target) return state;
  const [r0, c0] = target.start; const [r1, c1] = target.end;
  const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0);
  const cells = Array.from({ length: target.word.length }, (_, i) => [r0 + dr * i, c0 + dc * i]);
  const words = state.words.map(w => (w.id === target.id ? { ...w, found: true, cells, hinted: true } : w));
  const finishedAt = words.every(w => w.found) ? Date.now() : null;
  return { ...state, words, selectStart: null, hintsUsed: state.hintsUsed + 1, combo: 0, finishedAt };
}
export function wordSearchSubmission(state, timeLimitSec = 240) {
  const foundWords = state.words.filter(w => w.found && !w.hinted).length + state.words.filter(w => w.hinted).length;
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { foundWords, wrongSelections: state.wrongSelections, hintsUsed: state.hintsUsed, maxCombo: state.maxCombo, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

export const genRoundId = uid;

/* ═════════════════════ BÁSQUET (BASKETBALL) · R55 ═════════════════════
   Tiro parabólico real: el jugador define ángulo y fuerza; la pelota sale de (0,0) y debe entrar al aro
   en (dx,dy) BAJANDO (como en la vida real). El aro cambia de lugar en cada tiro. */
export const BASKET_G = 100;
const basketHoop = rnd => ({ dx: Math.round(160 + rnd() * 140), dy: Math.round(55 + rnd() * 60) });
export function basketballCreate(shots = 5, rnd = Math.random) {
  return { total: shots, shots: [], hoop: basketHoop(rnd), made: 0, streak: 0, maxStreak: 0, angle: 55, power: 50, lastPath: null, lastResult: null, startedAt: Date.now(), finishedAt: null, _rnd: rnd };
}
export function basketballVelocity(power) { return 60 + Math.max(0, Math.min(100, Number(power) || 0)) * 2; }
export function basketballHeightAt(x, angleDeg, power) {
  const t = angleDeg * Math.PI / 180, v = basketballVelocity(power), c = Math.cos(t);
  return x * Math.tan(t) - (BASKET_G * x * x) / (2 * v * v * c * c);
}
export function basketballShoot(state, angleDeg, power) {
  if (state.finishedAt || state.shots.length >= state.total) return state;
  const angle = Math.max(20, Math.min(80, Number(angleDeg) || 55)), pw = Math.max(0, Math.min(100, Number(power) || 0));
  const { dx, dy } = state.hoop;
  const yAt = basketballHeightAt(dx, angle, pw);
  const descending = basketballHeightAt(dx + 1, angle, pw) < yAt;
  const diff = yAt - dy;
  const made = Math.abs(diff) <= 9 && descending;
  const rim = !made && Math.abs(diff) <= 18;
  const path = [];
  for (let x = 0; x <= dx + 60; x += 6) { const y = basketballHeightAt(x, angle, pw); path.push([x, Math.round(y * 10) / 10]); if (y < -30) break; }
  const streak = made ? state.streak + 1 : 0;
  const swish = made && Math.abs(diff) <= 3;
  const accuracy = Math.max(0, Math.round(100 - Math.abs(diff) * 2.5));
  const shots = [...state.shots, { made, swish, accuracy, angle, power: pw }];
  const feedback = made ? (swish ? '¡Limpia! Ni tocó el aro 🏀✨' : streak >= 3 ? `¡Encestó! Racha x${streak} 🔥` : '¡Encestó! 🏀') : rim ? '¡Casi! Pegó en el aro.' : (!descending && diff > 0) ? 'Muy fuerte: la pelota iba subiendo.' : diff > 0 ? 'Se pasó por arriba: baje un poco la fuerza.' : 'Le faltó: suba la fuerza o el ángulo.';
  const done = shots.length >= state.total;
  return { ...state, angle, power: pw, shots, made: state.made + (made ? 1 : 0), streak, maxStreak: Math.max(state.maxStreak, streak), lastPath: path, lastResult: { made, rim, feedback, hoop: state.hoop }, hoop: done ? state.hoop : basketHoop(state._rnd || Math.random), finishedAt: done ? Date.now() : null };
}
export function basketballSubmission(state) {
  // Métricas que el servidor (api/juegos.js) usa para calcular los puntos oficiales.
  const n = state.shots.length || 1;
  return { made: state.made, swish: state.shots.filter(x => x.swish).length, bestStreak: state.maxStreak, avgAccuracy: Math.round(state.shots.reduce((t, x) => t + (x.accuracy || 0), 0) / n) };
}

/* ═════════════════════ DARDOS (DARTS) · R58 ═════════════════════
   Cuenta regresiva: se empieza en 150 y hay que llegar EXACTO a 0. Si un dardo se pasa, no resta ("se pasó").
   La mira se mueve sola (curva de Lissajous) y acelera un poco con cada dardo. Máximo 30 dardos.
   Diana: 50 · 25 · 15 · 10 · 5 · 1. Lo ideal (más puntos) es cerrar en 9 dardos o menos. */
export const DART_RINGS = [[0.07, 50], [0.16, 25], [0.36, 15], [0.56, 10], [0.78, 5], [1, 1]];
export const DART_TARGET = 150, DART_MAX = 30;
export function dartsCreate(target = DART_TARGET, rnd = Math.random) {
  return { target, remaining: target, throws: [], max: DART_MAX, bulls: 0, lastBust: false, phase: rnd() * 6, startedAt: Date.now(), finishedAt: null, finished: false };
}
export function dartsAimAt(state, ms) {
  const sp = 1 + Math.min(state.throws.length, 15) * 0.06;
  const t = ms / 1000;
  return { x: 0.88 * Math.sin(t * 1.9 * sp + state.phase), y: 0.88 * Math.sin(t * 2.6 * sp + state.phase * 1.7 + 1.1) };
}
export function dartsPoints(x, y) {
  const d = Math.hypot(x, y);
  for (const [r, p] of DART_RINGS) if (d <= r) return p;
  return 0;
}
export function dartsThrow(state, x, y) {
  if (state.finishedAt || state.throws.length >= state.max) return state;
  const px = Math.max(-1.2, Math.min(1.2, Number(x) || 0)), py = Math.max(-1.2, Math.min(1.2, Number(y) || 0));
  const points = dartsPoints(px, py);
  const bust = points > state.remaining;
  const remaining = bust ? state.remaining : state.remaining - points;
  const accuracy = Math.max(0, Math.round((1 - Math.min(1, Math.hypot(px, py))) * 100));
  const throws = [...state.throws, { x: px, y: py, points, bust, accuracy }];
  const finished = remaining === 0;
  const done = finished || throws.length >= state.max;
  return { ...state, throws, remaining, lastBust: bust, bulls: state.bulls + (points === 50 && !bust ? 1 : 0), finished, finishedAt: done ? Date.now() : null };
}
export function dartsSubmission(state) {
  const n = state.throws.length || 1;
  return { finished: state.finished === true, dartsUsed: state.throws.length, avgAccuracy: Math.round(state.throws.reduce((t, d) => t + (d.accuracy || 0), 0) / n), bonusHits: state.bulls };
}

/* ═════════════════════ COLOREAR (COLOR_CHALLENGE) · R55 ═════════════════════
   Dibujos hechos de regiones SVG; se elige un color y se toca cada región. Termina al pintar todo. */
const P = n => Math.round(n * 10) / 10;
function petal(cx, cy, r0, r1, a, w) {
  const ax = cx + r0 * Math.cos(a), ay = cy + r0 * Math.sin(a);
  const bx = cx + r1 * Math.cos(a), by = cy + r1 * Math.sin(a);
  const mid = (r0 + r1) / 2, c1x = cx + mid * Math.cos(a - w), c1y = cy + mid * Math.sin(a - w), c2x = cx + mid * Math.cos(a + w), c2y = cy + mid * Math.sin(a + w);
  return `M${P(ax)} ${P(ay)}Q${P(c1x)} ${P(c1y)} ${P(bx)} ${P(by)}Q${P(c2x)} ${P(c2y)} ${P(ax)} ${P(ay)}Z`;
}
function ringSeg(cx, cy, r0, r1, a0, a1) {
  const p = (r, a) => `${P(cx + r * Math.cos(a))} ${P(cy + r * Math.sin(a))}`;
  return `M${p(r0, a0)}L${p(r1, a0)}A${r1} ${r1} 0 0 1 ${p(r1, a1)}L${p(r0, a1)}A${r0} ${r0} 0 0 0 ${p(r0, a0)}Z`;
}
export const COLOR_DESIGNS = [
  { id: 'mandala', name: 'Mandala', build() {
    const R = []; const c = 150;
    R.push(`M${c - 22} ${c}a22 22 0 1 0 44 0a22 22 0 1 0 -44 0Z`);
    for (let i = 0; i < 8; i++) R.push(petal(c, c, 24, 80, i * Math.PI / 4, 0.32));
    for (let i = 0; i < 16; i++) R.push(petal(c, c, 84, 118, i * Math.PI / 8 + Math.PI / 16, 0.16));
    for (let i = 0; i < 8; i++) R.push(ringSeg(c, c, 122, 142, i * Math.PI / 4, (i + 1) * Math.PI / 4));
    return R;
  } },
  { id: 'vitral', name: 'Vitral', build() {
    const R = []; const n = 4, s = 70, o = 10;
    for (let r = 0; r < n; r++) for (let q = 0; q < n; q++) {
      const x = o + q * s, y = o + r * s;
      if ((r + q) % 2) { R.push(`M${x} ${y}L${x + s} ${y}L${x} ${y + s}Z`); R.push(`M${x + s} ${y}L${x + s} ${y + s}L${x} ${y + s}Z`); }
      else { R.push(`M${x} ${y}L${x + s} ${y}L${x + s} ${y + s}Z`); R.push(`M${x} ${y}L${x + s} ${y + s}L${x} ${y + s}Z`); }
    }
    return R;
  } },
  { id: 'flor', name: 'Flor', build() {
    const R = []; const cx = 150, cy = 118;
    for (let i = 0; i < 10; i++) R.push(petal(cx, cy, 18, 78, i * Math.PI / 5, 0.3));
    R.push(`M${cx - 18} ${cy}a18 18 0 1 0 36 0a18 18 0 1 0 -36 0Z`);
    R.push(`M146 196L154 196L154 262L146 262Z`);
    R.push(`M150 236Q110 200 96 222Q118 246 150 236Z`, `M150 226Q190 190 206 212Q182 238 150 226Z`);
    R.push(`M100 262L200 262L188 296L112 296Z`);
    return R;
  } },
];
export const COLOR_PALETTE = ['#e2231a', '#ff7a1a', '#ffc933', '#7bd148', '#1faa4f', '#18b6c9', '#1f7cf2', '#5a3fd6', '#c03fd6', '#ff5fa2', '#8b5a2b', '#0a1f3a'];
// Modo Reto: se muestra un MODELO ya pintado y hay que copiarlo. La precisión (% de partes con el color correcto)
// decide los puntos: con menos de 70% el servidor da 0. Cambiar una parte que ya estaba bien cuenta como error.
function modelFor(regions, rnd) {
  const pal = COLOR_PALETTE.slice(0, 11);
  const picks = []; while (picks.length < 4) { const c = pal[Math.floor(rnd() * pal.length)]; if (!picks.includes(c)) picks.push(c); }
  return regions.map((_, i) => picks[(i + Math.floor(rnd() * 2)) % picks.length]);
}
export function colorCreate(designIndex = 0, rnd = Math.random) {
  const d = COLOR_DESIGNS[((designIndex % COLOR_DESIGNS.length) + COLOR_DESIGNS.length) % COLOR_DESIGNS.length];
  const regions = d.build();
  return { designId: d.id, designName: d.name, regions, model: modelFor(regions, rnd), fills: {}, selected: COLOR_PALETTE[0], wrongChanges: 0, startedAt: Date.now(), finishedAt: null };
}
export function colorPick(state, color) { return COLOR_PALETTE.includes(color) ? { ...state, selected: color } : state; }
export function colorPrecision(state) {
  const ok = state.regions.reduce((t, _, i) => t + (state.fills[i] === state.model[i] ? 1 : 0), 0);
  return Math.round(ok / state.regions.length * 100);
}
export function colorFill(state, index) {
  if (state.finishedAt || index < 0 || index >= state.regions.length) return state;
  const prev = state.fills[index];
  if (prev === state.selected) return state;
  const wrongChanges = state.wrongChanges + ((prev === state.model[index]) || (prev && state.selected !== state.model[index]) ? 1 : 0);
  const fills = { ...state.fills, [index]: state.selected };
  const done = Object.keys(fills).length >= state.regions.length && state.regions.every((_, i) => fills[i] === state.model[i]);
  return { ...state, fills, wrongChanges, finishedAt: done ? Date.now() : null };
}
export function colorFinishNow(state) { return state.finishedAt ? state : { ...state, finishedAt: Date.now() }; }
export function colorSubmission(state) {
  const precisionPct = colorPrecision(state);
  const completed = Object.keys(state.fills).length >= state.regions.length;
  return { completed, precisionPct, wrongChanges: state.wrongChanges, finePremium: completed && precisionPct === 100 && state.wrongChanges === 0 };
}
