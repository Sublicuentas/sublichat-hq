// Motores puros de los 3 juegos (sin DOM, sin temporizadores reales): reciben estado + acción, devuelven
// el nuevo estado. La pantalla (juegos.js) solo pinta este estado y llama a estas funciones ante cada toque.
import { HANGMAN_WORDS, WORDSEARCH_SETS, MEMORY_SYMBOLS } from './juegos-data.js';

const shuffle = (arr, rnd = Math.random) => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; } return a; };
const uid = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

/* ═════════════════════ PARES DE CARTAS (MEMORY_PAIRS) ═════════════════════ */
export function memoryCreate(pairCount = 12, rnd = Math.random) {
  const symbols = shuffle(MEMORY_SYMBOLS, rnd).slice(0, pairCount);
  const cards = shuffle(symbols.flatMap((s, i) => [{ symbol: s, pairId: i }, { symbol: s, pairId: i }]), rnd).map((c, i) => ({ ...c, id: i, matched: false }));
  return { cards, flipped: [], pairsFound: 0, moves: 0, combo: 0, maxCombo: 0, pending: false, startedAt: Date.now(), finishedAt: null };
}
export function memoryFlip(state, index) {
  if (state.pending || state.finishedAt) return state;
  const card = state.cards[index];
  if (!card || card.matched || state.flipped.includes(index)) return state;
  const flipped = [...state.flipped, index];
  if (flipped.length < 2) return { ...state, flipped };
  const [a, b] = flipped; const match = state.cards[a].symbol === state.cards[b].symbol;
  const moves = state.moves + 1;
  if (match) {
    const combo = state.combo + 1; const maxCombo = Math.max(state.maxCombo, combo);
    const cards = state.cards.map((c, i) => (i === a || i === b ? { ...c, matched: true } : c));
    const pairsFound = state.pairsFound + 1;
    const finishedAt = pairsFound === state.cards.length / 2 ? Date.now() : null;
    return { ...state, cards, flipped: [], moves, combo, maxCombo, pairsFound, finishedAt };
  }
  return { ...state, flipped, moves, combo: 0, pending: true }; // se resuelve (oculta) con memoryResolveMismatch tras una pausa visual
}
export function memoryResolveMismatch(state) { return state.pending ? { ...state, flipped: [], pending: false } : state; }
export function memorySubmission(state, timeLimitSec = 120) {
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { pairsFound: state.pairsFound, moves: Math.max(state.cards.length / 2, state.moves), maxCombo: state.maxCombo, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

/* ═════════════════════ EL AHORCADO (HANGMAN) ═════════════════════ */
const norm = s => String(s || '').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
export function hangmanCreate(rounds = 5, maxErrors = 7, maxHints = 2, rnd = Math.random) {
  const pool = shuffle(HANGMAN_WORDS, rnd).slice(0, rounds);
  return {
    rounds: pool.map(p => ({ word: norm(p.word), category: p.category, clue: p.clue, guessed: [], wrong: [], solved: false, gaveUp: false })),
    roundIndex: 0, maxErrors, hintsUsed: 0, maxHints, startedAt: Date.now(), finishedAt: null,
  };
}
export function hangmanGuess(state, letterRaw) {
  const letter = norm(letterRaw).slice(0, 1);
  if (!/^[A-Z]$/.test(letter) || state.finishedAt) return state;
  const round = state.rounds[state.roundIndex]; if (!round || round.solved || round.gaveUp) return state;
  if (round.guessed.includes(letter) || round.wrong.includes(letter)) return state;
  const hit = round.word.includes(letter);
  const nRound = hit
    ? { ...round, guessed: [...round.guessed, letter] }
    : { ...round, wrong: [...round.wrong, letter] };
  nRound.solved = [...nRound.word].every(ch => nRound.guessed.includes(ch));
  nRound.gaveUp = !nRound.solved && nRound.wrong.length >= state.maxErrors;
  const rounds = state.rounds.map((r, i) => (i === state.roundIndex ? nRound : r));
  const done = nRound.solved || nRound.gaveUp;
  const isLast = state.roundIndex === state.rounds.length - 1;
  const roundIndex = done && !isLast ? state.roundIndex + 1 : state.roundIndex;
  const finishedAt = done && isLast ? Date.now() : null;
  return { ...state, rounds, roundIndex, finishedAt };
}
export function hangmanHint(state) {
  if (state.hintsUsed >= state.maxHints || state.finishedAt) return state;
  const round = state.rounds[state.roundIndex]; if (!round || round.solved || round.gaveUp) return state;
  const missing = [...new Set([...round.word])].find(ch => !round.guessed.includes(ch)); if (!missing) return state;
  return hangmanGuess({ ...state, hintsUsed: state.hintsUsed + 1 }, missing);
}
export function hangmanSubmission(state, timeLimitSec = 180) {
  const solvedWords = state.rounds.filter(r => r.solved).length;
  const totalWrongLetters = state.rounds.reduce((t, r) => t + r.wrong.length, 0);
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { solvedWords, totalWrongLetters, hintsUsed: state.hintsUsed, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

/* ═════════════════════ SOPA DE LETRAS (WORD_SEARCH) ═════════════════════ */
const DIRS = [[0, 1], [1, 0], [1, 1], [1, -1], [0, -1], [-1, 0], [-1, -1], [-1, 1]]; // incluye reversa (spec: palabras invertidas)
function tryBuildGrid(size, words, rnd) {
  const grid = Array.from({ length: size }, () => Array(size).fill(''));
  const placed = [];
  // Las palabras más largas son las más difíciles de encajar: se colocan primero, con la rejilla más vacía.
  const ordered = words.slice().sort((a, b) => b.word.length - a.word.length);
  for (const { word, category } of ordered) {
    const w = word; let ok = false;
    for (let attempt = 0; attempt < 400 && !ok; attempt++) {
      const [dr, dc] = DIRS[Math.floor(rnd() * DIRS.length)];
      const r0 = Math.floor(rnd() * size), c0 = Math.floor(rnd() * size);
      const r1 = r0 + dr * (w.length - 1), c1 = c0 + dc * (w.length - 1);
      if (r1 < 0 || r1 >= size || c1 < 0 || c1 >= size) continue;
      let fits = true;
      for (let i = 0; i < w.length; i++) { const cell = grid[r0 + dr * i][c0 + dc * i]; if (cell && cell !== w[i]) { fits = false; break; } }
      if (!fits) continue;
      for (let i = 0; i < w.length; i++) grid[r0 + dr * i][c0 + dc * i] = w[i];
      placed.push({ id: `w${placed.length}`, word: w, category, start: [r0, c0], end: [r1, c1], found: false });
      ok = true;
    }
    if (!ok) return null; // esta rejilla no alcanzó: se reintenta completa (ver wordSearchCreate)
  }
  return { grid, placed };
}
export function wordSearchCreate(size = 12, setIndex = 0, rnd = Math.random) {
  const set = WORDSEARCH_SETS[setIndex % WORDSEARCH_SETS.length];
  const words = set.words.map(w => ({ word: norm(w.word), category: w.category }));
  let built = null;
  for (let round = 0; round < 12 && !built; round++) built = tryBuildGrid(size, words, rnd);
  if (!built) { // muy improbable (12 intentos de rejilla completa); nunca se entrega un tablero con palabras faltantes
    const bigger = tryBuildGrid(size + 2, words, rnd);
    built = bigger || { grid: Array.from({ length: size }, () => Array(size).fill('A')), placed: [] };
    if (bigger) size += 2;
  }
  const { grid, placed } = built;
  // El orden en pantalla sigue siendo el original (no el de longitud) para que la lista de "palabras a encontrar" no salte.
  const placedById = new Map(placed.map(p => [p.word, p]));
  const orderedForDisplay = words.map(w => placedById.get(w.word)).filter(Boolean);
  const ABC = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let r = 0; r < size; r++) for (let c = 0; c < size; c++) if (!grid[r][c]) grid[r][c] = ABC[Math.floor(rnd() * ABC.length)];
  return { size, grid, words: orderedForDisplay, selectStart: null, wrongSelections: 0, hintsUsed: 0, combo: 0, maxCombo: 0, startedAt: Date.now(), finishedAt: null };
}
const sameLine = (r0, c0, r1, c1) => { const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0); return (dr === 0 || dc === 0 || Math.abs(r1 - r0) === Math.abs(c1 - c0)); };
export function wordSearchSelect(state, r, c) {
  if (state.finishedAt) return state;
  if (!state.selectStart) return { ...state, selectStart: [r, c] };
  const [r0, c0] = state.selectStart;
  if (r0 === r && c0 === c) return { ...state, selectStart: null };
  if (!sameLine(r0, c0, r, c)) return { ...state, selectStart: [r, c] }; // reinicia selección con el nuevo punto
  const dr = Math.sign(r - r0), dc = Math.sign(c - c0);
  const len = Math.max(Math.abs(r - r0), Math.abs(c - c0)) + 1;
  const cells = Array.from({ length: len }, (_, i) => [r0 + dr * i, c0 + dc * i]);
  const text = cells.map(([rr, cc]) => state.grid[rr][cc]).join('');
  const rev = [...text].reverse().join('');
  const hit = state.words.find(w => !w.found && (w.word === text || w.word === rev));
  if (hit) {
    const words = state.words.map(w => (w.id === hit.id ? { ...w, found: true, cells } : w));
    const combo = state.combo + 1; const maxCombo = Math.max(state.maxCombo, combo);
    const finishedAt = words.every(w => w.found) ? Date.now() : null;
    return { ...state, words, selectStart: null, combo, maxCombo, finishedAt };
  }
  return { ...state, selectStart: null, wrongSelections: state.wrongSelections + 1, combo: 0 };
}
export function wordSearchHint(state) {
  if (state.finishedAt) return state;
  const target = state.words.find(w => !w.found); if (!target) return state;
  const [r0, c0] = target.start; const [r1, c1] = target.end;
  const dr = Math.sign(r1 - r0), dc = Math.sign(c1 - c0);
  const cells = Array.from({ length: target.word.length }, (_, i) => [r0 + dr * i, c0 + dc * i]);
  const words = state.words.map(w => (w.id === target.id ? { ...w, found: true, cells, hinted: true } : w));
  const finishedAt = words.every(w => w.found) ? Date.now() : null;
  return { ...state, words, selectStart: null, hintsUsed: state.hintsUsed + 1, combo: 0, finishedAt };
}
export function wordSearchSubmission(state, timeLimitSec = 240) {
  const foundWords = state.words.filter(w => w.found && !w.hinted).length + state.words.filter(w => w.hinted).length;
  const elapsedMs = (state.finishedAt || Date.now()) - state.startedAt;
  return { foundWords, wrongSelections: state.wrongSelections, hintsUsed: state.hintsUsed, maxCombo: state.maxCombo, timeLimitSec, timeRemainingSec: Math.max(0, timeLimitSec - Math.floor(elapsedMs / 1000)) };
}

export const genRoundId = uid;
