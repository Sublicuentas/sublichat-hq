// Rediseño R41: Cobros, Tickets y avisos (2 secciones) e Inventario (con logos y detalle de cuenta).
// Funciones puras que devuelven HTML; la lógica (API, estado, eventos) sigue viviendo en main.js.
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

const I = Object.freeze({
  back: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0a1f3a" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.300" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.600-5.900"/><path d="M20 4v5h-5"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.800" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
  down: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  search: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="#0a1f3a" stroke-width="2.200" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.600-3.600"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.200" stroke-linecap="round"><path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2.200"/><circle cx="9" cy="17" r="2.200"/></svg>',
  people: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0a1f3a" stroke-width="2" stroke-linecap="round"><circle cx="9" cy="8" r="3.500"/><path d="M2.500 20c.5-3.800 3.200-5.800 6.500-5.800s6 2 6.500 5.800"/><circle cx="17" cy="9" r="2.800"/><path d="M17 14.300c2.600 0 4.500 1.700 4.800 4.700"/></svg>',
  calendar: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3.500" y="5" width="17" height="15.500" rx="3"/><path d="M8 3v4M16 3v4M3.500 10h17"/><circle cx="8.500" cy="14" r=".9" fill="#0a1f3a"/><circle cx="12" cy="14" r=".9" fill="#0a1f3a"/><circle cx="15.500" cy="14" r=".9" fill="#0a1f3a"/></svg>',
  clock: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.100" stroke-linecap="round"><circle cx="12" cy="12" r="8.500"/><path d="M12 7v5.500l3.500 2"/></svg>',
  megaphone: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M8 20h8l17-9v26l-17-9H8z" fill="#e2231a"/><rect x="11" y="27" width="7" height="12" rx="3" fill="#b3110a"/><path d="M38 18c2.600 1.800 4 4.200 4 7s-1.400 5.200-4 7" fill="none" stroke="#e2231a" stroke-width="3.200" stroke-linecap="round"/></svg>',
  ticket: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M6 15a4 4 0 0 1 4-4h28a4 4 0 0 1 4 4v4a5 5 0 0 0 0 10v4a4 4 0 0 1-4 4H10a4 4 0 0 1-4-4v-4a5 5 0 0 0 0-10z" fill="#1f7be8"/><path d="M18 19h12M18 24h12M18 29h8" stroke="#fff" stroke-width="3" stroke-linecap="round"/></svg>',
  attach: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#0a1f3a" stroke-width="2.100" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11.500 12.400 19a5 5 0 0 1-7-7l8-8a3.400 3.400 0 0 1 4.800 4.800l-8 8a1.800 1.800 0 0 1-2.500-2.500L14.800 8"/></svg>',
  grid4: '<svg viewBox="0 0 32 32" width="34" height="34" aria-hidden="true"><circle cx="9" cy="9" r="5.500" fill="#1f7be8"/><circle cx="23" cy="9" r="5.500" fill="#1f7be8"/><circle cx="9" cy="23" r="5.500" fill="#1f7be8"/><circle cx="23" cy="23" r="5.500" fill="#1f7be8"/></svg>',
  wrench: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#e2231a" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><path d="M14.500 6a4 4 0 0 0 4.800 5.300L11 19.600a2.300 2.300 0 0 1-3.300-3.300l8.300-8.300"/></svg>',
  sync: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#1f7be8" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 0 0-14-5.300M4 4v3.500h3.500M4 12a8 8 0 0 0 14 5.300M20 20v-3.500h-3.500"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#1c8a3c" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.500"/><path d="m8 12.300 2.900 2.900L16.200 9.500"/></svg>',
  chat: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#5d7387" stroke-width="2.100" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.500A2.500 2.500 0 0 1 6.500 3h11A2.500 2.500 0 0 1 20 5.500v8a2.500 2.500 0 0 1-2.500 2.500H11l-4.500 4v-4h0A2.500 2.500 0 0 1 4 13.500z"/><circle cx="9" cy="9.500" r=".9" fill="#5d7387"/><circle cx="12" cy="9.500" r=".9" fill="#5d7387"/><circle cx="15" cy="9.500" r=".9" fill="#5d7387"/></svg>',
  dots: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#0a1f3a"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>',
  key: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="15" r="4"/><path d="m10.800 12.200 8.700-8.700M16 7l3 3M13.500 9.500l2.500 2.500"/></svg>',
  copy: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.100" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/></svg>',
});
export const ICONS2 = I;

/* ═════════════ logos de plataformas ═════════════ */
const LOGO = Object.freeze({
  netflix: 'netflix', netflixpremium: 'netflix', vipnetflix: 'netflix', netflixvip: 'netflix', vip: 'netflix',
  disney: 'disney', disneyp: 'disney', disneys: 'disney', disneypremium: 'disney', disneystandard: 'disney',
  hbomax: 'hbo', hbo: 'hbo', max: 'hbo', primevideo: 'prime', prime: 'prime', paramount: 'paramount', paramountp: 'paramount',
  crunchyroll: 'crunchyroll', crunchy: 'crunchyroll', vix: 'vix', viki: 'viki', vikirakuten: 'viki', universal: 'universal', universalp: 'universal',
  spotify: 'spotify', youtube: 'youtube', canva: 'canva', gemini: 'gemini', geminipro: 'gemini', chatgpt: 'chatgpt', duolingo: 'duolingo',
  office: 'office365', office365: 'office365', office2021: 'office365', microsoft: 'office365',
  stellatv: 'stella-tv', stella: 'stella-tv', oleada: 'oleada-tv', oleadatv: 'oleada-tv', latintv: 'latin-tv', latin: 'latin-tv',
  iptv: 'iptv', liontv: 'iptv', evoutouch: 'iptv', nanotech: 'iptv', eset: 'eset', windows10: 'windows10', windows11: 'windows11',
  appletv: 'appletv', deezer: 'deezer', adobeexpress: 'adobeexpress', star: 'disney',
});
export function platformCanon(value = '') {
  const raw = String(value ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  if (LOGO[raw]) return raw;
  const noNum = raw.replace(/\d+$/, '');
  return LOGO[noNum] ? noNum : (noNum || raw);
}
export function platformLogoFile(value = '') { return LOGO[platformCanon(value)] || ''; }
export function platformLogoHtml(value = '', label = '', cls = '') {
  const f = platformLogoFile(value);
  return f ? `<img class="pf-logo ${cls}" src="/assets/plataformas/${f}.webp" alt="" loading="lazy">` : `<span class="pf-logo pf-fallback ${cls}">${esc(String(label || value || '?').trim().charAt(0).toUpperCase())}</span>`;
}

/* ═════════════ COBROS (Renovar) ═════════════ */
export function cobrosScreenHtml({ counts = {}, filter = 'hoy', seller = '', sellers = [], groups = [], heading = '', headingCount = 0 } = {}) {
  const tabs = [['hoy', 'Hoy', I.calendar], ['proximo', 'Próximo', I.calendar], ['vencidos', 'Vencidos', I.clock]];
  return `<section class="cb-page">
    <div class="sb-top"><button type="button" class="sb-icon-btn" id="cobrosBack" data-tab="inicio" aria-label="Volver">${I.back}</button><button type="button" class="sb-icon-btn" id="refreshData" aria-label="Actualizar">${I.refresh}</button></div>
    <section class="cb-hero"><div class="cb-copy"><p class="eyebrow">RENOVACIONES</p><h1>Renovar</h1><p>Cobro + gestión de servicios + renovación conectada a Sublichat.</p></div><img class="cb-art" src="/assets/mas/cobros-hero.webp" alt=""></section>
    <label class="cb-seller"><i>${I.people}</i><span><small>Vendedor</small><select id="renewSellerFilter"><option value="">Todos</option>${sellers.map(v => `<option value="${esc(v)}" ${seller === v ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></span><b>${I.down}</b></label>
    <nav class="cb-tabs">${tabs.map(([id, label, ico]) => `<button type="button" data-filter="${id}" class="${filter === id ? 'active' : ''}"><i>${id === 'hoy' ? '' : ico}</i><span>${label}</span><em>${esc(counts[id] ?? 0)}</em></button>`).join('')}</nav>
    <div class="cb-date"><span><i>${I.calendar}</i><b>${esc(heading)}</b></span><small>${esc(headingCount)} cliente${Number(headingCount) === 1 ? '' : 's'}</small></div>
    <section class="cb-list">${groups.length ? groups.map(g => `<button type="button" class="cb-row" data-renew-group="${esc(g.key)}"><span class="cb-day"><b>${esc(g.day)}</b><small>${esc(g.mon)}</small></span><span class="cb-info"><strong>${esc(g.nombre)}</strong><span>${esc(g.plataformas)} · ${esc(g.nServicios)} servicio${Number(g.nServicios) === 1 ? '' : 's'}</span><small>${esc(g.nTotal)} total</small></span><span class="cb-amount">${esc(g.total)}</span><span class="cb-go">${I.chevron}</span></button>`).join('') : '<div class="empty-state"><strong>Todo al día</strong><span>No hay registros en esta sección.</span></div>'}</section>
  </section>`;
}

/* ═════════════ TICKETS Y AVISOS ═════════════ */
export const TICKET_DONE = Object.freeze(['resuelto', 'finalizado', 'cerrado']);
export const isAviso = t => String(t?.tipo || '').toLowerCase() === 'aviso' || /^\s*aviso\b/i.test(String(t?.titulo || ''));
export const ticketTitle = t => String(t?.titulo || 'Ticket').replace(/^\s*aviso\s*[·:\-–]\s*/i, '');
// Lo que se ve por defecto: abiertos SIN responder. Lo demás (respondidos o cerrados) va al Historial.
export const ticketNeedsAttention = t => !TICKET_DONE.includes(String(t?.estado || 'abierto').toLowerCase()) && !(Array.isArray(t?.respuestas) && t.respuestas.length);
const STATUS = Object.freeze({
  abierto: ['Abierto', 'open', I.wrench], proceso: ['En proceso', 'proc', I.sync], respondido: ['Respondido', 'answ', I.chat],
  resuelto: ['Resuelto', 'done', I.check], finalizado: ['Resuelto', 'done', I.check], cerrado: ['Cerrado', 'closed', I.chat],
});
export const ticketStatus = t => STATUS[String(t?.estado || 'abierto').toLowerCase()] || STATUS.abierto;
export const TICKET_FILTERS = Object.freeze([['', 'Todos'], ['abierto', 'Abierto'], ['proceso', 'En proceso'], ['respondido', 'Respondido'], ['resuelto', 'Resuelto'], ['cerrado', 'Cerrado']]);

export function ticketRowHtml(t, { expanded = false, cardHtml = '', when = '', actor = '' } = {}) {
  const [label, tone, ico] = ticketStatus(t);
  const id = esc(t.id || t._id || '');
  const aviso = isAviso(t);
  return `<article class="tk-item ${expanded ? 'open' : ''}"><button type="button" class="tk-row" data-tk-toggle="${id}" aria-expanded="${expanded}"><span class="tk-ico ${tone}">${aviso ? I.megaphone : ico}</span><span class="tk-info"><strong>${esc(ticketTitle(t))}</strong><small>#${esc(t.numero || '—')} · ${esc(actor)}</small><small>${esc(when)}</small></span><span class="tk-chip ${tone}">${esc(label)}</span><span class="tk-go ${expanded ? 'up' : ''}">${I.chevron}</span></button>${expanded ? `<div class="tk-detail">${cardHtml}</div>` : ''}</article>`;
}

export function ticketsScreenHtml({ tab = 'avisos', counts = {}, noticeFormHtml = '', ticketFormHtml = '', visible = [], history = [], query = '', filter = '', filtersOpen = false, historyOpen = false, rowHtml = () => '', searching = false } = {}) {
  const isNotices = tab === 'avisos';
  const seg = `<nav class="tk-seg"><button type="button" class="${isNotices ? 'on' : ''}" data-tk-tab="avisos"><i>${I.megaphone}</i><span><b>Avisos</b><small>Comunicación masiva</small></span></button><button type="button" class="${!isNotices ? 'on' : ''}" data-tk-tab="tickets"><i>${I.ticket}</i><span><b>Tickets</b><small>Soporte y solicitudes</small></span></button></nav>`;
  const head = `<div class="sb-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver">${I.back}</button><button type="button" class="sb-icon-btn" id="ticketsRefresh" aria-label="Actualizar">${I.refresh}</button></div>
    <section class="tk-hero"><div><p class="eyebrow">SUBLICUENTAS</p><h1>Tickets y avisos</h1><p>Soporte · comunicación · respuestas · evidencias</p></div></section>${seg}`;
  const compose = isNotices
    ? `<section class="tk-card"><header><span class="tk-badge red">${I.megaphone}</span><div><h3>Publicar aviso</h3><p>Envía información a todos o a destinatarios específicos.</p></div></header>${noticeFormHtml}</section>`
    : `<section class="tk-banner"><i>${I.ticket}</i><div><b>Solicita soporte o reporta un problema</b><span>Nuestro equipo te ayudará lo antes posible.</span></div></section><section class="tk-card"><header><span class="tk-badge blue">${I.ticket}</span><div><h3>Nuevo ticket</h3><p>Reporta un problema o solicita soporte.</p></div></header>${ticketFormHtml}</section>`;
  const filters = filtersOpen ? `<div class="tk-filters">${TICKET_FILTERS.map(([v, l]) => `<button type="button" class="${filter === v ? 'on' : ''}" data-tk-status="${v}">${l}</button>`).join('')}</div>` : '';
  const listTitle = isNotices ? 'Avisos pendientes' : 'Mis tickets';
  const search = `<div class="tk-listhead"><h3>${listTitle}</h3><div class="tk-search"><span>${I.search}</span><input id="ticketSearch" type="search" value="${esc(query)}" placeholder="${isNotices ? 'Buscar aviso…' : 'Buscar ticket…'}" autocomplete="off"></div><button type="button" class="tk-filterbtn ${filter || filtersOpen ? 'on' : ''}" id="ticketFilterBtn" aria-label="Filtrar">${I.sliders}</button></div>${filters}`;
  const mainList = visible.length ? visible.map(rowHtml).join('') : `<div class="tk-empty"><strong>${searching ? 'Sin resultados' : (isNotices ? 'Sin avisos pendientes' : 'Sin tickets pendientes')}</strong><span>${searching ? 'Prueba con otra búsqueda o filtro.' : 'Lo que ya tiene respuesta o está cerrado está en el historial.'}</span></div>`;
  const hist = searching ? '' : `<section class="tk-history"><button type="button" class="tk-history-head ${historyOpen ? 'open' : ''}" id="ticketHistoryToggle" aria-expanded="${historyOpen}"><span>🕘 Historial de respuestas y cerrados</span><b>${esc(counts.history ?? history.length)}</b>${I.down}</button>${historyOpen ? `<div class="tk-history-body">${history.length ? history.map(rowHtml).join('') : '<div class="tk-empty"><span>El historial está vacío.</span></div>'}</div>` : ''}</section>`;
  return `<section class="tk-page">${head}${compose}${search}<section class="tk-list">${mainList}</section>${hist}</section>`;
}

/* ═════════════ INVENTARIO ═════════════ */
export const INV_SORTS = Object.freeze([['recientes', 'Más recientes'], ['libres', 'Más libres'], ['correo', 'Correo A-Z'], ['plataforma', 'Plataforma']]);
export const INV_CUPOS = Object.freeze([['', 'Todas'], ['libres', 'Con cupos'], ['llenas', 'Llenas']]);
export const invUsaUsuario = plat => /stella|oleada|latin|lion|evou|nanotech|iptv/.test(platformCanon(plat));

export function inventoryStats(item = {}) {
  const clients = Array.isArray(item.clientes) ? item.clientes : [];
  const used = Number(item.ocupados ?? clients.length) || 0;
  const free = Math.max(0, Number(item.disponibles) || 0);
  const cap = Number(item.capacidad) || used + free;
  return { clients, used, free, cap };
}
export function inventoryFreeSlots(item = {}) {
  const { clients, cap, free } = inventoryStats(item);
  const taken = new Set(clients.map(c => String(c?.slot ?? '').trim()).filter(Boolean));
  const numbered = clients.every(c => c?.slot == null || /^\d+$/.test(String(c.slot)));
  if (!numbered || !cap || free === 0) return { slots: [], count: free };
  const slots = []; for (let n = 1; n <= cap; n += 1) if (!taken.has(String(n))) slots.push(n);
  // Si los perfiles guardados no cuadran con "disponibles", no se inventan números: se muestra solo la cantidad.
  return slots.length === free ? { slots, count: free } : { slots: [], count: free };
}

export function inventoryScreenHtml({ platforms = [], total = 0, plat = '', query = '', sort = 'recientes', cupo = '', filtersOpen = false, items = [], shown = 0, all = 0 } = {}) {
  const chips = [`<button type="button" class="inv-chip ${plat === '' ? 'on' : ''}" data-inv-plat=""><i>${I.grid4}</i><b>Todas</b><small>${esc(total)}</small></button>`]
    .concat(platforms.map(p => `<button type="button" class="inv-chip ${plat === p.key ? 'on' : ''}" data-inv-plat="${esc(p.key)}"><i>${platformLogoHtml(p.key, p.label)}</i><b>${esc(p.label)}</b><small>${esc(p.count)}</small></button>`)).join('');
  const filters = filtersOpen ? `<div class="tk-filters">${INV_CUPOS.map(([v, l]) => `<button type="button" class="${cupo === v ? 'on' : ''}" data-inv-cupo="${v}">${l}</button>`).join('')}</div>` : '';
  return `<section class="inv-page">
    <div class="sb-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver">${I.back}</button><div class="sb-top-title"><strong>Inventario</strong><small>Disponibilidad de cuentas por plataforma</small></div><button type="button" class="sb-icon-btn ${cupo || filtersOpen ? 'on' : ''}" id="invFilterBtn" aria-label="Filtros">${I.sliders}</button></div>
    <div class="cli-search"><span class="ico">${I.search}</span><input id="invSearch" type="search" value="${esc(query)}" placeholder="Buscar cuenta, correo o plataforma…" autocomplete="off"></div>${filters}
    <div class="inv-chips">${chips}</div>
    <div class="inv-listhead"><h2>Cuentas disponibles</h2><label class="cli-sort"><select id="invSort" aria-label="Ordenar">${INV_SORTS.map(([v, l]) => `<option value="${v}" ${sort === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <p class="inv-count">Mostrando <b>${esc(shown)}</b> de <b>${esc(all)}</b> cuentas</p>
    <section class="inv-list">${items.length ? items.map(it => {
      const s = inventoryStats(it.raw);
      return `<article class="inv-row"><span class="inv-logo">${platformLogoHtml(it.raw.plataforma, it.label)}</span><div class="inv-info"><strong>${esc(it.label)}</strong><span>${esc(it.raw.correo || 'Sin correo')}</span><em class="inv-tag">${I.key}${esc(s.used)}/${esc(s.cap || '—')} ocupados</em></div><span class="inv-free ${s.free > 0 ? 'ok' : 'full'}"><b>${s.free > 0 ? '● ' : ''}${esc(s.free)}</b><small>${s.free > 0 ? 'libres' : 'llena'}</small></span><button type="button" class="inv-dots" data-inv-open="${esc(it.id)}" aria-label="Ver cuenta">${I.dots}</button></article>`;
    }).join('') : '<div class="empty-state"><strong>Sin cuentas</strong><span>No se encontraron cuentas con ese filtro.</span></div>'}</section>
  </section>`;
}

export function inventoryDetailHtml({ item = {}, label = '' } = {}) {
  const s = inventoryStats(item);
  const ident = invUsaUsuario(item.plataforma) ? 'Usuario' : 'Correo';
  const fs = inventoryFreeSlots(item);
  const row = (k, v, copy = '') => `<div class="inv-kv"><span>${esc(k)}</span><b>${esc(v || '—')}</b>${copy ? `<button type="button" class="inv-copy" data-copy="${esc(copy)}" aria-label="Copiar ${esc(k)}">${I.copy}</button>` : ''}</div>`;
  return `<div class="sr-form inv-detail"><div class="sr-sheet-head"><div class="inv-detail-title">${platformLogoHtml(item.plataforma, label, 'big')}<div><small>CUENTA DE INVENTARIO</small><h3>${esc(label)}</h3></div></div><button type="button" class="sr-x" data-sr-cancel aria-label="Cerrar">×</button></div>
    <div class="inv-kvs">${row(ident, item.correo, item.correo)}${row('Clave', item.clave, item.clave)}${row('Plataforma', label)}${row('Capacidad', s.cap)}${row('Ocupados', s.used)}${row('Disponibles', s.free)}${row('Estado', item.estado || 'activa')}</div>
    <div class="inv-block"><h4>Perfiles disponibles <em>${esc(fs.count)}</em></h4>${fs.slots.length ? `<div class="inv-slots">${fs.slots.map(n => `<span>Perfil ${n}</span>`).join('')}</div>` : (fs.count ? `<p>${esc(fs.count)} perfil(es) libre(s) en esta cuenta.</p>` : '<p>No quedan perfiles libres: la cuenta está llena.</p>')}</div>
    <div class="inv-block"><h4>Perfiles asignados <em>${esc(s.clients.length)}</em></h4>${s.clients.length ? `<div class="inv-assigned">${s.clients.map(c => `<article><span>${c.slot != null && c.slot !== '' ? `Perfil ${esc(c.slot)}` : 'Perfil'}</span><b>${esc(c.nombre || 'Sin nombre')}</b><small>${c.pin ? `PIN: ${esc(c.pin)}` : 'Sin PIN'}</small></article>`).join('')}</div>` : '<p>Sin perfiles asignados.</p>'}</div>
    <div class="sr-actions"><button type="button" class="sr-btn ghost" data-copy-all>${I.copy} Copiar datos</button><button type="button" class="sr-btn primary" data-sr-cancel>Cerrar</button></div></div>`;
}
export function inventoryCopyText({ item = {}, label = '' } = {}) {
  const ident = invUsaUsuario(item.plataforma) ? 'Usuario' : 'Correo';
  return `${label}\n${ident}: ${item.correo || ''}\nClave: ${item.clave || ''}`;
}
