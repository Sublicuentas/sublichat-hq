// Aula de clases · misma estructura visual y de contenido que la Academia web (academia-sublicuentas.html).
// Funciones puras que devuelven HTML: el estado (progreso, respuestas) vive en main.js.
import { COURSES } from './academia-data.js';
import { AVATARS, MASCOTS } from './aula-assets.js';

const USERS = Object.freeze({
  libni: { name: 'Libni', defaultAvatar: 0 },
  naara: { name: 'Naara', defaultAvatar: 1 },
  geisell: { name: 'Geisell', defaultAvatar: 2 },
});
// Misma equivalencia que api/academia.js: una persona = un documento de progreso.
const ALIASES = Object.freeze({ sublicuentas: 'naara', admin: 'naara', administrador: 'naara', owner: 'naara', relojes: 'libni', finanzas: 'libni', geissel: 'geisell' });

export const AULA_BADGES = Object.freeze(['Primer paso', 'Disciplina', 'Agente Pro', 'Cierre', 'Renovador', 'Soporte', 'Marketing', 'Caso Pro', 'Supervisor', 'Máquina de ventas', 'Leyenda']);

export function aulaUserKey(usuario = '') {
  const u = String(usuario || '').trim().toLowerCase();
  return ALIASES[u] || u;
}
export function aulaUserName(usuario = '') {
  const k = aulaUserKey(usuario);
  return USERS[k]?.name || (k ? k.charAt(0).toUpperCase() + k.slice(1) : 'Agente');
}
export function aulaDefaultAvatar(usuario = '') { return USERS[aulaUserKey(usuario)]?.defaultAvatar ?? 0; }

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const br = (v = '') => esc(v).replace(/\n/g, '<br>');

let uid = 0;
// Los SVG de avatar/mascota usan ids de gradientes: hay que hacerlos únicos cuando se repiten en pantalla.
export function aulaUniq(svg = '') {
  const n = `_u${++uid}`;
  return String(svg)
    .replace(/id="([^"]+)"/g, (m, id) => `id="${id}${n}"`)
    .replace(/url\(#([^)]+)\)/g, (m, id) => `url(#${id}${n})`)
    .replace(/href="#([^"]+)"/g, (m, id) => `href="#${id}${n}"`);
}

export const aulaXp = (done = []) => done.length * 50;
export const aulaPct = (done = []) => Math.round((done.length / COURSES.length) * 100);
export function aulaCategories() { return ['Todos', ...Array.from(new Set(COURSES.map(c => c.cat)))]; }

export function aulaEarnedBadges(done = []) {
  const base = [];
  if (done.length >= 1) base.push('Primer paso');
  if (done.length >= 5) base.push('Disciplina');
  if (done.length >= 12) base.push('Agente Pro');
  if (done.length >= 25) base.push('Cierre');
  if (done.length >= 50) base.push('Supervisor');
  if (done.length >= 80) base.push('Máquina de ventas');
  if (done.length >= COURSES.length) base.push('Leyenda');
  return [...new Set([...base, ...COURSES.filter((c, i) => done.includes(i) && ((i + 1) % 10 === 0)).map(c => c.badge)])];
}

export function aulaAvatar(index, usuario = '') {
  const i = Number.isInteger(index) ? index : aulaDefaultAvatar(usuario);
  return AVATARS[i] || AVATARS[aulaDefaultAvatar(usuario)] || AVATARS[0];
}
export function aulaMascot(index) {
  const i = Number.isInteger(index) ? index : 0;
  return MASCOTS[i] || MASCOTS[0];
}
function mascotLine(m, seed = 0) {
  const lines = Array.isArray(m?.lines) && m.lines.length ? m.lines : ['¡Vamos con todo!'];
  return lines[Math.abs(Number(seed) || 0) % lines.length];
}

function header(title, subtitle, { settings = true } = {}) {
  return `<section class="top"><button class="back" id="backMore" type="button" aria-label="Volver">‹</button><div class="title"><h1>${esc(title)}</h1><p>${esc(subtitle)}</p></div>${settings ? '<button class="settingsBtn" id="aulaSettings" type="button" aria-label="Ajustes">⚙️</button>' : ''}</section>`;
}

export function aulaLoadingHtml() {
  return `<div class="aula">${header('Aula de clases', 'Lecciones con teoría, ejemplos y quiz', { settings: false })}<div class="dashHead"><div style="flex:1"><h2>Cargando su progreso…</h2><div class="xp"><i style="width:35%"></i></div></div></div></div>`;
}
export function aulaErrorHtml(message = '') {
  return `<div class="aula">${header('Aula de clases', 'Lecciones con teoría, ejemplos y quiz', { settings: false })}<div class="why-card">⚠️ ${esc(message)}</div><button type="button" class="primary" id="aulaRetry">Reintentar</button></div>`;
}

// Panel principal: cabecera del agente, estadísticas, misión, logros, filtros y ruta de niveles.
export function aulaDashboardHtml({ done = [], cat = 'Todos', usuario = '', avatar = null, mascot = null } = {}) {
  const av = aulaAvatar(avatar, usuario);
  const m = aulaMascot(mascot);
  const earned = aulaEarnedBadges(done);
  const unlocked = done.length;
  const next = COURSES[unlocked] || COURSES[COURSES.length - 1];
  const visible = COURSES.map((c, i) => ({ ...c, i })).filter(c => cat === 'Todos' || c.cat === cat);
  const pct = aulaPct(done);
  return `<div class="aula fade-in">
    ${header('Aula de clases', 'Lecciones con teoría, ejemplos y quiz')}
    <div class="dashHead"><span class="avatar" style="background:${av.bg}">${aulaUniq(av.svg)}</span><div style="flex:1"><h2>Hola, ${esc(aulaUserName(usuario))}</h2><p>${pct}% completado · ${aulaXp(done)} XP · ${COURSES.length} cursos</p><div class="xp"><i style="width:${pct}%"></i></div></div></div>
    <div class="stats"><div class="stat"><b>📚 ${done.length}</b><span>Cursos</span></div><div class="stat"><b>⭐ ${aulaXp(done)}</b><span>XP</span></div><div class="stat"><b>🏆 ${earned.length}</b><span>Logros</span></div></div>
    <div class="coach-card"><div class="coach-emoji coach-mascot" data-aula-wave="1">${aulaUniq(m.svg)}</div><div><b>${esc(m.name)}</b><p>${esc(mascotLine(m, done.length))}</p><small class="coach-hint">Tócame 👋 · elígeme en Ajustes</small></div></div>
    <div class="mission-card"><h3>🎯 Misión de hoy</h3><ul><li>Complete 1 curso: <b>${esc(next.title)}</b>.</li><li>Escriba una práctica libre antes de ver la respuesta modelo.</li><li>Use un mensaje aprendido con un cliente real.</li></ul></div>
    <div class="achievement-card"><div class="achievement-title">🏅 Logros de superación</div><div class="badges">${AULA_BADGES.map(b => `<span class="badge-pill ${earned.includes(b) ? 'on' : ''}">${earned.includes(b) ? '✅' : '🔒'} ${esc(b)}</span>`).join('')}</div></div>
    <div class="module-filter">${aulaCategories().map(c => `<button type="button" class="filter-btn ${c === cat ? 'on' : ''}" data-academia-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
    <div class="section">Ruta interactiva · desbloqueo por niveles · ${visible.length} cursos en esta vista</div>
    <div class="path">${visible.map(c => `<button type="button" class="node ${done.includes(c.i) ? 'done' : ''} ${c.i === unlocked ? 'current' : ''} ${c.i > unlocked ? 'locked' : ''}" data-academia-open="${c.i}"><div class="bubble">${done.includes(c.i) ? '✅' : esc(c.icon || '📘')}</div><div class="info"><b>${esc(c.title)}</b><small>Nivel ${c.i + 1} · ${esc(c.subtitle || '')}</small><span class="cat">${esc(c.cat)}</span></div></button>`).join('')}</div>
    <button type="button" class="ghost" id="aulaSettings2">⚙️ Ajustes de avatar</button>
    <button type="button" class="ghost" id="aulaGoHome">Volver a inicio</button>
  </div>`;
}

// Lección: mismo orden que la web (por qué importa → qué es → cómo se hace → ejemplos → casos → quiz → consejo).
export function aulaLessonHtml({ i = 0, done = [], sel = {}, usuario = '', mascot = null } = {}) {
  const c = COURSES[i];
  if (!c) return aulaDashboardHtml({ done, usuario });
  const m = aulaMascot(mascot);
  const isDone = done.includes(i);
  const scenarios = (c.scenarios || []).map((s, si) => {
    const key = `${i}-sc-${si}`, chosen = sel[key];
    const opts = (s.options || []).map((o, oi) => {
      const cls = chosen == null ? '' : (o.ok ? 'good' : (chosen === oi ? 'bad' : ''));
      return `<button type="button" class="choice ${cls}" ${chosen != null ? 'disabled' : ''} data-academia-answer="${key}:${oi}">${esc(o.t)}</button>`;
    }).join('');
    const exp = chosen == null ? '' : `${s.options?.[chosen]?.ok ? '✅ ¡Bien! ' : '❌ '}${esc(s.explain || '')}`;
    return `<div class="scn"><div class="bubble-cli2">${esc(s.client)}</div><div class="choices">${opts}</div><div class="scn-exp">${exp}</div></div>`;
  }).join('');
  const quizItems = c.quiz || [];
  const answered = quizItems.filter((q, qi) => sel[`${i}-q-${qi}`] != null).length;
  const correct = quizItems.filter((q, qi) => sel[`${i}-q-${qi}`] === q.correct).length;
  const quiz = quizItems.map((q, qi) => {
    const key = `${i}-q-${qi}`, chosen = sel[key];
    const opts = (q.opts || []).map((o, oi) => {
      const cls = chosen == null ? '' : (oi === q.correct ? 'good' : (chosen === oi ? 'bad' : ''));
      return `<button type="button" class="choice ${cls}" ${chosen != null ? 'disabled' : ''} data-academia-answer="${key}:${oi}">${esc(o)}</button>`;
    }).join('');
    const exp = chosen == null ? '' : `${chosen === q.correct ? '✅ ' : '❌ '}${esc(q.explain || '')}`;
    return `<div class="q-item"><p class="q-text">${qi + 1}. ${esc(q.q)}</p><div class="choices">${opts}</div><div class="q-exp">${exp}</div></div>`;
  }).join('');
  let feedback = `Conteste las ${quizItems.length} preguntas para completar el nivel.`;
  if (quizItems.length && answered >= quizItems.length) {
    const pct = Math.round((correct / quizItems.length) * 100);
    feedback = `<div class="grade-box">${pct >= 70 ? '🏆' : '📚'} Nota: ${correct}/${quizItems.length} (${pct}%). ${pct >= 70 ? '¡Aprobado! Ya puede completar el nivel.' : 'Puede completar igual, pero repáselo para dominarlo.'}</div>`;
  } else if (answered > 0) {
    feedback = `Va ${answered}/${quizItems.length}…`;
  }
  const canComplete = isDone || !quizItems.length || answered >= quizItems.length;
  return `<div class="aula fade-in">
    ${header(c.title, c.subtitle || 'Aula de clases', { settings: false })}
    <div class="lesson">
      <div class="meta">Nivel ${i + 1} · ${esc(c.cat)}</div><div class="bigicon">${esc(c.icon || '📘')}</div><h2>${esc(c.title)}</h2><div class="type-tag">${esc(c.subtitle || '')}</div>
      <div class="coach-card"><div class="coach-emoji coach-mascot" data-aula-wave="1">${aulaUniq(m.svg)}</div><div><b>${esc(m.name)} dice:</b><p>${esc(mascotLine(m, i))}</p></div></div>
      <div class="why-card"><b>📌 Por qué importa:</b> ${esc(c.intro || '')}</div>
      ${c.concept ? `<div class="exercise-card"><h3>📖 ¿Qué es ${esc(c.concept.term)}?</h3><div class="concept">${esc(c.concept.def)}</div></div>` : ''}
      ${(c.sections || []).length ? `<div class="exercise-card"><h3>📚 Cómo se hace</h3>${c.sections.map(s => `<div class="sec"><h4>${esc(s.h)}</h4><p>${br(s.p)}</p></div>`).join('')}</div>` : ''}
      ${(c.examples || []).length ? `<div class="exercise-card"><h3>💬 Ejemplos reales</h3>${c.examples.map(e => `<div class="exmp"><div class="exmp-sit">${esc(e.sit)}</div><div class="ex-good"><span class="ex-tag">✅ Así sí</span><div>${esc(e.bien)}</div></div><div class="ex-bad"><span class="ex-tag">❌ Así no</span><div>${esc(e.mal)}</div></div><div class="why-line">💡 ${esc(e.why)}</div></div>`).join('')}</div>` : ''}
      ${scenarios ? `<div class="exercise-card"><h3>🎮 ¿Cómo responderías?</h3><p>Le escribe un cliente. Toque la mejor respuesta.</p>${scenarios}</div>` : ''}
      ${quiz ? `<div class="exercise-card"><h3>🧠 Quiz del nivel</h3>${quiz}<div class="feedback">${feedback}</div></div>` : ''}
      ${c.tip ? `<div class="recuerda"><b>💡 Consejo para hoy:</b> ${esc(c.tip)}</div>` : ''}
      <button type="button" class="primary" id="academiaComplete" ${canComplete ? '' : 'disabled'}>${isDone ? 'Nivel completado · volver a ruta' : 'Completar nivel'}</button>
      <button type="button" class="ghost" id="aulaBackRoute">Volver a ruta</button>
    </div>
  </div>`;
}

export function aulaSettingsHtml({ usuario = '', avatar = null, mascot = null, saving = false } = {}) {
  const avIdx = Number.isInteger(avatar) ? avatar : aulaDefaultAvatar(usuario);
  const maIdx = Number.isInteger(mascot) ? mascot : 0;
  const av = aulaAvatar(avIdx, usuario);
  return `<div class="aula fade-in">
    ${header('Ajustes', `Ajustes de ${aulaUserName(usuario)}`, { settings: false })}
    <div class="settings-card"><h2>⚙️ Ajustes de ${esc(aulaUserName(usuario))}</h2><p>Elige tu avatar y tu mascota coach. La mascota te acompaña y te saluda 🐾</p>
      <div class="coach-card"><div class="coach-emoji">${aulaUniq(av.svg)}</div><div><b>Avatar actual</b><p>${esc(av.name)}</p></div></div>
      <div class="option-title">Avatar del agente</div><div class="avatar-grid">${AVATARS.map((a, i) => `<button type="button" class="avatar-tile ${avIdx === i ? 'on' : ''}" data-aula-avatar="${i}"><span class="av-emoji" style="background:${a.bg}">${aulaUniq(a.svg)}</span><small>${esc(a.name)}</small></button>`).join('')}</div>
      <div class="option-title">Mascota coach (elige tu favorita 🐾)</div><div class="mascot-grid">${MASCOTS.map((mm, i) => `<button type="button" class="mascot-tile ${maIdx === i ? 'on' : ''}" data-aula-mascot="${i}"><span class="mascot-emoji">${aulaUniq(mm.svg)}</span><small>${esc(mm.name)}</small></button>`).join('')}</div>
      <button type="button" class="primary" id="aulaSaveSettings" ${saving ? 'disabled' : ''}>${saving ? 'Guardando…' : 'Guardar ajustes'}</button><button type="button" class="ghost" id="aulaSettingsBack">Volver a ruta</button>
    </div>
  </div>`;
}
