// Sorteos y premios en móvil: mismo alcance que el panel de Sublichat HQ (sorteos-admin.js), adaptado al teléfono.
// Funciones puras que devuelven HTML (o leen un formulario); los eventos y las llamadas a /api/sorteos viven en main.js.
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export const TIPO_PREMIO = Object.freeze({
  perfil: ['📺', 'Perfil de streaming'], descuento_porcentaje: ['％', 'Descuento de renovación'], descuento_fijo: ['🏷️', 'Descuento fijo'],
  cine: ['🎬', 'Boleto de cine'], recarga: ['📱', 'Recarga telefónica'], dias_extra: ['🗓️', 'Días extra de servicio'], personalizado: ['✨', 'Premio digital personalizado'],
});
export const PRESETS = Object.freeze({
  perfil: ['1', 'mes', 'manual'], descuento_porcentaje: ['10', '%', 'cupon'], descuento_fijo: ['50', 'Lps.', 'cupon'], cine: ['1', 'boleto', 'codigo'],
  recarga: ['100', 'Lps.', 'manual'], dias_extra: ['7', 'días', 'manual'], personalizado: ['1', '', 'manual'],
});
export const CATEGORIAS = Object.freeze({ general: 'Todos los clientes', compras: 'Compras nuevas', renovaciones: 'Renovaciones', club_vip: '👑 Club VIP' });
export const ESTADOS = Object.freeze({ borrador: 'Borrador', activo: 'Activo', cerrado: 'Participación cerrada', finalizado: 'Finalizado' });
export const ALCANCES = Object.freeze({ sublicuentas: 'Sublicuentas', relojes: 'Relojes', ambos: 'Ambos negocios' });
const HEX = /^#[0-9a-f]{6}$/i;
const safeHex = (v, fb = '#e2231a') => (HEX.test(String(v || '')) ? String(v) : fb);

export function fmtDate(v) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? 'Sin fecha' : d.toLocaleString('es-HN', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' });
}
const pad = n => String(n).padStart(2, '0');
export function localInput(v) {
  const d = new Date(v); if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
export function defaultLocal(days = 0, now = new Date()) { return localInput(new Date(now.getTime() + days * 86400000)); }

export function prizeLabel(p = {}) {
  const v = Number(p.valor) || 0;
  return [p.plataforma, v ? `${v} ${p.unidad || ''}`.trim() : ''].filter(Boolean).join(' · ') || 'Premio digital';
}
export function stockText(p = {}) {
  if (p.entregaModo === 'codigo') return `${Number(p.codigosDisponibles) || 0} código(s) disponible(s)`;
  const left = Math.max(0, (Number(p.stock) || 0) - (Number(p.reservados) || 0) - (Number(p.entregados) || 0));
  return `${left} disponible(s)`;
}

export function raffleMetrics(data = {}) {
  const draws = Array.isArray(data.sorteos) ? data.sorteos : [];
  const prizes = Array.isArray(data.premios) ? data.premios : [];
  const deliveries = Array.isArray(data.entregas) ? data.entregas : [];
  const pending = draws.filter(d => d.ganador && !deliveries.some(x => String(x.sorteoId) === String(d.id))).length
    + deliveries.filter(x => !['entregado', 'listo'].includes(x.estado)).length;
  return {
    tickets: draws.reduce((t, d) => t + Number(d.totalBoletos || 0), 0),
    active: draws.filter(d => d.estado === 'activo').length,
    prizes: prizes.filter(p => p.activo !== false).length,
    pending,
  };
}
// Qué botones corresponden a cada sorteo (mismas reglas que el panel web).
export function drawActions(d = {}) {
  const winner = Boolean(d.ganador);
  return {
    edit: !winner && ['borrador', 'activo'].includes(d.estado),
    close: !winner && d.estado === 'activo',
    spin: !winner && d.estado === 'cerrado',
    backfill: !winner && d.estado === 'activo' && ['general', 'club_vip', 'oro'].includes(d.categoria),
    del: !winner && d.estado !== 'finalizado',
    audit: !winner && ['activo', 'cerrado'].includes(d.estado),
  };
}

const drawCard = (d, premios, busy) => {
  const a = drawActions(d);
  const names = (d.premioIds || []).map(id => premios.find(p => p.id === id)?.nombre).filter(Boolean);
  const dis = busy ? 'disabled' : '';
  const w = d.ganador;
  return `<article class="sr-card" style="--sr-c:${esc(safeHex(d.color))}">
    <header><div class="sr-chips"><span class="sr-state ${esc(d.estado || 'borrador')}">${esc(ESTADOS[d.estado] || d.estado || 'Borrador')}</span><span class="sr-scope">${esc(ALCANCES[d.alcance] || d.alcance || '')}</span></div><b class="sr-count">${Number(d.totalBoletos) || 0}<small>boletos</small></b></header>
    <h3>${esc(d.titulo || 'Sorteo')}</h3><p>${esc(d.descripcion || 'Los clientes participan automáticamente con sus compras y renovaciones.')}</p>
    <div class="sr-meta"><span>◎ ${esc(CATEGORIAS[d.categoria === 'oro' ? 'club_vip' : d.categoria] || d.categoria || '')}</span><span>⌛ ${esc(fmtDate(d.fechaFin))}</span></div>
    <div class="sr-pills">${names.map(n => `<span>🎁 ${esc(n)}</span>`).join('') || '<span>Sin premios visibles</span>'}</div>
    ${w ? `<div class="sr-winner-mini"><span>🏆</span><div><small>GANADOR</small><b>${esc(w.clienteNombre || 'Cliente')}</b><em>${esc(w.codigo || '')}</em></div></div>` : ''}
    <footer>
      ${a.spin ? `<button type="button" class="sr-btn primary wide pulse" data-sr-spin="${esc(d.id)}" ${dis}>🎡 Girar ruleta</button>` : ''}
      ${a.close ? `<button type="button" class="sr-btn dark wide" data-sr-close="${esc(d.id)}" ${dis}>Cerrar participación</button>` : ''}
      <button type="button" class="sr-btn ghost" data-sr-tickets="${esc(d.id)}">🎟️ Ver boletos</button>
      ${a.edit ? `<button type="button" class="sr-btn ghost" data-sr-edit-draw="${esc(d.id)}" ${dis}>✏️ Editar</button>` : ''}
      ${a.audit ? `<button type="button" class="sr-btn ghost" data-sr-audit="${esc(d.id)}" ${dis}>🔍 Auditar boletos</button>` : ''}
      ${a.backfill ? `<button type="button" class="sr-btn ghost" data-sr-backfill="${esc(d.id)}" ${dis}>📥 Cargar desde agosto 2026</button>` : ''}
      ${a.del ? `<button type="button" class="sr-btn danger" data-sr-delete="${esc(d.id)}" ${dis}>🗑 Eliminar</button>` : ''}
    </footer></article>`;
};

const prizeCard = (p, busy) => {
  const t = TIPO_PREMIO[p.tipo] || TIPO_PREMIO.personalizado;
  const dis = busy ? 'disabled' : '';
  return `<article class="sr-card prize" style="--sr-c:${esc(safeHex(p.color))}">
    <header><div class="sr-chips"><span class="sr-state ${p.activo !== false ? 'activo' : 'borrador'}">${p.activo !== false ? 'Disponible' : 'Oculto'}</span><span class="sr-scope">${esc(p.ownerVendor === 'relojes' ? 'Relojes' : 'Sublicuentas')}</span></div><span class="sr-prize-ico">${t[0]}</span></header>
    <h3>${esc(p.nombre)}</h3><p>${esc(p.descripcion || prizeLabel(p))}</p><small class="sr-stock">${esc(stockText(p))} · ${esc(t[1])}</small>
    <footer><button type="button" class="sr-btn ghost" data-sr-edit-prize="${esc(p.id)}" ${dis}>✏️ Editar premio</button><button type="button" class="sr-btn danger" data-sr-delete-prize="${esc(p.id)}" ${dis}>🗑 Eliminar</button></footer></article>`;
};

const winnerRow = (d, entregas, busy) => {
  const w = d.ganador || {};
  const delivery = entregas.find(x => String(x.sorteoId || '') === String(d.id || ''));
  const st = !delivery ? 'Esperando elección' : (delivery.estado === 'entregado' ? 'Entregado' : delivery.estado === 'listo' ? 'Código listo' : 'Preparar entrega');
  return `<article class="sr-winner"><span class="crown">🏆</span><div class="who"><small>${esc(d.titulo)}</small><b>${esc(w.clienteNombre || 'Cliente')}</b><span>${esc(w.telefono || 'Sin teléfono')} · ${esc(w.codigo || '')}</span></div><div class="prize"><small>PREMIO ELEGIDO</small><b>${esc(delivery?.premioNombre || 'Aún no ha elegido')}</b><span class="sr-delivery ${esc(delivery?.estado || 'espera')}">${esc(st)}</span></div>${delivery && delivery.estado !== 'entregado' ? `<button type="button" class="sr-btn primary" data-sr-deliver="${esc(delivery.id)}" ${busy ? 'disabled' : ''}>Marcar entregado</button>` : ''}</article>`;
};

export function sorteosScreenHtml({ data = null, tab = 'sorteos', status = null, busy = false, error = '' } = {}) {
  const top = `<div class="sb-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0a1f3a" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg></button><div class="sb-top-title"><strong>Sorteos y premios</strong><small>Promociones y dinámicas</small></div><button type="button" class="sb-icon-btn" id="rafflesRefresh" aria-label="Actualizar" ${busy ? 'disabled' : ''}><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/></svg></button></div>`;
  if (error && !data) return `<section class="sr-page">${top}<div class="error-box"><span>${esc(error)}</span></div><button type="button" class="primary" id="rafflesRetry">Reintentar</button></section>`;
  if (!data) return `<section class="sr-page">${top}<div class="loading-card"><span class="spinner"></span><strong>Cargando sorteos…</strong></div></section>`;
  const m = raffleMetrics(data);
  const draws = data.sorteos || []; const premios = data.premios || []; const entregas = data.entregas || [];
  const metrics = `<div class="sr-metrics"><article><i class="red">🎟️</i><div><b>${m.tickets.toLocaleString('es-HN')}</b><small>boletos emitidos</small></div></article><article><i class="blue">◉</i><div><b>${m.active}</b><small>sorteos activos</small></div></article><article><i class="gold">🎁</i><div><b>${m.prizes}</b><small>premios disponibles</small></div></article><article><i class="green">✓</i><div><b>${m.pending}</b><small>elecciones pendientes</small></div></article></div>`;
  const banner = status?.text ? `<div class="sr-status ${esc(status.type || '')}">${busy && !status.type ? '<span class="spinner"></span>' : ''}<span>${esc(status.text)}</span></div>` : '';
  const tabs = `<nav class="sr-tabs">${[['sorteos', '🎟️ Sorteos'], ['premios', '🎁 Premios digitales'], ['ganadores', '🏆 Ganadores']].map(([id, l]) => `<button type="button" class="${tab === id ? 'on' : ''}" data-sr-tab="${id}">${l}</button>`).join('')}</nav>`;
  let body = '';
  if (tab === 'premios') {
    body = `<div class="sr-toolbar"><div><b>Catálogo de premios digitales</b><span>Perfiles, descuentos, cine, recargas, días extra o algo personalizado.</span></div><div class="sr-toolbar-btns"><button type="button" class="sr-btn vip" id="srPrepareVip" ${busy ? 'disabled' : ''}>👑 Preparar Club VIP</button><button type="button" class="sr-btn primary" id="srNewPrize" ${busy ? 'disabled' : ''}>＋ Nuevo premio</button></div></div>
      <div class="sr-list">${premios.map(p => prizeCard(p, busy)).join('') || '<div class="sr-empty"><b>No hay premios todavía.</b><br>Agrega al menos uno para crear un sorteo.</div>'}</div>`;
  } else if (tab === 'ganadores') {
    const won = draws.filter(d => d.ganador);
    body = `<div class="sr-toolbar"><div><b>Ganadores y entregas</b><span>El cliente elige su premio desde su enlace; aquí se completa la entrega.</span></div></div>
      <div class="sr-list">${won.map(d => winnerRow(d, entregas, busy)).join('') || '<div class="sr-empty"><b>Aún no hay ganadores.</b><br>Cuando gires una ruleta, el resultado aparecerá aquí.</div>'}</div>`;
  } else {
    body = `<div class="sr-toolbar"><div><b>Campañas de premios</b><span>El ganador recibe o elige entre 1 y 5 premios digitales.</span></div><button type="button" class="sr-btn primary" id="srNewDraw" ${busy ? 'disabled' : ''}>＋ Nuevo sorteo</button></div>
      <div class="sr-list">${draws.map(d => drawCard(d, premios, busy)).join('') || '<div class="sr-empty"><b>Todavía no hay sorteos.</b><br>Crea al menos un premio y publica tu primera campaña.</div>'}</div>`;
  }
  return `<section class="sr-page">${top}${metrics}${banner}${tabs}${body}</section>`;
}

/* ───────────── hojas (formularios) ───────────── */
const sheetHead = (kicker, title) => `<div class="sr-sheet-head"><div><small>${esc(kicker)}</small><h3>${esc(title)}</h3></div><button type="button" class="sr-x" data-sr-cancel aria-label="Cerrar">×</button></div>`;

export function prizeSheetHtml({ prize = null, permisos = { alcance: 'todos' }, accent = '#e2231a' } = {}) {
  const p = prize ? { ...prize } : { nombre: '', descripcion: '', tipo: 'perfil', valor: 1, unidad: 'mes', plataforma: '', entregaModo: 'manual', instrucciones: '', stock: 1, activo: true, color: accent, ownerVendor: permisos.alcance === 'relojes' ? 'relojes' : 'sublicuentas' };
  const types = Object.entries(TIPO_PREMIO).map(([v, t]) => `<option value="${v}" ${v === p.tipo ? 'selected' : ''}>${t[0]} ${esc(t[1])}</option>`).join('');
  return `<form class="sr-form" id="srPrizeForm">${sheetHead('PREMIO DIGITAL', prize ? 'Editar premio' : 'Nuevo premio')}
    <label class="sr-field">Nombre del premio<input id="srPrizeName" maxlength="120" required value="${esc(p.nombre)}" placeholder="Ej. 1 mes de Netflix"></label>
    <div class="sr-row"><label class="sr-field">Tipo<select id="srPrizeType">${types}</select></label>${permisos.alcance === 'todos' ? `<label class="sr-field">Lo administra<select id="srPrizeOwner"><option value="sublicuentas" ${p.ownerVendor !== 'relojes' ? 'selected' : ''}>Sublicuentas</option><option value="relojes" ${p.ownerVendor === 'relojes' ? 'selected' : ''}>Relojes</option></select></label>` : ''}</div>
    <div class="sr-row"><label class="sr-field">Valor<input id="srPrizeValue" type="number" inputmode="decimal" min="0" step="1" value="${Number(p.valor) || 0}"></label><label class="sr-field">Unidad<input id="srPrizeUnit" maxlength="40" value="${esc(p.unidad || '')}" placeholder="mes, %, Lps., días"></label></div>
    <label class="sr-field">Plataforma o proveedor<input id="srPrizePlatform" maxlength="100" value="${esc(p.plataforma || '')}" placeholder="Netflix, Cinemark, Tigo…"></label>
    <label class="sr-field">Descripción<textarea id="srPrizeDesc" rows="2" maxlength="500" placeholder="Qué recibirá el ganador">${esc(p.descripcion || '')}</textarea></label>
    <div class="sr-row"><label class="sr-field">Forma de entrega<select id="srPrizeDelivery"><option value="manual" ${p.entregaModo === 'manual' ? 'selected' : ''}>Preparación manual</option><option value="codigo" ${p.entregaModo === 'codigo' ? 'selected' : ''}>Código / QR digital</option><option value="cupon" ${p.entregaModo === 'cupon' ? 'selected' : ''}>Cupón automático</option></select></label><label class="sr-field">Existencias<input id="srPrizeStock" type="number" inputmode="numeric" min="0" max="9999" value="${Number(p.stock) || 0}"></label></div>
    <label class="sr-field">Nuevos códigos digitales · uno por línea<textarea id="srPrizeCodes" rows="3" placeholder="CINE-ABC-123&#10;CINE-XYZ-456"></textarea><small>${prize && p.entregaModo === 'codigo' ? `Ya hay ${Number(p.codigosDisponibles) || 0} código(s) guardado(s). Los nuevos se agregan sin mostrarlos aquí.` : 'Para boletos de cine u otros códigos virtuales.'}</small></label>
    <label class="sr-field">Instrucciones para el ganador<textarea id="srPrizeInstructions" rows="2" maxlength="500" placeholder="Cómo usar o reclamar el premio">${esc(p.instrucciones || '')}</textarea></label>
    <div class="sr-row"><label class="sr-field">Color<input id="srPrizeColor" type="color" value="${esc(safeHex(p.color, accent))}"></label><label class="sr-switch"><input id="srPrizeActive" type="checkbox" ${p.activo !== false ? 'checked' : ''}><span></span>Premio disponible</label></div>
    <div class="sr-actions"><button type="button" class="sr-btn ghost" data-sr-cancel>Cancelar</button><button type="submit" class="sr-btn primary">Guardar premio</button></div></form>`;
}
export function readPrizeForm(root) {
  const q = s => root.querySelector(s);
  return {
    nombre: q('#srPrizeName').value.trim(), tipo: q('#srPrizeType').value, valor: Number(q('#srPrizeValue').value) || 0,
    unidad: q('#srPrizeUnit').value.trim(), plataforma: q('#srPrizePlatform').value.trim(), descripcion: q('#srPrizeDesc').value.trim(),
    entregaModo: q('#srPrizeDelivery').value, stock: Number(q('#srPrizeStock').value) || 0,
    codigos: q('#srPrizeCodes').value.split(/\r?\n/).map(x => x.trim()).filter(Boolean),
    instrucciones: q('#srPrizeInstructions').value.trim(), color: q('#srPrizeColor').value, activo: q('#srPrizeActive').checked,
    ownerVendor: q('#srPrizeOwner')?.value || 'relojes',
  };
}

export function drawSheetHtml({ draw = null, premios = [], permisos = { alcance: 'todos' }, accent = '#e2231a', now = new Date() } = {}) {
  const d = draw ? { ...draw } : { titulo: '', descripcion: '', categoria: 'general', alcance: permisos.alcance === 'relojes' ? 'relojes' : 'sublicuentas', estado: 'activo', fechaInicio: defaultLocal(0, now), fechaFin: defaultLocal(7, now), premioIds: [], reglas: { limitePorCliente: 30 }, color: accent };
  const cat = d.categoria === 'oro' ? 'club_vip' : d.categoria;
  const scopes = permisos.alcance === 'relojes' ? '<option value="relojes">Relojes</option>' : Object.entries(ALCANCES).map(([v, l]) => `<option value="${v}" ${v === d.alcance ? 'selected' : ''}>${l}</option>`).join('');
  const picks = premios.filter(p => p.activo !== false || (d.premioIds || []).includes(p.id));
  return `<form class="sr-form" id="srDrawForm">${sheetHead('CAMPAÑA DE FIDELIDAD', draw ? 'Editar sorteo' : 'Nuevo sorteo')}
    <label class="sr-field">Nombre del sorteo<input id="srDrawTitle" maxlength="140" required value="${esc(d.titulo)}" placeholder="Ej. Gran sorteo de septiembre"></label>
    <label class="sr-field">Mensaje para los clientes<textarea id="srDrawDesc" rows="2" maxlength="600" placeholder="Renueva a tiempo y gana más oportunidades…">${esc(d.descripcion || '')}</textarea></label>
    <div class="sr-row"><label class="sr-field">Categoría<select id="srDrawCategory">${Object.entries(CATEGORIAS).map(([v, l]) => `<option value="${v}" ${v === cat ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label><label class="sr-field">Clientes de<select id="srDrawScope">${scopes}</select></label></div>
    <div class="sr-row"><label class="sr-field">Inicio<input id="srDrawStart" type="datetime-local" required value="${esc(localInput(d.fechaInicio) || defaultLocal(0, now))}"></label><label class="sr-field">Cierre<input id="srDrawEnd" type="datetime-local" required value="${esc(localInput(d.fechaFin) || defaultLocal(7, now))}"></label></div>
    <div class="sr-row"><label class="sr-field">Publicación<select id="srDrawState"><option value="activo" ${d.estado === 'activo' ? 'selected' : ''}>Publicar ahora</option><option value="borrador" ${d.estado === 'borrador' ? 'selected' : ''}>Guardar borrador</option></select></label><label class="sr-field">Color<input id="srDrawColor" type="color" value="${esc(safeHex(d.color, accent))}"></label></div>
    <div class="sr-note"><b>Boletos automáticos</b><span>Compra nueva = 1 boleto · renovación puntual = 2. La misma operación nunca se cuenta dos veces. Los niveles de fidelidad no agregan boletos.</span></div>
    <div class="sr-note vip" id="srVipConditions" ${cat === 'club_vip' ? '' : 'hidden'}><b>👑 Condiciones Club VIP</b><span>Solo participan clientes Oro, Diamante y Élite vigentes. El premio se reclama en 72 horas, no se cambia por efectivo ni es transferible. Un ganador no repite durante 60 días.</span></div>
    <label class="sr-field">Máximo de boletos por cliente<input id="srRuleLimit" type="number" inputmode="numeric" min="1" max="200" value="${Number(d.reglas?.limitePorCliente) || 30}"></label>
    <div class="sr-picker-head"><b>Premio del ganador</b><span id="srDrawHint">Elige entre 1 y 5 premios.</span></div>
    <div class="sr-picker">${picks.map(p => `<label><input type="checkbox" data-sr-prize-choice value="${esc(p.id)}" ${(d.premioIds || []).includes(p.id) ? 'checked' : ''}><i>${(TIPO_PREMIO[p.tipo] || TIPO_PREMIO.personalizado)[0]}</i><span><b>${esc(p.nombre)}</b><small>${esc(stockText(p))}</small></span></label>`).join('') || '<div class="sr-empty">No hay premios activos.</div>'}</div>
    <div class="sr-actions"><button type="button" class="sr-btn ghost" data-sr-cancel>Cancelar</button><button type="submit" class="sr-btn primary">Guardar sorteo</button></div></form>`;
}
export function readDrawForm(root) {
  const q = s => root.querySelector(s);
  const selected = [...root.querySelectorAll('[data-sr-prize-choice]')].filter(i => i.checked).map(i => i.value);
  if (selected.length < 1 || selected.length > 5) throw new Error('Selecciona entre 1 y 5 premios para el ganador.');
  const start = q('#srDrawStart').value, end = q('#srDrawEnd').value;
  return {
    titulo: q('#srDrawTitle').value.trim(), descripcion: q('#srDrawDesc').value.trim(), categoria: q('#srDrawCategory').value, alcance: q('#srDrawScope').value,
    estado: q('#srDrawState').value, fechaInicio: start ? new Date(start).toISOString() : '', fechaFin: end ? new Date(end).toISOString() : '',
    color: q('#srDrawColor').value, premioIds: selected, reglas: { compra: 1, renovacion: 2, bonoNivel: false, limitePorCliente: Number(q('#srRuleLimit').value) },
  };
}

export function ticketsSheetHtml({ draw = {}, tickets = [] } = {}) {
  const label = t => (t === 'renovacion' ? 'Renovación' : t === 'oro' ? 'Bono Oro' : 'Compra nueva');
  return `<div class="sr-form">${sheetHead('BOLETOS PARTICIPANTES', draw.titulo || 'Sorteo')}
    <div class="sr-tickets">${tickets.map(t => `<article><b>${esc(t.codigo)}</b><span>${esc(t.clienteNombre || 'Cliente')}</span><small>${label(t.tipo)}</small></article>`).join('') || '<div class="sr-empty">No hay boletos emitidos todavía.</div>'}</div>
    ${Number(draw.totalBoletos) > tickets.length ? `<p class="sr-list-note">Se muestran los boletos recientes disponibles en esta vista. Total registrado: ${Number(draw.totalBoletos)}.</p>` : ''}
    <div class="sr-actions"><button type="button" class="sr-btn primary" data-sr-cancel>Cerrar</button></div></div>`;
}

export function wheelSheetHtml({ draw = {}, tickets = [] } = {}) {
  const people = new Map();
  tickets.forEach(t => { const k = String(t.clientId || t.clienteNombre || t.id); const p = people.get(k) || { nombre: t.clienteNombre || 'Cliente', boletos: 0, codigos: [] }; p.boletos += 1; p.codigos.push(t.codigo); people.set(k, p); });
  const rows = [...people.values()].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es')).map((p, i) => `<article><i>${i + 1}</i><div><b>${esc(p.nombre)}</b><span>${p.boletos} boleto${p.boletos === 1 ? '' : 's'}</span></div><small>${esc(p.codigos.join(', '))}</small></article>`).join('');
  return `<div class="sr-form">${sheetHead('🔴 SORTEO EN VIVO · AUDITABLE', draw.titulo || 'Sorteo')}
    <div class="sr-wheel-stage"><span class="ptr">▼</span><div class="sr-wheel" id="srWheel"><div><b>${tickets.length}</b><span>boletos</span></div></div></div>
    <div class="sr-live" id="srWheelLive">Al girar verás pasar cada boleto participante.</div>
    <div class="sr-facts"><span>👥 <b>${people.size}</b> clientes vigentes</span><span>🎟️ <b>${tickets.length}</b> boletos</span><span>🔀 Selección <b>aleatoria</b></span></div>
    <p class="sr-list-note">Todos los boletos vigentes participan. La elección es aleatoria, se hace una sola vez y queda registrada.</p>
    <details class="sr-people"><summary>Ver lista completa de participantes <b>${people.size}</b></summary><div class="sr-people-list">${rows || '<div class="sr-empty">No hay participantes vigentes.</div>'}</div></details>
    <div class="sr-result" id="srWheelResult"><span>🏆 Todo listo para conocer al ganador.</span></div>
    <div class="sr-actions"><button type="button" class="sr-btn ghost" id="srWheelCancel" data-sr-cancel>Cancelar</button><button type="button" class="sr-btn primary pulse" id="srWheelGo">🎡 INICIAR SORTEO</button></div></div>`;
}

export function confirmSheetHtml({ title = '', body = '', ok = 'Aceptar', cancel = 'Cancelar', danger = false } = {}) {
  return `<div class="sr-form sr-confirm">${sheetHead('CONFIRMAR', title)}<div class="sr-confirm-body">${esc(body)}</div><div class="sr-actions"><button type="button" class="sr-btn ghost" data-sr-no>${esc(cancel)}</button><button type="button" class="sr-btn ${danger ? 'danger solid' : 'primary'}" data-sr-yes>${esc(ok)}</button></div></div>`;
}

/* ───────────── textos de auditoría / carga histórica ───────────── */
export function backfillPreviewText(p = {}, titulo = '') {
  const n = v => Number(v) || 0;
  return `Clientes vigentes detectados: ${n(p.clientesDetectados)}\nCompras verificadas: ${n(p.compras)}\nRenovaciones verificadas por servicio: ${n(p.renovaciones)}\nBoletos estimados: ${n(p.boletosEstimados)}\nRegistros ambiguos sin emitir: ${n(p.ambiguos)}\n\nLos meses y niveles no multiplican boletos.\n\n¿Autorizas emitir únicamente estos boletos comprobados en “${titulo}”?`;
}
export function auditText(report = {}) {
  const s = report.resumen || {}; const diffs = Array.isArray(report.diferencias) ? report.diferencias : [];
  const n = v => Number(v) || 0;
  const examples = diffs.slice(0, 8).map(item => {
    const parts = [];
    if (n(item.faltantes)) parts.push(`faltan ${n(item.faltantes)}`);
    if (n(item.sobrantes) + n(item.sinRespaldo)) parts.push(`sobran/sin respaldo ${n(item.sobrantes) + n(item.sinRespaldo)}`);
    if (n(item.ambiguos)) parts.push(`${n(item.ambiguos)} para revisión manual`);
    return `• ${item.nombre || 'Cliente'}${item.telefono ? ` (${item.telefono})` : ''}: ${parts.join(', ') || 'sin diferencia'}`;
  }).join('\n');
  return {
    text: `AUDITORÍA REAL · SOLO LECTURA · DESDE 01/08/2026\n\nOperaciones verificadas: ${n(s.operacionesVerificadas)}\nBoletos correctos esperados: ${n(s.boletosEsperados)}\nBoletos guardados: ${n(s.boletosGuardados)}\nFaltantes: ${n(s.faltantes)}\nSobrantes o sin respaldo: ${n(s.sobrantesOSinRespaldo)}\nRegistros ambiguos sin contar: ${n(s.registrosAmbiguos)}\nClientes con diferencias: ${n(s.clientesConDiferencias)}${examples ? `\n\nPrimeros casos:\n${examples}` : ''}`,
    needsRepair: n(s.faltantes) > 0 || n(s.sobrantesOSinRespaldo) > 0,
    ambiguos: n(s.registrosAmbiguos),
    boletosEsperados: n(s.boletosEsperados),
  };
}
