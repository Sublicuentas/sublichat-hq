// Módulos de "Más" conectados a Sublichat HQ: Pelis (/api/tmdb), Partidos (/api/partidos) y Subli (/api/chat).
// Funciones puras que devuelven HTML (el contenido va dentro de subPage() en main.js).
import { parseDateDMY } from './data.js';
import { platformLabel } from './operations.js';

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const spinner = text => `<div class="loading-card"><span class="spinner"></span><strong>${esc(text)}</strong></div>`;
const errorBox = text => `<div class="error-box"><span>${esc(text)}</span></div>`;

/* ───────────── Pelis ───────────── */
export function moviesContentHtml({ query = '', results = null, loading = false, error = '' } = {}) {
  const form = `<form class="mv-search" id="movieForm"><input id="movieQuery" type="search" placeholder="Buscar película o serie…" value="${esc(query)}" autocomplete="off"><button class="primary" type="submit" ${loading ? 'disabled' : ''}>Buscar</button></form><p class="muted note">Dónde verla en Honduras (datos de TMDB).</p>`;
  let body = '';
  if (loading) body = spinner('Buscando…');
  else if (error) body = errorBox(error);
  else if (results == null) body = '<div class="empty-state"><strong>🎬 Escriba un título</strong><span>Le muestro la sinopsis y en qué plataformas está disponible en Honduras.</span></div>';
  else if (!results.length) body = '<div class="empty-state"><strong>Sin resultados</strong><span>Pruebe con otro nombre.</span></div>';
  else {
    body = `<section class="list-stack">${results.map(r => {
      const providers = Array.isArray(r.proveedores) ? r.proveedores : [];
      const meta = [r.tipo, r.anio, r.rating ? `⭐ ${r.rating}` : ''].filter(Boolean).join(' · ');
      return `<article class="mv-card">${r.poster ? `<img class="mv-poster" src="${esc(r.poster)}" alt="" loading="lazy">` : '<div class="mv-poster mv-noposter">🎬</div>'}<div class="mv-info"><strong>${esc(r.titulo)}</strong><span>${esc(meta)}</span>${r.sinopsis ? `<p class="mv-sinopsis">${esc(r.sinopsis)}</p>` : ''}<div class="mv-chips">${providers.length ? providers.map(p => `<b>${esc(p)}</b>`).join('') : '<em>Sin plataformas en Honduras</em>'}</div></div></article>`;
    }).join('')}</section>`;
  }
  return form + body;
}

/* ───────────── Partidos ───────────── */
export const MATCH_MODES = Object.freeze([['hoy', 'Hoy'], ['nba', 'NBA'], ['mlb', 'MLB'], ['ufc', 'UFC'], ['tenis', 'Tenis'], ['f1', 'F1']]);

function matchStatus(m) {
  const st = String(m?.estado || '').toUpperCase();
  if (st === 'LIVE' || st === '1H' || st === '2H' || st === 'HT') return '<span class="mt-live">EN VIVO</span>';
  if (st === 'FT' || st === 'AET' || st === 'PEN') return '<span class="mt-final">Final</span>';
  return `<span class="mt-hora">${esc(m?.horaHN || '')}</span>`;
}
function team(name, logo) { return `<div class="mt-team">${logo ? `<img src="${esc(logo)}" alt="" loading="lazy">` : ''}<b>${esc(name || 'Por confirmar')}</b></div>`; }

export function matchesContentHtml({ mode = 'hoy', query = '', matches = null, loading = false, error = '' } = {}) {
  const chips = `<div class="mt-modes">${MATCH_MODES.map(([id, label]) => `<button type="button" class="${mode === id ? 'active' : ''}" data-match-mode="${id}">${label}</button>`).join('')}</div>`;
  const form = `<form class="mv-search" id="matchForm"><input id="matchQuery" type="search" placeholder="Buscar equipo…" value="${esc(mode === 'equipo' ? query : '')}" autocomplete="off"><button class="primary" type="submit" ${loading ? 'disabled' : ''}>Buscar</button></form>`;
  let body = '';
  if (loading) body = spinner('Cargando calendario…');
  else if (error) body = errorBox(error);
  else if (matches == null) body = '';
  else if (!matches.length) body = '<div class="empty-state"><strong>Sin partidos</strong><span>No hay partidos para esta selección.</span></div>';
  else {
    const groups = new Map();
    matches.forEach(m => { const k = m?.liga || 'Otros'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(m); });
    body = [...groups.entries()].map(([liga, rows]) => `<section class="mt-group"><h3 class="mt-liga">${esc(liga)}</h3>${rows.map(m => {
      const hasScore = m.golesLocal != null && m.golesVisita != null;
      return `<article class="mt-row">${team(m.local, m.logoLocal)}<div class="mt-mid">${hasScore ? `<strong>${esc(m.golesLocal)} - ${esc(m.golesVisita)}</strong>` : '<strong>vs</strong>'}${matchStatus(m)}</div>${team(m.visita, m.logoVisita)}${m.canal ? `<small class="mt-canal">📺 ${esc(m.canal)}</small>` : ''}</article>`;
    }).join('')}</section>`).join('');
  }
  return chips + form + body;
}

/* ───────────── Subli (asistente) ───────────── */
export const SUBLI_SUGGESTIONS = Object.freeze([
  '¿Qué clientes vencen hoy?', '¿Cuánto cobro esta semana?', 'Clientes vencidos con teléfono', '¿Cuántos clientes tiene cada vendedor?',
]);

export function subliContentHtml({ messages = [], loading = false } = {}) {
  const intro = '<div class="sb-msg bot">Hola 👋 Soy Subli. Pregúnteme por un cliente, sus cuentas, cobros de hoy o totales. Uso los datos reales de su cartera.</div>';
  const list = messages.map(m => `<div class="sb-msg ${m.role === 'user' ? 'me' : 'bot'} ${m.error ? 'err' : ''}">${esc(m.text).replace(/\n/g, '<br>')}</div>`).join('');
  const typing = loading ? '<div class="sb-msg bot typing"><span class="spinner"></span> Pensando…</div>' : '';
  const chips = messages.length ? '' : `<div class="sb-chips">${SUBLI_SUGGESTIONS.map(s => `<button type="button" data-subli-suggest="${esc(s)}">${esc(s)}</button>`).join('')}</div>`;
  return `<section class="subli-box"><div class="subli-msgs">${intro}${list}${typing}</div>${chips}<form class="sb-form" id="subliForm"><textarea id="subliInput" rows="2" placeholder="Escriba su pregunta…" ${loading ? 'disabled' : ''}></textarea><button class="primary" type="submit" ${loading ? 'disabled' : ''}>Enviar</button></form></section>`;
}

// Cartera que se le manda a Subli (misma forma que usa Sublichat web: nombre, tel, vendedor, cuentas[]).
export function subliClientsPayload(clients = [], today = new Date()) {
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return (Array.isArray(clients) ? clients : []).map(c => ({
    nombre: String(c?.nombrePerfil || c?.nombre || '').trim(),
    tel: String(c?.telefono || '').trim(),
    vendedor: String(c?.vendedor || '').trim(),
    cuentas: (Array.isArray(c?.servicios) ? c.servicios : []).map(s => {
      const d = parseDateDMY(String(s?.fechaRenovacion || ''));
      const diff = d ? Math.round((d - base) / 86400000) : null;
      return {
        plataforma: platformLabel(s?.plataforma) || String(s?.plataforma || ''),
        precio: Number(s?.precio || 0) || 0,
        renueva: d ? iso(d) : '',
        estado: diff == null ? 'sin fecha' : (diff < 0 ? 'vencido' : (diff === 0 ? 'vence hoy' : 'vigente')),
        correo: String(s?.correo || ''),
        clave: String(s?.clave || ''),
        pinPerfil: String(s?.pinPerfil || ''),
      };
    }),
  })).filter(c => c.nombre || c.tel);
}
