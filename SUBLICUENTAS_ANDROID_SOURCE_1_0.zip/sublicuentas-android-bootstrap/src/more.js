// Módulos de "Más" conectados a Sublichat HQ: Pelis (/api/tmdb), Partidos (/api/partidos) y Subli (/api/chat).
// Funciones puras que devuelven HTML (el contenido va dentro de subPage() en main.js).
import { parseDateDMY } from './data.js';
import { platformLabel } from './operations.js';

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const spinner = text => `<div class="loading-card"><span class="spinner"></span><strong>${esc(text)}</strong></div>`;
const errorBox = text => `<div class="error-box"><span>${esc(text)}</span></div>`;

/* ───────────── Pelis ───────────── */
// La pantalla vive en screens.js (rediseño R39); se reexporta con el nombre de siempre.
export { moviesContentHtml } from './screens.js';

/* ───────────── Partidos ───────────── */
export const MATCH_MODES = Object.freeze([['hoy', 'Hoy'], ['nba', 'NBA'], ['mlb', 'MLB'], ['ufc', 'UFC'], ['tenis', 'Tenis'], ['f1', 'F1']]);

const TZ = 'America/Tegucigalpa';
const MONTHS = { ene: 1, feb: 2, mar: 3, abr: 4, may: 5, jun: 6, jul: 7, ago: 8, sep: 9, set: 9, oct: 10, nov: 11, dic: 12 };

// Hoy en Honduras (AAAA-MM-DD), sin depender de la zona horaria del teléfono.
export function todayHN(now = new Date()) { return now.toLocaleDateString('en-CA', { timeZone: TZ }); }

// Día (AAAA-MM-DD, hora Honduras) de un partido: usa `dia` si el servidor lo manda; si no, lo saca de `horaHN`
// ("mar, 22 sept, 05:00 p. m.") para que funcione también con la versión anterior de /api/partidos.
export function matchDayKey(m, today = todayHN()) {
  if (m?.dia && /^\d{4}-\d{2}-\d{2}$/.test(String(m.dia))) return String(m.dia);
  const txt = String(m?.horaHN || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const hit = txt.match(/(\d{1,2})\s+([a-z]{3,})/);
  const month = hit ? MONTHS[hit[2].slice(0, 3)] : 0;
  if (!hit || !month) return '';
  const [ty, tm] = today.split('-').map(Number);
  let year = ty;
  if (month < tm - 6) year = ty + 1; else if (month > tm + 6) year = ty - 1;
  return `${year}-${String(month).padStart(2, '0')}-${String(Number(hit[1])).padStart(2, '0')}`;
}

function dayLabel(key) {
  const d = new Date(`${key}T12:00:00`);
  if (Number.isNaN(d.getTime())) return key;
  const t = d.toLocaleDateString('es-HN', { weekday: 'long', day: 'numeric', month: 'long' });
  return t.charAt(0).toUpperCase() + t.slice(1);
}

function matchStatus(m) {
  const st = String(m?.estado || '').toUpperCase();
  if (st === 'LIVE' || st === '1H' || st === '2H' || st === 'HT') return '<span class="mt-live">EN VIVO</span>';
  if (st === 'FT' || st === 'AET' || st === 'PEN') return '<span class="mt-final">Final</span>';
  return `<span class="mt-hora">${esc(m?.horaHN || '')}</span>`;
}
function team(name, logo) { return `<div class="mt-team">${logo ? `<img src="${esc(logo)}" alt="" loading="lazy">` : ''}<b>${esc(name || 'Por confirmar')}</b></div>`; }

function ligaGroups(rows) {
  const groups = new Map();
  rows.forEach(m => { const k = m?.liga || 'Otros'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(m); });
  return [...groups.entries()].map(([liga, list]) => `<section class="mt-group"><h3 class="mt-liga">${esc(liga)}</h3>${list.map(m => {
    const hasScore = m.golesLocal != null && m.golesVisita != null;
    return `<article class="mt-row">${team(m.local, m.logoLocal)}<div class="mt-mid">${hasScore ? `<strong>${esc(m.golesLocal)} - ${esc(m.golesVisita)}</strong>` : '<strong>vs</strong>'}${matchStatus(m)}</div>${team(m.visita, m.logoVisita)}${m.canal ? `<small class="mt-canal">📺 ${esc(m.canal)}</small>` : ''}</article>`;
  }).join('')}</section>`).join('');
}

export function matchesContentHtml({ mode = 'hoy', query = '', matches = null, loading = false, error = '', today = todayHN(), meta = null } = {}) {
  const chips = `<div class="mt-modes">${MATCH_MODES.map(([id, label]) => `<button type="button" class="${mode === id ? 'active' : ''}" data-match-mode="${id}">${label}</button>`).join('')}</div>`;
  const form = `<form class="mv-search" id="matchForm"><input id="matchQuery" type="search" placeholder="Buscar equipo…" value="${esc(mode === 'equipo' ? query : '')}" autocomplete="off"><button class="primary" type="submit" ${loading ? 'disabled' : ''}>Buscar</button></form>`;
  let body = '';
  if (loading) body = spinner('Cargando calendario…');
  else if (error) body = errorBox(error);
  else if (matches == null) body = '';
  else if (!matches.length) body = '<div class="empty-state"><strong>Sin partidos</strong><span>No hay partidos para esta selección.</span></div>';
  else if (mode === 'hoy') {
    // "Hoy" solo muestra partidos de hoy (hora Honduras). Si no hay, se dice claro y se muestran como "Próximos".
    const withDay = matches.map(m => ({ m, day: matchDayKey(m, today) }));
    const todays = withDay.filter(x => x.day === today).map(x => x.m);
    if (todays.length && !meta?.soloProximos) {
      body = `<h2 class="mt-day">Hoy · ${esc(dayLabel(today))}</h2>${ligaGroups(todays)}`;
    } else {
      const days = [...new Set(withDay.map(x => x.day))].sort();
      body = `<div class="mt-note">📅 Hoy (${esc(dayLabel(today))}) no hay partidos, o no se pudieron cargar. Estos son los <b>próximos eventos</b>:</div>${days.map(d => `<h2 class="mt-day">${d ? esc(dayLabel(d)) : 'Próximos'}</h2>${ligaGroups(withDay.filter(x => x.day === d).map(x => x.m))}`).join('')}`;
    }
  } else body = ligaGroups(matches);
  if (mode === 'hoy' && meta?.parcial && body && !loading && !error) body = `<div class="mt-note">⚠️ Algunas ligas no respondieron a tiempo; puede faltar información.${meta.detalle?.length ? `<br><small>${esc(meta.detalle.join(' · '))}</small>` : ''}</div>` + body;
  return chips + form + body;
}

/* ───────────── Subli (asistente) ───────────── */
// La pantalla vive en screens.js (rediseño R38); se reexporta con el nombre de siempre.
export { subliContentHtml, SUBLI_CATS, subliSuggestions } from './screens.js';

// Cartera que se le manda a Subli (misma forma que usa Sublichat web: nombre, tel, vendedor, cuentas[]).
export function subliClientsPayload(clients = [], today = new Date()) {
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return (Array.isArray(clients) ? clients : []).map(c => ({
    nombre: String(c?.nombrePerfil || c?.nombre || '').trim(),
    tel: String(c?.telefono || '').trim(),
    vendedor: String(c?.vendedor || '').trim(),
    cuentas: (Array.isArray(c?.servicios) ? c.servicios : []).map(s => {
      const d = parseDateDMY(String(s?.fechaRenovacion || ''));
      const diff = d ? Math.round((d - base) / 86400000) : null;
      return {
        plataforma: platformLabel(s?.plataforma) || String(s?.plataforma || ''),
        precio: Number(s?.precio || 0) || 0,
        renueva: d ? iso(d) : '',
        estado: diff == null ? 'sin fecha' : (diff < 0 ? 'vencido' : (diff === 0 ? 'vence hoy' : 'vigente')),
        correo: String(s?.correo || ''),
        clave: String(s?.clave || ''),
        pinPerfil: String(s?.pinPerfil || ''),
      };
    }),
  })).filter(c => c.nombre || c.tel);
}
