// Exportación profesional de Clientes y Cobros (R65) · según "Sublichat - Exportación Excel".
// Usa las MISMAS filas que alimentan la pantalla (allRows / filtros actuales), nunca el DOM ni el límite "Mostrar 100".
// Columnas por ALLOWLIST: jamás salen claves, PIN, correos de acceso, tokens ni credenciales IPTV.
import { parseDateDMY } from './data.js';

export const EXPORT_STATUS = Object.freeze({ vigentes: 'VIGENTES', hoy: 'HOY', proximos: 'PROXIMOS', proximo: 'PROXIMO', vencidos: 'VENCIDOS', todos: 'TODOS' });
const pad = n => String(n).padStart(2, '0');
export const isoDay = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const dmy = d => d ? `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}` : '';
export function rowStatus(date, today = new Date()) {
  if (!date) return 'SIN FECHA';
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const diff = Math.round((date - base) / 86400000);
  return diff < 0 ? 'VENCIDO' : diff === 0 ? 'HOY' : 'PROXIMO';
}
const toDate = v => { if (!v) return null; if (v instanceof Date) return v; if (typeof v === 'object' && v.seconds) return new Date(v.seconds * 1000); const d = parseDateDMY(String(v)) || new Date(String(v)); return Number.isFinite(d?.getTime?.()) ? d : null; };
const clean = v => String(v ?? '').replace(/[\t\r\n]+/g, ' ').trim();

// Una fila segura por servicio (allowlist).
export function toSafeServiceRow(r, { platformLabel = x => x, today = new Date() } = {}) {
  const raw = r.raw || {};
  const venc = parseDateDMY(r.fechaRenovacion);
  const meses = Number(raw.mesesContratados || raw.meses || 0);
  const perfiles = Array.isArray(r.perfiles) ? r.perfiles.length : 0;
  return {
    cliente: clean(r.nombre), telefono: clean(r.telefono), plataforma: clean(platformLabel(r.plataforma) || r.plataforma).replace(/^⭐\s*/, ''),
    plan: [meses ? `${meses} mes${meses === 1 ? '' : 'es'}` : '', perfiles > 1 ? `${perfiles} perfiles` : perfiles === 1 ? '1 perfil' : ''].filter(Boolean).join(' · '),
    vendedor: clean(r.vendedor), fechaInicio: toDate(raw.fechaCompra || raw.fechaInicio || raw.creadoEn || raw.createdAt), fechaVencimiento: venc,
    estado: rowStatus(venc, today), precioHnl: Number(r.precio) || 0, metodoPago: clean(raw.metodoPago || raw.formaPago || ''), notas: clean(raw.notaPublica || ''),
  };
}
// Resumen por cliente a partir de las MISMAS filas (así Resumen, Clientes y Servicios siempre cuadran).
export function buildExportDataset(rows = [], { platformLabel = x => x, today = new Date(), scope = 'filtered', filtros = {} } = {}) {
  const services = rows.map(r => toSafeServiceRow(r, { platformLabel, today }));
  const byClient = new Map();
  rows.forEach((r, i) => {
    const k = r.clienteId || `${String(r.nombre).toLowerCase()}|${String(r.telefono).replace(/\D/g, '')}`;
    const s = services[i];
    const c = byClient.get(k) || { cliente: s.cliente, telefono: s.telefono, vendedores: new Set(), plataformas: [], servicios: 0, totalHnl: 0, fechas: [], estados: new Set() };
    c.vendedores.add(s.vendedor || '—'); c.plataformas.push(s.plataforma); c.servicios += 1; c.totalHnl += s.precioHnl;
    if (s.fechaVencimiento) c.fechas.push(s.fechaVencimiento); c.estados.add(s.estado); byClient.set(k, c);
  });
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const clients = [...byClient.values()].map(c => {
    const futuras = c.fechas.filter(d => d >= base).sort((a, b) => a - b);
    const proxima = futuras[0] || c.fechas.sort((a, b) => b - a)[0] || null;
    const estado = c.estados.has('VENCIDO') && !futuras.length ? 'VENCIDO' : c.estados.has('HOY') ? 'HOY' : futuras.length ? 'VIGENTE' : c.estados.has('VENCIDO') ? 'VENCIDO' : 'SIN FECHA';
    return { cliente: c.cliente, telefono: c.telefono, vendedor: [...c.vendedores].join(' / '), plataformas: c.plataformas.join(' | '), servicios: c.servicios, totalHnl: c.totalHnl, proximaFecha: proxima, estado };
  }).sort((a, b) => (a.proximaFecha || 0) - (b.proximaFecha || 0) || a.cliente.localeCompare(b.cliente, 'es'));
  const count = (list, key) => { const m = new Map(); list.forEach(x => m.set(x[key] || '—', (m.get(x[key] || '—') || 0) + 1)); return [...m.entries()].sort((a, b) => b[1] - a[1]); };
  return { clients, services, meta: { generatedAt: new Date(), scope, filtros, totalClients: clients.length, totalServices: services.length, totalHnl: services.reduce((t, s) => t + s.precioHnl, 0), porEstado: count(services, 'estado'), porPlataforma: count(services, 'plataforma'), porVendedor: count(services, 'vendedor') } };
}
export function exportFileName(section, status, ext, now = new Date()) { return `SUBLICHAT_${section}_${EXPORT_STATUS[status] || String(status || 'TODOS').toUpperCase()}_${isoDay(now)}.${ext}`; }

/* ─────────── Excel (ExcelJS, ya incluido en la app) ─────────── */
export function buildExportWorkbook(ExcelJS, data, { titulo = 'SUBLICHAT - REPORTE' } = {}) {
  const wb = new ExcelJS.Workbook(); wb.creator = 'Sublichat'; wb.created = data.meta.generatedAt;
  const RED = 'FFE2231A', INK = 'FF0B1622', money = '"L" #,##0.00', dateFmt = 'dd/mm/yyyy';
  const head = ws => { const r = ws.getRow(1); r.font = { bold: true, color: { argb: 'FFFFFFFF' } }; r.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: RED } }; r.alignment = { vertical: 'middle' }; r.height = 20; ws.views = [{ state: 'frozen', ySplit: 1 }]; };
  // Resumen
  const rs = wb.addWorksheet('Resumen', { properties: { tabColor: { argb: RED } } });
  rs.columns = [{ width: 28 }, { width: 46 }];
  rs.addRow([titulo]).font = { bold: true, size: 15, color: { argb: RED } };
  const f = data.meta.filtros || {};
  const filas = [['Generado', data.meta.generatedAt], ['Alcance', data.meta.scope === 'all' ? 'Todos los autorizados' : 'Resultados filtrados'], ['Sección', f.seccion || ''], ['Estado', f.estado || 'Todos'], ['Vendedor', f.vendedor || 'Todos'], ['Plataforma', f.plataforma || 'Todas'], ['Búsqueda', f.busqueda || '—'], ['Orden', f.orden || '—'], [], ['Clientes', data.meta.totalClients], ['Servicios', data.meta.totalServices], ['Total (HNL)', data.meta.totalHnl], ['Moneda', 'HNL (Lempiras)']];
  filas.forEach(v => { const row = rs.addRow(v); if (v[0]) row.getCell(1).font = { bold: true, color: { argb: INK } }; });
  rs.getCell('B2').numFmt = 'dd/mm/yyyy hh:mm'; rs.getCell(`B${rs.rowCount - 1}`).numFmt = money;
  const bloque = (t, list) => { rs.addRow([]); rs.addRow([t, 'Servicios']).font = { bold: true, color: { argb: RED } }; list.forEach(([k, n]) => rs.addRow([k, n])); };
  bloque('Por estado', data.meta.porEstado); bloque('Por plataforma', data.meta.porPlataforma); bloque('Por vendedor', data.meta.porVendedor);
  // Clientes
  const cs = wb.addWorksheet('Clientes');
  cs.columns = [{ header: 'Cliente', key: 'cliente', width: 28 }, { header: 'Teléfono', key: 'telefono', width: 16 }, { header: 'Vendedor', key: 'vendedor', width: 20 }, { header: 'Plataformas', key: 'plataformas', width: 42 }, { header: 'Servicios', key: 'servicios', width: 11 }, { header: 'Total (HNL)', key: 'totalHnl', width: 14, style: { numFmt: money } }, { header: 'Próxima fecha', key: 'proximaFecha', width: 15, style: { numFmt: dateFmt } }, { header: 'Estado', key: 'estado', width: 12 }];
  data.clients.forEach(r => cs.addRow(r)); head(cs); if (data.clients.length) cs.autoFilter = { from: 'A1', to: `H${data.clients.length + 1}` };
  // Servicios
  const ss = wb.addWorksheet('Servicios');
  ss.columns = [{ header: 'Cliente', key: 'cliente', width: 28 }, { header: 'Teléfono', key: 'telefono', width: 16 }, { header: 'Plataforma', key: 'plataforma', width: 24 }, { header: 'Plan', key: 'plan', width: 18 }, { header: 'Vendedor', key: 'vendedor', width: 18 }, { header: 'Inicio', key: 'fechaInicio', width: 13, style: { numFmt: dateFmt } }, { header: 'Vencimiento', key: 'fechaVencimiento', width: 13, style: { numFmt: dateFmt } }, { header: 'Estado', key: 'estado', width: 12 }, { header: 'Precio (HNL)', key: 'precioHnl', width: 14, style: { numFmt: money } }, { header: 'Método de pago', key: 'metodoPago', width: 18 }, { header: 'Notas', key: 'notas', width: 32 }];
  data.services.forEach(r => ss.addRow(r)); head(ss); if (data.services.length) ss.autoFilter = { from: 'A1', to: `K${data.services.length + 1}` };
  return wb;
}
/* ─────────── CSV (UTF-8 con BOM, tildes correctas en Excel) y TXT (tabulado, 1 fila por servicio) ─────────── */
const q = v => { const s = String(v ?? ''); return /[",;\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
export function servicesToCsv(services) {
  const header = ['Cliente', 'Teléfono', 'Plataforma', 'Plan', 'Vendedor', 'Inicio', 'Vencimiento', 'Estado', 'Precio HNL', 'Método de pago', 'Notas'];
  const lines = services.map(r => [r.cliente, r.telefono, r.plataforma, r.plan, r.vendedor, dmy(r.fechaInicio), dmy(r.fechaVencimiento), r.estado, r.precioHnl.toFixed(2), r.metodoPago, r.notas].map(q).join(','));
  return '\uFEFF' + [header.join(','), ...lines].join('\r\n');
}
export function servicesToTxt(services) {
  const header = ['Cliente', 'Telefono', 'Plataforma', 'Plan', 'Vendedor', 'Vencimiento', 'Estado', 'Precio HNL'];
  return [header.join('\t'), ...services.map(r => [r.cliente, r.telefono, r.plataforma, r.plan, r.vendedor, dmy(r.fechaVencimiento), r.estado, r.precioHnl.toFixed(2)].map(clean).join('\t'))].join('\n');
}

/* ─────────── hoja inferior "Exportar" ─────────── */
const e = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const EXPORT_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg>';
export function exportSheetHtml({ section = 'CLIENTES', filteredCount = { clientes: 0, servicios: 0 }, allCount = { clientes: 0, servicios: 0 }, scope = 'filtered', format = 'xlsx', estadoLabel = '', busy = false, error = '' } = {}) {
  const opt = (name, value, cur, title, sub) => `<label class="ex-opt ${value === cur ? 'on' : ''}"><input type="radio" name="${name}" value="${value}" ${value === cur ? 'checked' : ''}><span><b>${title}</b><small>${sub}</small></span></label>`;
  const n = scope === 'all' ? allCount : filteredCount;
  return `<div class="ex-sheet"><div class="sheet-handle"></div><p class="eyebrow">EXPORTAR ${e(section)}</p><h2>Reporte de ${section === 'COBROS' ? 'cobros' : 'clientes'}</h2>
    <div class="ex-group"><span class="ex-lbl">Alcance</span>${opt('exScope', 'filtered', scope, 'Resultados filtrados', `${e(estadoLabel)} · ${filteredCount.clientes} clientes · ${filteredCount.servicios} servicios`)}${opt('exScope', 'all', scope, 'Todos los autorizados', `${allCount.clientes} clientes · ${allCount.servicios} servicios`)}</div>
    <div class="ex-group ex-row"><span class="ex-lbl">Formato</span>${opt('exFormat', 'xlsx', format, 'Excel', '.xlsx · 3 hojas')}${opt('exFormat', 'csv', format, 'CSV', 'hoja de cálculo')}${opt('exFormat', 'txt', format, 'TXT', 'texto plano')}</div>
    <p class="ex-note">🔒 Sin claves, PIN, correos de acceso ni credenciales. Incluye todos los resultados (no solo los ${'100'} visibles).</p>
    ${error ? `<p class="ex-error">${e(error)}</p>` : ''}
    ${n.servicios ? '' : '<p class="ex-error">No hay datos para exportar con estos filtros.</p>'}
    <div class="ex-actions"><button type="button" class="secondary" data-sr-cancel>Cancelar</button><button type="button" class="primary" id="exGo" ${busy || !n.servicios ? 'disabled' : ''}>${busy ? '<span class="spinner sm"></span> Generando…' : `${EXPORT_ICON} Generar y compartir`}</button></div></div>`;
}
