// Pantallas rediseñadas (Más y Clientes). Funciones puras que devuelven HTML: los datos y eventos viven en main.js.
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

/* ───────────── iconos de línea/planos (SVG en línea) ───────────── */
export const SVG = Object.freeze({
  search: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2.2"/><circle cx="9" cy="17" r="2.2"/></svg>',
  plus: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e2231a" stroke-width="3.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/></svg>',
  grid: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/></svg>',
  person: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 20c.6-4 3.8-6 7.5-6s6.9 2 7.5 6"/></svg>',
  doc: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M9 12h7M9 16h7"/></svg>',
  calendarBlue: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><rect x="5" y="9" width="38" height="33" rx="9" fill="#1f88e6"/><rect x="9" y="18" width="30" height="20" rx="5" fill="#fff"/><rect x="14" y="4" width="5" height="10" rx="2.5" fill="#0b5fb0"/><rect x="29" y="4" width="5" height="10" rx="2.5" fill="#0b5fb0"/><circle cx="18" cy="26" r="2.6" fill="#1f88e6"/><circle cx="30" cy="26" r="2.6" fill="#1f88e6"/><circle cx="18" cy="33" r="2.6" fill="#1f88e6"/></svg>',
  clock: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="24" cy="24" r="20" fill="#13a8e8"/><circle cx="24" cy="24" r="14.5" fill="#fff"/><path d="M24 15.5v9.2l6.4 3.6" stroke="#13a8e8" stroke-width="3.3" stroke-linecap="round" fill="none"/></svg>',
  warning: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M24 5 45 41H3Z" fill="#e2231a" stroke="#e2231a" stroke-width="3" stroke-linejoin="round"/><rect x="21.3" y="17" width="5.4" height="13" rx="2.7" fill="#fff"/><circle cx="24" cy="34.5" r="2.8" fill="#fff"/></svg>',
  people: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="10" cy="19" r="5" fill="#2b2f3a"/><path d="M1 37c.4-6.5 4-9.5 9-9.5 1.5 0 2.8.3 4 .9-2.6 2.3-4 5.2-4.2 8.6z" fill="#2b2f3a"/><circle cx="38" cy="19" r="5" fill="#2b2f3a"/><path d="M47 37c-.4-6.5-4-9.5-9-9.5-1.5 0-2.8.3-4 .9 2.6 2.3 4 5.2 4.2 8.6z" fill="#2b2f3a"/><circle cx="24" cy="14" r="8" fill="#e2231a"/><path d="M9 42c0-8.5 6.5-14 15-14s15 5.5 15 14z" fill="#e2231a"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
  dots: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#0a1f3a"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>',
  sort: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="#0a1f3a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4v16M4 16l4 4 4-4M16 20V4M12 8l4-4 4 4"/></svg>',
  user: '<svg viewBox="0 0 24 24" width="30" height="30" fill="#fff"><circle cx="12" cy="8" r="4.2"/><path d="M4 21c.5-4.6 3.8-7 8-7s7.5 2.4 8 7z"/></svg>',
});

/* ───────────── MÁS ───────────── */
export const MAS_MODULES = Object.freeze({
  pelis: { title: 'Pelis', sub: 'Películas y series', img: 'mas-pelis', tint: 'pink' },
  partidos: { title: 'Partidos', sub: 'Deportes en vivo', img: 'mas-partidos', tint: 'blue' },
  subli: { title: 'Subli', sub: 'Herramientas del sistema', img: 'mas-subli', tint: 'white' },
  perfil: { title: 'Perfil', sub: 'Tu cuenta y configuración', img: 'mas-perfil', tint: 'pink' },
  'nuevo-crm': { title: 'Nuevo CRM', sub: 'Agregar cliente', img: 'mas-nuevo-crm', tint: 'blue' },
  inventario: { title: 'Inventario', sub: 'Stock y cuentas', img: 'mas-inventario', tint: 'white' },
  'control-maestro': { title: 'Control Maestro', sub: 'Cuentas y estado', img: 'mas-control-maestro', tint: 'pink' },
  finanzas: { title: 'Control financiero', sub: 'Ingresos y egresos', img: 'mas-control-financiero', tint: 'blue' },
  sorteos: { title: 'Sorteos', sub: 'Promociones y dinámicas', img: 'mas-sorteos', tint: 'blue' },
  aula: { title: 'Aula de clases', sub: 'Capacitaciones', img: 'mas-aula', tint: 'pink' },
  materia: { title: 'Materia cerebral', sub: 'Ideas y recursos', img: 'mas-materia', tint: 'white' },
});

export function masHomeHtml({ modules = [], sessionLabel = 'Sublicuentas', online = true, syncText = 'En línea', version = '1.0' } = {}) {
  const cards = modules.filter(id => MAS_MODULES[id]).map((id, i) => {
    const m = MAS_MODULES[id];
    return `<button type="button" class="mas-card tint-${m.tint}" data-open="${esc(id)}"><span class="mas-ico"><img src="/assets/mas/${m.img}.png" alt="" loading="lazy"></span><span class="mas-txt"><strong>${esc(m.title)}</strong><small>${esc(m.sub)}</small></span><span class="mas-go">${SVG.chevron}</span></button>`;
  }).join('');
  return `<header class="mas-hero">
    <div class="mas-brand"><img src="/assets/sublicuentas-logo-oficial.png" alt="Sublicuentas"><small>Conectamos emociones, creamos experiencias</small></div>
    <p class="mas-eyebrow">MÓDULOS</p><h1>Más</h1><i class="mas-bar"></i><p class="mas-sub">Herramientas operativas · nada se elimina</p>
    <p class="mas-tagline">Más<br><em>que una app,</em><br><em>tu centro de control.</em></p>
    <img class="mas-robot" src="/assets/mas/mas-robot.png" alt="Sublibot">
  </header>
  <section class="mas-grid">${cards}<div class="mas-card mas-info tint-blue"><span class="mas-ico"><img src="/assets/mas/mas-resultados.png" alt="" loading="lazy"></span><span class="mas-txt"><em>MISMAS HERRAMIENTAS</em><strong>Más resultados</strong><small>Conectamos emociones, creamos experiencias.</small></span></div></section>
  <section class="mas-session"><div class="mas-session-who"><span class="av">${SVG.user}</span><div><small>Sesión</small><strong>${esc(sessionLabel)}</strong></div></div><div class="mas-session-ver"><span>Versión ${esc(version)}</span><b class="${online ? 'ok' : 'wait'}"><i></i>${esc(syncText)}</b></div></section>`;
}

/* ───────────── CLIENTES ───────────── */
export const CLIENT_SORTS = Object.freeze([['recientes', 'Más recientes'], ['vence', 'Próximo vencimiento'], ['nombre', 'Nombre A-Z'], ['monto', 'Mayor monto']]);

export function clientCardHtml(c = {}) {
  return `<article class="cli-card"><button type="button" class="cli-main" data-client-id="${esc(c.clienteId)}"><span class="cli-avatar tone-${esc(c.tone || 'r')}">${esc(c.initials || 'C')}</span><span class="cli-info"><strong>${esc(c.nombre)}</strong><span class="ph">${esc(c.telefono || 'Sin teléfono')}</span><small>${esc((c.plataformas || []).join(' · '))}</small></span><span class="cli-date">${esc(c.fecha || 'Sin fecha')}</span></button><button type="button" class="cli-dots" data-client-actions="${esc(c.actionKey)}" aria-label="Acciones">${SVG.dots}</button><div class="cli-foot"><b>${esc(c.total)}</b><span class="chip ${esc(c.statusTone || '')}">${esc(c.statusLabel || '')}</span><span class="chip vend">${esc(c.vendedor || 'Sin vendedor')}</span></div></article>`;
}

export function clientsScreenHtml({
  counts = {}, statusFilter = 'vigentes', search = '', filtersOpen = true, platforms = [], sellers = [], platformFilter = '', sellerFilter = '',
  limit = 100, sort = 'recientes', shown = 0, total = 0, uniqueClients = 0, cards = [], canNewCrm = false, platformLabel = v => v,
} = {}) {
  const tabs = [['vigentes', 'Vigentes', SVG.people], ['hoy', 'Hoy', SVG.calendarBlue], ['proximos', 'Próximos', SVG.clock], ['vencidos', 'Vencidos', SVG.warning]];
  const opt = (v, cur, label) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(label ?? v)}</option>`;
  const limitOpts = [[50, '50'], [100, '100'], [250, '250'], [1000, 'Todos']].map(([v, l]) => `<option value="${v}" ${Number(limit) === v ? 'selected' : ''}>${l}</option>`).join('');
  return `<section class="cli-hero"><button type="button" class="cli-refresh" id="refreshData" aria-label="Actualizar">${SVG.refresh}</button><div class="cli-hero-copy"><p class="eyebrow">CRM</p><h1>Clientes</h1><p class="muted">Cartera, cobros y renovaciones</p></div><img class="cli-hero-img" src="/assets/clientes-hero.png" alt=""></section>
    ${canNewCrm ? `<button type="button" class="cli-cta" data-tab-jump="nuevo-crm"><span class="plus">${SVG.plus}</span><span class="txt">Nuevo CRM · Registrar venta</span><span class="go">${SVG.chevron}</span></button>` : ''}
    <div class="cli-search"><span class="ico">${SVG.search}</span><input id="clientSearch" type="search" value="${esc(search)}" placeholder="Buscar cliente, teléfono o plataforma…" autocomplete="off"><button type="button" class="cli-filter-btn ${filtersOpen ? 'on' : ''}" id="clientFiltersToggle" aria-label="Filtros" aria-pressed="${filtersOpen}">${SVG.sliders}</button></div>
    <div class="cli-tabs">${tabs.map(([id, label, ico]) => `<button type="button" data-client-status="${id}" class="t-${id} ${statusFilter === id ? 'active' : ''}"><i class="ico">${ico}</i><span>${label}</span><b>${esc(counts[id] ?? 0)}</b><em></em></button>`).join('')}</div>
    <section class="cli-filters" ${filtersOpen ? '' : 'hidden'}>
      <label class="cli-filter"><span>Plataformas</span><div class="cli-sel"><i>${SVG.grid}</i><select id="clientPlatformFilter"><option value="">Todas</option>${platforms.map(v => opt(v, platformFilter, platformLabel(v))).join('')}</select></div></label>
      <label class="cli-filter"><span>Vendedores</span><div class="cli-sel"><i>${SVG.person}</i><select id="clientSellerFilter"><option value="">Todos</option>${sellers.map(v => opt(v, sellerFilter)).join('')}</select></div></label>
      <label class="cli-filter"><span>Mostrar</span><div class="cli-sel"><i>${SVG.doc}</i><select id="clientLimit">${limitOpts}</select></div></label>
    </section>
    <button type="button" class="cli-today" id="clientCobrosHoy"><i>${SVG.calendarBlue}</i><span>Cobros de hoy</span><b>${SVG.chevron}</b></button>
    <div class="cli-meta"><p>Mostrando <b>${esc(shown)}</b> de <b>${esc(total)}</b> registros · <b>${esc(uniqueClients)}</b> clientes</p><label class="cli-sort">${SVG.sort}<select id="clientSort" aria-label="Ordenar">${CLIENT_SORTS.map(([v, l]) => opt(v, sort, l)).join('')}</select></label></div>
    <section class="cli-list">${cards.length ? cards.map(clientCardHtml).join('') : `<div class="empty-state"><strong>Sin resultados</strong><span>Revise búsqueda, vendedor, plataforma o estado.</span></div>`}</section>`;
}

const TONES = ['r', 'b', 'g', 'a'];
export function clientTone(name = '') {
  let h = 0; for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return TONES[h % TONES.length];
}
export function clientInitials(name = '') {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return 'C';
  return (parts.length > 1 ? parts[0][0] + parts[1][0] : parts[0].slice(0, 2)).toUpperCase();
}
export function dueStatus(fechaDMY, parse, today = new Date()) {
  const d = parse(fechaDMY); if (!d) return { tone: '', label: 'Sin fecha', diff: null };
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const diff = Math.round((d - base) / 86400000);
  return diff < 0 ? { tone: 'bad', label: 'Vencido', diff } : diff === 0 ? { tone: 'hoy', label: 'Hoy', diff } : { tone: 'ok', label: 'Vigente', diff };
}
// "Más recientes" = última actualización de la ficha (ISO, {seconds} de Firestore o epoch).
export function recentMs(client = {}) {
  for (const v of [client.updatedAt, client.actualizadoEn, client.createdAt, client.creadoEn, client.fechaCreacion]) {
    if (v == null || v === '') continue;
    if (typeof v === 'number') return v < 1e12 ? v * 1000 : v;
    if (typeof v === 'object') { const s = v.seconds ?? v._seconds; if (Number.isFinite(Number(s))) return Number(s) * 1000; continue; }
    const t = Date.parse(String(v)); if (Number.isFinite(t)) return t;
  }
  return 0;
}
export function sortClientGroups(groups = [], sort = 'recientes', { clientById = () => null, parse = () => null } = {}) {
  const list = groups.slice();
  if (sort === 'nombre') return list.sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), 'es'));
  if (sort === 'monto') return list.sort((a, b) => (b.total || 0) - (a.total || 0));
  if (sort === 'vence') return list.sort((a, b) => (parse(a.fechaRenovacion)?.getTime() ?? Infinity) - (parse(b.fechaRenovacion)?.getTime() ?? Infinity));
  return list.map((g, i) => ({ g, i, t: recentMs(clientById(g.clienteId) || {}) })).sort((a, b) => (b.t - a.t) || (a.i - b.i)).map(x => x.g);
}
