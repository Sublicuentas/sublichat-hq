// Pantallas rediseñadas (Más y Clientes). Funciones puras que devuelven HTML: los datos y eventos viven en main.js.
import { mdToHtml } from './markdown.js';
import { CALC_CARD_ICON } from './calculadora.js';
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

/* ───────────── iconos de línea/planos (SVG en línea) ───────────── */
export const SVG = Object.freeze({
  search: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.2" stroke-linecap="round"><path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2.2"/><circle cx="9" cy="17" r="2.2"/></svg>',
  plus: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e2231a" stroke-width="3.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#0a1f3a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/></svg>',
  grid: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linejoin="round"><rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/></svg>',
  person: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4.5 20c.6-4 3.8-6 7.5-6s6.9 2 7.5 6"/></svg>',
  doc: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#e2231a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M9 12h7M9 16h7"/></svg>',
  calendarBlue: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><rect x="5" y="9" width="38" height="33" rx="9" fill="#1f88e6"/><rect x="9" y="18" width="30" height="20" rx="5" fill="#fff"/><rect x="14" y="4" width="5" height="10" rx="2.5" fill="#0b5fb0"/><rect x="29" y="4" width="5" height="10" rx="2.5" fill="#0b5fb0"/><circle cx="18" cy="26" r="2.6" fill="#1f88e6"/><circle cx="30" cy="26" r="2.6" fill="#1f88e6"/><circle cx="18" cy="33" r="2.6" fill="#1f88e6"/></svg>',
  clock: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="24" cy="24" r="20" fill="#13a8e8"/><circle cx="24" cy="24" r="14.5" fill="#fff"/><path d="M24 15.5v9.2l6.4 3.6" stroke="#13a8e8" stroke-width="3.3" stroke-linecap="round" fill="none"/></svg>',
  warning: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><path d="M24 5 45 41H3Z" fill="#e2231a" stroke="#e2231a" stroke-width="3" stroke-linejoin="round"/><rect x="21.3" y="17" width="5.4" height="13" rx="2.7" fill="#fff"/><circle cx="24" cy="34.5" r="2.8" fill="#fff"/></svg>',
  people: '<svg viewBox="0 0 48 48" width="100%" height="100%" aria-hidden="true"><circle cx="10" cy="19" r="5" fill="#2b2f3a"/><path d="M1 37c.4-6.5 4-9.5 9-9.5 1.5 0 2.8.3 4 .9-2.6 2.3-4 5.2-4.2 8.6z" fill="#2b2f3a"/><circle cx="38" cy="19" r="5" fill="#2b2f3a"/><path d="M47 37c-.4-6.5-4-9.5-9-9.5-1.5 0-2.8.3-4 .9 2.6 2.3 4 5.2 4.2 8.6z" fill="#2b2f3a"/><circle cx="24" cy="14" r="8" fill="#e2231a"/><path d="M9 42c0-8.5 6.5-14 15-14s15 5.5 15 14z" fill="#e2231a"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
  dots: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#0a1f3a"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>',
  sort: '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="#0a1f3a" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4v16M4 16l4 4 4-4M16 20V4M12 8l4-4 4 4"/></svg>',
  user: '<svg viewBox="0 0 24 24" width="30" height="30" fill="#fff"><circle cx="12" cy="8" r="4.2"/><path d="M4 21c.5-4.6 3.8-7 8-7s7.5 2.4 8 7z"/></svg>',
});

/* ───────────── MÁS ───────────── */
// R77: ícono de la tarjeta Códigos (llave con destellos, colores de marca)
const CODIGOS_CARD_ICON = '<svg viewBox="0 0 64 64" width="100%" height="100%" aria-hidden="true"><rect x="4" y="4" width="56" height="56" rx="16" fill="#0d2a5c"/><circle cx="24" cy="30" r="10" fill="none" stroke="#ffd98a" stroke-width="5"/><path d="M32 34 50 52M43 45l5-5M47 49l4-4" stroke="#ffd98a" stroke-width="5" stroke-linecap="round"/><circle cx="46" cy="16" r="4" fill="#e2231a"/><rect x="10" y="48" width="16" height="4" rx="2" fill="#e2231a"/></svg>';
export const MAS_MODULES = Object.freeze({
  pelis: { title: 'Pelis', sub: 'Películas y series', img: 'mas-pelis', tint: 'pink' },
  partidos: { title: 'Partidos', sub: 'Deportes en vivo', img: 'mas-partidos', tint: 'blue' },
  subli: { title: 'Subli', sub: 'Herramientas del sistema', img: 'mas-subli', tint: 'white' },
  perfil: { title: 'Perfil', sub: 'Tu cuenta y configuración', img: 'mas-perfil', tint: 'pink' },
  codigos: { title: 'Códigos', sub: 'Netflix, Disney+ y más', svg: CODIGOS_CARD_ICON, tint: 'pink' }, // R77
  'nuevo-crm': { title: 'Nuevo CRM', sub: 'Agregar cliente', img: 'mas-nuevo-crm', tint: 'blue' },
  inventario: { title: 'Inventario', sub: 'Stock y cuentas', img: 'mas-inventario', tint: 'white' },
  calculadora: { title: 'Calculadora de venta', sub: 'Cotiza y aplica descuentos', svg: CALC_CARD_ICON, tint: 'blue' },
  'control-maestro': { title: 'Control Maestro', sub: 'Cuentas y estado', img: 'mas-control-maestro', tint: 'pink' },
  finanzas: { title: 'Control financiero', sub: 'Ingresos y egresos', img: 'mas-control-financiero', tint: 'blue' },
  sorteos: { title: 'Sorteos', sub: 'Promociones y dinámicas', img: 'mas-sorteos', tint: 'blue' },
  aula: { title: 'Aula de clases', sub: 'Capacitaciones', img: 'mas-aula', tint: 'pink' },
  materia: { title: 'Materia cerebral', sub: 'Ideas y recursos', img: 'mas-materia', tint: 'white' },
});

export function masHomeHtml({ modules = [], sessionLabel = 'Sublicuentas', online = true, syncText = 'En línea', version = '1.0' } = {}) {
  const cards = modules.filter(id => MAS_MODULES[id]).map((id, i) => {
    const m = MAS_MODULES[id];
    return `<button type="button" class="mas-card tint-${m.tint}" data-open="${esc(id)}"><span class="mas-ico">${m.svg ? m.svg : `<img src="/assets/mas/${m.img}.png" alt="" loading="lazy">`}</span><span class="mas-txt"><strong>${esc(m.title)}</strong><small>${esc(m.sub)}</small></span><span class="mas-go">${SVG.chevron}</span></button>`;
  }).join('');
  return `<header class="mas-hero">
    <div class="mas-brand"><img src="/assets/sublicuentas-logo-oficial.png" alt="Sublicuentas"><small>Conectamos emociones, creamos experiencias</small></div>
    <p class="mas-eyebrow">MÓDULOS</p><h1>Más</h1><i class="mas-bar"></i><p class="mas-sub">Herramientas operativas · nada se elimina</p>
    <p class="mas-tagline">Más<br><em>que una app,</em><br><em>tu centro de control.</em></p>
    <img class="mas-robot" src="/assets/mas/robot-sentado.webp" alt="Sublibot">
  </header>
  <section class="mas-grid">${cards}<div class="mas-card mas-info tint-blue${cards.length===0||(modules.filter(id => MAS_MODULES[id]).length%2===0)?' wide':''}"><span class="mas-ico"><img src="/assets/mas/mas-resultados.png" alt="" loading="lazy"></span><span class="mas-txt"><em>MISMAS HERRAMIENTAS</em><strong>Más resultados</strong><small>Conectamos emociones, creamos experiencias.</small></span></div></section>
  <section class="mas-session"><div class="mas-session-who"><span class="av">${SVG.user}</span><div><small>Sesión</small><strong>${esc(sessionLabel)}</strong></div></div><div class="mas-session-ver"><span>Versión ${esc(version)}</span><b class="${online ? 'ok' : 'wait'}"><i></i>${esc(syncText)}</b></div></section>`;
}

/* ───────────── CLIENTES ───────────── */
export const CLIENT_SORTS = Object.freeze([['recientes', 'Más recientes'], ['vence', 'Próximo vencimiento'], ['nombre', 'Nombre A-Z'], ['monto', 'Mayor monto']]);

export function clientCardHtml(c = {}) {
  return `<article class="cli-card"><button type="button" class="cli-main" data-client-id="${esc(c.clienteId)}"><span class="cli-avatar tone-${esc(c.tone || 'r')}">${esc(c.initials || 'C')}</span><span class="cli-info"><strong>${esc(c.nombre)}</strong>${c.terceros && c.terceros.length ? `<em class="cli-tercero">🔑 Tercero: ${esc(c.terceros.join(', '))}</em>` : ''}<span class="ph">${esc(c.telefono || 'Sin teléfono')}</span><small>${esc((c.plataformas || []).join(' · '))}</small></span><span class="cli-date">${esc(c.fecha || 'Sin fecha')}</span></button><button type="button" class="cli-dots" data-client-actions="${esc(c.actionKey)}" aria-label="Acciones">${SVG.dots}</button><div class="cli-foot"><b>${esc(c.total)}</b><span class="chip ${esc(c.statusTone || '')}">${esc(c.statusLabel || '')}</span><span class="chip vend">${esc(c.vendedor || 'Sin vendedor')}</span></div></article>`;
}

export function clientsScreenHtml({
  counts = {}, statusFilter = 'vigentes', search = '', filtersOpen = true, platforms = [], sellers = [], platformFilter = '', sellerFilter = '',
  limit = 100, sort = 'recientes', shown = 0, total = 0, uniqueClients = 0, cards = [], canNewCrm = false, platformLabel = v => v,
} = {}) {
  const tabs = [['vigentes', 'Vigentes', SVG.people], ['hoy', 'Hoy', SVG.calendarBlue], ['proximos', 'Próximos', SVG.clock], ['vencidos', 'Vencidos', SVG.warning]];
  const opt = (v, cur, label) => `<option value="${esc(v)}" ${cur === v ? 'selected' : ''}>${esc(label ?? v)}</option>`;
  const limitOpts = [[50, '50'], [100, '100'], [250, '250'], [1000, 'Todos']].map(([v, l]) => `<option value="${v}" ${Number(limit) === v ? 'selected' : ''}>${l}</option>`).join('');
  return `<section class="cli-hero"><button type="button" class="cli-refresh" id="refreshData" aria-label="Actualizar">${SVG.refresh}</button><div class="cli-hero-copy"><p class="eyebrow">CRM</p><h1>Clientes</h1><p class="muted">Cartera, cobros y renovaciones</p></div><img class="cli-hero-img" src="/assets/clientes-hero.png" alt=""></section>
    ${canNewCrm ? `<button type="button" class="cli-cta" data-tab-jump="nuevo-crm"><span class="plus">${SVG.plus}</span><span class="txt">Nuevo CRM · Registrar venta</span><span class="go">${SVG.chevron}</span></button>` : ''}
    <div class="cli-search"><span class="ico">${SVG.search}</span><input id="clientSearch" type="search" value="${esc(search)}" placeholder="Buscar cliente, teléfono o plataforma…" autocomplete="off"><button type="button" class="cli-filter-btn ${filtersOpen ? 'on' : ''}" id="clientFiltersToggle" aria-label="Filtros" aria-pressed="${filtersOpen}">${SVG.sliders}</button></div>
    <div class="cli-tabs">${tabs.map(([id, label, ico]) => `<button type="button" data-client-status="${id}" class="t-${id} ${statusFilter === id ? 'active' : ''}"><i class="ico">${ico}</i><span>${label}</span><b>${esc(counts[id] ?? 0)}</b><em></em></button>`).join('')}</div>
    <section class="cli-filters" ${filtersOpen ? '' : 'hidden'}>
      <label class="cli-filter"><span>Plataformas</span><div class="cli-sel"><i>${SVG.grid}</i><select id="clientPlatformFilter"><option value="">Todas</option>${platforms.map(v => opt(v, platformFilter, platformLabel(v))).join('')}</select></div></label>
      <label class="cli-filter"><span>Vendedores</span><div class="cli-sel"><i>${SVG.person}</i><select id="clientSellerFilter"><option value="">Todos</option>${sellers.map(v => opt(v, sellerFilter)).join('')}</select></div></label>
      <label class="cli-filter"><span>Mostrar</span><div class="cli-sel"><i>${SVG.doc}</i><select id="clientLimit">${limitOpts}</select></div></label>
    </section>
    <button type="button" class="cli-today" id="clientCobrosHoy"><i>${SVG.calendarBlue}</i><span>Cobros de hoy</span><b>${SVG.chevron}</b></button>
    <div class="cli-meta"><p>Mostrando <b>${esc(shown)}</b> de <b>${esc(total)}</b> clientes · <b>${esc(uniqueClients)}</b> cuentas</p><div class="cli-tools"><label class="cli-sort">${SVG.sort}<select id="clientSort" aria-label="Ordenar">${CLIENT_SORTS.map(([v, l]) => opt(v, sort, l)).join('')}</select></label><button type="button" class="export-btn" id="exportClients" aria-label="Exportar clientes"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 19h14"/></svg><span>Exportar</span></button></div></div>
    <section class="cli-list">${cards.length ? cards.map(clientCardHtml).join('') : `<div class="empty-state"><strong>Sin resultados</strong><span>Revise búsqueda, vendedor, plataforma o estado.</span></div>`}</section>`;
}

const TONES = ['r', 'b', 'g', 'a'];
export function clientTone(name = '') {
  let h = 0; for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return TONES[h % TONES.length];
}
export function clientInitials(name = '') {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return 'C';
  return (parts.length > 1 ? parts[0][0] + parts[1][0] : parts[0].slice(0, 2)).toUpperCase();
}
export function dueStatus(fechaDMY, parse, today = new Date()) {
  const d = parse(fechaDMY); if (!d) return { tone: '', label: 'Sin fecha', diff: null };
  const base = new Date(today); base.setHours(12, 0, 0, 0);
  const diff = Math.round((d - base) / 86400000);
  return diff < 0 ? { tone: 'bad', label: 'Vencido', diff } : diff === 0 ? { tone: 'hoy', label: 'Hoy', diff } : { tone: 'ok', label: 'Vigente', diff };
}
// "Más recientes" = última actualización de la ficha (ISO, {seconds} de Firestore o epoch).
export function recentMs(client = {}) {
  for (const v of [client.updatedAt, client.actualizadoEn, client.createdAt, client.creadoEn, client.fechaCreacion]) {
    if (v == null || v === '') continue;
    if (typeof v === 'number') return v < 1e12 ? v * 1000 : v;
    if (typeof v === 'object') { const s = v.seconds ?? v._seconds; if (Number.isFinite(Number(s))) return Number(s) * 1000; continue; }
    const t = Date.parse(String(v)); if (Number.isFinite(t)) return t;
  }
  return 0;
}
export function sortClientGroups(groups = [], sort = 'recientes', { clientById = () => null, parse = () => null } = {}) {
  const list = groups.slice();
  if (sort === 'nombre') return list.sort((a, b) => String(a.nombre).localeCompare(String(b.nombre), 'es'));
  if (sort === 'monto') return list.sort((a, b) => (b.total || 0) - (a.total || 0));
  if (sort === 'vence') return list.sort((a, b) => (parse(a.fechaRenovacion)?.getTime() ?? Infinity) - (parse(b.fechaRenovacion)?.getTime() ?? Infinity));
  return list.map((g, i) => ({ g, i, t: recentMs(clientById(g.clienteId) || {}) })).sort((a, b) => (b.t - a.t) || (a.i - b.i)).map(x => x.g);
}


/* ───────────── SUBLI (asistente) ───────────── */
const SB_ICONS = Object.freeze({
  clientes: '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="24" cy="22" r="10" fill="#e2231a"/><path d="M5 53c0-11.5 8.5-18.5 19-18.5S43 41.500 43 53z" fill="#e2231a"/><circle cx="44.500" cy="25" r="8.500" fill="#ff7d73"/><path d="M34.500 53c.6-8.500 6-14.500 14-14.500 6.200 0 10.800 3.200 12.500 8.500V53z" fill="#ff7d73"/></svg>',
  vencimientos: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="10" y="10" width="44" height="46" rx="10" fill="#1f7be8"/><rect x="21" y="4" width="6.500" height="12" rx="3.200" fill="#0a3f9f"/><rect x="36.500" y="4" width="6.500" height="12" rx="3.200" fill="#0a3f9f"/><rect x="18" y="24" width="28" height="4.500" rx="2.200" fill="#fff"/><rect x="18" y="33" width="28" height="4.500" rx="2.200" fill="#fff"/><rect x="18" y="42" width="19" height="4.500" rx="2.200" fill="#fff"/></svg>',
  cobros: '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M10 44v8c0 4.400 9 8 22 8s22-3.600 22-8v-8z" fill="#0f7f3d"/><ellipse cx="32" cy="44" rx="22" ry="8" fill="#1fb65a"/><path d="M10 30v8c0 4.400 9 8 22 8s22-3.600 22-8v-8z" fill="#12994a"/><ellipse cx="32" cy="30" rx="22" ry="8" fill="#1fb65a"/><path d="M10 16v8c0 4.400 9 8 22 8s22-3.600 22-8v-8z" fill="#12994a"/><ellipse cx="32" cy="16" rx="22" ry="8" fill="#5cf08f"/></svg>',
  reportes: '<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="6" y="36" width="15" height="22" rx="5" fill="#7a3ff0"/><rect x="25" y="22" width="15" height="36" rx="5" fill="#7a3ff0"/><rect x="44" y="6" width="15" height="52" rx="5" fill="#7a3ff0"/></svg>',
  bolt: '<svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><path d="M13.500 2 4 14h6.500L9.500 22 20 9.500h-6.500z" fill="#1fa8ee"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#1976e6" stroke-width="2.500" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 1 1-2.500-5.800"/><path d="M20 4v5h-5"/></svg>',
  send: '<svg viewBox="0 0 24 24" width="26" height="26" fill="#fff" aria-hidden="true"><path d="M21.500 2.500 2.800 10.300c-.9.400-.9 1.700.1 2l4.900 1.700 1.800 5.600c.3 1 1.600 1.200 2.200.4l2.500-3 4.600 3.400c.8.600 1.900.1 2.100-.8l3-15.800c.2-1.100-.9-1.900-1.900-1.500z"/><path d="M8 14.200 19 6.200 10.200 15.800z" fill="#ff8b83"/></svg>',
  back: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0a1f3a" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>',
  more: '<svg viewBox="0 0 24 24" width="24" height="24" fill="#0a1f3a"><circle cx="12" cy="5" r="2.200"/><circle cx="12" cy="12" r="2.200"/><circle cx="12" cy="19" r="2.200"/></svg>',
});

export const SUBLI_CATS = Object.freeze({
  clientes: { label: 'Clientes', questions: ['¿Cuántos clientes vigentes tengo?', '¿Cuántos clientes tiene cada vendedor?', 'Clientes con más de una plataforma', 'Buscar un cliente por nombre o teléfono'] },
  vencimientos: { label: 'Vencimientos', questions: ['¿Qué clientes vencen hoy?', '¿Qué vence mañana?', 'Clientes vencidos con teléfono', '¿Qué vence esta semana?'] },
  cobros: { label: 'Cobros', questions: ['¿Cuánto cobro esta semana?', '¿Cuánto cobro hoy?', '¿Cuánto tengo vencido sin renovar?', 'Cobros de hoy por vendedor'] },
  reportes: { label: 'Reportes', questions: ['Resumen de la cartera por plataforma', 'Ingresos esperados este mes', 'Clientes y montos por vendedor', 'Plataformas con más clientes'] },
});
export const SUBLI_DEFAULT_SUGGESTIONS = Object.freeze(['¿Qué clientes vencen hoy?', '¿Cuánto cobro esta semana?', 'Clientes vencidos con teléfono']);

// 3 preguntas sugeridas: las del mockup por defecto; por categoría si se elige; y el botón ↻ va rotando.
export function subliSuggestions(cat = '', offset = 0) {
  const pool = SUBLI_CATS[cat]?.questions || [...SUBLI_DEFAULT_SUGGESTIONS, ...Object.values(SUBLI_CATS).flatMap(c => c.questions.slice(1))];
  const uniq = [...new Set(pool)];
  const start = ((Number(offset) || 0) * 3) % uniq.length;
  return [0, 1, 2].map(i => uniq[(start + i) % uniq.length]);
}

export function subliContentHtml({ messages = [], loading = false, cat = '', sugOffset = 0, menuOpen = false } = {}) {
  const chatting = messages.length > 0 || loading;
  const bubble = m => {
    if (m.role === 'user') return `<div class="sb-msg me">${esc(m.text).replace(/\n/g, '<br>')}</div>`;
    if (m.error) return `<div class="sb-msg bot err">${esc(m.text)}</div>`;
    return `<div class="sb-msg bot md">${mdToHtml(m.text)}</div>`;
  };
  const menu = menuOpen ? `<button type="button" class="sb-menu-backdrop" id="subliMenuClose" aria-label="Cerrar"></button><div class="sb-menu" role="menu"><button type="button" id="subliNewChat">🗑️ Nueva conversación</button><button type="button" id="subliCopyLast">📋 Copiar última respuesta</button></div>` : '';
  const top = `<div class="sb-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver">${SB_ICONS.back}</button>${chatting ? '<div class="sb-top-title"><strong>Subli</strong><small>Asistente de Sublicuentas</small></div>' : ''}<button type="button" class="sb-icon-btn" id="subliMenuBtn" aria-label="Opciones">${SB_ICONS.more}</button>${menu}</div>`;
  const welcome = `<section class="sb-hero"><div class="sb-hero-copy"><h1>Subli</h1><p>Asistente de Sublicuentas</p></div><img class="sb-robot" src="/assets/mas/robot-parado.webp" alt="Sublibot"><div class="sb-hello"><b>¡Hola! 👋</b><p>Soy Subli. Pregúntame por clientes, cuentas, cobros, renovaciones o reportes. Uso los datos reales de tu cartera.</p></div></section>
    <h2 class="sb-q">¿Qué deseas consultar?</h2>
    <div class="sb-cats">${Object.entries(SUBLI_CATS).map(([id, c]) => `<button type="button" class="${cat === id ? 'on' : ''}" data-subli-cat="${id}"><i>${SB_ICONS[id]}</i><span>${c.label}</span></button>`).join('')}</div>
    <div class="sb-sug-head"><span>${SB_ICONS.bolt}<b>Preguntas sugeridas</b></span><button type="button" id="subliRefresh" aria-label="Otras preguntas">${SB_ICONS.refresh}</button></div>
    <div class="sb-sug-list">${subliSuggestions(cat, sugOffset).map(q => `<button type="button" data-subli-suggest="${esc(q)}"><span>${esc(q)}</span>${SVG.chevron}</button>`).join('')}</div>`;
  const chat = `<section class="subli-msgs">${messages.map(bubble).join('')}${loading ? '<div class="sb-msg bot typing"><span class="spinner"></span> Pensando…</div>' : ''}</section>`;
  return `<section class="sb-page ${chatting ? 'chatting' : ''}">${top}${chatting ? chat : welcome}
    <form class="sb-composer" id="subliForm"><textarea id="subliInput" rows="1" enterkeyhint="send" placeholder="Escribe tu pregunta…" ${loading ? 'disabled' : ''}></textarea><button type="submit" class="sb-send" aria-label="Enviar" ${loading ? 'disabled' : ''}>${SB_ICONS.send}</button></form></section>`;
}


/* ───────────── PELIS ───────────── */
const PL_CLAPPER = '<svg viewBox="0 0 96 80" width="84" height="70" aria-hidden="true"><g transform="rotate(-9 34 26)"><rect x="8" y="12" width="60" height="15" rx="3.500" fill="#23262f"/><path d="M16 12h9l-7 15h-9zM33 12h9l-7 15h-9zM50 12h9l-7 15h-9z" fill="#fff"/></g><rect x="8" y="30" width="60" height="40" rx="5" fill="#2a2d36"/><rect x="8" y="30" width="60" height="9" rx="3" fill="#23262f"/><path d="M14 30h8l-6 9h-8zM30 30h8l-6 9h-8zM46 30h8l-6 9h-8z" fill="#fff"/><path d="M15 50h46M15 58h34" stroke="#dfe3ea" stroke-width="2.200" stroke-linecap="round"/><path d="M76 8l-5 9M84 20l-9 3M80 32l-8-2" stroke="#e2231a" stroke-width="3.200" stroke-linecap="round"/></svg>';
export function moviesContentHtml({ query = '', results = null, loading = false, error = '', menuOpen = false } = {}) {
  const menu = menuOpen ? `<button type="button" class="sb-menu-backdrop" id="moviesMenuClose" aria-label="Cerrar"></button><div class="sb-menu" role="menu"><button type="button" id="movieClear">🧹 Limpiar búsqueda</button></div>` : '';
  const top = `<div class="sb-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver">${SB_ICONS.back}</button><button type="button" class="sb-icon-btn" id="moviesMenuBtn" aria-label="Opciones">${SB_ICONS.more}</button>${menu}</div>`;
  const hero = `<section class="pl-hero"><div class="pl-copy"><h1>Pelis</h1><h2>Dónde verlas en Honduras</h2><p>Busca una película o serie y te mostramos la sinopsis y en qué plataformas está disponible en Honduras.</p></div><img class="pl-art" src="/assets/mas/pelis-hero.webp" alt=""></section>`;
  const form = `<form class="pl-search" id="movieForm"><span class="ico">${SVG.search}</span><input id="movieQuery" type="search" placeholder="Buscar película o serie…" value="${esc(query)}" autocomplete="off"><button class="pl-go" type="submit" ${loading ? 'disabled' : ''}>Buscar</button></form><p class="pl-note"><i>📍</i>Resultados basados en disponibilidad en Honduras (TMDB).</p>`;
  let body = '';
  if (loading) body = '<div class="loading-card"><span class="spinner"></span><strong>Buscando…</strong></div>';
  else if (error) body = `<div class="error-box"><span>${esc(error)}</span></div>`;
  else if (results == null) body = `<div class="pl-empty"><i>${PL_CLAPPER}</i><strong>Escribe un título</strong><span>Te mostramos la sinopsis y en qué plataformas está disponible en Honduras.</span></div>`;
  else if (!results.length) body = '<div class="pl-empty"><i>🔎</i><strong>Sin resultados</strong><span>Prueba con otro nombre.</span></div>';
  else {
    body = `<section class="list-stack">${results.map(r => {
      const providers = Array.isArray(r.proveedores) ? r.proveedores : [];
      const meta = [r.tipo, r.anio, r.rating ? `⭐ ${r.rating}` : ''].filter(Boolean).join(' · ');
      return `<article class="mv-card">${r.poster ? `<img class="mv-poster" src="${esc(r.poster)}" alt="" loading="lazy">` : '<div class="mv-poster mv-noposter">🎬</div>'}<div class="mv-info"><strong>${esc(r.titulo)}</strong><span>${esc(meta)}</span>${r.sinopsis ? `<p class="mv-sinopsis">${esc(r.sinopsis)}</p>` : ''}<div class="mv-chips">${providers.length ? providers.map(p => `<b>${esc(p)}</b>`).join('') : '<em>Sin plataformas en Honduras</em>'}</div></div></article>`;
    }).join('')}</section>`;
  }
  return `<section class="pl-page">${top}${hero}${form}${body}</section>`;
}
