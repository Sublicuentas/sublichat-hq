// R201 · Cloudflare Turnstile en la APK. El cuadro vive en una página de sublichat.capuchino.lat (dominio autorizado en
// Cloudflare) dentro de un iframe y entrega el token por postMessage. Solo se aceptan mensajes de ese origen exacto.
// La clave secreta nunca está en la APK: el servidor (Vercel) valida el token.
import { turnstileConfig, TURNSTILE_PAGE, TURNSTILE_ORIGIN } from './api.js';

export function tsEstado(state, render) {
  if (!state.ts) {
    state.ts = { cargado:false, activo:false, token:'' };
    turnstileConfig().then(c => { state.ts.cargado = true; state.ts.activo = !!c.activo; if (state.ts.activo && !state.session && typeof render === 'function') render(); });
    if (typeof window !== 'undefined') window.addEventListener('message', ev => {
      if (ev.origin !== TURNSTILE_ORIGIN || !ev.data || ev.data.tipo !== 'subli-turnstile') return;
      state.ts.token = typeof ev.data.token === 'string' ? ev.data.token.slice(0, 2048) : '';
    });
  }
  return state.ts;
}

export function tsIframe(ts) {
  if (!ts || !ts.activo) return '';
  return `<iframe class="visual-login-ts" src="${TURNSTILE_PAGE}" title="Verificación de seguridad" style="width:100%;max-width:310px;height:72px;border:0;margin:6px auto 0;display:block;background:transparent"></iframe>`;
}
