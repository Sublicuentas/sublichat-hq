// Memoria PRO (R64) · reemplaza "Pares de cartas". Según "Sublichat - Memoria PRO Claude Pack":
// 30 imágenes locales, subconjunto nuevo y barajado cada partida (evita repetir el set anterior),
// Fácil 6 pares/75 s · Medio 8 pares/55 s · Difícil 10 pares/40 s, pausa que congela reloj y toques,
// al acertar: éxito breve y la pareja se desvanece; al fallar: se ven un momento y se voltean.
// Los SP los calcula el servidor (api/juegos.js) una sola vez por partida (gameId fijo = idempotente).

export const MEMORY_MODE_CONFIG = Object.freeze({
  EASY: { label: 'Fácil', pairs: 6, cards: 12, seconds: 75, columns: 3, pairPoints: 10, completionBonus: 30, maxTimeBonus: 20, mismatchRevealMs: 700, matchedRemoveMs: 450 },
  MEDIUM: { label: 'Medio', pairs: 8, cards: 16, seconds: 55, columns: 4, pairPoints: 15, completionBonus: 50, maxTimeBonus: 30, mismatchRevealMs: 650, matchedRemoveMs: 425 },
  HARD: { label: 'Difícil', pairs: 10, cards: 20, seconds: 40, columns: 4, pairPoints: 20, completionBonus: 80, maxTimeBonus: 40, mismatchRevealMs: 600, matchedRemoveMs: 400 },
});
export const MEMORY_MODES = ['EASY', 'MEDIUM', 'HARD'];
export const MEMORY_ASSET_IDS = ['apple', 'basketball', 'bulb', 'car', 'cat', 'cherries', 'dog', 'football', 'fox', 'frog', 'gamepad', 'grapes', 'headphones', 'koala', 'lemon', 'lion', 'monkey', 'orange', 'panda', 'pineapple', 'pool', 'rabbit', 'rainbow', 'rocket', 'soccer', 'star', 'strawberry', 'tennis', 'tiger', 'watermelon'];
export const MEMORY_POOL = MEMORY_ASSET_IDS.map(id => ({ id, src: `/assets/memoria/cards/${id}.webp` }));

function randomIndex(max) {
  if (max <= 1) return 0;
  const c = globalThis.crypto;
  if (c?.getRandomValues) { const b = new Uint32Array(1), lim = 0xFFFFFFFF - (0xFFFFFFFF % max); let v; do { c.getRandomValues(b); v = b[0]; } while (v >= lim); return v % max; }
  return Math.floor(Math.random() * max);
}
export function shuffle(input) { const out = [...input]; for (let i = out.length - 1; i > 0; i--) { const j = randomIndex(i + 1); [out[i], out[j]] = [out[j], out[i]]; } return out; }
export function chooseAssets(pool, count, lastAssetIds = []) {
  if (pool.length < count) throw new Error('Memory asset pool is too small.');
  const prev = new Set(lastAssetIds);
  return [...shuffle(pool.filter(a => !prev.has(a.id))), ...shuffle(pool.filter(a => prev.has(a.id)))].slice(0, count);
}
export function buildDeck(assets) {
  const deck = assets.flatMap((a, i) => { const pairId = `pair_${i}_${a.id}`; return [0, 1].map(k => ({ id: `${pairId}_${k}`, pairId, assetId: a.id, src: a.src, position: 0, state: 'HIDDEN' })); });
  return shuffle(deck).map((c, position) => ({ ...c, position }));
}
export function createMemoryGame(mode = 'EASY', { userId = 'yo', lastAssetIds = [], now = Date.now() } = {}) {
  const cfg = MEMORY_MODE_CONFIG[mode] || MEMORY_MODE_CONFIG.EASY;
  const m = MEMORY_MODE_CONFIG[mode] ? mode : 'EASY';
  return { gameId: `mem-${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`, userId, mode: m, status: 'READY', cards: buildDeck(chooseAssets(MEMORY_POOL, cfg.pairs, lastAssetIds)),
    selectedIds: [], pairsTotal: cfg.pairs, pairsFound: 0, secondsInitial: cfg.seconds, playedMs: 0, resumedAt: null, roundPoints: 0, mistakes: 0, startedAt: null, completedAt: null, submitted: false };
}
// Reloj por timestamps (la pausa no cuenta y no hay deriva de setInterval).
export function memoryPlayedMs(s, now = Date.now()) { return s.playedMs + (s.status === 'PLAYING' && s.resumedAt ? now - s.resumedAt : 0); }
export function memoryRemainingMs(s, now = Date.now()) { return Math.max(0, s.secondsInitial * 1000 - memoryPlayedMs(s, now)); }
export function startGame(s, now = Date.now()) { return s.status !== 'READY' ? s : { ...s, status: 'PLAYING', startedAt: now, resumedAt: now }; }
export function openCard(s, cardId, now = Date.now()) {
  if (s.status === 'READY') s = startGame(s, now);
  if (s.status !== 'PLAYING' || s.selectedIds.length >= 2) return s;
  const card = s.cards.find(c => c.id === cardId);
  if (!card || card.state !== 'HIDDEN') return s;
  return { ...s, selectedIds: [...s.selectedIds, cardId], cards: s.cards.map(c => c.id === cardId ? { ...c, state: 'OPEN' } : c) };
}
export function evaluateOpenPair(s, now = Date.now()) {
  if (s.selectedIds.length !== 2) return { state: s, result: 'WAITING' };
  const [aId, bId] = s.selectedIds; const a = s.cards.find(c => c.id === aId), b = s.cards.find(c => c.id === bId);
  if (!a || !b) return { state: { ...s, selectedIds: [] }, result: 'MISMATCH' };
  if (a.pairId === b.pairId) {
    const cfg = MEMORY_MODE_CONFIG[s.mode], found = s.pairsFound + 1, complete = found === s.pairsTotal;
    let next = { ...s, selectedIds: [], pairsFound: found, roundPoints: s.roundPoints + cfg.pairPoints, cards: s.cards.map(c => c.pairId === a.pairId ? { ...c, state: 'MATCHED' } : c) };
    if (complete) next = { ...next, playedMs: memoryPlayedMs(s, now), resumedAt: null, status: 'COMPLETED', completedAt: now };
    return { state: next, result: 'MATCH', matchedPairId: a.pairId };
  }
  return { state: { ...s, mistakes: s.mistakes + 1 }, result: 'MISMATCH' };
}
export function closeMismatch(s) { const open = new Set(s.selectedIds); return { ...s, selectedIds: [], cards: s.cards.map(c => open.has(c.id) && c.state === 'OPEN' ? { ...c, state: 'HIDDEN' } : c) }; }
export function removeMatchedPair(s, pairId) { return { ...s, cards: s.cards.map(c => c.pairId === pairId && c.state === 'MATCHED' ? { ...c, state: 'REMOVED' } : c) }; }
export function checkTimeout(s, now = Date.now()) { return s.status === 'PLAYING' && memoryRemainingMs(s, now) <= 0 ? { ...s, playedMs: s.secondsInitial * 1000, resumedAt: null, status: 'TIMEOUT', completedAt: now } : s; }
export function pauseGame(s, now = Date.now()) { return s.status !== 'PLAYING' ? s : { ...s, playedMs: memoryPlayedMs(s, now), resumedAt: null, status: 'PAUSED' }; }
export function resumeGame(s, now = Date.now()) { return s.status !== 'PAUSED' ? s : { ...s, status: 'PLAYING', resumedAt: now }; }
export function calculateFinalScore(s) {
  const cfg = MEMORY_MODE_CONFIG[s.mode], completed = s.status === 'COMPLETED';
  const pairs = s.pairsFound * cfg.pairPoints, completion = completed ? cfg.completionBonus : 0;
  const timeBonus = completed ? Math.min(cfg.maxTimeBonus, Math.floor(Math.floor(memoryRemainingMs(s) / 1000) / 2)) : 0;
  return { pairs, completion, timeBonus, total: pairs + completion + timeBonus };
}
// Lo que viaja al servidor (él recalcula; esto es evidencia, no el puntaje final).
export function memorySubmission(s) {
  return { pro: true, mode: s.mode, pairsFound: s.pairsFound, pairsTotal: s.pairsTotal, secondsRemaining: Math.floor(memoryRemainingMs(s) / 1000), elapsedMs: Math.round(memoryPlayedMs(s)), mistakes: s.mistakes, completed: s.status === 'COMPLETED',
    // compatibilidad con la versión anterior del servidor
    pairsFoundLegacy: s.pairsFound, errors: s.mistakes, timeLimitSec: s.secondsInitial, timeRemainingSec: Math.floor(memoryRemainingMs(s) / 1000) };
}
export const memoryLastAssets = user => { try { return JSON.parse(localStorage.getItem(`sublichat-memoria-last:${user}`) || '[]'); } catch (_) { return []; } };
export const memorySaveLastAssets = (user, s) => { try { localStorage.setItem(`sublichat-memoria-last:${user}`, JSON.stringify([...new Set(s.cards.map(c => c.assetId))])); } catch (_) {} };

/* ─────────── pantalla (visual aprobado) ─────────── */
const fmt = ms => { const t = Math.ceil(ms / 1000); return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; };
const I = {
  sprout: '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M12 21V11" stroke="#1faa4f" stroke-width="2.6" stroke-linecap="round"/><path d="M12 12C12 7 8.5 4.5 3.5 5c-.2 4.8 3 7.3 8.5 7Z" fill="#2fc262"/><path d="M12 12c0-5 3.5-7.5 8.5-7 .2 4.8-3 7.3-8.5 7Z" fill="#1faa4f"/></svg>',
  bars: c => `<svg viewBox="0 0 24 24" width="22" height="22" fill="${c}"><rect x="3" y="13" width="5" height="8" rx="1.3"/><rect x="9.5" y="8" width="5" height="13" rx="1.3"/><rect x="16" y="3" width="5" height="18" rx="1.3"/></svg>`,
  clock: '<svg viewBox="0 0 24 24" width="26" height="26"><circle cx="12" cy="12" r="10" fill="#ef4444"/><path d="M12 6.5V12h4" stroke="#fff" stroke-width="2.6" stroke-linecap="round" fill="none"/></svg>',
  cards: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="3" y="5" width="11" height="15" rx="2.5" transform="rotate(-12 8 12)" fill="#f87171"/><rect x="9" y="4" width="11" height="15" rx="2.5" transform="rotate(8 14 11)" fill="#e2231a"/></svg>',
  bulb: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#16a8e0"><path d="M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V17h5.2v-1.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3Zm-2.6 15.5h5.2V20a1 1 0 0 1-1 1h-3.2a1 1 0 0 1-1-1v-1.5Z"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
};
export function memoriaScreenHtml({ game, message = '', saving = false } = {}) {
  const g = game, cfg = MEMORY_MODE_CONFIG[g.mode];
  const rem = g.status === 'READY' ? g.secondsInitial * 1000 : memoryRemainingMs(g);
  const pct = Math.round(rem / (g.secondsInitial * 1000) * 100);
  const paused = g.status === 'PAUSED', over = g.status === 'COMPLETED' || g.status === 'TIMEOUT';
  const rows = Math.ceil(g.cards.length / cfg.columns);
  const tabs = MEMORY_MODES.map(m => `<button type="button" class="${m === g.mode ? 'on' : ''}" data-mc-mode="${m}">${m === 'EASY' ? I.sprout : I.bars(m === g.mode ? '#fff' : m === 'MEDIUM' ? '#1f7cf2' : '#e2231a')}<span>${MEMORY_MODE_CONFIG[m].label}</span></button>`).join('');
  const cards = g.cards.map(c => {
    if (c.state === 'REMOVED') return '<div class="mc-card gone" aria-hidden="true"></div>';
    const face = c.state !== 'HIDDEN';
    return `<button type="button" class="mc-card ${face ? 'face' : 'back'} ${c.state === 'OPEN' ? 'open' : ''} ${c.state === 'MATCHED' ? 'ok' : ''}" data-mc-card="${c.id}" aria-label="${face ? c.assetId : 'Carta oculta'}" ${over || paused ? 'disabled' : ''}>
      ${face ? `<img src="${c.src}" alt="" draggable="false">${c.state === 'MATCHED' ? `<i class="mc-check">${I.check}</i>` : ''}` : '<img class="mc-backimg" src="/assets/memoria/card-back.webp" alt="" draggable="false">'}</button>`;
  }).join('');
  const s = calculateFinalScore(g);
  const endCard = over ? `<section class="mc-end ${g.status === 'COMPLETED' ? 'win' : ''}"><b>${g.status === 'COMPLETED' ? '🎉 ¡Encontraste todos los pares!' : '⏱ Se acabó el tiempo'}</b>
      <span>Pares ${s.pairs} SP${s.completion ? ` · Completar ${s.completion}` : ''}${s.timeBonus ? ` · Tiempo ${s.timeBonus}` : ''} · <b>Total +${s.total} SP</b></span>
      ${g.submitted ? '<small>✅ Acreditado al SP global.</small>' : saving ? '<small>Guardando en el servidor…</small>' : '<button type="button" class="mc-mini" id="mcSubmit">Guardar SP pendientes</button>'}
      <button type="button" class="mc-again" id="mcAgain">↻ Jugar otra vez</button></section>` : '';
  return `<section class="jg-page mc-page" style="--mc-cols:${cfg.columns};--mc-rows:${rows}">
    <header class="mc-top"><button type="button" class="mc-back" id="jgQuit" aria-label="Volver">‹</button><img class="mc-icon" src="/assets/memoria/memory-icon.webp" alt=""><div class="mc-title"><b>Memoria</b><small>Par de cartas</small></div>
      <button type="button" class="mc-pause" id="mcPause" aria-label="${paused ? 'Reanudar' : 'Pausar'}" ${over || g.status === 'READY' ? 'disabled' : ''}>${paused ? '▶' : '❚❚'}</button></header>
    <nav class="mc-modes">${tabs}</nav>
    <section class="mc-time"><span class="mc-ti">${I.clock}</span><div><small>Tiempo restante</small><b id="mcTimer">${fmt(rem)}</b></div><div class="mc-bar"><i id="mcBar" style="width:${pct}%"></i></div></section>
    <section class="mc-stats"><div><span class="mc-si red">${I.cards}</span><span><small>Pares</small><b>${g.pairsFound} / ${g.pairsTotal}</b></span></div>
      <div><span class="mc-si gold">SP</span><span><small>SP</small><b>+${g.roundPoints}</b></span></div>
      <div><span class="mc-si blue">${I.bars('#1f7cf2')}</span><span><small>Modo</small><b>${cfg.label}</b></span></div></section>
    <div class="mc-board ${paused ? 'paused' : ''}" id="mcBoard">${cards}${paused ? '<button type="button" class="mc-paused" id="mcResume">▶ En pausa · tocar para seguir</button>' : ''}</div>
    ${endCard}
    <section class="mc-foot"><span class="mc-fi">${I.bulb}</span><span class="mc-tip">${message || (g.status === 'READY' ? 'Toca una carta para empezar. Las imágenes cambian en cada partida.' : 'Las imágenes cambian en cada partida')}</span><span class="mc-sep"></span><span class="mc-fi red">${I.cards}</span><b>Pares: ${g.pairsFound}/${g.pairsTotal}</b></section>
  </section>`;
}
