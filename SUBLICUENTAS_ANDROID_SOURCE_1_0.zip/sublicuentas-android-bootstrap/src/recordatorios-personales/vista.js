// Más › Recordatorios — pantallas (funciones puras que devuelven HTML).
import {
  CATEGORIAS, PRIORIDADES, REPETICIONES, UNIDADES, AVISOS, POSPONER, LIMITES,
  etiquetaCategoria, etiquetaPrioridad, filtrarVista, contarVistas, agruparPorFecha, encabezadoDia,
  cuandoTexto, momentoVencimiento, horaBonita, diaBonito, estadoEfectivo, esImportante, textoRepeticion, textoAvisos, fechaDMY,
} from './logica.js';

const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const ICO = n => `/assets/recordatorios/${n}.webp`;
const img = (n, cls = '', alt = '') => `<img class="${cls}" src="${ICO(n)}" alt="${esc(alt)}" loading="lazy" decoding="async" width="96" height="96">`;

const SVG = {
  back: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/></svg>',
  plus: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#E2231A" stroke-width="3" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>',
  down: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  search: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg>',
  clock: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#E2231A" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  dots: '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>',
  flag: '<svg viewBox="0 0 24 24" width="22" height="22" fill="#64748b"><path d="M5 21V4h11l-1.5 3.5L16 11H7v10z"/></svg>',
  check: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg>',
  close: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  cal: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#E2231A" stroke-width="2.2" stroke-linecap="round"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>',
};

const VISTAS = [['hoy', 'Hoy', 'hoy'], ['proximos', 'Próximos', 'proximos'], ['importantes', 'Importantes', 'importantes'], ['completados', 'Completados', 'completados']];
const TONO_CAT = { personal: 'green', familia: 'pink', trabajo: 'brown', pagos: 'blue', citas: 'purple', compras: 'violet', diligencias: 'cyan', pendientes: 'orange', eventos: 'pink', otro: 'gray' };

function top(idBack, idRight = 'rpSync', rightIco = SVG.refresh, rightLabel = 'Sincronizar', busy = false) {
  return `<section class="rp-top"><button type="button" class="rp-round" id="${idBack}" aria-label="Volver">${SVG.back}</button>${idRight ? `<button type="button" class="rp-round${busy ? ' spin' : ''}" id="${idRight}" aria-label="${esc(rightLabel)}">${rightIco}</button>` : ''}</section>`;
}
function hero(titulo, sub) {
  return `<section class="rp-hero"><div><p class="rp-eyebrow">PERSONAL</p><h1>${esc(titulo)}</h1><p class="rp-sub">${esc(sub)}</p></div>${img('recordatorios', 'rp-hero-img', '')}</section>`;
}

function badgePrioridad(r) {
  if (r.priority === 'urgent') return `<span class="rp-badge urgente">${img('urgente', 'rp-bi')}Urgente</span>`;
  if (esImportante(r)) return `<span class="rp-badge importante">${img('importante_prioridad', 'rp-bi')}Importante</span>`;
  return '';
}

export function tarjetaHtml(r, ahora = new Date()) {
  const est = estadoEfectivo(r, ahora);
  const t = momentoVencimiento(r);
  const cuando = r.status === 'completed' && r.completedAt ? `Hecho ${diaBonito(new Date(r.completedAt), ahora).toLowerCase()} · ${horaBonita(new Date(r.completedAt))}` : (t ? `${diaBonito(t, ahora)} · ${horaBonita(t)}` : 'Sin fecha');
  const extra = est === 'overdue' ? '<span class="rp-state vencido">Vencido</span>' : est === 'snoozed' ? '<span class="rp-state pospuesto">Pospuesto</span>' : '';
  return `<article class="rp-card${est === 'overdue' ? ' is-overdue' : ''}${r.status === 'completed' ? ' is-done' : ''}" data-rp-open="${esc(r.id)}">
    <span class="rp-cat-ico tone-${TONO_CAT[r.category] || 'gray'}">${img(r.category, '', etiquetaCategoria(r.category))}</span>
    <div class="rp-card-main"><strong>${esc(r.title)}</strong><span class="rp-when">${r.status === 'completed' ? SVG.check : SVG.clock}${esc(cuando)}${r.repeatRule && r.repeatRule !== 'none' ? ` · ${esc(textoRepeticion(r))}` : ''}</span>${r.note ? `<small>${esc(r.note)}</small>` : ''}</div>
    <div class="rp-card-side">${badgePrioridad(r)}${extra}<span class="rp-chip tone-${TONO_CAT[r.category] || 'gray'}">${esc(etiquetaCategoria(r.category))}</span></div>
    <button type="button" class="rp-kebab" data-rp-menu="${esc(r.id)}" aria-label="Opciones de ${esc(r.title)}">${SVG.dots}</button>
  </article>`;
}

function avisoPermisos(p) {
  if (p.permiso === 'web') return '<div class="rp-note">Las notificaciones funcionan en la app de Android. Aquí puede ver y editar sus recordatorios.</div>';
  if (p.permiso && p.permiso !== 'granted') return `<div class="rp-note warn"><span>🔕 Los avisos están apagados. Actívelos para que el teléfono le avise aunque Sublichat esté cerrada.</span><button type="button" id="rpPermiso">Activar avisos</button></div>`;
  if (p.permiso === 'granted' && p.exacta && p.exacta !== 'granted') return `<div class="rp-note"><span>⏱️ Para que suenen a la hora exacta (también en ahorro de batería) active “Alarmas y recordatorios”.</span><button type="button" id="rpExacta">Activar</button></div>`;
  return '';
}

export function listaHtml({ items = [], vista = 'hoy', q = '', categoria = '', prioridad = '', limite = 0, filtrosAbiertos = true, ahora = new Date(), permisos = {}, sync = {}, deshacer = null } = {}) {
  const filtros = { q, categoria, prioridad, ahora };
  const counts = contarVistas(items, filtros);
  const lista = filtrarVista(items, { ...filtros, vista });
  const visibles = limite ? lista.slice(0, limite) : lista;
  const tabs = VISTAS.map(([id, label, ico]) => `<button type="button" class="rp-tab${vista === id ? ' active' : ''}" data-rp-vista="${id}">${img(ico, 'rp-tab-ico')}<span>${label}</span><b class="${id === 'hoy' ? 'red' : id === 'completados' ? 'green' : ''}">${counts[id]}</b><i></i></button>`).join('');
  const opt = (v, cur, l) => `<option value="${esc(v)}"${v === cur ? ' selected' : ''}>${esc(l)}</option>`;
  const panel = `<section class="rp-filters"${filtrosAbiertos ? '' : ' hidden'}>
    <label><small>Categorías</small><span class="rp-select"><select id="rpCategoria">${opt('', categoria, 'Todas')}${CATEGORIAS.map(([v, l]) => opt(v, categoria, l)).join('')}</select>${SVG.down}</span></label>
    <label><small>Prioridad</small><span class="rp-select"><select id="rpPrioridad">${opt('', prioridad, 'Todas')}${PRIORIDADES.map(([v, l]) => opt(v, prioridad, l)).join('')}</select>${SVG.down}</span></label>
    <label><small>Mostrar</small><span class="rp-select"><select id="rpLimite">${opt('0', String(limite), 'Todos')}${opt('20', String(limite), '20')}${opt('50', String(limite), '50')}</select>${SVG.down}</span></label>
  </section>`;
  const tituloVista = { hoy: 'Recordatorios de hoy', proximos: 'Próximos recordatorios', importantes: 'Recordatorios importantes', completados: 'Completados' }[vista];
  let cuerpo;
  if (!visibles.length) {
    const vacio = { hoy: ['Nada pendiente para hoy', 'Cree un recordatorio y el teléfono le avisará a la hora.'], proximos: ['Sin recordatorios próximos', 'Lo que programe para mañana en adelante aparece aquí.'], importantes: ['Sin importantes', 'Marque un recordatorio como Importante o Urgente.'], completados: ['Todavía no hay completados', 'Al marcar “Hecho” quedan aquí con su fecha.'] }[vista];
    cuerpo = `<div class="rp-empty">${img(vista === 'completados' ? 'completados' : 'calendario', 'rp-empty-ico')}<strong>${esc(q || categoria || prioridad ? 'Sin resultados con ese filtro' : vacio[0])}</strong><span>${esc(q || categoria || prioridad ? 'Pruebe con otra búsqueda o quite los filtros.' : vacio[1])}</span></div>`;
  } else if (vista === 'proximos') {
    cuerpo = agruparPorFecha(visibles).map(g => `<h3 class="rp-day">${esc(encabezadoDia(g.fecha, ahora))} <small>· ${g.lista.length}</small></h3>${g.lista.map(r => tarjetaHtml(r, ahora)).join('')}`).join('');
  } else if (vista === 'hoy') {
    const vencidos = visibles.filter(r => estadoEfectivo(r, ahora) === 'overdue');
    const deHoy = visibles.filter(r => estadoEfectivo(r, ahora) !== 'overdue');
    cuerpo = `${vencidos.length ? `<h3 class="rp-day red">Vencidos <small>· ${vencidos.length}</small></h3>${vencidos.map(r => tarjetaHtml(r, ahora)).join('')}` : ''}${deHoy.length ? `${vencidos.length ? '<h3 class="rp-day">Hoy</h3>' : ''}${deHoy.map(r => tarjetaHtml(r, ahora)).join('')}` : ''}`;
  } else cuerpo = visibles.map(r => tarjetaHtml(r, ahora)).join('');
  const syncTxt = sync.pendientes ? `${sync.pendientes} sin subir · se sincroniza al tener internet` : (sync.error ? 'Sin conexión · guardado en el teléfono' : '');
  return `${top('rpBack', 'rpSync', SVG.refresh, 'Sincronizar', sync.busy)}
  ${hero('Recordatorios', 'Agenda, avisos y pendientes personales')}
  <button type="button" class="rp-cta" id="rpNuevo"><span class="plus">${SVG.plus}</span><span class="txt">Nuevo recordatorio</span><span class="go">${SVG.chevron}</span></button>
  <div class="rp-search"><span class="ico">${SVG.search}</span><input id="rpBuscar" type="search" placeholder="Buscar recordatorio, fecha o categoría…" value="${esc(q)}" autocomplete="off" enterkeyhint="search"><button type="button" id="rpFiltros" class="${filtrosAbiertos ? 'on' : ''}" aria-label="Filtros">${SVG.sliders}</button></div>
  <section class="rp-tabs">${tabs}</section>
  ${panel}
  ${avisoPermisos(permisos)}
  <div class="rp-band">${img(vista === 'completados' ? 'completados' : 'hoy', 'rp-band-ico')}<strong>${esc(tituloVista)}</strong><span class="rp-count">${lista.length}${limite && lista.length > limite ? ` · mostrando ${limite}` : ''}</span></div>
  <section class="rp-list">${cuerpo}</section>
  ${syncTxt ? `<p class="rp-sync-note">${esc(syncTxt)}</p>` : ''}
  ${deshacer ? `<div class="rp-undo"><span>Recordatorio eliminado</span><button type="button" id="rpDeshacer">Deshacer</button></div>` : ''}`;
}

export function formularioHtml({ borrador = {}, errores = {}, esNuevo = true, guardando = false, error = '' } = {}) {
  const b = borrador;
  const err = k => errores[k] ? `<small class="rp-err">${esc(errores[k])}</small>` : '';
  const cats = CATEGORIAS.map(([v, l]) => `<button type="button" class="rp-catbtn${b.category === v ? ' on' : ''}" data-rp-cat="${v}">${img(v, '', '')}<span>${esc(l)}</span></button>`).join('');
  const pris = PRIORIDADES.map(([v, l]) => `<button type="button" class="rp-pri pri-${v}${b.priority === v ? ' on' : ''}" data-rp-pri="${v}">${v === 'urgent' ? img('urgente', 'rp-pi') : v === 'important' ? img('importante_prioridad', 'rp-pi') : SVG.flag}<span>${esc(l)}</span></button>`).join('');
  const reps = REPETICIONES.map(([v, l]) => `<button type="button" class="rp-pill${b.repeatRule === v ? ' on' : ''}" data-rp-rep="${v}">${esc(l)}</button>`).join('');
  const custom = b.repeatRule === 'custom' ? `<div class="rp-custom"><span>Cada</span><input id="rpRepN" type="number" inputmode="numeric" min="1" max="365" value="${esc(b.repeatCustom?.every ?? 2)}"><span class="rp-select"><select id="rpRepU">${UNIDADES.map(([v, l]) => `<option value="${v}"${b.repeatCustom?.unit === v ? ' selected' : ''}>${esc(l)}</option>`).join('')}</select>${SVG.down}</span></div>${err('repeat')}` : '';
  const offs = new Set((b.alertOffsets || [0]).map(Number));
  const avisos = AVISOS.map(([v, l]) => `<button type="button" class="rp-pill${offs.has(v) ? ' on' : ''}" data-rp-aviso="${v}" aria-pressed="${offs.has(v)}">${esc(l)}</button>`).join('');
  const nota = String(b.note || '');
  return `${top('rpFormBack', '', '', '')}
  ${hero(esNuevo ? 'Nuevo recordatorio' : 'Editar recordatorio', 'Anote fecha, hora y detalles importantes')}
  <form class="rp-form" id="rpForm" novalidate>
    <label class="rp-field"><span>Título</span><input id="rpTitulo" maxlength="${LIMITES.titulo}" placeholder="Ej.: Pagar factura de internet" value="${esc(b.title || '')}" autocomplete="off">${err('title')}</label>
    <label class="rp-field"><span>Nota opcional</span><div class="rp-textarea"><textarea id="rpNota" maxlength="${LIMITES.nota}" rows="3" placeholder="Detalles, montos, direcciones…">${esc(nota)}</textarea><small id="rpNotaCount">${nota.length}/${LIMITES.nota}</small></div>${err('note')}</label>
    <div class="rp-row2">
      <label class="rp-field"><span>Fecha</span><div class="rp-input-ico">${SVG.cal}<input id="rpFecha" type="date" value="${esc(b.fecha || '')}"></div>${err('fecha')}</label>
      <label class="rp-field"><span>Hora</span><div class="rp-input-ico">${SVG.clock}<input id="rpHora" type="time" value="${esc(b.hora || '')}"></div>${err('hora')}</label>
    </div>
    <div class="rp-field"><span>Categoría</span><div class="rp-cats">${cats}</div>${err('category')}</div>
    <div class="rp-field"><span>Prioridad</span><div class="rp-pris">${pris}</div></div>
    <div class="rp-field"><span>Repetir</span><div class="rp-pills">${reps}</div>${custom}</div>
    <div class="rp-field"><span>Avisarme <em>(puede elegir varios)</em></span><div class="rp-pills">${avisos}</div></div>
    <div class="rp-toggle"><span class="rp-toggle-ico">${img('aviso', '', '')}</span><div><strong>Marcar como importante</strong><small>Aparecerá en la sección de recordatorios importantes</small></div><label class="rp-switch"><input type="checkbox" id="rpImportante" ${b.important || b.priority !== 'normal' ? 'checked' : ''} ${b.priority !== 'normal' ? 'disabled' : ''}><i></i></label></div>
    ${error ? `<div class="rp-form-error">${esc(error)}</div>` : ''}
    <button type="submit" class="rp-save" id="rpGuardar" ${guardando ? 'disabled' : ''}>${guardando ? 'Guardando…' : 'Guardar recordatorio'}</button>
    <button type="button" class="rp-cancel" id="rpCancelar" ${guardando ? 'disabled' : ''}>Cancelar</button>
  </form>`;
}

export function detalleHtml({ r, ahora = new Date() } = {}) {
  if (!r) return `${top('rpBack', '')}<div class="rp-empty"><strong>Este recordatorio ya no existe</strong><span>Pudo haberse eliminado.</span></div>`;
  const t = momentoVencimiento(r);
  const est = estadoEfectivo(r, ahora);
  const estTxt = { scheduled: 'Programado', snoozed: 'Pospuesto', overdue: 'Vencido', completed: 'Completado', cancelled: 'Cancelado' }[est];
  const fila = (ico, label, val) => `<div class="rp-drow"><span class="rp-dico">${ico}</span><span>${esc(label)}</span><b>${esc(val)}</b></div>`;
  const hecho = r.status === 'completed';
  return `${top('rpDetBack', 'rpDetMenu', SVG.dots, 'Más opciones')}
  <section class="rp-det-head${esImportante(r) ? ' imp' : ''}">
    <span class="rp-cat-ico big tone-${TONO_CAT[r.category] || 'gray'}">${img(r.category, '', '')}</span>
    <div><h1>${esc(r.title)}</h1><p>${SVG.clock}${esc(t ? cuandoTexto(r, ahora) : 'Sin fecha')}</p>${badgePrioridad(r)}</div>
  </section>
  ${r.note ? `<section class="rp-det-note">${esc(r.note).replace(/\n/g, '<br>')}</section>` : ''}
  <section class="rp-det-rows">
    ${fila(img(r.category, 'rp-mini'), 'Categoría', etiquetaCategoria(r.category))}
    ${fila(img('calendario', 'rp-mini'), 'Fecha', fechaDMY(r.fecha))}
    ${fila(img('proximos', 'rp-mini'), 'Hora', t ? horaBonita(r.status === 'snoozed' ? t : new Date(r.scheduledAt || t)) : '')}
    ${r.status === 'snoozed' && t ? fila(img('posponer', 'rp-mini'), 'Pospuesto a', `${diaBonito(t, ahora)} · ${horaBonita(t)}`) : ''}
    ${fila(img('repetir', 'rp-mini'), 'Repetir', textoRepeticion(r))}
    ${fila(img('aviso', 'rp-mini'), 'Avisarme', textoAvisos(r.alertOffsets))}
    ${fila(img(hecho ? 'completados' : 'hoy', 'rp-mini'), 'Estado', hecho && r.completedAt ? `Completado ${fechaDMY(r.completedAt.slice(0, 10))}` : estTxt)}
  </section>
  ${hecho
    ? `<button type="button" class="rp-done" id="rpRestaurar">Restaurar recordatorio</button>`
    : `<button type="button" class="rp-done" id="rpHecho">${SVG.check}Marcar como hecho</button>
       <div class="rp-det-actions"><button type="button" id="rpEditar">${img('editar', 'rp-mini')}Editar</button><button type="button" id="rpPosponer">${img('posponer', 'rp-mini')}Posponer</button></div>`}
  <button type="button" class="rp-delete" id="rpEliminar">${img('eliminar', 'rp-mini')}Eliminar recordatorio</button>`;
}

export function hojaHtml({ tipo = '', r = null, ahora = new Date(), elegir = '' } = {}) {
  if (!tipo || !r) return '';
  let body = '';
  if (tipo === 'menu') {
    const hecho = r.status === 'completed';
    body = `<h3>${esc(r.title)}</h3><div class="rp-sheet-list">
      ${hecho ? `<button type="button" data-rp-act="restaurar">${img('repetir', 'rp-mini')}Restaurar</button>` : `<button type="button" data-rp-act="hecho">${img('hecho', 'rp-mini')}Marcar como hecho</button><button type="button" data-rp-act="posponer">${img('posponer', 'rp-mini')}Posponer</button><button type="button" data-rp-act="editar">${img('editar', 'rp-mini')}Editar</button>`}
      <button type="button" data-rp-act="eliminar" class="danger">${img('eliminar', 'rp-mini')}Eliminar</button></div>`;
  } else if (tipo === 'posponer') {
    const minDT = new Date(ahora.getTime() + 60000);
    const pad = n => String(n).padStart(2, '0');
    const minVal = `${minDT.getFullYear()}-${pad(minDT.getMonth() + 1)}-${pad(minDT.getDate())}T${pad(minDT.getHours())}:${pad(minDT.getMinutes())}`;
    body = `<h3>Opciones de posponer</h3><div class="rp-sheet-list">${POSPONER.filter(p => p[0] !== 'elegir').map(([v, l]) => `<button type="button" data-rp-snooze="${v}">${SVG.clock}${esc(l)}</button>`).join('')}</div>
      <label class="rp-field rp-elegir"><span>Elegir fecha y hora</span><input id="rpElegir" type="datetime-local" min="${minVal}" value="${esc(elegir || minVal)}"></label>
      <button type="button" class="rp-save" data-rp-snooze="elegir">Posponer a esa fecha</button>`;
  } else if (tipo === 'eliminar') {
    body = `<h3>¿Eliminar este recordatorio?</h3><p class="rp-sheet-p">Se elimina solo “${esc(r.title)}”. Sus avisos pendientes se cancelan.</p>
      <button type="button" class="rp-save danger" data-rp-act="confirmar-eliminar">Eliminar</button>`;
  }
  return `<div class="rp-backdrop" id="rpSheetBg"><div class="rp-sheet" role="dialog" aria-modal="true"><button type="button" class="rp-sheet-x" id="rpSheetClose" aria-label="Cerrar">${SVG.close}</button>${body}</div></div>`;
}
