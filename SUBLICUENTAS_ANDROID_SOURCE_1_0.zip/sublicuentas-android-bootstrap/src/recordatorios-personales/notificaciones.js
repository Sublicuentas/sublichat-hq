// Más › Recordatorios — notificaciones del sistema Android (app en segundo plano o cerrada).
// Usa @capacitor/local-notifications (AlarmManager nativo). El plugin reprograma solo al reiniciar
// el teléfono (BOOT_COMPLETED) y la app vuelve a programar todo en cada arranque/actualización.
// No toca los avisos de cobro (ids 7100-7299, canal "cobros"): este módulo usa su propio rango de ids,
// sus propios canales y su propio tipo de acciones.
import { CANAL, CANAL_URGENTE, TIPO_ACCIONES, esIdRecordatorio, planNotificaciones, idsOcurrenciaActual } from './logica.js';

export const AVISOS_RP = { permiso: '', exacta: '', listo: false, escuchando: false };

// IMPORTANTE (igual que R75): un plugin de Capacitor nunca se devuelve suelto desde una función
// async porque es un Proxy que responde a `.then`. Siempre va envuelto: { LN }.
async function plugin() {
  try {
    const { Capacitor } = await import('@capacitor/core');
    if (!Capacitor?.isNativePlatform?.()) return null;
    const m = await import('@capacitor/local-notifications');
    return m.LocalNotifications ? { LN: m.LocalNotifications } : null;
  } catch (_) { return null; }
}

export async function prepararNotificaciones(alAccion) {
  const LN = (await plugin())?.LN;
  if (!LN) { AVISOS_RP.permiso = 'web'; return false; }
  if (!AVISOS_RP.listo) {
    AVISOS_RP.listo = true;
    try { await LN.createChannel({ id: CANAL, name: 'Sublichat Recordatorios', description: 'Recordatorios personales de Más › Recordatorios', importance: 4, visibility: 1, vibration: true, lights: true, lightColor: '#E2231A' }); } catch (_) {}
    try { await LN.createChannel({ id: CANAL_URGENTE, name: 'Sublichat Recordatorios urgentes', description: 'Recordatorios con prioridad Urgente', importance: 5, visibility: 1, vibration: true, lights: true, lightColor: '#E2231A' }); } catch (_) {}
    try {
      await LN.registerActionTypes({ types: [{ id: TIPO_ACCIONES, actions: [
        { id: 'hecho', title: '✅ Hecho' },
        { id: 'posponer', title: '⏰ Posponer' },
      ] }] });
    } catch (_) {}
  }
  if (!AVISOS_RP.escuchando && typeof alAccion === 'function') {
    AVISOS_RP.escuchando = true;
    // Otros módulos también escuchan este evento: aquí solo se atienden los de Recordatorios.
    LN.addListener('localNotificationActionPerformed', ev => {
      const x = ev?.notification?.extra || {};
      if (x.modulo !== 'recordatorios-personales') return;
      alAccion({ accion: ev?.actionId || 'tap', id: String(x.recordatorioId || ''), owner: String(x.owner || ''), ocurrencia: String(x.ocurrencia || ''), notificacionId: ev?.notification?.id });
    });
  }
  try { AVISOS_RP.permiso = (await LN.checkPermissions())?.display || ''; } catch (_) {}
  try { AVISOS_RP.exacta = (await LN.checkExactNotificationSetting?.())?.exact_alarm || ''; } catch (_) {}
  return true;
}

// Android 13+: el permiso se pide solo cuando el usuario usa Recordatorios (al guardar o al tocar "Activar").
export async function pedirPermiso() {
  const LN = (await plugin())?.LN;
  if (!LN) return 'web';
  try {
    let p = (await LN.checkPermissions())?.display;
    if (p !== 'granted') p = (await LN.requestPermissions())?.display;
    AVISOS_RP.permiso = p || '';
  } catch (_) {}
  return AVISOS_RP.permiso;
}

// Android 12+: "Alarmas y recordatorios" para que suene a la hora exacta aun en ahorro de batería.
export async function abrirAjusteAlarmasExactas() {
  const LN = (await plugin())?.LN;
  if (!LN?.changeExactNotificationSetting) return '';
  try { AVISOS_RP.exacta = (await LN.changeExactNotificationSetting())?.exact_alarm || ''; } catch (_) {}
  return AVISOS_RP.exacta;
}

// Cancela SOLO lo de este módulo y vuelve a programar el plan completo. Los ids son estables
// (recordatorio + ocurrencia + aviso), así que repetir esta función nunca duplica avisos.
export async function reprogramar(items = [], { owner = '', ahora = new Date() } = {}) {
  const LN = (await plugin())?.LN;
  if (!LN) return { ok: false, motivo: 'web' };
  let pendientes = [];
  try { pendientes = (await LN.getPending())?.notifications || []; } catch (_) {}
  const nuestros = pendientes.filter(n => esIdRecordatorio(n.id) || n?.extra?.modulo === 'recordatorios-personales').map(n => ({ id: n.id }));
  if (nuestros.length) { try { await LN.cancel({ notifications: nuestros }); } catch (_) {} }
  if (!owner) return { ok: true, programadas: 0 };
  try { AVISOS_RP.permiso = (await LN.checkPermissions())?.display || AVISOS_RP.permiso; } catch (_) {}
  if (AVISOS_RP.permiso !== 'granted') return { ok: false, motivo: 'permiso' };
  try { AVISOS_RP.exacta = (await LN.checkExactNotificationSetting?.())?.exact_alarm || AVISOS_RP.exacta; } catch (_) {}
  // Sin "Alarmas y recordatorios" el plugin abriría Ajustes en cada reprogramación: en ese caso se
  // programan como alarmas no exactas (llegan igual, con unos minutos de margen) y en la pantalla se
  // ofrece el botón para activarlas.
  const exacta = AVISOS_RP.exacta === 'granted';
  const plan = planNotificaciones(items, { ahora, owner }).map(n => ({ ...n, isExactNotification: exacta }));
  if (plan.length) {
    try { await LN.schedule({ notifications: plan }); }
    catch (e) { return { ok: false, motivo: 'programar', error: String(e?.message || e) }; }
  }
  return { ok: true, programadas: plan.length };
}

// Quita de la barra las notificaciones ya mostradas de la ocurrencia actual (al marcar Hecho/Posponer).
export async function limpiarEntregadas(r, extraId = null) {
  const LN = (await plugin())?.LN;
  if (!LN?.removeDeliveredNotifications || !r) return;
  const ids = [...new Set([...idsOcurrenciaActual(r), ...(extraId != null ? [Number(extraId)] : [])])];
  try { await LN.removeDeliveredNotifications({ notifications: ids.map(id => ({ id, title: '', body: '' })) }); } catch (_) {}
}
