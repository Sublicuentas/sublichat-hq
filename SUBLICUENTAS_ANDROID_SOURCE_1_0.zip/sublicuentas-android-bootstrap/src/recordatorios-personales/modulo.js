// Más › Recordatorios — controlador de la sección (estado de pantalla, eventos y enlace con avisos).
// Sección PERSONAL e independiente: no usa ni modifica clientes, ventas, cobros, renovaciones,
// tickets, Bot TG ni Panel de Socios. Solo toma de la app la sesión (para saber de quién son).
import './recordatorios.css';
import { state, ui, showToast } from '../app/core.js';
import { authPost } from '../api.js';
import { crearAlmacen } from './almacen.js';
import {
  borradorNuevo, borradorDesde, validarBorrador, aplicarBorrador, marcarHecho, calcularPosponer, posponer,
  eliminar, restaurar, normalizarAvisos, recalcularZona, LIMITES,
} from './logica.js';
import { AVISOS_RP, prepararNotificaciones, pedirPermiso, abrirAjusteAlarmasExactas, reprogramar, limpiarEntregadas } from './notificaciones.js';
import { listaHtml, formularioHtml, detalleHtml, hojaHtml } from './vista.js';

export const RP = {
  vista: 'lista', tab: 'hoy', q: '', categoria: '', prioridad: '', limite: 0, filtros: true,
  borrador: null, errores: {}, editId: '', volverA: 'lista', guardando: false, formError: '',
  detalleId: '', hoja: '', hojaId: '', elegir: '', deshacer: '', syncBusy: false, focusBuscar: false,
  iniciado: false, accionPendiente: null,
};
export const almacen = crearAlmacen({ post: body => authPost('/api/recordatorios', body) });

let timerProgramar = 0, timerSync = 0, timerDeshacer = 0;
const enPantalla = () => state.active === 'mas' && state.subview === 'recordatorios';
const ownerActual = () => String(state.session?.uid || state.session?.usuario || '');

function reiniciarPantalla() {
  Object.assign(RP, { vista: 'lista', tab: 'hoy', q: '', categoria: '', prioridad: '', limite: 0, borrador: null, errores: {}, editId: '', guardando: false, formError: '', detalleId: '', hoja: '', hojaId: '', deshacer: '' });
}

// Si cambia la cuenta (o se cierra sesión), se cargan SOLO los recordatorios del nuevo usuario
// y se reprograman sus alarmas. Nunca se muestran recordatorios de otra persona.
export function asegurarDueno() {
  const owner = ownerActual();
  if (almacen.owner === owner) return owner;
  if (owner) almacen.cargar(owner); else almacen.olvidar();
  reiniciarPantalla();
  programar(0);
  if (owner) sincronizarLuego(300);
  return owner;
}

export function programar(ms = 500) {
  clearTimeout(timerProgramar);
  timerProgramar = setTimeout(() => { reprogramar(almacen.items, { owner: almacen.owner }).catch(() => {}); }, ms);
}

export function sincronizarLuego(ms = 1200) {
  clearTimeout(timerSync);
  timerSync = setTimeout(async () => {
    if (!almacen.owner) return;
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
    RP.syncBusy = true;
    const antes = JSON.stringify(almacen.items);
    const res = await almacen.sincronizar().catch(() => ({ ok: false }));
    RP.syncBusy = false;
    const cambio = JSON.stringify(almacen.items) !== antes;
    if (cambio) programar(0);
    if (enPantalla() && (cambio || !res?.ok || RP.vista === 'lista') && !document.activeElement?.closest?.('#rpForm')) ui.render();
  }, ms);
}

// Arranque único: canales, botones de la notificación y listeners. Se llama en cada bindEvents
// (es barato) para que funcione aunque la app se abra desde una notificación con la app cerrada.
export function rpIniciar() {
  if (!RP.iniciado) {
    RP.iniciado = true;
    prepararNotificaciones(alTocarNotificacion).then(() => { programar(0); if (enPantalla()) ui.render(); }).catch(() => {});
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => sincronizarLuego(200));
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) return;
        asegurarDueno();
        // Zona horaria nueva: misma hora de pared, alarmas recalculadas.
        const antes = JSON.stringify(almacen.items.map(r => r.scheduledAt));
        const ajustados = recalcularZona(almacen.items);
        if (JSON.stringify(ajustados.map(r => r.scheduledAt)) !== antes) almacen.guardar(...ajustados.filter((r, i) => r.scheduledAt !== almacen.items[i]?.scheduledAt));
        prepararNotificaciones(alTocarNotificacion).finally(() => programar(0));
        sincronizarLuego(500);
        if (enPantalla()) ui.render();
      });
    }
  }
  asegurarDueno();
}

export function rpCerrarSesion() {
  // Sin sesión no quedan avisos personales programados en el teléfono.
  almacen.olvidar(); reiniciarPantalla();
  reprogramar([], { owner: '' }).catch(() => {});
}

function abrirSeccion() {
  state.active = 'mas'; state.subview = 'recordatorios'; state.selectedClientId = '';
}

function alTocarNotificacion(ev) {
  if (!state.session) { RP.accionPendiente = ev; return; }
  aplicarAccionNotificacion(ev);
}

function aplicarAccionNotificacion(ev) {
  const owner = asegurarDueno();
  if (!owner || (ev.owner && ev.owner !== owner)) return; // aviso de otra cuenta: no se muestra nada
  const r = almacen.obtener(ev.id);
  if (!r || r.deleted) { showToast('Ese recordatorio ya no existe.'); return; }
  abrirSeccion();
  if (ev.accion === 'hecho') { hacerHecho(r, ev.notificacionId); RP.vista = 'lista'; }
  else if (ev.accion === 'posponer') { RP.vista = 'detalle'; RP.detalleId = r.id; RP.hoja = 'posponer'; RP.hojaId = r.id; }
  else { RP.vista = 'detalle'; RP.detalleId = r.id; }
  ui.render();
}

// ——— Acciones ———
function guardarYProgramar(...registros) {
  almacen.guardar(...registros);
  programar(0);
  sincronizarLuego();
}

function hacerHecho(r, notificacionId = null) {
  const { actualizado, historial } = marcarHecho(r, new Date());
  limpiarEntregadas(r, notificacionId).catch(() => {});
  guardarYProgramar(actualizado, historial);
  showToast(historial ? 'Hecho ✓ · se programó la siguiente vez' : 'Recordatorio completado ✓');
}

function aplicarPosponer(r, opcion, elegido) {
  const hasta = calcularPosponer(opcion, r, new Date(), elegido);
  if (!hasta) { showToast('Elija una fecha y hora futura.'); return false; }
  limpiarEntregadas(r).catch(() => {});
  guardarYProgramar(posponer(r, hasta, new Date()));
  showToast('Recordatorio pospuesto');
  return true;
}

function eliminarRecordatorio(r) {
  limpiarEntregadas(r).catch(() => {});
  guardarYProgramar(eliminar(r, new Date()));
  RP.deshacer = r.id;
  clearTimeout(timerDeshacer);
  timerDeshacer = setTimeout(() => { RP.deshacer = ''; if (enPantalla() && RP.vista === 'lista') ui.render(); }, 7000);
}

function deshacerEliminar() {
  const r = almacen.obtener(RP.deshacer);
  RP.deshacer = ''; clearTimeout(timerDeshacer);
  if (!r) return;
  guardarYProgramar({ ...r, deleted: false, status: r.snoozedUntil ? 'snoozed' : 'scheduled', updatedAt: new Date().toISOString() });
  showToast('Recordatorio restaurado');
}

function abrirFormulario(r = null, volverA = 'lista') {
  RP.vista = 'form'; RP.editId = r?.id || ''; RP.volverA = volverA; RP.errores = {}; RP.formError = ''; RP.guardando = false;
  RP.borrador = r ? borradorDesde(r) : borradorNuevo(new Date());
}

async function guardarFormulario() {
  if (RP.guardando) return; // doble toque: no hay doble guardado
  leerFormulario();
  const previo = RP.editId ? almacen.obtener(RP.editId) : null;
  const { ok, errores } = validarBorrador(RP.borrador, { ahora: new Date(), esNuevo: !previo });
  RP.errores = errores; RP.formError = '';
  if (!ok) { ui.render(); return; }
  RP.guardando = true; ui.render();
  try {
    // 1) Persistir primero (funciona sin internet)…
    const r = aplicarBorrador(RP.borrador, previo, { ownerUserId: almacen.owner, ahora: new Date() });
    almacen.guardar(r);
    // 2) …después pedir permiso (solo la primera vez) y programar la alarma nueva (la vieja se cancela).
    if (AVISOS_RP.permiso && AVISOS_RP.permiso !== 'granted' && AVISOS_RP.permiso !== 'web') await pedirPermiso();
    programar(0);
    sincronizarLuego();
    RP.guardando = false; RP.borrador = null; RP.errores = {};
    RP.vista = previo && RP.volverA === 'detalle' ? 'detalle' : 'lista';
    RP.detalleId = r.id;
    if (RP.vista === 'lista') RP.tab = vistaDe(r);
    showToast(previo ? 'Cambios guardados' : 'Recordatorio guardado');
  } catch (e) {
    RP.guardando = false; RP.formError = String(e?.message || 'No se pudo guardar. Sus datos siguen en el formulario.');
  }
  ui.render();
}

function vistaDe(r) {
  const fin = new Date(); fin.setHours(23, 59, 59, 999);
  const t = r.status === 'snoozed' && r.snoozedUntil ? new Date(r.snoozedUntil) : new Date(r.scheduledAt);
  return t <= fin ? 'hoy' : 'proximos';
}

function leerFormulario() {
  const b = RP.borrador; if (!b) return;
  const v = sel => document.querySelector(sel);
  if (v('#rpTitulo')) b.title = v('#rpTitulo').value.slice(0, LIMITES.titulo);
  if (v('#rpNota')) b.note = v('#rpNota').value.slice(0, LIMITES.nota);
  if (v('#rpFecha')) b.fecha = v('#rpFecha').value;
  if (v('#rpHora')) b.hora = v('#rpHora').value;
  if (v('#rpRepN')) b.repeatCustom = { ...(b.repeatCustom || {}), every: Number(v('#rpRepN').value) };
  if (v('#rpRepU')) b.repeatCustom = { ...(b.repeatCustom || {}), unit: v('#rpRepU').value };
  if (v('#rpImportante') && b.priority === 'normal') b.important = !!v('#rpImportante').checked;
}

// ——— Vista ———
export function recordatoriosView() {
  const owner = asegurarDueno();
  if (!owner) return '<div class="rp-empty"><strong>Inicie sesión</strong><span>Los recordatorios son personales de cada usuario.</span></div>';
  const ahora = new Date();
  let html;
  if (RP.vista === 'form' && RP.borrador) html = formularioHtml({ borrador: RP.borrador, errores: RP.errores, esNuevo: !RP.editId, guardando: RP.guardando, error: RP.formError });
  else if (RP.vista === 'detalle') html = detalleHtml({ r: almacen.obtener(RP.detalleId), ahora });
  else html = listaHtml({
    items: almacen.items, vista: RP.tab, q: RP.q, categoria: RP.categoria, prioridad: RP.prioridad, limite: RP.limite, filtrosAbiertos: RP.filtros, ahora,
    permisos: { permiso: AVISOS_RP.permiso, exacta: AVISOS_RP.exacta }, sync: { pendientes: almacen.pendientes, error: almacen.error, busy: RP.syncBusy }, deshacer: RP.deshacer ? almacen.obtener(RP.deshacer) : null,
  });
  const hoja = RP.hoja ? hojaHtml({ tipo: RP.hoja, r: almacen.obtener(RP.hojaId), ahora, elegir: RP.elegir }) : '';
  return `<div class="rp-screen">${html}${hoja}</div>`;
}

const on = (sel, ev, fn) => document.querySelector(sel)?.addEventListener(ev, fn);
const onAll = (sel, ev, fn) => document.querySelectorAll(sel).forEach(el => el.addEventListener(ev, e => fn(el, e)));
const cerrarHoja = () => { RP.hoja = ''; RP.hojaId = ''; RP.elegir = ''; };

export function bindRecordatorios() {
  rpIniciar();
  if (state.session && RP.accionPendiente) { const ev = RP.accionPendiente; RP.accionPendiente = null; setTimeout(() => aplicarAccionNotificacion(ev), 0); }
  if (!enPantalla()) return;

  // Barra superior
  on('#rpBack', 'click', () => { cerrarHoja(); if (RP.vista !== 'lista') { RP.vista = 'lista'; ui.render(); return; } state.subview = null; ui.render(); });
  on('#rpDetBack', 'click', () => { cerrarHoja(); RP.vista = 'lista'; ui.render(); });
  on('#rpFormBack', 'click', () => { RP.vista = RP.volverA === 'detalle' && RP.editId ? 'detalle' : 'lista'; RP.borrador = null; ui.render(); });
  on('#rpCancelar', 'click', () => { RP.vista = RP.volverA === 'detalle' && RP.editId ? 'detalle' : 'lista'; RP.borrador = null; ui.render(); });
  on('#rpSync', 'click', () => { RP.syncBusy = true; ui.render(); sincronizarLuego(0); });
  on('#rpDetMenu', 'click', () => { RP.hoja = 'menu'; RP.hojaId = RP.detalleId; ui.render(); });

  // Lista
  on('#rpNuevo', 'click', () => { abrirFormulario(null, 'lista'); ui.render(); window.scrollTo?.(0, 0); });
  const buscar = document.querySelector('#rpBuscar');
  buscar?.addEventListener('input', () => { RP.q = buscar.value; RP.focusBuscar = true; ui.render(); });
  if (buscar && RP.focusBuscar) { RP.focusBuscar = false; buscar.focus(); const n = buscar.value.length; try { buscar.setSelectionRange(n, n); } catch (_) {} }
  on('#rpFiltros', 'click', () => { RP.filtros = !RP.filtros; ui.render(); });
  on('#rpCategoria', 'change', e => { RP.categoria = e.target.value; ui.render(); });
  on('#rpPrioridad', 'change', e => { RP.prioridad = e.target.value; ui.render(); });
  on('#rpLimite', 'change', e => { RP.limite = Number(e.target.value) || 0; ui.render(); });
  onAll('[data-rp-vista]', 'click', el => { RP.tab = el.dataset.rpVista; ui.render(); });
  onAll('[data-rp-open]', 'click', (el, e) => { if (e.target.closest('[data-rp-menu]')) return; RP.vista = 'detalle'; RP.detalleId = el.dataset.rpOpen; ui.render(); window.scrollTo?.(0, 0); });
  onAll('[data-rp-menu]', 'click', (el, e) => { e.stopPropagation(); RP.hoja = 'menu'; RP.hojaId = el.dataset.rpMenu; ui.render(); });
  on('#rpDeshacer', 'click', () => { deshacerEliminar(); ui.render(); });
  on('#rpPermiso', 'click', async () => { await pedirPermiso(); programar(0); ui.render(); });
  on('#rpExacta', 'click', async () => { await abrirAjusteAlarmasExactas(); programar(0); ui.render(); });

  // Detalle
  const actual = () => almacen.obtener(RP.detalleId);
  on('#rpHecho', 'click', () => { const r = actual(); if (r) { hacerHecho(r); ui.render(); } });
  on('#rpRestaurar', 'click', () => { const r = actual(); if (r) { guardarYProgramar(restaurar(r)); showToast('Recordatorio restaurado'); ui.render(); } });
  on('#rpEditar', 'click', () => { const r = actual(); if (r) { abrirFormulario(r, 'detalle'); ui.render(); } });
  on('#rpPosponer', 'click', () => { RP.hoja = 'posponer'; RP.hojaId = RP.detalleId; ui.render(); });
  on('#rpEliminar', 'click', () => { RP.hoja = 'eliminar'; RP.hojaId = RP.detalleId; ui.render(); });

  // Hojas (menú ⋮, posponer, confirmar eliminar)
  on('#rpSheetClose', 'click', () => { cerrarHoja(); ui.render(); });
  on('#rpSheetBg', 'click', e => { if (e.target.id === 'rpSheetBg') { cerrarHoja(); ui.render(); } });
  on('#rpElegir', 'input', e => { RP.elegir = e.target.value; });
  onAll('[data-rp-act]', 'click', el => {
    const r = almacen.obtener(RP.hojaId); if (!r) { cerrarHoja(); ui.render(); return; }
    const a = el.dataset.rpAct;
    if (a === 'hecho') { cerrarHoja(); hacerHecho(r); }
    else if (a === 'posponer') { RP.hoja = 'posponer'; }
    else if (a === 'editar') { cerrarHoja(); abrirFormulario(r, RP.vista === 'detalle' ? 'detalle' : 'lista'); }
    else if (a === 'restaurar') { cerrarHoja(); guardarYProgramar(restaurar(r)); showToast('Recordatorio restaurado'); }
    else if (a === 'eliminar') { RP.hoja = 'eliminar'; }
    else if (a === 'confirmar-eliminar') { cerrarHoja(); eliminarRecordatorio(r); RP.vista = 'lista'; }
    ui.render();
  });
  onAll('[data-rp-snooze]', 'click', el => {
    const r = almacen.obtener(RP.hojaId); if (!r) return;
    const elegido = el.dataset.rpSnooze === 'elegir' ? (document.querySelector('#rpElegir')?.value || RP.elegir) : null;
    if (aplicarPosponer(r, el.dataset.rpSnooze, elegido)) { cerrarHoja(); ui.render(); }
  });

  // Formulario
  const form = document.querySelector('#rpForm');
  if (form && RP.borrador) {
    form.addEventListener('submit', e => { e.preventDefault(); guardarFormulario(); });
    ['#rpTitulo', '#rpFecha', '#rpHora', '#rpRepN', '#rpRepU', '#rpImportante'].forEach(s => on(s, 'input', leerFormulario));
    on('#rpRepU', 'change', leerFormulario);
    on('#rpImportante', 'change', leerFormulario);
    const nota = document.querySelector('#rpNota');
    nota?.addEventListener('input', () => { leerFormulario(); const c = document.querySelector('#rpNotaCount'); if (c) c.textContent = `${nota.value.length}/${LIMITES.nota}`; });
    const cambiar = fn => { leerFormulario(); fn(RP.borrador); ui.render(); };
    onAll('[data-rp-cat]', 'click', el => cambiar(b => { b.category = el.dataset.rpCat; }));
    onAll('[data-rp-pri]', 'click', el => cambiar(b => { b.priority = el.dataset.rpPri; if (b.priority !== 'normal') b.important = true; }));
    onAll('[data-rp-rep]', 'click', el => cambiar(b => { b.repeatRule = el.dataset.rpRep; }));
    onAll('[data-rp-aviso]', 'click', el => cambiar(b => {
      const v = Number(el.dataset.rpAviso);
      const set = new Set(normalizarAvisos(b.alertOffsets));
      if (set.has(v)) { if (set.size > 1) set.delete(v); } else set.add(v);
      b.alertOffsets = normalizarAvisos([...set]);
    }));
  }
}
