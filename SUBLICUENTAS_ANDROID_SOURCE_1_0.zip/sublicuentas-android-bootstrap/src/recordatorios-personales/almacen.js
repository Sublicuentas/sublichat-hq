// Más › Recordatorios — almacenamiento local por usuario + sincronización con Sublichat HQ.
// Funciona sin internet: todo se guarda primero en el teléfono y se sube cuando hay conexión.
// Cada usuario tiene su propia llave local y su propia carpeta en el servidor (ownerUserId = su uid).
import { fusionar, recalcularZona } from './logica.js';

const PREFIJO = 'sublichat-recordatorios-personales:v1:';
const TOMBSTONE_DIAS = 30;

export function crearAlmacen({ storage = globalThis.localStorage, post = null, ahora = () => new Date() } = {}) {
  const s = { owner: '', items: [], sucios: new Set(), ultimaSync: '', sincronizando: null, error: '' };

  const llave = owner => PREFIJO + encodeURIComponent(owner);
  function persistir() {
    if (!s.owner) return;
    try { storage?.setItem(llave(s.owner), JSON.stringify({ items: s.items, sucios: [...s.sucios], ultimaSync: s.ultimaSync })); } catch (_) {}
  }
  function cargar(owner = '') {
    s.owner = String(owner || '');
    s.items = []; s.sucios = new Set(); s.ultimaSync = ''; s.error = '';
    if (!s.owner) return api;
    try {
      const raw = JSON.parse(storage?.getItem(llave(s.owner)) || '{}');
      s.items = (Array.isArray(raw.items) ? raw.items : []).filter(r => r && r.id && (!r.ownerUserId || r.ownerUserId === s.owner));
      s.sucios = new Set(Array.isArray(raw.sucios) ? raw.sucios : []);
      s.ultimaSync = String(raw.ultimaSync || '');
    } catch (_) {}
    const antes = JSON.stringify(s.items);
    s.items = recalcularZona(s.items);
    if (JSON.stringify(s.items) !== antes) persistir();
    return api;
  }
  function guardar(...registros) {
    if (!s.owner) throw new Error('Inicie sesión para guardar recordatorios.');
    for (const r of registros.filter(Boolean)) {
      const limpio = { ...r, ownerUserId: s.owner };
      const i = s.items.findIndex(x => x.id === limpio.id);
      if (i >= 0) s.items[i] = limpio; else s.items.push(limpio);
      s.sucios.add(limpio.id);
    }
    persistir();
    return registros;
  }
  function purgar() {
    const limite = new Date(ahora().getTime() - TOMBSTONE_DIAS * 86400000).toISOString();
    const antes = s.items.length;
    s.items = s.items.filter(r => !(r.deleted && !s.sucios.has(r.id) && String(r.updatedAt || '') < limite));
    if (s.items.length !== antes) persistir();
  }
  async function sincronizar() {
    if (!s.owner || typeof post !== 'function') return { ok: false, motivo: 'sin-sesion' };
    if (s.sincronizando) return s.sincronizando;
    const owner = s.owner;
    const cambios = s.items.filter(r => s.sucios.has(r.id));
    const enviados = new Map(cambios.map(r => [r.id, r.updatedAt]));
    s.sincronizando = (async () => {
      try {
        const res = await post({ accion: 'sincronizar', cambios, desde: s.ultimaSync });
        if (s.owner !== owner) return { ok: false, motivo: 'cambio-usuario' };
        if (!res || res.ok === false) throw new Error(res?.error || 'No se pudo sincronizar.');
        // El servidor ya filtra por el uid del token: solo devuelve lo de este usuario.
        s.items = recalcularZona(fusionar(s.items, (Array.isArray(res.items) ? res.items : []).map(r => ({ ...r, ownerUserId: owner }))));
        for (const [id, upd] of enviados) {
          const actual = s.items.find(r => r.id === id);
          if (!actual || String(actual.updatedAt || '') <= String(upd || '')) s.sucios.delete(id);
        }
        s.ultimaSync = String(res.ahora || s.ultimaSync || '');
        s.error = '';
        purgar();
        persistir();
        return { ok: true, recibidos: (res.items || []).length, enviados: cambios.length };
      } catch (e) {
        s.error = String(e?.message || 'Sin conexión');
        return { ok: false, motivo: 'error', error: s.error };
      } finally { s.sincronizando = null; }
    })();
    return s.sincronizando;
  }

  const api = {
    cargar, guardar, sincronizar, persistir,
    get owner() { return s.owner; },
    get items() { return s.items; },
    get pendientes() { return s.sucios.size; },
    get error() { return s.error; },
    get ultimaSync() { return s.ultimaSync; },
    obtener: id => s.items.find(r => r.id === id) || null,
    olvidar() { s.owner = ''; s.items = []; s.sucios = new Set(); s.ultimaSync = ''; s.error = ''; },
  };
  return api;
}
