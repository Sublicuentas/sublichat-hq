// Más › Recordatorios — lógica pura (sin DOM, sin Capacitor, sin red).
// Módulo PERSONAL e independiente: no lee ni escribe clientes, cobros, renovaciones,
// tickets, bot de Telegram ni Panel de Socios. Todo lo que hay aquí se puede probar con node --test.

export const CATEGORIAS = Object.freeze([
  ['personal', 'Personal'], ['familia', 'Familia'], ['trabajo', 'Trabajo'], ['pagos', 'Pagos'], ['citas', 'Citas'],
  ['compras', 'Compras'], ['diligencias', 'Diligencias'], ['pendientes', 'Pendientes'], ['eventos', 'Eventos'], ['otro', 'Otro'],
]);
export const PRIORIDADES = Object.freeze([['normal', 'Normal'], ['important', 'Importante'], ['urgent', 'Urgente']]);
export const REPETICIONES = Object.freeze([
  ['none', 'No repetir'], ['daily', 'Diario'], ['weekly', 'Semanal'], ['monthly', 'Mensual'], ['yearly', 'Anual'], ['custom', 'Personalizado'],
]);
export const UNIDADES = Object.freeze([['day', 'días'], ['week', 'semanas'], ['month', 'meses'], ['year', 'años']]);
export const AVISOS = Object.freeze([[0, 'A la hora'], [10, '10 min antes'], [30, '30 min antes'], [60, '1 hora antes'], [1440, '1 día antes']]);
export const POSPONER = Object.freeze([['10m', '10 minutos'], ['30m', '30 minutos'], ['1h', '1 hora'], ['manana', 'Mañana'], ['elegir', 'Elegir fecha y hora']]);
export const LIMITES = Object.freeze({ titulo: 80, nota: 500 });

const CAT_IDS = new Set(CATEGORIAS.map(c => c[0]));
const PRI_IDS = new Set(PRIORIDADES.map(p => p[0]));
const REP_IDS = new Set(REPETICIONES.map(r => r[0]));
const UNI_IDS = new Set(UNIDADES.map(u => u[0]));
const AVISO_IDS = new Set(AVISOS.map(a => a[0]));

export const etiquetaCategoria = id => (CATEGORIAS.find(c => c[0] === id) || CATEGORIAS[CATEGORIAS.length - 1])[1];
export const etiquetaPrioridad = id => (PRIORIDADES.find(p => p[0] === id) || PRIORIDADES[0])[1];

const pad = n => String(n).padStart(2, '0');
export function fechaISOLocal(d = new Date()) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
export function horaLocal(d = new Date()) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
export function zonaHoraria() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch (_) { return ''; } }

// La fuente de verdad es la hora "de pared": fecha + hora locales. Si el teléfono cambia de zona
// horaria, el recordatorio de las 10:00 sigue sonando a las 10:00 del lugar donde está el usuario.
export function aFecha(fecha = '', hora = '00:00') {
  const f = String(fecha || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const h = String(hora || '').match(/^(\d{1,2}):(\d{2})$/);
  if (!f || !h) return null;
  const y = +f[1], m = +f[2], d = +f[3], hh = +h[1], mm = +h[2];
  if (hh > 23 || mm > 59) return null;
  const date = new Date(y, m - 1, d, hh, mm, 0, 0);
  if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d) return null;
  return date;
}

function diasDelMes(y, m0) { return new Date(y, m0 + 1, 0).getDate(); }

// Suma unidades de calendario a una fecha AAAA-MM-DD. `ancla` = día del mes original, para que un
// mensual del 31 caiga el 30/28 en meses cortos y vuelva al 31 cuando el mes lo tenga.
export function sumarFecha(fecha, unidad, n = 1, ancla = 0) {
  const f = String(fecha || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!f) return '';
  let y = +f[1], m0 = +f[2] - 1, d = +f[3];
  const cant = Math.max(1, Math.round(Number(n) || 1));
  if (unidad === 'day' || unidad === 'week') {
    const dt = new Date(Date.UTC(y, m0, d));
    dt.setUTCDate(dt.getUTCDate() + cant * (unidad === 'week' ? 7 : 1));
    return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
  }
  const meses = unidad === 'year' ? cant * 12 : cant;
  const total = m0 + meses;
  y += Math.floor(total / 12); m0 = ((total % 12) + 12) % 12;
  const dia = Math.min(ancla || d, diasDelMes(y, m0));
  return `${y}-${pad(m0 + 1)}-${pad(dia)}`;
}

export function reglaRepeticion(r = {}) {
  const tipo = REP_IDS.has(r.repeatRule) ? r.repeatRule : 'none';
  if (tipo === 'none') return null;
  if (tipo === 'daily') return { unidad: 'day', n: 1 };
  if (tipo === 'weekly') return { unidad: 'week', n: 1 };
  if (tipo === 'monthly') return { unidad: 'month', n: 1 };
  if (tipo === 'yearly') return { unidad: 'year', n: 1 };
  const c = r.repeatCustom || {};
  return { unidad: UNI_IDS.has(c.unit) ? c.unit : 'day', n: Math.min(365, Math.max(1, Math.round(Number(c.every) || 1))) };
}

export function siguienteFecha(r = {}, desdeFecha = r.fecha) {
  const regla = reglaRepeticion(r);
  if (!regla) return '';
  return sumarFecha(desdeFecha, regla.unidad, regla.n, r.anchorDay || 0);
}

export function textoRepeticion(r = {}) {
  const tipo = REP_IDS.has(r.repeatRule) ? r.repeatRule : 'none';
  if (tipo !== 'custom') return (REPETICIONES.find(x => x[0] === tipo) || REPETICIONES[0])[1];
  const regla = reglaRepeticion(r);
  const u = (UNIDADES.find(x => x[0] === regla.unidad) || UNIDADES[0])[1];
  const uno = { day: 'Cada día', week: 'Cada semana', month: 'Cada mes', year: 'Cada año' };
  return regla.n === 1 ? uno[regla.unidad] : `Cada ${regla.n} ${u}`;
}

export function textoAvisos(offsets = []) {
  const list = normalizarAvisos(offsets);
  return list.map(o => (AVISOS.find(a => a[0] === o) || [o, `${o} min antes`])[1]).join(' + ');
}

export function normalizarAvisos(offsets) {
  const list = [...new Set((Array.isArray(offsets) ? offsets : [offsets]).map(Number).filter(o => AVISO_IDS.has(o)))].sort((a, b) => b - a);
  return list.length ? list : [0];
}

// Momento en que "vence" la ocurrencia actual: si está pospuesto, la hora pospuesta.
export function momentoVencimiento(r = {}) {
  if (r.status === 'snoozed' && r.snoozedUntil) {
    const t = new Date(r.snoozedUntil);
    if (!Number.isNaN(t.getTime())) return t;
  }
  return aFecha(r.fecha, r.hora);
}

export const esActivo = r => !!r && !r.deleted && r.status !== 'completed' && r.status !== 'cancelled';
export const esImportante = r => !!r && (r.important === true || r.priority === 'important' || r.priority === 'urgent');

// Estado que ve el usuario. "Vencido" se calcula: un recordatorio vencido NO desaparece.
export function estadoEfectivo(r = {}, ahora = new Date()) {
  if (r.deleted) return 'cancelled';
  if (r.status === 'completed' || r.status === 'cancelled') return r.status;
  const t = momentoVencimiento(r);
  if (t && t.getTime() < ahora.getTime()) return 'overdue';
  return r.status === 'snoozed' ? 'snoozed' : 'scheduled';
}

const PESO_PRIORIDAD = { urgent: 0, important: 1, normal: 2 };
export function ordenar(a, b) {
  const ta = momentoVencimiento(a)?.getTime() ?? Infinity;
  const tb = momentoVencimiento(b)?.getTime() ?? Infinity;
  if (ta !== tb) return ta - tb;
  const pa = PESO_PRIORIDAD[a.priority] ?? 2, pb = PESO_PRIORIDAD[b.priority] ?? 2;
  if (pa !== pb) return pa - pb; // Urgente primero cuando coincide fecha y hora
  if (esImportante(a) !== esImportante(b)) return esImportante(a) ? -1 : 1;
  return String(a.title || '').localeCompare(String(b.title || ''), 'es');
}

function mismoDia(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function finDelDia(d) { const x = new Date(d); x.setHours(23, 59, 59, 999); return x; }

export function normalizarTexto(v = '') {
  return String(v ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
}

export function coincideBusqueda(r = {}, q = '') {
  const t = normalizarTexto(q);
  if (!t) return true;
  const [y, m, d] = String(r.fecha || '').split('-');
  const bolsa = normalizarTexto([r.title, r.note, etiquetaCategoria(r.category), etiquetaPrioridad(r.priority), d && `${d}/${m}/${y}`, d && `${d}/${m}`].filter(Boolean).join(' '));
  return bolsa.includes(t);
}

// Pestañas de la pantalla principal.
//  · hoy: vencidos pendientes + los que vencen hoy (el vencido no desaparece).
//  · proximos: de mañana en adelante.
//  · importantes: activos con bandera Importante o prioridad Importante/Urgente.
//  · completados: historial, lo más reciente primero.
export function filtrarVista(items = [], { vista = 'hoy', q = '', categoria = '', prioridad = '', ahora = new Date() } = {}) {
  const fin = finDelDia(ahora);
  const base = (Array.isArray(items) ? items : []).filter(r => !r.deleted)
    .filter(r => !categoria || r.category === categoria)
    .filter(r => !prioridad || r.priority === prioridad)
    .filter(r => coincideBusqueda(r, q));
  if (vista === 'completados') {
    return base.filter(r => r.status === 'completed')
      .sort((a, b) => String(b.completedAt || '').localeCompare(String(a.completedAt || '')));
  }
  const activos = base.filter(esActivo);
  if (vista === 'importantes') return activos.filter(esImportante).sort(ordenar);
  if (vista === 'proximos') return activos.filter(r => { const t = momentoVencimiento(r); return t && t > fin; }).sort(ordenar);
  return activos.filter(r => { const t = momentoVencimiento(r); return t && t <= fin; }).sort(ordenar);
}

export function contarVistas(items = [], opts = {}) {
  return {
    hoy: filtrarVista(items, { ...opts, vista: 'hoy' }).length,
    proximos: filtrarVista(items, { ...opts, vista: 'proximos' }).length,
    importantes: filtrarVista(items, { ...opts, vista: 'importantes' }).length,
    completados: filtrarVista(items, { ...opts, vista: 'completados' }).length,
  };
}

// Próximos agrupados por fecha (encabezado por día).
export function agruparPorFecha(items = []) {
  const grupos = new Map();
  for (const r of items) {
    const t = momentoVencimiento(r);
    const k = t ? fechaISOLocal(t) : 'sin-fecha';
    if (!grupos.has(k)) grupos.set(k, []);
    grupos.get(k).push(r);
  }
  return [...grupos.entries()].map(([fecha, lista]) => ({ fecha, lista }));
}

const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
export function horaBonita(d) {
  if (!d) return '';
  let h = d.getHours(); const m = pad(d.getMinutes()); const pm = h >= 12;
  h = h % 12 || 12;
  return `${h}:${m} ${pm ? 'p. m.' : 'a. m.'}`;
}
export function diaBonito(d, ahora = new Date()) {
  if (!d) return 'Sin fecha';
  const man = new Date(ahora); man.setDate(man.getDate() + 1);
  const ayer = new Date(ahora); ayer.setDate(ayer.getDate() - 1);
  if (mismoDia(d, ahora)) return 'Hoy';
  if (mismoDia(d, man)) return 'Mañana';
  if (mismoDia(d, ayer)) return 'Ayer';
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}
export function encabezadoDia(fechaISO, ahora = new Date()) {
  const d = aFecha(fechaISO, '12:00');
  if (!d) return 'Sin fecha';
  const base = diaBonito(d, ahora);
  if (base === 'Hoy' || base === 'Mañana') return `${base} · ${d.getDate()} ${MESES[d.getMonth()]}`;
  const txt = `${DIAS[d.getDay()]} ${d.getDate()} ${MESES[d.getMonth()]}`;
  return txt.charAt(0).toUpperCase() + txt.slice(1);
}
export function cuandoTexto(r, ahora = new Date()) {
  const t = momentoVencimiento(r);
  return t ? `${diaBonito(t, ahora)} · ${horaBonita(t)}` : 'Sin fecha';
}
export function fechaDMY(fechaISO = '') {
  const [y, m, d] = String(fechaISO || '').split('-');
  return d ? `${d}/${m}/${y}` : '';
}

// ——— Formulario ———
export function borradorNuevo(ahora = new Date()) {
  const d = new Date(ahora.getTime() + 60 * 60 * 1000);
  d.setMinutes(d.getMinutes() < 30 ? 30 : 60, 0, 0);
  return {
    id: '', title: '', note: '', fecha: fechaISOLocal(d), hora: horaLocal(d), category: 'personal', priority: 'normal',
    repeatRule: 'none', repeatCustom: { every: 2, unit: 'day' }, alertOffsets: [0], important: false,
  };
}

export function borradorDesde(r = {}) {
  return {
    id: r.id || '', title: r.title || '', note: r.note || '', fecha: r.fecha || '', hora: r.hora || '',
    category: CAT_IDS.has(r.category) ? r.category : 'otro', priority: PRI_IDS.has(r.priority) ? r.priority : 'normal',
    repeatRule: REP_IDS.has(r.repeatRule) ? r.repeatRule : 'none', repeatCustom: { every: r.repeatCustom?.every || 2, unit: r.repeatCustom?.unit || 'day' },
    alertOffsets: normalizarAvisos(r.alertOffsets), important: r.important === true,
  };
}

export function validarBorrador(b = {}, { ahora = new Date(), esNuevo = true } = {}) {
  const errores = {};
  const titulo = String(b.title || '').trim();
  if (!titulo) errores.title = 'Escriba un título.';
  else if (titulo.length > LIMITES.titulo) errores.title = `Máximo ${LIMITES.titulo} caracteres.`;
  if (String(b.note || '').length > LIMITES.nota) errores.note = `Máximo ${LIMITES.nota} caracteres.`;
  const cuando = aFecha(b.fecha, b.hora);
  if (!b.fecha || !aFecha(b.fecha, '12:00')) errores.fecha = 'Elija la fecha.';
  if (!b.hora || !/^\d{1,2}:\d{2}$/.test(String(b.hora))) errores.hora = 'Elija la hora.';
  else if (!cuando && !errores.fecha) errores.hora = 'Hora no válida.';
  if (cuando && esNuevo && b.repeatRule === 'none' && cuando.getTime() < ahora.getTime() - 60 * 1000) errores.hora = 'Esa fecha y hora ya pasaron.';
  if (!CAT_IDS.has(b.category)) errores.category = 'Elija una categoría.';
  if (!PRI_IDS.has(b.priority)) errores.priority = 'Elija la prioridad.';
  if (b.repeatRule === 'custom') {
    const n = Number(b.repeatCustom?.every);
    if (!Number.isInteger(n) || n < 1 || n > 365) errores.repeat = 'Repetir cada 1 a 365.';
  }
  return { ok: Object.keys(errores).length === 0, errores };
}

export function nuevoId() {
  const u = globalThis.crypto?.randomUUID?.();
  return u ? `rp_${u.replace(/-/g, '')}` : `rp_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;
}

// Crea o actualiza el registro a partir del borrador ya validado.
export function aplicarBorrador(b, previo = null, { ownerUserId = '', ahora = new Date() } = {}) {
  const iso = ahora.toISOString();
  const cuando = aFecha(b.fecha, b.hora);
  const cambiaHorario = !previo || previo.fecha !== b.fecha || previo.hora !== b.hora || previo.repeatRule !== b.repeatRule;
  const repeatRule = REP_IDS.has(b.repeatRule) ? b.repeatRule : 'none';
  const r = {
    ...(previo || {}),
    id: previo?.id || b.id || nuevoId(),
    ownerUserId: previo?.ownerUserId || ownerUserId,
    title: String(b.title || '').trim().slice(0, LIMITES.titulo),
    note: String(b.note || '').slice(0, LIMITES.nota),
    category: CAT_IDS.has(b.category) ? b.category : 'otro',
    priority: PRI_IDS.has(b.priority) ? b.priority : 'normal',
    important: b.important === true || b.priority === 'important' || b.priority === 'urgent',
    fecha: b.fecha, hora: b.hora,
    anchorDay: cambiaHorario ? Number(String(b.fecha).slice(8, 10)) || 0 : (previo?.anchorDay || Number(String(b.fecha).slice(8, 10)) || 0),
    scheduledAt: cuando ? cuando.toISOString() : '',
    timezone: zonaHoraria(),
    repeatRule,
    repeatCustom: repeatRule === 'custom' ? { every: Math.max(1, Math.round(Number(b.repeatCustom?.every) || 1)), unit: UNI_IDS.has(b.repeatCustom?.unit) ? b.repeatCustom.unit : 'day' } : null,
    alertOffsets: normalizarAvisos(b.alertOffsets),
    createdAt: previo?.createdAt || iso,
    updatedAt: iso,
    deleted: false,
  };
  // Editar fecha/hora/repetición cancela la posposición: la alarma vieja se reemplaza por la nueva.
  if (cambiaHorario || !previo) { r.status = 'scheduled'; r.snoozedUntil = null; }
  else if (!['scheduled', 'snoozed'].includes(r.status)) r.status = 'scheduled';
  r.completedAt = r.status === 'completed' ? r.completedAt : null;
  r.nextOccurrenceAt = r.repeatRule !== 'none' ? (aFecha(siguienteFecha(r), r.hora)?.toISOString() || null) : null;
  return r;
}

// Posponer mueve SOLO la ocurrencia actual; la programación original queda igual.
export function calcularPosponer(opcion, r = {}, ahora = new Date(), elegido = null) {
  const t = new Date(ahora);
  t.setSeconds(0, 0);
  if (opcion === '10m') return new Date(t.getTime() + 10 * 60000);
  if (opcion === '30m') return new Date(t.getTime() + 30 * 60000);
  if (opcion === '1h') return new Date(t.getTime() + 60 * 60000);
  if (opcion === 'manana') {
    const [hh, mm] = String(r.hora || '09:00').split(':').map(Number);
    const d = new Date(ahora); d.setDate(d.getDate() + 1); d.setHours(Number.isFinite(hh) ? hh : 9, Number.isFinite(mm) ? mm : 0, 0, 0);
    return d;
  }
  if (opcion === 'elegir' && elegido) {
    const d = elegido instanceof Date ? elegido : new Date(elegido);
    if (!Number.isNaN(d.getTime()) && d.getTime() > ahora.getTime()) return d;
  }
  return null;
}

export function posponer(r, hasta, ahora = new Date()) {
  return { ...r, status: 'snoozed', snoozedUntil: hasta.toISOString(), updatedAt: ahora.toISOString() };
}

// Marcar como hecho. Si repite: se guarda una copia en Completados (historial) y el original
// pasa a la siguiente ocurrencia. Devuelve { actualizado, historial|null }.
export function marcarHecho(r, ahora = new Date()) {
  const iso = ahora.toISOString();
  if (!reglaRepeticion(r)) {
    return { actualizado: { ...r, status: 'completed', completedAt: iso, snoozedUntil: null, updatedAt: iso }, historial: null };
  }
  const historial = {
    ...r, id: nuevoId(), sourceId: r.id, repeatRule: 'none', repeatCustom: null, status: 'completed', completedAt: iso,
    snoozedUntil: null, nextOccurrenceAt: null, createdAt: iso, updatedAt: iso,
  };
  // Siguiente ocurrencia que todavía no haya pasado (si estuvo días sin marcarse, no deja una fila de vencidos).
  let fecha = siguienteFecha(r, r.fecha);
  let guard = 0;
  while (fecha && (aFecha(fecha, r.hora)?.getTime() ?? 0) <= ahora.getTime() && guard++ < 1000) fecha = siguienteFecha(r, fecha);
  const cuando = aFecha(fecha, r.hora);
  const actualizado = {
    ...r, fecha, scheduledAt: cuando ? cuando.toISOString() : '', status: 'scheduled', snoozedUntil: null, completedAt: null, updatedAt: iso,
  };
  actualizado.nextOccurrenceAt = aFecha(siguienteFecha(actualizado), r.hora)?.toISOString() || null;
  return { actualizado, historial };
}

export function restaurar(r, ahora = new Date()) {
  return { ...r, status: 'scheduled', completedAt: null, snoozedUntil: null, deleted: false, updatedAt: ahora.toISOString() };
}
export function eliminar(r, ahora = new Date()) {
  return { ...r, deleted: true, status: 'cancelled', updatedAt: ahora.toISOString() };
}

// ——— Notificaciones del sistema (plan puro; la capa nativa solo lo ejecuta) ———
export const NOTI_ID_MIN = 900000000;
const NOTI_ID_RANGO = 1000000000;
export function idNotificacion(clave = '') {
  let h = 2166136261;
  for (let i = 0; i < clave.length; i++) { h ^= clave.charCodeAt(i); h = Math.imul(h, 16777619); }
  return NOTI_ID_MIN + ((h >>> 0) % NOTI_ID_RANGO);
}
export const esIdRecordatorio = id => Number(id) >= NOTI_ID_MIN && Number(id) < NOTI_ID_MIN + NOTI_ID_RANGO;

export const CANAL = 'sublichat-recordatorios';
export const CANAL_URGENTE = 'sublichat-recordatorios-urgentes';
export const TIPO_ACCIONES = 'SUBLICHAT_RECORDATORIO';
const OCURRENCIAS_EXTRA = 3; // repetitivos: se dejan programadas las siguientes aunque no se marque "Hecho"
const MAX_NOTIFICACIONES = 400;

function ocurrenciasPlan(r, ahora) {
  const out = [];
  const primera = momentoVencimiento(r);
  if (!primera) return out;
  out.push({ clave: r.status === 'snoozed' ? `z:${r.snoozedUntil}` : `o:${r.fecha}`, t: primera, pospuesto: r.status === 'snoozed', offsets: r.status === 'snoozed' ? [0] : normalizarAvisos(r.alertOffsets) });
  if (reglaRepeticion(r)) {
    let fecha = r.fecha;
    for (let i = 0; i < OCURRENCIAS_EXTRA + 400 && out.length <= OCURRENCIAS_EXTRA; i++) {
      fecha = siguienteFecha(r, fecha);
      const t = aFecha(fecha, r.hora);
      if (!t) break;
      if (t.getTime() <= ahora.getTime()) continue;
      out.push({ clave: `o:${fecha}`, t, pospuesto: false, offsets: normalizarAvisos(r.alertOffsets) });
    }
  }
  return out;
}

// Ids posibles de la ocurrencia actual (para quitar de la barra lo ya mostrado al marcar Hecho/Posponer).
export function idsOcurrenciaActual(r = {}) {
  const claves = [`o:${r.fecha}`];
  if (r.snoozedUntil) claves.push(`z:${r.snoozedUntil}`);
  const ids = [];
  for (const c of claves) for (const [off] of AVISOS) ids.push(idNotificacion(`${r.id}|${c}|${off}`));
  return ids;
}

export function tituloNotificacion(r) {
  if (r.priority === 'urgent') return '🚨 Recordatorio urgente';
  if (esImportante(r)) return '🔔 Recordatorio importante';
  return '🔔 Recordatorio';
}

export function planNotificaciones(items = [], { ahora = new Date(), owner = '' } = {}) {
  const plan = [];
  for (const r of (Array.isArray(items) ? items : []).filter(esActivo)) {
    for (const oc of ocurrenciasPlan(r, ahora)) {
      for (const off of oc.offsets) {
        const at = new Date(oc.t.getTime() - off * 60000);
        if (at.getTime() <= ahora.getTime()) continue;
        const antes = off ? ` · ${(AVISOS.find(a => a[0] === off) || [0, `${off} min antes`])[1].replace(' antes', '')} antes` : '';
        const cuerpo = `${r.title}\n${etiquetaCategoria(r.category)} · ${diaBonito(oc.t, at)} · ${horaBonita(oc.t)}${antes}`;
        plan.push({
          id: idNotificacion(`${r.id}|${oc.clave}|${off}`),
          title: tituloNotificacion(r),
          body: cuerpo,
          largeBody: r.note ? `${cuerpo}\n\n${r.note}` : cuerpo,
          summaryText: etiquetaPrioridad(r.priority),
          schedule: { at, allowWhileIdle: true },
          channelId: r.priority === 'urgent' ? CANAL_URGENTE : CANAL,
          actionTypeId: TIPO_ACCIONES,
          largeIcon: `rp_cat_${CAT_IDS.has(r.category) ? r.category : 'otro'}`, // android-res/drawable-nodpi
          group: 'sublichat-recordatorios',
          autoCancel: true,
          extra: { modulo: 'recordatorios-personales', recordatorioId: r.id, ocurrencia: oc.clave, owner },
        });
      }
    }
  }
  plan.sort((a, b) => a.schedule.at - b.schedule.at);
  return plan.slice(0, MAX_NOTIFICACIONES);
}

// ——— Sincronización (último cambio gana, por updatedAt) ———
export function fusionar(locales = [], remotos = []) {
  const m = new Map((Array.isArray(locales) ? locales : []).map(r => [r.id, r]));
  for (const r of Array.isArray(remotos) ? remotos : []) {
    if (!r?.id) continue;
    const a = m.get(r.id);
    if (!a || String(r.updatedAt || '') > String(a.updatedAt || '')) m.set(r.id, r);
  }
  return [...m.values()];
}

// Si el teléfono cambió de zona horaria, se recalcula scheduledAt con la misma hora de pared.
export function recalcularZona(items = []) {
  return (Array.isArray(items) ? items : []).map(r => {
    const t = aFecha(r.fecha, r.hora);
    if (!t) return r;
    const iso = t.toISOString();
    return iso === r.scheduledAt ? r : { ...r, scheduledAt: iso, timezone: zonaHoraria() };
  });
}
