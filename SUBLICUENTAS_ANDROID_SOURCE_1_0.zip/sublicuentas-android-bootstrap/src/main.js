import './styles.css';

const tabs = [
  ['inicio', 'Inicio', '⌂'],
  ['clientes', 'Clientes', '👥'],
  ['renovar', 'Renovar', '↻'],
  ['catalogo', 'Catálogo', '▦'],
  ['mas', 'Más', '•••']
];

const state = {
  active: 'inicio',
  theme: localStorage.getItem('sublicuentas-theme') || 'system'
};

function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
}

function dashboard() {
  return `
    <section class="hero">
      <div>
        <p class="eyebrow">SUBLICUENTAS 1.0</p>
        <h1>Centro de operaciones</h1>
        <p class="muted">Android · Debug interno</p>
      </div>
      <div class="bot">🤖</div>
    </section>
    <section class="metrics">
      <article><span>Vence hoy</span><strong>—</strong></article>
      <article><span>Próximo</span><strong>—</strong></article>
      <article><span>Vencidos</span><strong>—</strong></article>
      <article><span>Cobrado hoy</span><strong>—</strong></article>
      <article><span>Disponibles</span><strong>—</strong></article>
    </section>
    <section class="panel">
      <h2>Acciones rápidas</h2>
      <div class="quick">
        <button>Nuevo cliente</button>
        <button>Renovar</button>
        <button>Activar TV</button>
        <button>WhatsApp</button>
      </div>
    </section>
    <section class="panel">
      <h2>Estado</h2>
      <p><span class="dot"></span> Shell Android listo para conectar al Core.</p>
      <p class="muted">Este primer APK valida instalación, navegación y base Capacitor. Los datos reales se habilitan por módulos.</p>
    </section>`;
}

function placeholder(title, text) {
  return `<section class="panel page"><p class="eyebrow">SUBLICUENTAS</p><h1>${title}</h1><p class="muted">${text}</p></section>`;
}

function page() {
  if (state.active === 'inicio') return dashboard();
  if (state.active === 'clientes') return placeholder('Clientes', 'CRM móvil por clienteId → compraId → perfilId.');
  if (state.active === 'renovar') return placeholder('Renovar', 'Hoy · Próximo · Vencidos. La escritura autoritativa seguirá en Core.');
  if (state.active === 'catalogo') return placeholder('Catálogo', 'Consulta operativa del mismo Catálogo Relojes.');
  return `
    <section class="panel page">
      <p class="eyebrow">SUBLICUENTAS</p><h1>Más</h1>
      <div class="menu-list">
        <button>Inventario</button><button>Activar TV</button><button>Finanzas</button><button>Tickets</button><button>Sorteos</button><button>Perfil</button>
      </div>
      <label class="theme-row">Tema
        <select id="themeSelect">
          <option value="system">Sistema</option><option value="light">Claro</option><option value="dark">Oscuro</option>
        </select>
      </label>
      <p class="muted version">Versión 1.0 · build 1 · com.sublicuentas.app</p>
    </section>`;
}

function render() {
  applyTheme();
  document.querySelector('#app').innerHTML = `
    <main>${page()}</main>
    <nav class="bottom-nav">
      ${tabs.map(([id,label,icon]) => `<button data-tab="${id}" class="${state.active===id?'active':''}"><span>${icon}</span><small>${label}</small></button>`).join('')}
    </nav>`;
  document.querySelectorAll('[data-tab]').forEach(btn => btn.addEventListener('click', () => { state.active = btn.dataset.tab; render(); }));
  const sel = document.querySelector('#themeSelect');
  if (sel) {
    sel.value = state.theme;
    sel.addEventListener('change', () => { state.theme = sel.value; localStorage.setItem('sublicuentas-theme', state.theme); render(); });
  }
}

render();
