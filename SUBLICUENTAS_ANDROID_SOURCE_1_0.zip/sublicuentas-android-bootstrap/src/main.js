import './styles.css';
import {
  clearSession,
  loadMobileResource,
  getSession,
  loadCatalog,
  loadProfile,
  loadRaffles,
  loadTickets,
  loginUser,
  registerRenewalPayment,
  renewService,
} from './api.js';
import {
  dashboardSummary,
  coreCollectionsForRole,
  filterClients,
  formatDateShort,
  money,
  parseDateDMY,
  roleCapabilities,
  roleLabel,
  serviceRowsFromClients,
} from './data.js';

const svg = (body, size=22) => `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
function icon(name, size=22) {
  const icons = {
    home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-6h5v6"/>',
    users:'<circle cx="9" cy="8" r="3"/><path d="M3.5 19c.6-3.3 2.5-5 5.5-5s4.9 1.7 5.5 5"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.7c2.9-.6 5 .9 5.5 4.3"/>',
    renew:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
    catalog:'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
    more:'<circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none"/>',
    search:'<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
    refresh:'<path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/>',
    box:'<path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7"/><path d="M12 11v10"/>',
    finance:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8 9h8M8 13h3M8 17h8"/>',
    ticket:'<path d="M4 6h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4V6Z"/><path d="M12 8v8"/>',
    gift:'<rect x="4" y="10" width="16" height="10" rx="2"/><path d="M12 10v10M3 10h18v-3H3z"/><path d="M12 7c-1.5-4-6-4-6-1.5S9 7 12 7Zm0 0c1.5-4 6-4 6-1.5S15 7 12 7Z"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4.5 21c.8-4.4 3.3-6.5 7.5-6.5s6.7 2.1 7.5 6.5"/>',
    chevron:'<path d="m9 6 6 6-6 6"/>',
    back:'<path d="m15 6-6 6 6 6"/>',
    phone:'<path d="M6.5 3.5 10 7l-2 3c1.4 2.8 3.2 4.6 6 6l3-2 3.5 3.5-2.2 3c-.7 1-2 1.4-3.2 1C8.6 19.4 4.6 15.4 2.5 8.9c-.4-1.2 0-2.5 1-3.2l3-2.2Z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>',
    logout:'<path d="M10 4H5v16h5"/><path d="m14 8 4 4-4 4M18 12H9"/>',
    cloud:'<path d="M7 18h10a4 4 0 0 0 .6-8 6 6 0 0 0-11.5 1A3.5 3.5 0 0 0 7 18Z"/>',
    alert:'<path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17h.01"/>',
  };
  return svg(icons[name] || icons.more, size);
}

const BUILD_NUMBER = String(import.meta.env.VITE_BUILD_NUMBER || '1');

const state = {
  active:'inicio',
  subview:null,
  theme:localStorage.getItem('sublicuentas-theme') || 'system',
  session:getSession(),
  loading:false,
  sync:'idle',
  clients:[],
  inventory:[],
  finances:[],
  catalog:null,
  tickets:null,
  raffles:null,
  controlInventory:null,
  profile:null,
  whatsappChooser:false,
  search:'',
  renewFilter:'hoy',
  selectedClientId:'',
  renewKey:'',
  toast:'',
  errors:{},
};

function esc(value='') {
  return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function applyTheme() { document.documentElement.dataset.theme = state.theme; }
function cap() { return roleCapabilities(state.session?.role || '', state.session?.usuario || ''); }
function todayISO() { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function todayDMY() { const [y,m,d]=todayISO().split('-'); return `${d}/${m}/${y}`; }
function rowKey(row) { return `${row.clienteId}|${row.compraId || ''}|${row.servicioIndex}`; }
function allRows() { return serviceRowsFromClients(state.clients); }
function clientName(client) { return client?.nombrePerfil || client?.nombre || 'Cliente'; }
function avatarMarkup() {
  const avatar = state.profile?.avatar || '';
  if (avatar) return `<img src="${esc(avatar)}" class="avatar-img" alt="Perfil">`;
  return `<div class="avatar-fallback">${icon('user',22)}</div>`;
}

function showToast(message) {
  state.toast = message;
  render();
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>{ state.toast=''; render(); }, 3200);
}

async function loadCoreData({force=false}={}) {
  if (!state.session || state.loading) return;
  state.loading = true; state.sync='syncing'; render();
  const collections = new Set(coreCollectionsForRole(state.session.role || '', state.session.usuario || ''));
  const tasks = [
    ['clients', () => loadMobileResource('clientes', {pageSize:250,maxPages:24})],
    ...(collections.has('inventario') ? [['inventory', () => loadMobileResource('inventario', {pageSize:250,maxPages:16})]] : []),
    ...(collections.has('finanzas_movimientos') ? [['finances', () => loadMobileResource('finanzas_movimientos', {pageSize:250,maxPages:16})]] : []),
    ['profile', () => loadProfile(state.session.usuario).then(x=>x.perfil || null)],
  ];
  if (!collections.has('inventario')) state.inventory = [];
  if (!collections.has('finanzas_movimientos')) state.finances = [];
  const results = await Promise.allSettled(tasks.map(([,fn])=>fn()));
  results.forEach((result,index)=>{
    const key = tasks[index][0];
    if (result.status === 'fulfilled') { state[key] = result.value; delete state.errors[key]; }
    else state.errors[key] = result.reason?.message || 'No disponible';
  });
  state.loading=false;
  state.sync = Object.keys(state.errors).length ? 'partial' : 'online';
  render();
}

async function ensureCatalog() {
  if (state.catalog || !cap().catalogo) return;
  try { const data=await loadCatalog(); state.catalog=data.catalog || {}; delete state.errors.catalog; }
  catch(e){ state.errors.catalog=e.message; }
  render();
}

async function ensureTickets() {
  if (state.tickets) return;
  try { const data=await loadTickets(100); state.tickets=data.items || []; delete state.errors.tickets; }
  catch(e){ state.errors.tickets=e.message; }
  render();
}

async function ensureRaffles() {
  if (state.raffles || !cap().sorteos) return;
  try { state.raffles=await loadRaffles(); delete state.errors.raffles; }
  catch(e){ state.errors.raffles=e.message; }
  render();
}

async function ensureControlMaster() {
  if (state.controlInventory || !cap().controlMaestro) return;
  try { state.controlInventory=await loadMobileResource('inventario', {pageSize:250,maxPages:16}); delete state.errors.controlMaster; }
  catch(e){ state.errors.controlMaster=e.message; }
  render();
}

function loginView() {
  return `<main class="login-shell">
    <section class="login-card">
      <div class="brand-mark"><span>Subli</span><b>cuentas</b></div>
      <div class="login-orb">${icon('cloud',30)}</div>
      <p class="eyebrow">ACCESO INTERNO</p>
      <h1>Centro de operaciones</h1>
      <p class="muted login-copy">Entre con el mismo usuario que utiliza en Sublichat.</p>
      <form id="loginForm" class="login-form">
        <label>Usuario<input id="loginUser" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="sublicuentas"></label>
        <label>Clave<input id="loginPassword" type="password" autocomplete="current-password" placeholder="••••••••"></label>
        <button class="primary" type="submit" ${state.loading?'disabled':''}>${state.loading?'Ingresando…':'Iniciar sesión'}</button>
      </form>
      ${state.errors.login?`<div class="error-box">${icon('alert',18)}<span>${esc(state.errors.login)}</span></div>`:''}
      <p class="version muted">Sublicuentas 1.0 · Android</p>
    </section>
  </main>`;
}

function syncPill() {
  const cfg = state.sync==='online' ? ['sync-ok','Sincronizado'] : state.sync==='syncing' ? ['syncing','Sincronizando'] : state.sync==='partial' ? ['sync-warn','Parcial'] : ['','Listo'];
  return `<span class="sync-pill ${cfg[0]}"><i></i>${cfg[1]}</span>`;
}

function dashboardView() {
  const rows = allRows();
  const summary = dashboardSummary(rows, new Date());
  const available = state.inventory.reduce((sum,item)=>sum + Math.max(0,Number(item?.disponibles || 0)),0);
  const income = state.finances.filter(m=>String(m?.tipo||'').toLowerCase()==='ingreso' && (String(m?.fechaPago||'')===todayISO() || String(m?.fecha||'')===todayDMY())).reduce((sum,m)=>sum+Number(m?.monto||0),0);
  const firstName = String(state.profile?.nombre || state.session?.usuario || 'Sublicuentas').split(/\s+/)[0];
  return `<section class="topbar">
      <div><p class="eyebrow">SUBLICUENTAS</p><h1>Hola, ${esc(firstName)}</h1><div class="top-meta">${syncPill()}<span>${esc(roleLabel(state.session?.role, state.session?.usuario))}</span></div></div>
      <button class="avatar-btn" data-open="perfil">${avatarMarkup()}</button>
    </section>
    <section class="metrics">
      <button class="metric danger-soft" data-renew-filter="hoy"><span>Vence hoy</span><strong>${summary.hoy}</strong></button>
      <button class="metric info-soft" data-renew-filter="proximo"><span>Próximo <small>${summary.proximo.label}</small></span><strong>${summary.proximo.count}</strong></button>
      <button class="metric warn-soft" data-renew-filter="vencidos"><span>Vencidos</span><strong>${summary.vencidos}</strong></button>
      ${cap().finanzas ? `<article class="metric"><span>Cobrado hoy</span><strong class="money-strong">${money(income)}</strong></article>` : ''}
      ${cap().inventario ? `<button class="metric wide" data-open="inventario"><span>Disponibles</span><strong>${available}</strong></button>` : ''}
    </section>
    <section class="panel compact-panel">
      <div class="section-head"><div><p class="eyebrow">OPERACIÓN</p><h2>Acciones rápidas</h2></div><button class="icon-btn" id="refreshData" aria-label="Actualizar datos">${icon('refresh')}</button></div>
      <div class="quick-grid">
        <button data-tab-jump="clientes">${icon('users')}<span>Clientes</span></button>
        <button data-tab-jump="renovar">${icon('renew')}<span>Renovar</span></button>
        <button id="openWhatsApp" class="quick-wide">${icon('phone')}<span>WhatsApp</span></button>
      </div>
    </section>
    ${state.errors.clients?`<div class="error-box">${icon('alert',18)}<span>Clientes: ${esc(state.errors.clients)}</span></div>`:''}`;
}

function clientsView() {
  if (state.selectedClientId) return clientDetailView();
  const filtered = filterClients(state.clients, state.search).slice(0,120);
  return `<section class="page-head"><div><p class="eyebrow">CRM</p><h1>Clientes</h1><p class="muted">${state.clients.length} fichas sincronizadas</p></div><button class="icon-btn" id="refreshData">${icon('refresh')}</button></section>
    <div class="search-box">${icon('search',20)}<input id="clientSearch" value="${esc(state.search)}" placeholder="Buscar cliente, teléfono o plataforma"></div>
    <section class="list-stack client-list">
      ${filtered.length ? filtered.map(client=>{
        const services=Array.isArray(client.servicios)?client.servicios:[];
        return `<button class="client-row" data-client-id="${esc(client.id)}"><div class="client-avatar">${esc(clientName(client).slice(0,1).toUpperCase())}</div><div class="grow"><strong>${esc(clientName(client))}</strong><span>${esc(client.telefono || 'Sin teléfono')} · ${services.length} servicio${services.length===1?'':'s'}</span><small>${services.slice(0,3).map(s=>esc(s.plataforma||'Servicio')).join(' · ')}</small></div>${icon('chevron',19)}</button>`;
      }).join('') : `<div class="empty-state">${icon('search',28)}<strong>Sin resultados</strong><span>Pruebe con otro nombre, teléfono o plataforma.</span></div>`}
    </section>`;
}

function clientDetailView() {
  const client = state.clients.find(c=>c.id===state.selectedClientId);
  if (!client) { state.selectedClientId=''; return clientsView(); }
  const rows = allRows().filter(r=>r.clienteId===client.id);
  return `<section class="page-head detail-head"><button class="back-btn" id="backClients">${icon('back')}</button><div class="grow"><p class="eyebrow">FICHA</p><h1>${esc(clientName(client))}</h1><p class="muted">${esc(client.telefono || 'Sin teléfono')}</p></div></section>
    <section class="panel identity-card"><div>${icon('user',22)}</div><div><span>ID cliente</span><strong>${esc(client.id)}</strong></div></section>
    <section class="list-stack service-list">
      ${rows.length ? rows.map(row=>`<article class="service-card"><div class="service-top"><div><strong>${esc(row.plataforma)}</strong><span>${esc(row.correo || 'Sin correo')}</span></div><span class="date-chip">${esc(row.fechaRenovacion || 'Sin fecha')}</span></div><div class="service-bottom"><span>${row.precio?money(row.precio):'Sin precio'}${row.compraId?` · ${esc(row.compraId.slice(0,10))}`:''}</span><button class="mini-primary" data-renew-key="${esc(rowKey(row))}">${icon('renew',16)} Renovar</button></div></article>`).join('') : `<div class="empty-state"><strong>Sin servicios</strong><span>Esta ficha no tiene servicios activos.</span></div>`}
    </section>`;
}

function renewalRows() {
  const rows=allRows();
  const base=new Date(); base.setHours(12,0,0,0);
  const parsed=rows.map(r=>({r,d:parseDateDMY(r.fechaRenovacion)})).filter(x=>x.d);
  if (state.renewFilter==='hoy') return parsed.filter(x=>Math.round((x.d-base)/86400000)===0).map(x=>x.r);
  if (state.renewFilter==='vencidos') return parsed.filter(x=>x.d<base).sort((a,b)=>a.d-b.d).map(x=>x.r);
  const future=parsed.filter(x=>x.d>base).sort((a,b)=>a.d-b.d);
  if (!future.length) return [];
  const key=future[0].d.toDateString();
  return future.filter(x=>x.d.toDateString()===key).map(x=>x.r);
}

function renewView() {
  const rows=renewalRows();
  return `<section class="page-head"><div><p class="eyebrow">RENOVACIONES</p><h1>Renovar</h1><p class="muted">Actualizado con las fichas reales</p></div><button class="icon-btn" id="refreshData">${icon('refresh')}</button></section>
    <div class="segmented"><button data-filter="hoy" class="${state.renewFilter==='hoy'?'active':''}">Hoy</button><button data-filter="proximo" class="${state.renewFilter==='proximo'?'active':''}">Próximo</button><button data-filter="vencidos" class="${state.renewFilter==='vencidos'?'active':''}">Vencidos</button></div>
    <section class="list-stack renew-list">
      ${rows.length?rows.slice(0,120).map(row=>`<button class="renew-row" data-renew-key="${esc(rowKey(row))}"><div class="renew-date">${formatDateShort(row.fechaRenovacion)}</div><div class="grow"><strong>${esc(row.nombre)}</strong><span>${esc(row.plataforma)} · ${row.precio?money(row.precio):'Sin precio'}</span></div>${icon('chevron',18)}</button>`).join(''):`<div class="empty-state">${icon('calendar',30)}<strong>Todo al día</strong><span>No hay registros en esta sección.</span></div>`}
    </section>`;
}

function catalogView() {
  if (!cap().catalogo) return `<div class="empty-state page-empty">${icon('catalog',34)}<strong>Catálogo no disponible</strong><span>Su usuario conserva los mismos permisos de Sublichat.</span></div>`;
  if (!state.catalog && !state.errors.catalog) return `<div class="loading-card"><span class="spinner"></span><strong>Cargando catálogo…</strong></div>`;
  if (state.errors.catalog) return `<div class="error-box">${icon('alert',18)}<span>${esc(state.errors.catalog)}</span></div>`;
  const products=(state.catalog?.products || []).filter(p=>p.active!==false);
  return `<section class="page-head"><div><p class="eyebrow">CATÁLOGO RELOJES</p><h1>Catálogo</h1><p class="muted">${products.length} productos activos</p></div></section>
    <section class="catalog-grid">${products.slice(0,100).map(product=>{
      const plans=Array.isArray(product.plans)?product.plans.filter(p=>p.active!==false):[];
      const price=plans.map(p=>Number(p.price)).filter(Number.isFinite).sort((a,b)=>a-b)[0];
      return `<article class="product-card">${product.imageUrl?`<img src="${esc(product.imageUrl)}" alt="">`:`<div class="product-icon">${icon('catalog',24)}</div>`}<div><strong>${esc(product.name||'Producto')}</strong><span>${esc(product.categoryId||'')}</span>${Number.isFinite(price)?`<b>${money(price)}</b>`:''}</div></article>`;
    }).join('')}</section>`;
}

function inventoryView() {
  const rows=state.inventory.slice().sort((a,b)=>String(a.plataforma||'').localeCompare(String(b.plataforma||'')));
  return subPage('Inventario', 'Disponibilidad de cuentas', `${rows.length?`<section class="list-stack">${rows.slice(0,160).map(item=>`<article class="inventory-row"><div><strong>${esc(item.plataforma||'Cuenta')}</strong><span>${esc(item.correo||'')}</span></div><div class="stock"><b>${Number(item.disponibles||0)}</b><small>libres</small></div></article>`).join('')}</section>`:`<div class="empty-state"><strong>Sin cuentas</strong><span>No se encontraron cuentas de inventario.</span></div>`}`);
}

function ticketsView() {
  if (!state.tickets && !state.errors.tickets) return subPage('Tickets','Bandeja interna','<div class="loading-card"><span class="spinner"></span><strong>Cargando tickets…</strong></div>');
  const items=state.tickets || [];
  return subPage('Tickets','Bandeja interna', state.errors.tickets?`<div class="error-box">${icon('alert',18)}<span>${esc(state.errors.tickets)}</span></div>`:`<section class="list-stack">${items.slice(0,100).map(t=>`<article class="ticket-row"><div class="ticket-num">#${esc(t.numero||'—')}</div><div class="grow"><strong>${esc(t.titulo||'Ticket')}</strong><span>${esc(t.estado||'abierto')} · ${esc(t.creadoPor||'')}</span></div></article>`).join('')||'<div class="empty-state"><strong>Sin tickets</strong><span>No hay tickets en la bandeja.</span></div>'}</section>`);
}

function controlMasterView() {
  if (!state.controlInventory && !state.errors.controlMaster) return subPage('Control Maestro','Cuentas y asignaciones','<div class="loading-card"><span class="spinner"></span><strong>Cargando cuentas…</strong></div>');
  if (state.errors.controlMaster) return subPage('Control Maestro','Cuentas y asignaciones',`<div class="error-box">${icon('alert',18)}<span>${esc(state.errors.controlMaster)}</span></div>`);
  const rows=(state.controlInventory || []).slice().sort((a,b)=>String(a.plataforma||'').localeCompare(String(b.plataforma||'')) || String(a.correo||'').localeCompare(String(b.correo||'')));
  const total=rows.length;
  const libres=rows.reduce((sum,item)=>sum+Math.max(0,Number(item.disponibles||0)),0);
  const ocupados=rows.reduce((sum,item)=>sum+Math.max(0,Number(item.ocupados ?? (Array.isArray(item.clientes)?item.clientes.length:0))),0);
  const content=`<section class="finance-grid control-summary"><article><span>Cuentas</span><strong>${total}</strong></article><article><span>Libres</span><strong>${libres}</strong></article><article class="wide"><span>Asignaciones</span><strong>${ocupados}</strong></article></section>
    <section class="list-stack control-list">${rows.slice(0,180).map(item=>{
      const clients=Array.isArray(item.clientes)?item.clientes:[];
      const used=Number(item.ocupados ?? clients.length) || 0;
      const capacity=Number(item.capacidad || (used + Number(item.disponibles||0))) || 0;
      return `<article class="inventory-row control-row"><div class="grow"><strong>${esc(item.plataforma||'Cuenta')}</strong><span>${esc(item.correo||'Sin correo')}</span><small>${used}/${capacity || '—'} ocupados · ${clients.length} asignados</small></div><div class="stock"><b>${Math.max(0,Number(item.disponibles||0))}</b><small>libres</small></div></article>`;
    }).join('') || '<div class="empty-state"><strong>Sin cuentas</strong><span>No hay cuentas disponibles en Control Maestro.</span></div>'}</section>`;
  return subPage('Control Maestro','Cuentas y asignaciones',content);
}

function rafflesView() {
  if (!state.raffles && !state.errors.raffles) return subPage('Sorteos','Premios y boletos','<div class="loading-card"><span class="spinner"></span><strong>Cargando sorteos…</strong></div>');
  if (state.errors.raffles) return subPage('Sorteos','Premios y boletos',`<div class="error-box">${icon('alert',18)}<span>${esc(state.errors.raffles)}</span></div>`);
  const draws=Array.isArray(state.raffles?.sorteos)?state.raffles.sorteos:[];
  const prizes=Array.isArray(state.raffles?.premios)?state.raffles.premios:[];
  const active=draws.filter(d=>String(d.estado||'').toLowerCase()==='activo').length;
  const tickets=draws.reduce((sum,d)=>sum+Math.max(0,Number(d.totalBoletos||0)),0);
  const content=`<section class="finance-grid raffle-summary"><article><span>Activos</span><strong>${active}</strong></article><article><span>Premios</span><strong>${prizes.length}</strong></article><article class="wide"><span>Boletos visibles</span><strong>${tickets}</strong></article></section>
    <section class="list-stack raffle-list">${draws.slice(0,100).map(draw=>{
      const winner=draw?.ganador?.clienteNombre || draw?.ganador?.nombre || '';
      const end=draw.fechaFin ? new Date(draw.fechaFin) : null;
      const endLabel=end && !Number.isNaN(end.getTime()) ? end.toLocaleDateString('es-HN',{day:'2-digit',month:'2-digit',year:'numeric'}) : 'Sin fecha';
      return `<article class="service-card raffle-card"><div class="service-top"><div><strong>${esc(draw.titulo||'Sorteo')}</strong><span>${esc(draw.categoria||'general')} · termina ${esc(endLabel)}</span></div><span class="date-chip raffle-state">${esc(draw.estado||'borrador')}</span></div><div class="service-bottom"><span>${Number(draw.totalBoletos||0)} boletos</span><strong>${winner?`Ganador: ${esc(winner)}`:'Sin ganador'}</strong></div></article>`;
    }).join('') || '<div class="empty-state"><strong>Sin sorteos</strong><span>No hay campañas visibles para este usuario.</span></div>'}</section>`;
  return subPage('Sorteos','Premios y boletos',content);
}

function profileView() {
  const p=state.profile || {};
  return subPage('Perfil','Cuenta y preferencias', `<section class="profile-card"><div class="profile-avatar-large">${avatarMarkup()}</div><h2>${esc(p.nombre || state.session?.usuario || 'Sublicuentas')}</h2><p>${esc(roleLabel(state.session?.role, state.session?.usuario))}</p>${p.telefono?`<span>${esc(p.telefono)}</span>`:''}</section>
    <section class="panel settings-panel"><label class="theme-row"><span><strong>Tema</strong><small>Claro, oscuro o sistema</small></span><select id="themeSelect"><option value="system">Sistema</option><option value="light">Claro</option><option value="dark">Oscuro</option></select></label><div class="setting-line"><span><strong>Versión</strong><small>Android interno</small></span><b>1.0 · build ${esc(BUILD_NUMBER)}</b></div><div class="setting-line"><span><strong>Paquete</strong><small>Identidad Android</small></span><b>com.sublicuentas.app</b></div></section>
    <button class="danger-button" id="logoutBtn">${icon('logout',20)} Cerrar sesión</button>`);
}

function financeView() {
  const today=state.finances.filter(m=>(String(m.fechaPago||'')===todayISO() || String(m.fecha||'')===todayDMY()));
  const ingresos=today.filter(m=>String(m.tipo||'').toLowerCase()==='ingreso').reduce((s,m)=>s+Number(m.monto||0),0);
  const egresos=today.filter(m=>String(m.tipo||'').toLowerCase()==='egreso').reduce((s,m)=>s+Number(m.monto||0),0);
  return subPage('Finanzas','Resumen de hoy',`<section class="finance-grid"><article><span>Ingresos</span><strong>${money(ingresos)}</strong></article><article><span>Egresos</span><strong>${money(egresos)}</strong></article><article class="wide"><span>Neto</span><strong>${money(ingresos-egresos)}</strong></article></section><p class="muted note">Los movimientos se leen de la misma colección financiera de Sublichat.</p>`);
}

function subPage(title, subtitle, content) {
  return `<section class="page-head detail-head"><button class="back-btn" id="backMore">${icon('back')}</button><div><p class="eyebrow">SUBLICUENTAS</p><h1>${esc(title)}</h1><p class="muted">${esc(subtitle)}</p></div></section>${content}`;
}

function moreView() {
  if (state.subview==='inventario') return inventoryView();
  if (state.subview==='control-maestro') return controlMasterView();
  if (state.subview==='finanzas') return financeView();
  if (state.subview==='tickets') return ticketsView();
  if (state.subview==='sorteos') return rafflesView();
  if (state.subview==='perfil') return profileView();
  const c=cap();
  const items=[
    c.inventario&&['inventario','Inventario','box'], c.controlMaestro&&['control-maestro','Control Maestro','box'], c.finanzas&&['finanzas','Finanzas','finance'], c.tickets&&['tickets','Tickets','ticket'], c.sorteos&&['sorteos','Sorteos','gift'], c.perfil&&['perfil','Perfil','user']
  ].filter(Boolean);
  return `<section class="page-head"><div><p class="eyebrow">MÓDULOS</p><h1>Más</h1><p class="muted">Herramientas según su permiso</p></div></section><section class="module-grid">${items.map(([id,label,ico])=>`<button data-open="${id}"><span class="module-icon">${icon(ico,24)}</span><strong>${label}</strong>${icon('chevron',18)}</button>`).join('')}</section><section class="panel settings-mini"><div><span>Sesión</span><strong>${esc(roleLabel(state.session?.role, state.session?.usuario))}</strong></div><div><span>Estado</span>${syncPill()}</div></section>`;
}

function currentView() {
  if (state.active==='inicio') return dashboardView();
  if (state.active==='clientes') return clientsView();
  if (state.active==='renovar') return renewView();
  if (state.active==='catalogo') return catalogView();
  return moreView();
}

function navTabs() {
  const c=cap();
  return [
    ['inicio','Inicio','home'],
    ['clientes','Clientes','users'],
    ['renovar','Renovar','renew'],
    ...(c.catalogo?[['catalogo','Catálogo','catalog']]:[]),
    ['mas','Más','more'],
  ];
}

function renewalSheet() {
  if (!state.renewKey) return '';
  const row=allRows().find(r=>rowKey(r)===state.renewKey);
  if (!row) return '';
  return `<div class="sheet-backdrop" id="closeSheet"><section class="bottom-sheet" role="dialog" aria-modal="true" onclick="event.stopPropagation()"><div class="sheet-handle"></div><p class="eyebrow">CONFIRMAR RENOVACIÓN</p><h2>${esc(row.nombre)}</h2><p class="sheet-service">${esc(row.plataforma)} · vence ${esc(row.fechaRenovacion||'—')}</p><div class="sheet-summary"><span>Monto registrado</span><strong>${row.precio?money(row.precio):'Sin monto'}</strong></div><p class="muted note">Se renovará +30 días usando la misma operación de Sublichat. La fecha debe quedar confirmada por Firebase antes de registrar el cobro.</p><div class="sheet-actions"><button class="secondary" id="cancelRenew">Cancelar</button><button class="primary" id="confirmRenew" ${state.loading?'disabled':''}>${state.loading?'Guardando…':'Renovar +30 días'}</button></div></section></div>`;
}

function whatsappSheet() {
  if (!state.whatsappChooser) return '';
  return `<div class="sheet-backdrop" id="closeWhatsAppChooser"><section class="bottom-sheet whatsapp-sheet" role="dialog" aria-modal="true" onclick="event.stopPropagation()"><div class="sheet-handle"></div><p class="eyebrow">ABRIR WHATSAPP</p><h2>¿Cuál desea usar?</h2><p class="muted note">Seleccione la aplicación que quiere abrir.</p><div class="whatsapp-choices"><button class="whatsapp-choice" data-whatsapp-package="com.whatsapp">${icon('phone')}<span><strong>WhatsApp normal</strong><small>Aplicación personal</small></span></button><button class="whatsapp-choice" data-whatsapp-package="com.whatsapp.w4b">${icon('phone')}<span><strong>WhatsApp Business</strong><small>Aplicación de negocio</small></span></button></div><button class="secondary whatsapp-cancel" id="cancelWhatsApp">Cancelar</button></section></div>`;
}

function launchWhatsApp(packageName) {
  const allowed = new Set(['com.whatsapp','com.whatsapp.w4b']);
  if (!allowed.has(packageName)) return;
  state.whatsappChooser=false;
  render();
  window.location.href=`intent://send#Intent;scheme=whatsapp;package=${packageName};end`;
}

function appShell() {
  const tabs=navTabs();
  return `<main class="app-main">${currentView()}</main><nav class="bottom-nav" style="--nav-count:${tabs.length}">${tabs.map(([id,label,ico])=>`<button data-tab="${id}" class="${state.active===id?'active':''}"><span>${icon(ico,22)}</span><small>${label}</small></button>`).join('')}</nav>${renewalSheet()}${whatsappSheet()}${state.toast?`<div class="toast">${esc(state.toast)}</div>`:''}`;
}

function render() {
  applyTheme();
  const root=document.querySelector('#app');
  root.innerHTML=state.session?appShell():loginView();
  bindEvents();
}

function bindEvents() {
  const login=document.querySelector('#loginForm');
  if (login) login.addEventListener('submit', async e=>{
    e.preventDefault();
    const usuario=document.querySelector('#loginUser').value.trim();
    const clave=document.querySelector('#loginPassword').value;
    if (!usuario || !clave) { state.errors.login='Escriba usuario y clave.'; render(); return; }
    state.loading=true; delete state.errors.login; render();
    try { state.session=await loginUser(usuario,clave); state.loading=false; state.active='inicio'; render(); await loadCoreData({force:true}); }
    catch(err){ state.loading=false; state.errors.login=err.message || 'No se pudo iniciar sesión.'; render(); }
    return;
  });

  document.querySelectorAll('[data-tab]').forEach(btn=>btn.addEventListener('click', async()=>{
    state.active=btn.dataset.tab; state.subview=null; state.selectedClientId='';
    render();
    if (state.active==='catalogo') await ensureCatalog();
  }));
  document.querySelectorAll('[data-tab-jump]').forEach(btn=>btn.addEventListener('click',()=>{state.active=btn.dataset.tabJump;state.subview=null;render();}));
  document.querySelectorAll('[data-open]').forEach(btn=>btn.addEventListener('click', async()=>{
    const id=btn.dataset.open;
    state.active='mas';state.subview=id;render();
    if(id==='tickets') await ensureTickets();
    if(id==='sorteos') await ensureRaffles();
    if(id==='control-maestro') await ensureControlMaster();
  }));
  document.querySelectorAll('[data-renew-filter]').forEach(btn=>btn.addEventListener('click',()=>{state.active='renovar';state.renewFilter=btn.dataset.renewFilter;render();}));
  document.querySelectorAll('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{state.renewFilter=btn.dataset.filter;render();}));
  document.querySelectorAll('[data-client-id]').forEach(btn=>btn.addEventListener('click',()=>{state.selectedClientId=btn.dataset.clientId;render();}));
  document.querySelectorAll('[data-renew-key]').forEach(btn=>btn.addEventListener('click',()=>{state.renewKey=btn.dataset.renewKey;render();}));

  document.querySelector('#clientSearch')?.addEventListener('input', e=>{state.search=e.target.value; const pos=e.target.selectionStart; render(); const input=document.querySelector('#clientSearch'); input?.focus(); input?.setSelectionRange(pos,pos);});
  document.querySelector('#backClients')?.addEventListener('click',()=>{state.selectedClientId='';render();});
  document.querySelector('#backMore')?.addEventListener('click',()=>{state.subview=null;render();});
  document.querySelector('#refreshData')?.addEventListener('click',()=>loadCoreData({force:true}));
  document.querySelector('#openWhatsApp')?.addEventListener('click',()=>{state.whatsappChooser=true;render();});
  document.querySelector('#closeWhatsAppChooser')?.addEventListener('click',()=>{state.whatsappChooser=false;render();});
  document.querySelector('#cancelWhatsApp')?.addEventListener('click',()=>{state.whatsappChooser=false;render();});
  document.querySelectorAll('[data-whatsapp-package]').forEach(btn=>btn.addEventListener('click',()=>launchWhatsApp(btn.dataset.whatsappPackage)));
  document.querySelector('#closeSheet')?.addEventListener('click',()=>{state.renewKey='';render();});
  document.querySelector('#cancelRenew')?.addEventListener('click',()=>{state.renewKey='';render();});
  document.querySelector('#confirmRenew')?.addEventListener('click',handleRenewal);
  document.querySelector('#logoutBtn')?.addEventListener('click',()=>{clearSession();state.session=null;state.clients=[];state.inventory=[];state.finances=[];state.profile=null;state.catalog=null;state.tickets=null;state.raffles=null;state.controlInventory=null;state.active='inicio';state.subview=null;render();});
  const sel=document.querySelector('#themeSelect');
  if(sel){sel.value=state.theme;sel.addEventListener('change',()=>{state.theme=sel.value;localStorage.setItem('sublicuentas-theme',state.theme);render();});}
}

async function handleRenewal() {
  const row=allRows().find(r=>rowKey(r)===state.renewKey);
  if (!row || state.loading) return;
  state.loading=true; render();
  try {
    const result=await renewService(row,30);
    if (!result?.ok || result?.verified !== true) throw new Error(result?.error || 'Firebase no confirmó la nueva fecha.');
    let financeWarning='';
    try { await registerRenewalPayment(row,row.precio); }
    catch(e){ financeWarning=' La fecha sí quedó renovada, pero revise el cobro en Finanzas.'; }
    const client=state.clients.find(c=>c.id===row.clienteId);
    const service=client?.servicios?.find(s=>String(s.compraId||'')===String(row.compraId||'')) || client?.servicios?.[row.servicioIndex];
    if(service && result.fechaNueva) service.fechaRenovacion=result.fechaNueva;
    state.loading=false;state.renewKey='';
    showToast(`Renovación confirmada: ${result.fechaNueva || '+30 días'}.${financeWarning}`);
    await loadCoreData({force:true});
  } catch(e) {
    state.loading=false;
    showToast(e.message || 'No se pudo renovar.');
  }
}

render();
if (state.session) loadCoreData({force:true});
