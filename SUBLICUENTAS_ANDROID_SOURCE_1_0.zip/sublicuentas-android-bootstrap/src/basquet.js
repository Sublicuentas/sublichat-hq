// Básquet PRO (R67) · según "Sublichat — Básquet PRO": selección de 3 personajes 3D (2 niños y 1 niña),
// partida de 5 tiros, el aro cambia de lugar en cada tiro, ángulo 25°–85° y fuerza 10–100, trayectoria
// parabólica simulada (no hay azar en el enceste), swish = bonus, 90 s de presión suave, reanudación local.
// El servidor (api/juegos.js) vuelve a simular cada tiro con la MISMA física y acredita una sola vez (gameId).

export const BASKET_CHARACTERS = [
  { id: 'boy_1', name: 'Jugador 1', gender: 'BOY', img: '/assets/basquet/jugador1.webp', jerseyColor: '#2563eb', tagline: 'Equilibrado y confiable.', description: 'Siempre firme en el tiro.', stats: { precision: 4, power: 3, speed: 3 } },
  { id: 'boy_2', name: 'Jugador 2', gender: 'BOY', img: '/assets/basquet/jugador2.webp', jerseyColor: '#ef4444', tagline: 'Rápido y ágil.', description: 'Ideal para encestar desde cualquier lugar.', stats: { precision: 4, power: 3, speed: 5 } },
  { id: 'girl_1', name: 'Jugadora 3', gender: 'GIRL', img: '/assets/basquet/jugadora3.webp', jerseyColor: '#a855f7', tagline: 'Precisa y muy estable.', description: 'La reina del tiro limpio.', stats: { precision: 5, power: 3, speed: 4 } },
];
export const BQ = Object.freeze({ SHOTS: 5, SECONDS: 90, ANGLE_MIN: 25, ANGLE_MAX: 85, POWER_MIN: 10, POWER_MAX: 100, HOOP_MIN: 0.60, HOOP_MAX: 0.88 });

/* ─────────── física (idéntica en el servidor) ─────────── */
// Cancha lógica 360×220 (SVG). La pelota sale de la mano del jugador y el aro está a la altura fija RIM_Y.
export const COURT = Object.freeze({ W: 360, H: 220, START_X: 0.12, START_Y: 0.78, RIM_Y: 0.38, G: 100 });
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export function heightAt(xw, angleDeg, power) { // altura (unidades mundo) a la distancia horizontal xw
  const t = angleDeg * Math.PI / 180, v = 60 + clamp(power, 0, 100) * 2, c = Math.cos(t);
  return xw * Math.tan(t) - (COURT.G * xw * xw) / (2 * v * v * c * c);
}
export function simulateShot(angleDeg, power, hoopX) {
  const a = clamp(Number(angleDeg) || 0, BQ.ANGLE_MIN, BQ.ANGLE_MAX), p = clamp(Number(power) || 0, BQ.POWER_MIN, BQ.POWER_MAX);
  const dx = (clamp(Number(hoopX) || 0.7, 0, 1) - COURT.START_X) * COURT.W, dy = (COURT.START_Y - COURT.RIM_Y) * COURT.H;
  const y = heightAt(dx, a, p), descending = heightAt(dx + 1, a, p) < y, diff = y - dy;
  const scored = Math.abs(diff) <= 9 && descending, swish = scored && Math.abs(diff) <= 3.5, hitRim = !swish && Math.abs(diff) <= 16;
  const path = []; // puntos en coordenadas SVG para animar el vuelo
  for (let xw = 0; xw <= dx + 70; xw += 5) { const hw = heightAt(xw, a, p); const sx = COURT.START_X * COURT.W + xw, sy = COURT.START_Y * COURT.H - hw; path.push([+sx.toFixed(1), +sy.toFixed(1)]); if (sy > COURT.H + 10 || (scored && xw >= dx)) break; }
  if (scored) { const hx = hoopX * COURT.W, ry = COURT.RIM_Y * COURT.H; path.push([+hx.toFixed(1), ry + 14], [+hx.toFixed(1), ry + 40]); }
  const feedback = scored ? (swish ? '¡Canasta limpia! +3 🏀✨' : '¡Enceste! +2 🏀') : hitRim ? '¡Casi! Pegó en el aro.' : !descending && diff > 0 ? 'Muy fuerte: iba subiendo al llegar.' : diff > 0 ? 'Se pasó por arriba: baje la fuerza.' : 'Le faltó: suba la fuerza o el ángulo.';
  return { scored, swish, hitRim, diff: +diff.toFixed(1), path, feedback };
}
export function generateNextHoopX(prev, rnd = Math.random) {
  let next = BQ.HOOP_MIN + rnd() * (BQ.HOOP_MAX - BQ.HOOP_MIN);
  if (prev !== undefined && Math.abs(next - prev) < 0.08) next = next < 0.74 ? next + 0.10 : next - 0.10;
  return +clamp(next, BQ.HOOP_MIN, BQ.HOOP_MAX).toFixed(3);
}
export function calculateMatchSP(g) {
  const swishes = g.shotHistory.filter(s => s.swish).length;
  return g.totalScore * 10 + (g.shotsMade === BQ.SHOTS ? 25 : 0) + (swishes >= 3 ? 15 : 0);
}

/* ─────────── estado ─────────── */
export function createBasketGame(userId = 'yo', selectedCharacterId = 'boy_2', now = Date.now()) {
  return { schemaVersion: 1, gameId: `bq-${now.toString(36)}-${Math.random().toString(36).slice(2, 7)}`, userId, selectedCharacterId, shotsTotal: BQ.SHOTS, shotsTaken: 0, shotsMade: 0,
    currentHoopX: generateNextHoopX(undefined), currentAngle: 66, currentPower: 50, shotHistory: [], totalScore: 0, status: 'PLAYING', paused: false, playedMs: 0, resumedAt: now, startedAt: now, finishedAt: null, lastShot: null, submitted: false };
}
export const bqPlayedMs = (g, now = Date.now()) => g.playedMs + (g.status === 'PLAYING' && !g.paused && g.resumedAt ? now - g.resumedAt : 0);
export const bqRemainingMs = (g, now = Date.now()) => Math.max(0, BQ.SECONDS * 1000 - bqPlayedMs(g, now));
export const setAngle = (g, v) => ({ ...g, currentAngle: clamp(Math.round(v), BQ.ANGLE_MIN, BQ.ANGLE_MAX) });
export const setPower = (g, v) => ({ ...g, currentPower: clamp(Math.round(v), BQ.POWER_MIN, BQ.POWER_MAX) });
export function resolveCurrentShot(g, now = Date.now()) {
  if (g.status !== 'PLAYING' || g.paused || g.shotsTaken >= g.shotsTotal) return g;
  const res = simulateShot(g.currentAngle, g.currentPower, g.currentHoopX);
  const points = res.scored ? (res.swish ? 3 : 2) : 0;
  const shot = { shotIndex: g.shotsTaken + 1, hoopX: g.currentHoopX, angleDeg: g.currentAngle, power: g.currentPower, scored: res.scored, swish: res.swish, points };
  const shotsTaken = g.shotsTaken + 1, done = shotsTaken >= g.shotsTotal;
  return { ...g, shotsTaken, shotsMade: g.shotsMade + (res.scored ? 1 : 0), totalScore: g.totalScore + points, shotHistory: [...g.shotHistory, shot],
    lastShot: { ...shot, path: res.path, feedback: res.feedback, hitRim: res.hitRim }, currentHoopX: done ? g.currentHoopX : generateNextHoopX(g.currentHoopX),
    ...(done ? { status: 'FINISHED', playedMs: bqPlayedMs(g, now), resumedAt: null, finishedAt: now } : {}) };
}
export const bqTimeUp = (g, now = Date.now()) => g.status === 'PLAYING' && !g.paused && bqRemainingMs(g, now) <= 0 ? { ...g, status: 'FINISHED', playedMs: BQ.SECONDS * 1000, resumedAt: null, finishedAt: now, timeUp: true } : g;
export const bqPause = (g, now = Date.now()) => g.status !== 'PLAYING' || g.paused ? g : { ...g, playedMs: bqPlayedMs(g, now), resumedAt: null, paused: true };
export const bqResume = (g, now = Date.now()) => g.status !== 'PLAYING' || !g.paused ? g : { ...g, paused: false, resumedAt: now };
// Evidencia: solo ángulo, fuerza y posición de cada tiro (el servidor simula de nuevo y calcula los SP).
export function basketProSubmission(g) {
  return { pro: true, gameId: g.gameId, characterId: g.selectedCharacterId, shots: g.shotHistory.map(s => ({ angle: s.angleDeg, power: s.power, hoopX: s.hoopX })), elapsedMs: Math.round(bqPlayedMs(g)),
    made: g.shotsMade, swish: g.shotHistory.filter(s => s.swish).length, bestStreak: 0, avgAccuracy: 0 }; // compatibilidad con el servidor anterior
}
const KEY = u => `sublichat:basket:active-game:${u}`, CKEY = u => `sublichat:basket:character:${u}`;
export const bqSave = (u, g) => { try { localStorage.setItem(KEY(u), JSON.stringify(g)); } catch (_) {} };
export const bqLoad = u => { try { const g = JSON.parse(localStorage.getItem(KEY(u)) || 'null'); return g?.schemaVersion === 1 ? g : null; } catch (_) { return null; } };
export const bqClear = u => { try { localStorage.removeItem(KEY(u)); } catch (_) {} };
export const bqGetCharacter = u => { try { return localStorage.getItem(CKEY(u)) || 'boy_2'; } catch (_) { return 'boy_2'; } };
export const bqSetCharacter = (u, id) => { try { localStorage.setItem(CKEY(u), id); } catch (_) {} };

/* ─────────── pantallas ─────────── */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = ms => { const t = Math.ceil(ms / 1000); return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; };
const ICO = {
  run: '<svg viewBox="0 0 24 24" width="24" height="24" fill="#ef4444"><circle cx="15" cy="4" r="2.4"/><path d="M13 7 9 9l-2 4 2 1 1.6-3 1.6-.8-1.2 4.8L8 20l1.6 1.2 3.4-4 1.8 1.8L14 23h2l1-6-2-2 .8-3.2L18 14h3v-2h-2.2l-2-4A2 2 0 0 0 13 7Z"/></svg>',
  arm: '<svg viewBox="0 0 24 24" width="24" height="24" fill="#2563eb"><path d="M6 21c-1.7 0-3-1.3-3-3 0-6 3-12 6-14l3 1-1 3-2 1c-1 2-1.3 4-1 6 2-2 5-3 8-2 2.8.8 4 3 4 5v3H6Z"/></svg>',
  target: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#16a34a" stroke-width="2.4"><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.5" fill="#16a34a"/><path d="M12 1v5M12 18v5M1 12h5M18 12h5"/></svg>',
  clock: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#2563eb" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  net: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#16a34a" stroke-width="2.2" stroke-linecap="round"><ellipse cx="12" cy="6" rx="9" ry="2.6"/><path d="M4 7l3 12h10l3-12M8 8l2 11M16 8l-2 11M12 8.6V19M5.5 12h13M6.5 16h11"/></svg>',
  ball: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3v18M5.6 5.6c3.5 3.5 3.5 9.3 0 12.8M18.4 5.6c-3.5 3.5-3.5 9.3 0 12.8"/></svg>',
  angle: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#ef4444" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16M4 20 14 5"/><path d="M10 20a7 7 0 0 0-2-5"/></svg>',
};
const bars = (n, color) => `<span class="bq-bars">${Array.from({ length: 5 }, (_, i) => `<i style="${i < n ? `background:${color}` : ''}"></i>`).join('')}</span>`;
const header = sub => `<header class="bq-head"><button type="button" class="bq-back" id="jgQuit" aria-label="Volver">‹</button><div><h1>Básquet <img src="/assets/basquet/balon-titulo.webp" alt=""></h1><p>${sub}</p></div><img class="bq-hero" src="/assets/basquet/hero.webp" alt=""></header>`;

export function basketSelectHtml({ selectedId = 'boy_2' } = {}) {
  const sel = BASKET_CHARACTERS.find(c => c.id === selectedId) || BASKET_CHARACTERS[1];
  const cards = BASKET_CHARACTERS.map(c => `<button type="button" class="bq-char ${c.id === sel.id ? 'on' : ''}" data-bq-char="${c.id}" style="--jc:${c.jerseyColor}" aria-pressed="${c.id === sel.id}">${c.id === sel.id ? '<i class="bq-check">✓</i>' : ''}<span class="bq-charimg"><img src="${c.img}" alt="${esc(c.name)}" draggable="false"></span><b>${esc(c.name)}</b></button>`).join('');
  return `<section class="jg-page bq-page bq-select">${header('Elija su jugador para iniciar.')}
    <div class="bq-chars">${cards}</div>
    <section class="bq-info"><div class="bq-info-top"><span class="bq-avatar" style="--jc:${sel.jerseyColor}"><img src="${sel.img}" alt=""></span><div><b>${esc(sel.name)}</b><p><strong>${esc(sel.tagline)}</strong> ${esc(sel.description)}</p></div></div>
      <div class="bq-stats"><div><span class="bq-si red">${ICO.run}</span><span><small>Velocidad</small>${bars(sel.stats.speed, '#ef4444')}</span></div><div><span class="bq-si blue">${ICO.arm}</span><span><small>Fuerza</small>${bars(sel.stats.power, '#2563eb')}</span></div><div><span class="bq-si green">${ICO.target}</span><span><small>Precisión</small>${bars(sel.stats.precision, '#16a34a')}</span></div></div></section>
    <button type="button" class="bq-cta" id="bqStart"><img src="/assets/basquet/balon-titulo.webp" alt="">Comenzar</button>
  </section>`;
}

export function basketCourtSvg(g, { flying = false, hoopX } = {}) {
  const hx = (hoopX ?? g.currentHoopX) * COURT.W, ry = COURT.RIM_Y * COURT.H;
  const last = g.lastShot, sx = COURT.START_X * COURT.W, sy = COURT.START_Y * COURT.H;
  const a = g.currentAngle * Math.PI / 180, L = 20 + g.currentPower * 0.45;
  const guide = [0, 1, 2, 3, 4, 5].map(i => { const xw = i * L / 5; return `${(sx + xw).toFixed(1)},${(sy - xw * Math.tan(a) * 0.9).toFixed(1)}`; }).join(' ');
  return `<svg class="bq-court" viewBox="0 0 360 220" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Cancha">
    <defs><linearGradient id="bqSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4aa8f0"/><stop offset="1" stop-color="#bfe4ff"/></linearGradient>
      <linearGradient id="bqFloor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8835a"/><stop offset="1" stop-color="#c85f3a"/></linearGradient>
      <linearGradient id="bqWall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2f56b8"/><stop offset="1" stop-color="#23449a"/></linearGradient>
      <radialGradient id="bqBall" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#ffb066"/><stop offset=".6" stop-color="#ef6c1a"/><stop offset="1" stop-color="#b8480c"/></radialGradient></defs>
    <rect width="360" height="220" fill="url(#bqSky)"/>
    <g fill="#fff" opacity=".9"><ellipse cx="200" cy="40" rx="30" ry="11"/><ellipse cx="220" cy="33" rx="18" ry="11"/><ellipse cx="310" cy="58" rx="26" ry="9"/></g>
    <g fill="#6f8fc4" opacity=".7"><rect x="100" y="60" width="16" height="70"/><rect x="120" y="72" width="22" height="58"/><rect x="150" y="50" width="14" height="80"/><rect x="170" y="78" width="26" height="52"/><rect x="238" y="66" width="18" height="64"/><rect x="262" y="84" width="24" height="46"/></g>
    <g fill="#3f9a4d"><circle cx="30" cy="112" r="20"/><circle cx="62" cy="118" r="16"/><circle cx="300" cy="116" r="18"/><circle cx="332" cy="110" r="20"/></g>
    <rect x="0" y="118" width="360" height="40" fill="url(#bqWall)"/>
    <g stroke="#cfd8e3" stroke-width=".7" opacity=".85">${Array.from({ length: 30 }, (_, i) => `<path d="M${i * 12} 96 L${i * 12 + 22} 130 M${i * 12 + 22} 96 L${i * 12} 130"/>`).join('')}</g>
    <rect x="0" y="94" width="360" height="3" fill="#8b98a8"/>
    <path d="M300 146 l12 -16 l6 10 l6 -12 l6 14" stroke="#9fc0ff" stroke-width="2.5" fill="none" opacity=".7"/>
    <rect x="0" y="156" width="360" height="64" fill="url(#bqFloor)"/>
    <ellipse cx="190" cy="186" rx="120" ry="18" fill="none" stroke="#fff" stroke-width="2" opacity=".9"/><path d="M0 204 L360 196" stroke="#fff" stroke-width="2" opacity=".8"/>
    <g transform="translate(318 120)"><rect x="-4" y="0" width="30" height="36" rx="3" fill="#39414d"/>${[0, 1, 2, 3].map(i => `<circle cx="${4 + (i % 2) * 14}" cy="${10 + Math.floor(i / 2) * 15}" r="6.5" fill="url(#bqBall)"/>`).join('')}</g>
    <g transform="translate(336 18)"><rect x="-2" y="10" width="4" height="96" fill="#6b7280"/><rect x="-14" y="0" width="28" height="16" rx="3" fill="#374151"/><g fill="#fff6cf">${[0, 1, 2].map(i => `<rect x="${-11 + i * 8}" y="3" width="6" height="4.5" rx="1"/><rect x="${-11 + i * 8}" y="9" width="6" height="4.5" rx="1"/>`).join('')}</g></g>
    <rect x="120" y="${ry - 30}" width="240" height="7" rx="3.5" fill="#6b7280"/>
    <g class="bq-hoop" id="bqHoop" transform="translate(${hx.toFixed(1)} 0)">
      <rect x="-26" y="${ry - 52}" width="52" height="38" rx="3" fill="#fff" stroke="#e2231a" stroke-width="3"/>
      <rect x="-11" y="${ry - 34}" width="22" height="16" fill="none" stroke="#e2231a" stroke-width="2.4"/>
      <path d="M-12 ${ry} L-8 ${ry + 16} L8 ${ry + 16} L12 ${ry}M-6 ${ry} L-3 ${ry + 16} M6 ${ry} L3 ${ry + 16} M0 ${ry} V${ry + 16}" stroke="#fff" stroke-width="1.4" fill="none"/>
      <ellipse cx="0" cy="${ry}" rx="12.5" ry="3" fill="none" stroke="#f05a1a" stroke-width="3"/>
      ${g.status === 'PLAYING' && !flying ? `<path d="M-38 ${ry - 34} l-8 5 l8 5" stroke="#16a8e0" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M38 ${ry - 34} l8 5 l-8 5" stroke="#16a8e0" stroke-width="3" fill="none" stroke-linecap="round"/>` : ''}
    </g>
    ${last && !flying && last.path?.length ? `<polyline points="${last.path.map(p => p.join(',')).join(' ')}" fill="none" stroke="${last.scored ? '#16a34a' : '#fff'}" stroke-width="2" stroke-dasharray="5 5" opacity=".85"/>` : ''}
    ${g.status === 'PLAYING' && !flying ? `<polyline points="${guide}" fill="none" stroke="#fff" stroke-width="2.6" stroke-dasharray="5 6" stroke-linecap="round" opacity=".9" id="bqGuide"/>` : ''}
    <g id="bqBallG" transform="translate(${sx} ${sy})"><circle r="8" fill="url(#bqBall)" stroke="#8a3b00" stroke-width="1"/><path d="M-8 0H8M0 -8V8" stroke="#8a3b00" stroke-width="1"/></g>
  </svg>`;
}

export function basketPlayHtml({ game, flying = false, hoopX, saving = false } = {}) {
  const g = game, ch = BASKET_CHARACTERS.find(c => c.id === g.selectedCharacterId) || BASKET_CHARACTERS[1];
  const rem = g.status === 'PLAYING' ? bqRemainingMs(g) : Math.max(0, BQ.SECONDS * 1000 - g.playedMs);
  const over = g.status === 'FINISHED';
  const msg = flying ? 'Lanzando…' : g.lastShot ? g.lastShot.feedback : 'Mueve el ángulo y la fuerza, luego toca Lanzar.';
  const aPct = (g.currentAngle - BQ.ANGLE_MIN) / (BQ.ANGLE_MAX - BQ.ANGLE_MIN) * 100, pPct = (g.currentPower - BQ.POWER_MIN) / (BQ.POWER_MAX - BQ.POWER_MIN) * 100;
  const sp = calculateMatchSP(g);
  return `<section class="jg-page bq-page bq-play">${header('5 tiros. Ajusta el ángulo y la fuerza, el aro cambia de lugar en cada tiro. <small>¡Las canastas limpias suman extra!</small>')}
    <section class="bq-panel"><div class="bq-kpis"><div><span class="bq-ki blue">${ICO.clock}</span><span><small>Tiempo</small><b id="bqTimer">${fmt(rem)}</b></span></div><div><span class="bq-ki green">${ICO.net}</span><span><small>Encestes</small><b>${g.shotsMade}/${g.shotsTaken}</b></span></div><div><span class="bq-ki red">${ICO.ball}</span><span><small>Tiros</small><b>${g.shotsTaken}/${g.shotsTotal}</b></span></div></div>
      <div class="bq-btns"><button type="button" class="bq-restart" id="bqRestart">↻ Reiniciar</button><button type="button" class="bq-pause" id="bqPause" ${over ? 'disabled' : ''}>${g.paused ? '▶ Seguir' : '❚❚ Pausar'}</button></div></section>
    <section class="bq-card">
      <div class="bq-stage">${basketCourtSvg(g, { flying, hoopX })}<img class="bq-shooter" src="${ch.img}" alt="${esc(ch.name)}"><p class="bq-tip ${g.lastShot?.scored && !flying ? 'ok' : ''}" id="bqTip">💡 ${esc(msg)}</p>${g.paused ? '<button type="button" class="bq-paused" id="bqResume">▶ En pausa · tocar para seguir</button>' : ''}</div>
      ${over ? `<div class="bq-end"><b>${g.timeUp ? '⏱ Se acabó el tiempo' : '🏁 Partida terminada'} · ${g.shotsMade}/${g.shotsTotal} encestes · ${g.shotHistory.filter(s => s.swish).length} limpias</b><span>${g.totalScore} puntos · <strong>+${sp} SP</strong>${g.submitted ? ' · ✅ acreditados' : ''}</span>
        <div class="bq-end-btns"><button type="button" class="bq-alt" id="bqChange">Cambiar jugador</button>${g.submitted ? '' : `<button type="button" class="bq-alt" id="bqSave" ${saving ? 'disabled' : ''}>${saving ? 'Guardando…' : 'Guardar SP'}</button>`}<button type="button" class="bq-cta sm" id="bqAgain">↻ Jugar otra vez</button></div></div>`
      : `<div class="bq-controls">
        <label class="bq-slider"><span class="bq-ci red">${ICO.angle}</span><span class="bq-cl"><small>Ángulo</small><b id="bqAngleVal">${g.currentAngle} °</b></span><input type="range" id="bqAngle" min="${BQ.ANGLE_MIN}" max="${BQ.ANGLE_MAX}" step="1" value="${g.currentAngle}" style="--p:${aPct}%" class="red" ${flying || g.paused ? 'disabled' : ''}></label>
        <label class="bq-slider"><span class="bq-ci blue">${ICO.arm}</span><span class="bq-cl"><small>Fuerza</small><b id="bqPowerVal">${g.currentPower}</b></span><input type="range" id="bqPower" min="${BQ.POWER_MIN}" max="${BQ.POWER_MAX}" step="1" value="${g.currentPower}" style="--p:${pPct}%" class="blue" ${flying || g.paused ? 'disabled' : ''}></label>
        <button type="button" class="bq-cta" id="bqShoot" ${flying || g.paused ? 'disabled' : ''}><img src="/assets/basquet/balon-titulo.webp" alt="">Lanzar</button></div>`}
    </section>
  </section>`;
}
