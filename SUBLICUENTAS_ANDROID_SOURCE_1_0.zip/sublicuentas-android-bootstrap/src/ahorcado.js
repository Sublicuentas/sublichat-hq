// Ahorcado PRO (R66) · según "Sublichat — Ahorcado PRO". 5 rondas, 7 intentos, 2 pistas por partida,
// reloj de 3 minutos por partida (timestamps: la pausa no cuenta), racha, ahorcado 3D que avanza por etapas,
// reanudación local y SP que calcula el servidor una sola vez por partida (gameId fijo).
import { HANGMAN_WORDS, HANGMAN_CATEGORIES } from './ahorcado-palabras.js';

export const HANG = Object.freeze({ ROUNDS: 5, MAX_ATTEMPTS: 7, HINTS: 2, GAME_SECONDS: 180 });
export const HANG_POINTS = Object.freeze({ WIN: 20, TIME_STEP: 5, TIME_MAX: 10, NO_HINT: 5, STREAK_EVERY: 3, STREAK_BONUS: 10, MATCH_COMPLETE: 20 });
const rnd = n => { const c = globalThis.crypto; if (c?.getRandomValues) { const b = new Uint32Array(1); c.getRandomValues(b); return b[0] % n; } return Math.floor(Math.random() * n); };
export function pickRoundWord(pool, usedIds, recentIds) {
  const available = pool.filter(w => !usedIds.has(w.id) && !recentIds.has(w.id));
  const fallback = pool.filter(w => !usedIds.has(w.id));
  const source = available.length ? available : fallback;
  return source[rnd(source.length)];
}
const letters = answer => [...new Set(answer.replace(/\s+/g, '').split(''))];
function newRound(word, index) { return { roundIndex: index, wordId: word.id, answer: word.answer, clue: word.clue, category: word.category, guessedLetters: [], wrongLetters: [], attemptsLeft: HANG.MAX_ATTEMPTS, hintsUsed: 0, status: 'PLAYING', points: 0, secondsAtEnd: null }; }
export function hangmanNewGame({ userId = 'yo', recentIds = [], now = Date.now(), pool = HANGMAN_WORDS } = {}) {
  const used = new Set(), recent = new Set(recentIds), words = [];
  for (let i = 0; i < HANG.ROUNDS; i++) { const w = pickRoundWord(pool, used, recent); used.add(w.id); words.push(w); }
  return { schemaVersion: 1, gameId: `hang-${now.toString(36)}-${Math.random().toString(36).slice(2, 7)}`, userId, roundsTotal: HANG.ROUNDS, currentRound: 1, streak: 0, bestStreak: 0,
    hintsLeft: HANG.HINTS, totalPoints: 0, words: words.map(w => w.id), rounds: [newRound(words[0], 1)], queue: words.slice(1), status: 'PLAYING', paused: false,
    playedMs: 0, resumedAt: now, startedAt: now, finishedAt: null, submitted: false };
}
export const hangPlayedMs = (g, now = Date.now()) => g.playedMs + (g.status === 'PLAYING' && !g.paused && g.resumedAt ? now - g.resumedAt : 0);
export const hangRemainingMs = (g, now = Date.now()) => Math.max(0, HANG.GAME_SECONDS * 1000 - hangPlayedMs(g, now));
export const hangRound = g => g.rounds[g.rounds.length - 1];
export const isRoundSolved = r => letters(r.answer).every(l => r.guessedLetters.includes(l));
export function calculateRoundPoints(r, streak, secondsRemaining) {
  if (r.status !== 'WON') return 0;
  const time = Math.min(Math.floor(secondsRemaining / HANG_POINTS.TIME_STEP), HANG_POINTS.TIME_MAX);
  return HANG_POINTS.WIN + time + (r.hintsUsed === 0 ? HANG_POINTS.NO_HINT : 0) + (streak > 0 && streak % HANG_POINTS.STREAK_EVERY === 0 ? HANG_POINTS.STREAK_BONUS : 0);
}
function closeRound(g, status, now) {
  const r = { ...hangRound(g), status }; const secs = Math.floor(hangRemainingMs(g, now) / 1000);
  const streak = status === 'WON' ? g.streak + 1 : 0;
  r.secondsAtEnd = secs; r.points = calculateRoundPoints(r, streak, secs);
  const rounds = [...g.rounds.slice(0, -1), r];
  return { ...g, rounds, streak, bestStreak: Math.max(g.bestStreak, streak), totalPoints: g.totalPoints + r.points };
}
export function pressLetter(g, letter, now = Date.now()) {
  if (g.status !== 'PLAYING' || g.paused) return g;
  const r = hangRound(g); if (r.status !== 'PLAYING') return g;
  const L = String(letter || '').toUpperCase(); if (!/^[A-ZÑ]$/.test(L) || r.guessedLetters.includes(L) || r.wrongLetters.includes(L)) return g;
  const hit = r.answer.includes(L);
  const nr = { ...r, guessedLetters: hit ? [...r.guessedLetters, L] : r.guessedLetters, wrongLetters: hit ? r.wrongLetters : [...r.wrongLetters, L], attemptsLeft: hit ? r.attemptsLeft : r.attemptsLeft - 1 };
  let next = { ...g, rounds: [...g.rounds.slice(0, -1), nr] };
  if (isRoundSolved(nr)) next = closeRound(next, 'WON', now); else if (nr.attemptsLeft <= 0) next = closeRound(next, 'LOST', now);
  return next;
}
export function useHint(g, now = Date.now()) {
  const r = hangRound(g); if (g.status !== 'PLAYING' || g.paused || g.hintsLeft <= 0 || r.status !== 'PLAYING') return { game: g, letter: null };
  const unrevealed = letters(r.answer).filter(l => !r.guessedLetters.includes(l)); if (!unrevealed.length) return { game: g, letter: null };
  const letter = unrevealed[rnd(unrevealed.length)];
  const nr = { ...r, hintsUsed: r.hintsUsed + 1, guessedLetters: [...r.guessedLetters, letter] };
  let next = { ...g, hintsLeft: g.hintsLeft - 1, rounds: [...g.rounds.slice(0, -1), nr] };
  if (isRoundSolved(nr)) next = closeRound(next, 'WON', now);
  return { game: next, letter };
}
// Pasa a la siguiente ronda o termina (al completar 5 rondas suma el bono de partida).
export function nextRound(g, now = Date.now()) {
  if (g.status !== 'PLAYING' || hangRound(g).status === 'PLAYING') return g;
  if (g.rounds.length >= g.roundsTotal) return finishGame(g, now);
  const [w, ...rest] = g.queue;
  return { ...g, currentRound: g.rounds.length + 1, rounds: [...g.rounds, newRound(w, g.rounds.length + 1)], queue: rest };
}
export function finishGame(g, now = Date.now()) {
  if (g.status !== 'PLAYING') return g;
  let next = g; if (hangRound(next).status === 'PLAYING') next = closeRound(next, 'LOST', now);
  const complete = next.rounds.length === next.roundsTotal && next.rounds.every(r => r.status !== 'PLAYING');
  return { ...next, playedMs: hangPlayedMs(g, now), resumedAt: null, status: 'COMPLETED', finishedAt: now, matchBonus: complete ? HANG_POINTS.MATCH_COMPLETE : 0, totalPoints: next.totalPoints + (complete ? HANG_POINTS.MATCH_COMPLETE : 0) };
}
export function checkTimeUp(g, now = Date.now()) { return g.status === 'PLAYING' && !g.paused && hangRemainingMs(g, now) <= 0 ? finishGame(g, now) : g; }
export function pauseHang(g, now = Date.now()) { return g.status !== 'PLAYING' || g.paused ? g : { ...g, playedMs: hangPlayedMs(g, now), resumedAt: null, paused: true }; }
export function resumeHang(g, now = Date.now()) { return g.status !== 'PLAYING' || !g.paused ? g : { ...g, paused: false, resumedAt: now }; }
export function getMaskedAnswer(answer, guessed) { return answer.split('').map(ch => ch === ' ' ? ' ' : guessed.includes(ch) ? ch : '_'); }
// Evidencia para el servidor: por ronda, si ganó, errores, pistas y segundos restantes (él recalcula y limita).
export function hangmanProSubmission(g) {
  return { pro: true, gameId: g.gameId, rounds: g.rounds.map(r => ({ won: r.status === 'WON', wrong: r.wrongLetters.length, hints: r.hintsUsed, secondsRemaining: r.secondsAtEnd ?? 0, len: r.answer.length })), roundsTotal: g.roundsTotal, elapsedMs: Math.round(hangPlayedMs(g)),
    // compatibilidad con la versión anterior del servidor
    solvedWords: g.rounds.filter(r => r.status === 'WON').length, totalWrongLetters: g.rounds.reduce((t, r) => t + r.wrongLetters.length, 0), hintsUsed: HANG.HINTS - g.hintsLeft, timeLimitSec: HANG.GAME_SECONDS, timeRemainingSec: Math.floor(hangRemainingMs(g) / 1000) };
}
// Persistencia / recientes
const KEY = u => `sublichat:hangman:active-game:${u}`, RKEY = u => `sublichat:hangman:recent:${u}`;
export const hangSave = (u, g) => { try { localStorage.setItem(KEY(u), JSON.stringify({ ...g, _savedAt: Date.now() })); } catch (_) {} };
export const hangLoad = u => { try { const g = JSON.parse(localStorage.getItem(KEY(u)) || 'null'); return g?.schemaVersion === 1 ? g : null; } catch (_) { return null; } };
export const hangRecent = u => { try { return JSON.parse(localStorage.getItem(RKEY(u)) || '[]'); } catch (_) { return []; } };
export const hangRememberWords = (u, g) => { try { localStorage.setItem(RKEY(u), JSON.stringify([...g.words, ...hangRecent(u)].slice(0, 15))); } catch (_) {} };

/* ─────────── render (referencia 3D aprobada, hecho en SVG) ─────────── */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = ms => { const t = Math.ceil(ms / 1000); return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; };
export function hangmanSceneSvg(wrong = 0, state = 'PLAYING') {
  const lost = state === 'LOST', won = state === 'WON';
  const part = (n, svg) => wrong >= n ? `<g class="hg-part">${svg}</g>` : '';
  const stroke = 'stroke="#1c1c24" stroke-width="7" stroke-linecap="round" fill="none"';
  const face = lost ? '<path d="M-9 -4l6 6M-3 -4l-6 6M3 -4l6 6M9 -4l-6 6" stroke="#1c1c24" stroke-width="2.6" stroke-linecap="round"/><path d="M-7 12q7 -6 14 0" stroke="#1c1c24" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
    : won ? '<path d="M-10 -1q3 -5 6 0M4 -1q3 -5 6 0" stroke="#1c1c24" stroke-width="2.8" fill="none" stroke-linecap="round"/><path d="M-7 8q7 8 14 0" stroke="#1c1c24" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
    : '<ellipse cx="-6" cy="-1" rx="3.4" ry="5" fill="#1c1c24"/><ellipse cx="6" cy="-1" rx="3.4" ry="5" fill="#1c1c24"/><circle cx="-5" cy="-3" r="1.2" fill="#fff"/><circle cx="7" cy="-3" r="1.2" fill="#fff"/><path d="M-4 10q4 3 8 0" stroke="#1c1c24" stroke-width="2.2" fill="none" stroke-linecap="round"/>';
  return `<svg class="hg-scene" viewBox="0 0 360 220" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Ahorcado: ${wrong} de 7 errores">
    <defs><linearGradient id="hgSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fd3ff"/><stop offset="1" stop-color="#dff3ff"/></linearGradient>
      <linearGradient id="hgWood" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#c77b3b"/><stop offset=".55" stop-color="#a45c25"/><stop offset="1" stop-color="#7c4115"/></linearGradient>
      <linearGradient id="hgWoodH" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#d58a47"/><stop offset="1" stop-color="#8e4d1c"/></linearGradient>
      <radialGradient id="hgHead" cx=".38" cy=".32" r=".75"><stop offset="0" stop-color="#ffffff"/><stop offset=".7" stop-color="#e9edf2"/><stop offset="1" stop-color="#b9c2cc"/></radialGradient>
      <radialGradient id="hgBush" cx=".4" cy=".35" r=".8"><stop offset="0" stop-color="#7fd66b"/><stop offset="1" stop-color="#2f9a45"/></radialGradient>
      <linearGradient id="hgGround" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c9e9a8"/><stop offset="1" stop-color="#8fca6e"/></linearGradient></defs>
    <rect width="360" height="220" fill="url(#hgSky)"/>
    <g fill="#fff" opacity=".95"><ellipse cx="70" cy="62" rx="42" ry="17"/><ellipse cx="98" cy="52" rx="26" ry="18"/><ellipse cx="290" cy="80" rx="40" ry="15"/><ellipse cx="312" cy="70" rx="24" ry="16"/></g>
    <g opacity=".85"><circle cx="18" cy="150" r="30" fill="#6fbf6a"/><circle cx="48" cy="140" r="22" fill="#86cf73"/><circle cx="330" cy="150" r="34" fill="#6fbf6a"/><circle cx="355" cy="130" r="22" fill="#86cf73"/>
      <ellipse cx="300" cy="170" rx="26" ry="16" fill="#b8bfc8"/><ellipse cx="40" cy="176" rx="22" ry="14" fill="#c4cad2"/></g>
    <ellipse cx="180" cy="206" rx="210" ry="36" fill="url(#hgGround)"/>
    <ellipse cx="170" cy="196" rx="92" ry="9" fill="rgba(60,40,20,.2)"/>
    <rect x="96" y="182" width="150" height="14" rx="4" fill="url(#hgWoodH)"/><rect x="104" y="174" width="44" height="12" rx="3" fill="url(#hgWood)"/>
    <rect x="112" y="40" width="20" height="142" rx="4" fill="url(#hgWood)"/>
    <rect x="104" y="34" width="112" height="16" rx="4" fill="url(#hgWoodH)"/>
    <path d="M131 76 L166 50 L176 50 L131 90 Z" fill="url(#hgWood)"/>
    <circle cx="122" cy="42" r="3.2" fill="#9aa4ae"/><circle cx="122" cy="176" r="3" fill="#9aa4ae"/>
    <g class="${lost ? 'hg-sway' : ''}">
      <path d="M196 50 V${wrong ? 80 : 96}" stroke="#c9a15a" stroke-width="5" stroke-linecap="round"/>
      <path d="M192 54 l8 4 M192 62 l8 4 M192 70 l8 4" stroke="#a37d3a" stroke-width="2"/>
      ${wrong ? '' : '<ellipse cx="196" cy="102" rx="9" ry="8" fill="none" stroke="#c9a15a" stroke-width="4.5"/>'}
      <g transform="translate(196 0)">
        ${part(2, `<path d="M0 116 V150" ${stroke}/>`)}
        ${part(3, `<path d="M0 124 L-17 142" ${stroke}/><circle cx="-18" cy="143" r="4.5" fill="#1c1c24"/>`)}
        ${part(4, `<path d="M0 124 L17 142" ${stroke}/><circle cx="18" cy="143" r="4.5" fill="#1c1c24"/>`)}
        ${part(5, `<path d="M0 150 L-12 172" ${stroke}/><ellipse cx="-14" cy="174" rx="6" ry="3.5" fill="#1c1c24"/>`)}
        ${part(6, `<path d="M0 150 L12 172" ${stroke}/><ellipse cx="14" cy="174" rx="6" ry="3.5" fill="#1c1c24"/>`)}
        ${part(1, `<ellipse cx="0" cy="81" rx="9" ry="5" fill="none" stroke="#c9a15a" stroke-width="4"/><g transform="translate(0 97)"><circle r="21" fill="#1c1c24"/><circle r="18.5" fill="url(#hgHead)"/>${face}</g>`)}
      </g>
    </g>
    <g><circle cx="150" cy="186" r="11" fill="url(#hgBush)"/><circle cx="162" cy="182" r="9" fill="url(#hgBush)"/><circle cx="238" cy="186" r="10" fill="url(#hgBush)"/><circle cx="88" cy="188" r="12" fill="url(#hgBush)"/><ellipse cx="250" cy="190" rx="12" ry="7" fill="#c4cad2"/><ellipse cx="110" cy="192" rx="10" ry="6" fill="#b8bfc8"/></g>
  </svg>`;
}
const KEYS = [['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'], ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ñ'], ['Z', 'X', 'C', 'V', 'B', 'N', 'M']];
export function hangmanProScreenHtml({ game, flash = '', saving = false } = {}) {
  const g = game, r = hangRound(g), cat = HANGMAN_CATEGORIES[r.category] || { label: r.category, icon: '🔤' };
  const over = g.status === 'COMPLETED', done = r.status !== 'PLAYING';
  const rem = over ? Math.max(0, HANG.GAME_SECONDS * 1000 - g.playedMs) : hangRemainingMs(g);
  const wrong = HANG.MAX_ATTEMPTS - r.attemptsLeft;
  const mask = done ? r.answer.split('') : getMaskedAnswer(r.answer, r.guessedLetters);
  const tiles = mask.map((ch, i) => `<span class="hg-tile ${ch !== '_' ? 'on' : ''} ${done && !r.guessedLetters.includes(r.answer[i]) ? 'miss' : ''}">${ch === '_' ? '' : esc(ch)}</span>`).join('');
  const hearts = Array.from({ length: HANG.MAX_ATTEMPTS }, (_, i) => `<i class="${i < r.attemptsLeft ? 'on' : ''}">❤</i>`).join('');
  const kb = KEYS.map(row => `<div class="hg-row">${row.map(k => { const ok = r.guessedLetters.includes(k), bad = r.wrongLetters.includes(k); return `<button type="button" class="hg-key ${ok ? 'ok' : ''} ${bad ? 'bad' : ''}" data-hg-key="${k}" ${ok || bad || done || over || g.paused ? 'disabled' : ''}>${k}</button>`; }).join('')}</div>`).join('');
  const banner = done && !over ? `<div class="hg-banner ${r.status === 'WON' ? 'win' : 'lose'}"><b>${r.status === 'WON' ? `¡Correcto! +${r.points} SP` : `La palabra era ${esc(r.answer)}`}</b><button type="button" class="hg-next" id="hgNext">${g.rounds.length >= g.roundsTotal ? 'Ver resultado' : 'Siguiente ronda ▸'}</button></div>` : '';
  const result = over ? `<div class="hg-banner ${g.rounds.filter(x => x.status === 'WON').length ? 'win' : 'lose'}"><b>Partida terminada · ${g.rounds.filter(x => x.status === 'WON').length}/${g.roundsTotal} palabras · +${g.totalPoints} SP</b>${g.submitted ? '<small>✅ Acreditado al SP global.</small>' : ''}<button type="button" class="hg-next" id="hgAgain">↻ Jugar otra vez</button></div>` : '';
  return `<section class="jg-page hg-page">
    <header class="hg-head"><button type="button" class="hg-back" id="jgQuit" aria-label="Volver">‹</button><div><p class="hg-eyebrow">🎮 Juegos PRO</p><h1>El ahorcado</h1><p class="hg-sub">Adivina la palabra antes de quedarte sin intentos.</p></div>
      <svg class="hg-pad" viewBox="0 0 90 60" aria-hidden="true"><rect x="6" y="10" width="78" height="42" rx="21" fill="#f3f6fa" stroke="#dfe6ee"/><path d="M26 22v18M17 31h18" stroke="#e2231a" stroke-width="7" stroke-linecap="round"/><circle cx="60" cy="26" r="4.5" fill="#e2231a"/><circle cx="68" cy="34" r="4.5" fill="#e2231a"/><circle cx="52" cy="34" r="4.5" fill="#e2231a"/></svg></header>
    <section class="hg-stats"><div><span class="hg-si">⏱</span><span><small>Tiempo</small><b id="hgTimer">${fmt(rem)}</b></span></div><div><span class="hg-si">🎯</span><span><small>Ronda</small><b>${g.rounds.length}/${g.roundsTotal}</b></span></div><div><span class="hg-si">🔥</span><span><small>Racha</small><b>x${g.streak}</b></span></div></section>
    <div class="hg-actions"><button type="button" class="hg-hint" id="hgHint" ${g.hintsLeft <= 0 || done || over || g.paused ? 'disabled' : ''}>💡 Pistas (${g.hintsLeft})</button><button type="button" class="hg-pause" id="hgPause" ${over ? 'disabled' : ''}>${g.paused ? '▶ Seguir' : '❚❚ Pausar'}</button></div>
    <section class="hg-card">
      <div class="hg-stage">${hangmanSceneSvg(wrong, r.status)}<span class="hg-cat">${cat.icon} ${esc(cat.label)}</span>${g.paused ? '<button type="button" class="hg-paused" id="hgResume">▶ En pausa · tocar para seguir</button>' : ''}</div>
      <div class="hg-body">
        <div class="hg-word ${flash}">${tiles}</div>
        <p class="hg-clue">${esc(r.clue)}</p>
        <div class="hg-hearts"><span>Intentos restantes</span><span class="hg-hs">${hearts}</span></div>
        ${banner || result || `<div class="hg-kb">${kb}</div>`}
        <button type="button" class="hg-save" id="hgSave" ${g.submitted || saving ? 'disabled' : ''}>${saving ? 'Guardando…' : g.submitted ? '✅ Puntos guardados' : '▶ Guardar puntos'}</button>
      </div>
    </section>
  </section>`;
}
