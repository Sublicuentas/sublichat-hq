// Sopa de Letras PRO (R61) · según "Sublichat - Sopa de Letras PRO" (24/09/2026).
// Motor puro con semilla (ronda reproducible), niveles, selección por arrastre o dos toques, pista con costo,
// cronómetro por timestamps (la pausa no cuenta), guardado/reanudación y métricas para que el servidor
// recalcule los SP (api/juegos.js). El SP global y el ranking son los mismos de los demás juegos.

/* ─────────── configuración central (balance) ─────────── */
export const SOPA_SCORE = Object.freeze({ WORD_FOUND: 20, ROUND_COMPLETE: 30, NO_HINT_BONUS: 15, HINT_COST: 10, MAX_SPEED_BONUS: 25 });
export const SOPA_LEVELS = Object.freeze({
  atencion: { id: 'atencion', n: 1, name: 'Atención', grid: 6, words: 3, dirs: ['E', 'S'], targetMs: 60000 },
  intermedio: { id: 'intermedio', n: 2, name: 'Intermedio', grid: 8, words: 5, dirs: ['E', 'S', 'SE', 'NE'], targetMs: 120000 },
  pro: { id: 'pro', n: 3, name: 'Pro', grid: 10, words: 7, dirs: ['E', 'W', 'N', 'S', 'NE', 'NW', 'SE', 'SW'], targetMs: 180000 },
});
export const SOPA_LEVEL_ORDER = ['atencion', 'intermedio', 'pro'];
const DIRS = { E: [0, 1], W: [0, -1], N: [-1, 0], S: [1, 0], NE: [-1, 1], NW: [-1, -1], SE: [1, 1], SW: [1, -1] };

// Banco de palabras por tema (se muestran con tilde; en el tablero van normalizadas).
export const SOPA_BANK = [
  { tema: 'Frutas', words: ['UVA', 'PERA', 'KIWI', 'MANGO', 'PIÑA', 'COCO', 'LIMA', 'MELÓN', 'FRESA', 'SANDÍA', 'CEREZA', 'NARANJA', 'GUAYABA', 'PAPAYA', 'MARACUYÁ'] },
  { tema: 'Autos', words: ['AUDI', 'KIA', 'FORD', 'SEAT', 'MAZDA', 'HONDA', 'TOYOTA', 'NISSAN', 'SUZUKI', 'VOLVO', 'PORSCHE', 'HYUNDAI', 'CHEVROLET', 'FERRARI'] },
  { tema: 'Cuerpo', words: ['BAZO', 'OJO', 'MANO', 'PIE', 'CODO', 'NARIZ', 'HÍGADO', 'RODILLA', 'HOMBRO', 'CEREBRO', 'PULMÓN', 'CORAZÓN', 'ESTÓMAGO', 'TOBILLO'] },
  { tema: 'Animales', words: ['GATO', 'PERRO', 'OSO', 'LEÓN', 'TIGRE', 'MONO', 'LORO', 'VACA', 'CABALLO', 'JAGUAR', 'DELFÍN', 'TORTUGA', 'GUACAMAYA', 'IGUANA'] },
  { tema: 'Streaming', words: ['SERIE', 'CINE', 'CANAL', 'PERFIL', 'PANTALLA', 'ESTRENO', 'EPISODIO', 'TEMPORADA', 'NETFLIX', 'DISNEY', 'SPOTIFY', 'PELÍCULA'] },
  { tema: 'Honduras', words: ['COPÁN', 'ROATÁN', 'LEMPIRA', 'TELA', 'CEIBA', 'CATRACHO', 'BALEADA', 'PUPUSA', 'MAYA', 'OLANCHO', 'CHOLUTECA', 'TEGUCIGALPA'] },
];

export function normalizeWord(input = '') {
  return String(input).toUpperCase().replace(/Ñ/g, '\u0001').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\u0001/g, 'Ñ').replace(/[^A-ZÑ]/g, '');
}
// RNG con semilla (mulberry32 sobre un hash de texto): mismo seed → mismo tablero.
export function seededRng(seed = '') {
  let h = 1779033703 ^ String(seed).length;
  for (let i = 0; i < String(seed).length; i++) { h = Math.imul(h ^ String(seed).charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); }
  let a = h >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function canPlace(grid, word, row, col, dr, dc) {
  for (let i = 0; i < word.length; i++) {
    const r = row + dr * i, c = col + dc * i;
    if (!grid[r] || grid[r][c] === undefined) return false;
    if (grid[r][c] && grid[r][c] !== word[i]) return false;
  }
  return true;
}
const shuffle = (arr, rng) => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

function tryBuild(level, seed) {
  const rng = seededRng(seed);
  const theme = SOPA_BANK[Math.floor(rng() * SOPA_BANK.length)];
  const pool = shuffle(theme.words.filter(w => normalizeWord(w).length <= level.grid && normalizeWord(w).length >= 3), rng);
  if (pool.length < level.words) return null;
  const chosen = pool.slice(0, level.words).sort((a, b) => normalizeWord(b).length - normalizeWord(a).length);
  const grid = Array.from({ length: level.grid }, () => Array(level.grid).fill(''));
  const words = [];
  for (const display of chosen) {
    const text = normalizeWord(display); let placed = null;
    for (let attempt = 0; attempt < 300 && !placed; attempt++) {
      const dir = level.dirs[Math.floor(rng() * level.dirs.length)], [dr, dc] = DIRS[dir];
      const row = Math.floor(rng() * level.grid), col = Math.floor(rng() * level.grid);
      if (canPlace(grid, text, row, col, dr, dc)) {
        for (let i = 0; i < text.length; i++) grid[row + dr * i][col + dc * i] = text[i];
        placed = { id: `w${words.length + 1}`, text, displayText: display, start: { row, col }, end: { row: row + dr * (text.length - 1), col: col + dc * (text.length - 1) }, direction: dir, found: false };
      }
    }
    if (!placed) return null; // no cupo: se regenera con otra semilla (nunca se muestra una ronda incompleta)
    words.push(placed);
  }
  const alphabet = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ';
  for (let r = 0; r < level.grid; r++) for (let c = 0; c < level.grid; c++) if (!grid[r][c]) grid[r][c] = alphabet[Math.floor(rng() * alphabet.length)];
  return { theme: theme.tema, grid, words };
}
export function sopaCreate(levelId = 'atencion', seed = '', { now = Date.now() } = {}) {
  const level = SOPA_LEVELS[levelId] || SOPA_LEVELS.atencion;
  let baseSeed = seed || `${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  let built = null, usedSeed = baseSeed;
  for (let k = 0; k < 40 && !built; k++) { usedSeed = k ? `${baseSeed}#${k}` : baseSeed; built = tryBuild(level, usedSeed); }
  return { schemaVersion: 1, roundId: `ws-${usedSeed.replace(/[^a-z0-9]/gi, '')}-${now.toString(36)}`, gameId: 'word_search', seed: usedSeed, levelId: level.id, gridSize: level.grid,
    theme: built.theme, grid: built.grid, words: built.words, foundWordIds: [], foundPaths: [], startedAt: now, elapsedMs: 0, pausedAt: null,
    hintCount: 0, hintCell: null, hintUntil: 0, roundScore: 0, status: 'playing', finishedAt: null, submitted: false, submitResult: null };
}

/* ─────────── selección y validación ─────────── */
export function cellsBetween(start, end) {
  const rowDelta = Math.abs(end.row - start.row), colDelta = Math.abs(end.col - start.col);
  if (!(rowDelta === 0 || colDelta === 0 || rowDelta === colDelta)) return [];
  const dr = Math.sign(end.row - start.row), dc = Math.sign(end.col - start.col), len = Math.max(rowDelta, colDelta) + 1;
  return Array.from({ length: len }, (_, i) => ({ row: start.row + dr * i, col: start.col + dc * i }));
}
// Encaja un arrastre torcido a la dirección más cercana de las 8 posibles.
export function snapEnd(start, raw, size) {
  const dr = raw.row - start.row, dc = raw.col - start.col;
  if (!dr && !dc) return { ...start };
  const ang = Math.atan2(dr, dc), step = Math.PI / 4, k = Math.round(ang / step);
  const sr = Math.round(Math.sin(k * step)), sc = Math.round(Math.cos(k * step));
  let len = Math.max(Math.abs(dr), Math.abs(dc));
  while (len > 0) { const r = start.row + sr * len, c = start.col + sc * len; if (r >= 0 && c >= 0 && r < size && c < size) return { row: r, col: c }; len -= 1; }
  return { ...start };
}
export const textFromCells = (grid, cells) => cells.map(c => grid[c.row]?.[c.col] || '').join('');
export function sopaElapsed(round, now = Date.now()) {
  if (round.status !== 'playing') return round.elapsedMs;
  return round.elapsedMs + Math.max(0, now - round.startedAt);
}
export function sopaScore(round, elapsedMs = sopaElapsed(round)) {
  const found = round.foundWordIds.length;
  let s = found * SOPA_SCORE.WORD_FOUND - round.hintCount * SOPA_SCORE.HINT_COST;
  if (found === round.words.length) {
    const target = (SOPA_LEVELS[round.levelId] || SOPA_LEVELS.atencion).targetMs;
    s += SOPA_SCORE.ROUND_COMPLETE + (round.hintCount ? 0 : SOPA_SCORE.NO_HINT_BONUS) + (elapsedMs < target ? Math.round(SOPA_SCORE.MAX_SPEED_BONUS * (1 - elapsedMs / target)) : 0);
  }
  return Math.max(0, s);
}
export function sopaResolve(round, cells, now = Date.now()) {
  if (round.status !== 'playing' || !cells?.length) return { round, result: { type: 'ignored' } };
  if (cells.some(c => c.row < 0 || c.col < 0 || c.row >= round.gridSize || c.col >= round.gridSize)) return { round, result: { type: 'miss' } };
  const fwd = textFromCells(round.grid, cells), rev = [...fwd].reverse().join('');
  const word = round.words.find(w => !w.found && (w.text === fwd || w.text === rev));
  if (!word) return { round, result: { type: 'miss' } };
  const words = round.words.map(w => w.id === word.id ? { ...w, found: true } : w);
  const foundWordIds = [...round.foundWordIds, word.id];
  const foundPaths = [...round.foundPaths, { wordId: word.id, start: cells[0], end: cells[cells.length - 1] }];
  let next = { ...round, words, foundWordIds, foundPaths, hintCell: round.hintCell && words.find(w => !w.found && w.start.row === round.hintCell.row && w.start.col === round.hintCell.col) ? round.hintCell : null };
  if (foundWordIds.length === words.length) { next = { ...next, elapsedMs: sopaElapsed(round, now), status: 'completed', finishedAt: now }; }
  next.roundScore = sopaScore(next, sopaElapsed(next, now));
  return { round: next, result: { type: 'hit', wordId: word.id, word: word.displayText } };
}
export function sopaHint(round, now = Date.now()) {
  if (round.status !== 'playing') return round;
  const pending = round.words.filter(w => !w.found); if (!pending.length) return round;
  const target = pending[round.hintCount % pending.length];
  const next = { ...round, hintCount: round.hintCount + 1, hintCell: { row: target.start.row, col: target.start.col }, hintUntil: now + 4000 };
  next.roundScore = sopaScore(next); return next;
}
export function sopaPause(round, now = Date.now()) { return round.status === 'playing' ? { ...round, elapsedMs: sopaElapsed(round, now), status: 'paused', pausedAt: now } : round; }
export function sopaResume(round, now = Date.now()) { return round.status === 'paused' ? { ...round, status: 'playing', startedAt: now, pausedAt: null } : round; }
// El servidor recibe tablero, palabras y trazos: vuelve a leer cada trazo en el tablero y recalcula los SP.
export function sopaSubmission(round) {
  return { schemaVersion: 1, levelId: round.levelId, seed: round.seed, grid: round.grid.map(r => r.join('')), words: round.words.map(w => w.text),
    selections: round.foundPaths.map(p => ({ r1: p.start.row, c1: p.start.col, r2: p.end.row, c2: p.end.col })), hintsUsed: round.hintCount, elapsedMs: Math.round(round.elapsedMs),
    // compatibilidad con la versión anterior del servidor
    foundWords: round.foundWordIds.length, wrongSelections: 0, maxCombo: 0, timeLimitSec: Math.round((SOPA_LEVELS[round.levelId] || SOPA_LEVELS.atencion).targetMs / 1000), timeRemainingSec: 0 };
}

/* ─────────── guardado / reanudación ─────────── */
const storeKey = user => `sublichat-sopa-v1:${String(user || 'yo').toLowerCase()}`;
export function sopaSave(user, round) { try { localStorage.setItem(storeKey(user), JSON.stringify({ schemaVersion: 1, round, lastSavedAt: Date.now() })); } catch (_) {} }
export function sopaLoad(user) {
  try { const v = JSON.parse(localStorage.getItem(storeKey(user)) || 'null'); if (v?.schemaVersion !== 1 || !v.round?.grid) return null; return v.round; } catch (_) { return null; }
}
export function sopaClear(user) { try { localStorage.removeItem(storeKey(user)); } catch (_) {} }

/* ─────────── pantalla (réplica del visual aprobado) ─────────── */
const escS = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const fmtMs = ms => { const t = Math.max(0, Math.floor(ms / 1000)); return `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`; };
const ICO = {
  clock: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2"/></svg>',
  trophy: '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M7 3h10v3h3v2a5 5 0 0 1-4.3 5A5 5 0 0 1 13 15.9V18h3v3H8v-3h3v-2.1A5 5 0 0 1 8.3 13 5 5 0 0 1 4 8V6h3V3Zm0 5H6a3 3 0 0 0 1 2.2V8Zm10 0v2.2A3 3 0 0 0 18 8h-1Z"/></svg>',
  bars: '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><rect x="4" y="13" width="4" height="7" rx="1"/><rect x="10" y="9" width="4" height="11" rx="1"/><rect x="16" y="4" width="4" height="16" rx="1"/></svg>',
  list: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="3.5" width="14" height="17" rx="2"/><path d="M8.5 8h7M8.5 12h7M8.5 16h5"/></svg>',
  target: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/><path d="M15 9l5-5M17 4h3v3"/></svg>',
  bulb: '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V17h5.2v-1.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3Zm-2.6 15.5h5.2V20a1 1 0 0 1-1 1h-3.2a1 1 0 0 1-1-1v-1.5Z"/></svg>',
  refresh: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M20 7v5h-5"/><path d="M19 12a7 7 0 1 0-2 5"/></svg>',
};
const LOGO = '<span class="ws-logo" aria-hidden="true"><i>W</i><i>O</i><i>R</i><i>D</i><i>A</i><i>S</i><i>P</i><i>A</i><i class="r">L</i><i>A</i><i>B</i><i class="r">R</i><b></b></span>';

export function sopaScreenHtml({ round, totalSP = 0, levelMenu = false, message = '', saving = false } = {}) {
  const r = round, n = r.gridSize, lvl = SOPA_LEVELS[r.levelId] || SOPA_LEVELS.atencion;
  const found = r.foundWordIds.length, total = r.words.length, pct = Math.round(found / total * 100);
  const paused = r.status === 'paused', done = r.status === 'completed';
  const hintOn = r.hintCell && Date.now() < r.hintUntil;
  const lines = r.foundPaths.map(p => `<line x1="${p.start.col + .5}" y1="${p.start.row + .5}" x2="${p.end.col + .5}" y2="${p.end.row + .5}"/>`).join('');
  const foundCells = new Set(r.foundPaths.flatMap(p => cellsBetween(p.start, p.end).map(c => `${c.row},${c.col}`)));
  const cells = r.grid.map((row, ri) => row.map((ch, ci) => `<div class="ws-cell ${foundCells.has(`${ri},${ci}`) ? 'found' : ''} ${hintOn && r.hintCell.row === ri && r.hintCell.col === ci ? 'hint' : ''}" data-ws="${ri},${ci}">${escS(ch)}</div>`).join('')).join('');
  const chips = r.words.map(w => `<span class="ws-chip ${w.found ? 'on' : ''}">${escS(w.displayText)}</span>`).join('');
  const menu = levelMenu ? `<div class="ws-levels" role="menu">${SOPA_LEVEL_ORDER.map(id => { const L = SOPA_LEVELS[id]; return `<button type="button" class="${id === r.levelId ? 'on' : ''}" data-sopa-level="${id}"><b>Nivel ${L.n} · ${L.name}</b><small>${L.grid}×${L.grid} · ${L.words} palabras · ${L.dirs.length === 2 ? 'horizontal y vertical' : L.dirs.length === 4 ? 'con diagonales' : '8 direcciones'}</small></button>`; }).join('')}</div>` : '';
  const doneCard = done ? `<section class="ws-done"><b>🎉 ¡Ronda completa!</b><span>Tiempo ${fmtMs(r.elapsedMs)} · ${r.hintCount ? `${r.hintCount} pista${r.hintCount === 1 ? '' : 's'}` : 'sin pistas (+15)'} · ronda <b>+${r.roundScore} SP</b></span>
      ${r.submitted ? `<small>✅ Acreditado al SP global${r.submitResult?.totalPoints != null ? ` · total ${Number(r.submitResult.totalPoints).toLocaleString('en-US')} SP` : ''}.</small>` : saving ? '<small>Guardando en el servidor…</small>' : `<button type="button" class="ws-retry" id="sopaSubmit">Guardar SP pendientes</button>`}</section>` : '';
  return `<section class="jg-page ws-page">
    <header class="ws-top"><button type="button" class="ws-back" id="jgQuit" aria-label="Volver">‹</button>${LOGO}<div class="ws-title"><b>Sopa de letras</b><small>Nivel ${escS(lvl.name)} · ${escS(r.theme)}</small></div>
      <button type="button" class="ws-pause" id="sopaPause" aria-label="${paused ? 'Reanudar' : 'Pausar'}" ${done ? 'disabled' : ''}>${paused ? '▶' : '❚❚'}</button></header>
    <div class="ws-progress"><div class="ws-bar"><i style="width:${pct}%"></i></div><b>${found}/${total}</b></div>
    <section class="ws-stats">
      <div class="ws-stat"><span class="ws-si red">${ICO.clock}</span><span><b id="sopaTimer">${fmtMs(sopaElapsed(r))}</b><small>Tiempo</small></span></div>
      <div class="ws-stat"><span class="ws-si red">${ICO.trophy}</span><span><b>${Number(totalSP || 0).toLocaleString('en-US')} SP</b><small>Puntos</small></span></div>
      <button type="button" class="ws-stat" id="sopaLevel" aria-expanded="${levelMenu}"><span class="ws-si red">${ICO.bars}</span><span><b>Nivel ${lvl.n}</b><small>${escS(lvl.name)} ▾</small></span></button>
    </section>${menu}
    <div class="ws-chips">${chips}</div>
    <div class="ws-board ${paused ? 'paused' : ''}" id="sopaBoard" style="--n:${n}">
      <svg class="ws-lines" viewBox="0 0 ${n} ${n}" preserveAspectRatio="none" aria-hidden="true">${lines}<line id="sopaLive" x1="0" y1="0" x2="0" y2="0" style="display:none"/></svg>
      ${cells}${paused ? '<button type="button" class="ws-paused" id="sopaResume">▶ En pausa · tocar para seguir</button>' : ''}
    </div>
    <p class="ws-msg" id="sopaMsg">${escS(message || (done ? '' : 'Arrastre desde la primera letra hasta la última (o toque inicio y fin).'))}</p>
    ${doneCard}
    <section class="ws-foot">
      <div class="ws-fs"><span class="ws-fi gray">${ICO.list}</span><span><small>Palabras</small><b>${total}</b></span></div>
      <div class="ws-fs"><span class="ws-fi red">${ICO.target}</span><span><small>Encontradas</small><b>${found} / ${total}</b></span></div>
      <button type="button" class="ws-fs" id="sopaHint" ${done || paused ? 'disabled' : ''}><span class="ws-fi cyan">${ICO.bulb}</span><span><small>Pista</small><em>- ${SOPA_SCORE.HINT_COST} SP</em></span></button>
    </section>
    <button type="button" class="ws-new" id="sopaNew">${ICO.refresh} Nueva ronda</button>
  </section>`;
}

/* ─────────── gestos: arrastre + dos toques ─────────── */
export function attachSopaControls({ size, onCells, isBlocked = () => false } = {}) {
  const board = document.getElementById('sopaBoard'); if (!board) return () => {};
  const live = document.getElementById('sopaLive');
  let start = null, end = null, moved = false, pick = null;
  const cellAt = e => { const r = board.getBoundingClientRect(); const c = Math.floor((e.clientX - r.left) / (r.width / size)), ro = Math.floor((e.clientY - r.top) / (r.height / size)); return (ro >= 0 && c >= 0 && ro < size && c < size) ? { row: ro, col: c } : null; };
  const paint = cells => {
    board.querySelectorAll('.ws-cell.sel').forEach(el => el.classList.remove('sel'));
    cells.forEach(c => board.querySelector(`[data-ws="${c.row},${c.col}"]`)?.classList.add('sel'));
    if (live) { if (cells.length) { const a = cells[0], b = cells[cells.length - 1]; live.setAttribute('x1', a.col + .5); live.setAttribute('y1', a.row + .5); live.setAttribute('x2', b.col + .5); live.setAttribute('y2', b.row + .5); live.style.display = ''; } else live.style.display = 'none'; }
  };
  const down = e => { if (isBlocked()) return; const c = cellAt(e); if (!c) return; start = c; end = c; moved = false; try { board.setPointerCapture(e.pointerId); } catch (_) {} paint([c]); e.preventDefault(); };
  const move = e => { if (!start) return; const raw = cellAt(e); if (!raw) return; const s = snapEnd(start, raw, size); if (s.row !== end.row || s.col !== end.col) { end = s; moved = true; paint(cellsBetween(start, end)); } };
  const up = () => {
    if (!start) return; const a = start, b = end; start = null;
    if (moved && (a.row !== b.row || a.col !== b.col)) { pick = null; board.querySelectorAll('.ws-cell.pick').forEach(el => el.classList.remove('pick')); paint([]); onCells(cellsBetween(a, b)); return; }
    // alternativa accesible: toque en la primera letra y luego en la última
    if (pick && (pick.row !== a.row || pick.col !== a.col)) { const cells = cellsBetween(pick, a); pick = null; board.querySelectorAll('.ws-cell.pick').forEach(el => el.classList.remove('pick')); paint([]); onCells(cells.length ? cells : [a]); return; }
    pick = a; paint([]); board.querySelectorAll('.ws-cell.pick').forEach(el => el.classList.remove('pick')); board.querySelector(`[data-ws="${a.row},${a.col}"]`)?.classList.add('pick');
  };
  const cancel = () => { start = null; paint([]); };
  board.addEventListener('pointerdown', down); board.addEventListener('pointermove', move); board.addEventListener('pointerup', up); board.addEventListener('pointercancel', cancel);
  return () => { board.removeEventListener('pointerdown', down); board.removeEventListener('pointermove', move); board.removeEventListener('pointerup', up); board.removeEventListener('pointercancel', cancel); };
}
