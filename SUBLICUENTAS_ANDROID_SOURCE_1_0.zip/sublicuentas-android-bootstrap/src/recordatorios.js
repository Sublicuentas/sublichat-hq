// R73 · Recordatorios de cobro (notificaciones locales del teléfono).
// Igual que el aviso de las 7 AM del bot de Telegram: cada usuario recibe SOLO sus propios cobros
// (Sublicuentas no ve los de Relojes, Relojes no ve los de Sublicuentas, Geisell solo los suyos).
//   · 7:00 AM → "Hoy toca cobrar a 12"
//   · 7:00 PM → "Mañana vencen 12"
// Se programan los próximos 7 días con los datos que ya tiene la app, y se reprograman cada vez
// que la app sincroniza (así los números siguen al día aunque se renueve o se agregue una venta).
import { canonicalSeller, parseDateDMY, operatorIdentity, money } from './data.js';

export const REMINDER_KEY = 'sublicuentas-recordatorios';
export const REMINDER_DEFAULTS = Object.freeze({ activo: true, horaHoy: '07:00', horaManana: '19:00' });
export const REMINDER_CHANNEL = 'cobros';
export const REMINDER_DAYS = 7;
const ID_HOY = 7100, ID_MANANA = 7200; // rango propio: 7100-7299

export function loadReminderConfig(storage = globalThis.localStorage) {
  try { return { ...REMINDER_DEFAULTS, ...JSON.parse(storage?.getItem(REMINDER_KEY) || '{}') }; }
  catch (_) { return { ...REMINDER_DEFAULTS }; }
}
export function saveReminderConfig(cfg, storage = globalThis.localStorage) {
  const clean = { ...REMINDER_DEFAULTS, ...cfg };
  try { storage?.setItem(REMINDER_KEY, JSON.stringify(clean)); } catch (_) {}
  return clean;
}

// Vendedor dueño de la sesión: 'sublicuentas' | 'relojes' | 'geisell' | nombre del vendedor.
export function reminderSellerOf(role = '', usuario = '') {
  const id = operatorIdentity(role, usuario);
  return id === 'limited' ? canonicalSeller(usuario) : id;
}

export function isReminderId(id) { const n = Number(id); return n >= ID_HOY && n < ID_MANANA + 100; }

function atTime(day, hhmm) {
  const [h, m] = String(hhmm || '').split(':').map(Number);
  const d = new Date(day); d.setHours(Number.isFinite(h) ? h : 7, Number.isFinite(m) ? m : 0, 0, 0);
  return d;
}
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const clientes = n => `${n} cliente${n === 1 ? '' : 's'}`;

// Cobros (grupos cliente/tercero + fecha, los mismos de la pantalla Cobros) de UN vendedor en un día.
export function cobrosDelDia(groups = [], day, seller = '') {
  const s = canonicalSeller(seller);
  const list = (Array.isArray(groups) ? groups : []).filter(g => {
    if (s && canonicalSeller(g.vendedor) !== s) return false;
    const d = parseDateDMY(g.fechaRenovacion);
    return d && sameDay(d, day);
  });
  return { count: list.length, total: list.reduce((sum, g) => sum + (Number(g.total) || 0), 0) };
}

// R74: vencidos sin gestionar de UN vendedor al llegar ese día (fecha anterior al día y sin renovar).
export function vencidosAl(groups = [], day, seller = '') {
  const s = canonicalSeller(seller);
  const start = new Date(day); start.setHours(0, 0, 0, 0);
  return (Array.isArray(groups) ? groups : []).filter(g => {
    if (s && canonicalSeller(g.vendedor) !== s) return false;
    const d = parseDateDMY(g.fechaRenovacion);
    return d && d < start;
  }).length;
}

// Plan de notificaciones a programar (función pura: se prueba sin teléfono).
export function planReminders({ groups = [], seller = '', cfg = REMINDER_DEFAULTS, now = new Date(), days = REMINDER_DAYS } = {}) {
  if (!cfg?.activo || !seller) return [];
  const out = [];
  const base = new Date(now); base.setHours(12, 0, 0, 0);
  for (let i = 0; i < days; i += 1) {
    const day = new Date(base); day.setDate(base.getDate() + i);
    const morning = atTime(day, cfg.horaHoy);
    const hoy = cobrosDelDia(groups, day, seller);
    const venc = vencidosAl(groups, day, seller); // R74: el aviso de la mañana también cuenta los vencidos
    const extraVenc = venc ? ` · además ${venc} vencido${venc === 1 ? '' : 's'} sin gestionar` : '';
    if (morning > now && hoy.count > 0) out.push({
      id: ID_HOY + i, channelId: REMINDER_CHANNEL,
      title: `💰 Hoy toca cobrar a ${clientes(hoy.count)}`,
      body: `Total por cobrar hoy: ${money(hoy.total)}${extraVenc}. Toque para abrir Cobros.`,
      schedule: { at: morning, allowWhileIdle: true },
      extra: { ir: 'cobros', filtro: 'hoy' },
    });
    else if (morning > now && venc > 0) out.push({
      id: ID_HOY + i, channelId: REMINDER_CHANNEL,
      title: `⚠️ ${venc} vencido${venc === 1 ? '' : 's'} sin gestionar`,
      body: 'Hoy no vence nadie, pero quedan cobros atrasados. Toque para verlos.',
      schedule: { at: morning, allowWhileIdle: true },
      extra: { ir: 'cobros', filtro: 'vencidos' },
    });
    const evening = atTime(day, cfg.horaManana);
    const next = new Date(day); next.setDate(day.getDate() + 1);
    const manana = cobrosDelDia(groups, next, seller);
    if (evening > now && manana.count > 0) out.push({
      id: ID_MANANA + i, channelId: REMINDER_CHANNEL,
      title: `📅 Mañana vencen ${manana.count}`,
      body: `Mañana toca cobrar a ${clientes(manana.count)} · ${money(manana.total)}. Toque para verlos.`,
      schedule: { at: evening, allowWhileIdle: true },
      extra: { ir: 'cobros', filtro: 'proximo' },
    });
  }
  return out;
}

// R74 · Datos del widget "Cobros" de la pantalla de inicio: cobros del vendedor agrupados por fecha.
// El widget (Android) calcula Hoy / Próximos / Vencidos con la fecha del teléfono, así sigue correcto
// al cambiar el día aunque la app no se abra.
export function widgetPayload({ groups = [], seller = '', sellerLabel = '', now = new Date() } = {}) {
  const s = canonicalSeller(seller);
  const dias = {};
  for (const g of Array.isArray(groups) ? groups : []) {
    if (!s || canonicalSeller(g.vendedor) !== s) continue;
    const d = parseDateDMY(g.fechaRenovacion); if (!d) continue;
    const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const cur = dias[k] || { n: 0, t: 0 };
    dias[k] = { n: cur.n + 1, t: Math.round((cur.t + (Number(g.total) || 0)) * 100) / 100 }; // R76: cantidad + monto
  }
  const hh = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  return { vendedor: sellerLabel || s, actualizado: hh, dias };
}
