import { chargePlatformName, iptvUsesMaxPlayer } from './operations.js';
const env = (typeof import.meta !== 'undefined' && import.meta.env) ? import.meta.env : {};
// sublichat-hq.vercel.app REDIRIGE a sublichat.capuchino.lat (confirmado: al pedirlo, Vercel responde
// con un 30x hacia ese dominio). Una redirección entre dominios distintos puede fallar justo en
// peticiones POST (como /api/login) por las reglas más estrictas de CORS para redirecciones — aunque
// una carga simple sí la siga sin problema. Por eso se apunta DIRECTO al dominio final, sin el salto
// de por medio, evitando ese problema de raíz. Si algún día hace falta apuntar a otro sitio (por
// ejemplo para pruebas), VITE_API_BASE_URL sigue teniendo la última palabra.
export const API_BASE = String(env.VITE_API_BASE_URL || 'https://sublichat.capuchino.lat').replace(/\/$/, '');
export const FIREBASE_API_KEY = 'AIzaSyA_b1a0Zo4OIAj4KayD5ChtPWToANQ1nrA';
export const FIREBASE_PROJECT_ID = 'sublicuentasbot';
const SESSION_KEY = 'sublicuentas-session-v1';

const TRUSTED_API_HOSTS = new Set([
  'sublichat-hq.vercel.app',
  'sublichat.capuchino.lat',
  'sublicuentas.com',
  'www.sublicuentas.com',
]);

export function isRedirectStatus(status) {
  return [301, 302, 303, 307, 308].includes(Number(status));
}

export function resolveSafeRedirectUrl(currentUrl, location) {
  const target = new URL(String(location || ''), String(currentUrl || ''));
  if (target.protocol !== 'https:') throw new Error('El servidor intentó una redirección no segura.');
  if (!TRUSTED_API_HOSTS.has(target.hostname.toLowerCase())) {
    throw new Error(`El servidor intentó redirigir a un dominio no autorizado: ${target.hostname}`);
  }
  return target.href;
}

function headerValue(headers, wanted) {
  const entries = Object.entries(headers || {});
  const found = entries.find(([key]) => key.toLowerCase() === String(wanted).toLowerCase());
  return found ? String(found[1] || '') : '';
}

async function nativeJsonRequest(url, { method='GET', headers={}, body }={}, redirectsLeft=4) {
  let core;
  try { core = await import('@capacitor/core'); } catch (_) { return null; }
  if (!core?.Capacitor?.isNativePlatform?.()) return null;

  const response = await core.CapacitorHttp.request({
    url,
    method,
    headers: { Accept:'application/json', ...headers },
    data: body,
    disableRedirects: true,
    connectTimeout: 15000,
    readTimeout: 30000,
  });

  if (isRedirectStatus(response.status)) {
    if (redirectsLeft <= 0) throw new Error('El servidor redirigió demasiadas veces el acceso.');
    const location = headerValue(response.headers, 'location');
    if (!location) {
      const error = new Error(`El servidor redirigió el acceso (${response.status}) sin indicar destino.`);
      error.status = response.status;
      throw error;
    }
    const nextUrl = resolveSafeRedirectUrl(url, location);
    const nextMethod = Number(response.status) === 303 ? 'GET' : method;
    const nextBody = Number(response.status) === 303 ? undefined : body;
    return nativeJsonRequest(nextUrl, { method:nextMethod, headers, body:nextBody }, redirectsLeft - 1);
  }

  const data = typeof response.data === 'string'
    ? (() => { try { return JSON.parse(response.data); } catch (_) { return response.data ? { error:response.data.slice(0,300) } : {}; } })()
    : (response.data || {});
  return { status:Number(response.status || 0), ok:Number(response.status) >= 200 && Number(response.status) < 300, data };
}

// R69 · Paquete B — sesión en ALMACÉN SEGURO (Android Keystore vía @aparajita/capacitor-secure-storage).
// • El idToken vive SOLO en memoria. En el almacén seguro va lo mínimo para restaurar: refreshToken + metadatos.
// • localStorage/sessionStorage ya no guardan tokens (se migran y se borran al abrir).
// • Fuera del teléfono (pruebas/navegador) se usa un almacén EN MEMORIA explícito: nunca se cae a localStorage.
// La sesión solo se cierra con "Cerrar sesión" o tras 1 día completo sin usar la app.
export const SESSION_IDLE_MS = 24 * 60 * 60 * 1000;
const SECURE_KEY = 'session';
let SESSION = null;          // sesión activa (con idToken) en memoria
let secureImpl = null;       // { get(k), set(k,v), remove(k), mode }
const memoryStore = new Map();
export async function secureStore() {
  if (secureImpl) return secureImpl;
  let native = false;
  try { const { Capacitor } = await import('@capacitor/core'); native = Capacitor?.isNativePlatform?.() === true; } catch (_) { native = false; }
  if (native) {
    const { SecureStorage } = await import('@aparajita/capacitor-secure-storage'); // si falla, la promesa rechaza: no hay respaldo inseguro
    await SecureStorage.setKeyPrefix('sublicuentas_');
    secureImpl = { mode: 'keystore', get: async k => { const v = await SecureStorage.get(k); return v == null ? null : (typeof v === 'string' ? JSON.parse(v) : v); }, set: (k, v) => SecureStorage.set(k, JSON.stringify(v)), remove: k => SecureStorage.remove(k) };
  } else {
    secureImpl = { mode: 'memory', get: async k => (memoryStore.has(k) ? JSON.parse(memoryStore.get(k)) : null), set: async (k, v) => { memoryStore.set(k, JSON.stringify(v)); }, remove: async k => { memoryStore.delete(k); } };
  }
  return secureImpl;
}
export function __setSecureStoreForTests(impl) { secureImpl = impl; SESSION = null; }
function legacyStores() { const out = []; try { if (typeof localStorage !== 'undefined') out.push(localStorage); } catch (_) {} try { if (typeof sessionStorage !== 'undefined') out.push(sessionStorage); } catch (_) {} return out; }
function wipeLegacy() { for (const st of legacyStores()) { try { st.removeItem(SESSION_KEY); } catch (_) {} } }
const persistable = s => s ? { usuario: s.usuario, role: s.role, uid: s.uid, displayName: s.displayName, email: s.email, refreshToken: s.refreshToken, lastActiveAt: s.lastActiveAt || Date.now(), savedAt: Date.now() } : null;
async function persistSecure(s) { try { const st = await secureStore(); if (s) await st.set(SECURE_KEY, persistable(s)); else await st.remove(SECURE_KEY); } catch (e) { console.warn('[sesion] almacén seguro no disponible'); throw e; } }
// Se llama una vez al abrir la app (antes de pintar la pantalla con datos).
export async function hydrateSession() {
  let value = null;
  for (const st of legacyStores()) { // migración desde versiones que guardaban la sesión en texto plano
    try { const v = JSON.parse(st.getItem(SESSION_KEY) || 'null'); if (v && !value) value = { ...v, lastActiveAt: Number(v.lastActiveAt) || Date.now() }; } catch (_) {}
  }
  wipeLegacy();
  if (value) { SESSION = value; await persistSecure(value).catch(() => {}); }
  else { try { const st = await secureStore(); const saved = await st.get(SECURE_KEY); if (saved) SESSION = { ...saved, idToken: '', expiresAt: 0 }; } catch (_) { SESSION = null; } }
  if (SESSION && Number(SESSION.lastActiveAt) && Date.now() - Number(SESSION.lastActiveAt) > SESSION_IDLE_MS) { SESSION = null; await persistSecure(null).catch(() => {}); }
  return SESSION;
}
export function getSession() {
  if (SESSION && Number(SESSION.lastActiveAt) && Date.now() - Number(SESSION.lastActiveAt) > SESSION_IDLE_MS) { SESSION = null; persistSecure(null).catch(() => {}); } // 1 día sin actividad
  return SESSION;
}
export function setSession(value) {
  wipeLegacy();
  SESSION = value ? { ...value, lastActiveAt: Date.now() } : null;
  persistSecure(SESSION).catch(() => {});
}
// Marca actividad (toques, teclas, llamadas al servidor). Guarda en el almacén seguro como máximo cada 30 s.
let lastTouchWrite = 0;
export function touchSession() {
  if (!SESSION) return;
  const now = Date.now();
  if (Number(SESSION.lastActiveAt) && now - Number(SESSION.lastActiveAt) > SESSION_IDLE_MS) return; // ya venció: no se revive
  SESSION.lastActiveAt = now;
  if (now - lastTouchWrite < 30000) return;
  lastTouchWrite = now; persistSecure(SESSION).catch(() => {});
}

export function clearSession() { setSession(null); }

async function readJson(response) {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch (_) { return { error:text.slice(0,300) }; }
}

async function requestJson(url, { method='GET', headers={}, body, retryAuth=true }={}) {
  const native = await nativeJsonRequest(url, { method, headers, body });
  let status, ok, data;
  if (native) {
    ({ status, ok, data } = native);
  } else {
    const response = await fetch(url, {
      method,
      headers: { Accept:'application/json', ...headers },
      body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)),
    });
    status = response.status;
    ok = response.ok;
    data = await readJson(response);
  }
  if (status === 401 && retryAuth && getSession()?.refreshToken) {
    await refreshSession();
    const session = getSession();
    const nextHeaders = { ...headers, ...(session?.idToken ? { Authorization:`Bearer ${session.idToken}` } : {}) };
    return requestJson(url, { method, headers:nextHeaders, body, retryAuth:false });
  }
  if (!ok || data?.ok === false) {
    const error = new Error(data?.error || `Solicitud falló (${status})`);
    error.status = status;
    error.data = data;
    throw error;
  }
  return data;
}

export function buildLoginPayload(usuario, clave) {
  return {
    usuario:String(usuario || '').trim().toLowerCase(),
    clave:String(clave ?? ''),
  };
}

export function loginWebFetch() {
  const original = globalThis.CapacitorWebFetch;
  if (typeof original === 'function') return original.bind(globalThis);
  const regular = globalThis.fetch;
  return typeof regular === 'function' ? regular.bind(globalThis) : null;
}

export async function loginEndpointRequest(usuario, clave, fetchImpl = loginWebFetch()) {
  if (typeof fetchImpl !== 'function') throw new Error('No hay transporte web disponible para iniciar sesión.');
  const url = `${API_BASE}/api/login`;
  const response = await fetchImpl(url, {
    method:'POST',
    headers:{'Content-Type':'application/json','Accept':'application/json'},
    body:JSON.stringify(buildLoginPayload(usuario, clave)),
  });
  const data = await readJson(response);
  if (!response.ok || data?.ok === false) {
    const error = new Error(data?.error || `Solicitud falló (${response.status})`);
    error.status = Number(response.status || 0);
    error.data = data;
    throw error;
  }
  return data;
}

export async function loginUser(usuario, clave) {
  const first = await loginEndpointRequest(usuario, clave);
  if (!first?.token) throw new Error('El servidor no devolvió una sesión válida.');
  const auth = await requestJson(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(FIREBASE_API_KEY)}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:{ token:first.token, returnSecureToken:true }, retryAuth:false
  });
  const session = {
    usuario:first.usuario,
    role:first.role,
    uid:auth.localId || '',
    idToken:auth.idToken,
    refreshToken:auth.refreshToken,
    expiresAt:Date.now() + Math.max(60, Number(auth.expiresIn || 3600) - 60) * 1000,
  };
  setSession(session);
  return session;
}

export async function refreshSession() {
  const current = getSession();
  if (!current?.refreshToken) throw new Error('La sesión venció. Inicie sesión nuevamente.');
  const response = await fetch(`https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(FIREBASE_API_KEY)}`, {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`grant_type=refresh_token&refresh_token=${encodeURIComponent(current.refreshToken)}`,
  });
  const data = await readJson(response);
  if (!response.ok || !data.id_token) {
    // Solo se cierra si Firebase dice que el acceso ya no es válido; un error temporal (sin señal, 5xx) NO saca al usuario.
    const code = String(data?.error?.message || data?.error || '');
    if ([400, 401, 403].includes(Number(response.status)) && /TOKEN|USER_DISABLED|USER_NOT_FOUND|INVALID/i.test(code)) {
      clearSession();
      throw new Error('La sesión venció. Inicie sesión nuevamente.');
    }
    throw new Error('Sin conexión con el servidor. Intente de nuevo.');
  }
  const next = {
    ...current,
    idToken:data.id_token,
    refreshToken:data.refresh_token || current.refreshToken,
    uid:data.user_id || current.uid,
    expiresAt:Date.now() + Math.max(60, Number(data.expires_in || 3600) - 60) * 1000,
  };
  setSession(next);
  return next;
}

// R70: una sola renovación del token a la vez (antes 4 cargas en paralelo pedían 4 renovaciones al mismo tiempo).
let refreshing = null;
function refreshOnce() { if (!refreshing) refreshing = refreshSession().finally(() => { refreshing = null; }); return refreshing; }
async function validSession(force = false) {
  let session = getSession();
  if (!session) throw new Error('Inicie sesión.');
  if (force || !session.idToken || Number(session.expiresAt || 0) <= Date.now() + 30000) session = await refreshOnce();
  return session;
}

// R69 · Paquetes F y G — idempotencia, timeouts, reintentos y compatibilidad de versión.
export const API_VERSION = 2;
export const APP_BUILD = Number((typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_BUILD_NUMBER) || 1) || 1;
const READ_PATHS = new Set(['/api/mobile-core', '/api/chat', '/api/tmdb', '/api/partidos', '/api/login']);
const READ_ACTION_RE = /^(listar|list|get|obtener|leer|lectura|resumen|ranking|buscar|consultar|ver|detalle|asegurar_enlaces|historial|catalogo|config|perfil_get|estado)/i;
export function newOperationId() {
  try { if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID(); } catch (_) {}
  const b = new Uint8Array(16); try { globalThis.crypto.getRandomValues(b); } catch (_) { for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256); }
  b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128; const h = [...b].map(x => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
// Mutación = escribe datos. Los juegos quedan fuera (tienen su propio id de partida).
export function isMutation(path, body = {}) {
  if (READ_PATHS.has(path) || path === '/api/juegos') return false;
  const a = String(body?.accion || body?.action || body?.op || '');
  return !READ_ACTION_RE.test(a);
}
export const COMPAT = { minAppBuild: 0, blocked: false, message: '' };
export function setCompatibility(cfg = {}) {
  COMPAT.minAppBuild = Number(cfg.minAppBuild) || 0;
  COMPAT.blocked = COMPAT.minAppBuild > APP_BUILD;
  COMPAT.message = COMPAT.blocked ? `Actualización requerida: instale la versión ${COMPAT.minAppBuild} o superior de la app para guardar cambios.` : '';
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => { const e = new Error('Tiempo de espera agotado'); e.timeout = true; rej(e); }, ms))]);
const isNetworkError = e => e?.timeout || /network|failed to fetch|load failed|timeout|tiempo de espera|conexi/i.test(String(e?.message || '')) && !e?.status;
const sleep = ms => new Promise(r => setTimeout(r, ms));
export async function authPost(path, body={}) {
  const mutation = isMutation(path, body);
  if (mutation && COMPAT.blocked) { const e = new Error(COMPAT.message); e.updateRequired = true; throw e; }
  const operationId = mutation ? String(body?.operationId || newOperationId()) : '';
  const payload = mutation ? { ...body, operationId, clientMeta: { source: 'android', appBuild: APP_BUILD, apiVersion: API_VERSION, requestId: newOperationId() } } : body;
  let forceRefresh = false;
  const attempt = async () => {
    const session = await validSession(forceRefresh);
    touchSession();
    return withTimeout(requestJson(`${API_BASE}${path}`, {
      method:'POST',
      headers:{ 'Content-Type':'application/json', Authorization:`Bearer ${session.idToken}` }, // build/versión/operationId viajan en el cuerpo (no rompe CORS)
      body: payload,
    }), mutation ? 30000 : 45000);
  };
  // Lecturas: reintento corto con espera creciente. Mutaciones: 1 reintento SOLO con el MISMO operationId.
  const tries = mutation ? 2 : 3;
  for (let i = 0; ; i++) {
    try {
      const r = await attempt();
      if (r?.updateRequired || r?.code === 'UPDATE_REQUIRED') { setCompatibility({ minAppBuild: r.minAppBuild }); const e = new Error(COMPAT.message || 'Actualización requerida'); e.updateRequired = true; throw e; }
      return r;
    } catch (e) {
      // R70: token vencido o rechazado (401) → se renueva UNA vez y se repite la misma solicitud (mismo operationId).
      if (Number(e?.status) === 401 && !forceRefresh) { forceRefresh = true; continue; }
      if (e?.status === 426 || /UPDATE_REQUIRED/.test(String(e?.message || ''))) { setCompatibility({ minAppBuild: e?.data?.minAppBuild || APP_BUILD + 1 }); const u = new Error(COMPAT.message); u.updateRequired = true; throw u; }
      if (i + 1 >= tries || !isNetworkError(e)) throw e;
      await sleep(mutation ? 1200 : [400, 1200][i] || 1200);
    }
  }
}

export function decodeFirestoreValue(value={}) {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  if ('referenceValue' in value) return value.referenceValue;
  if ('geoPointValue' in value) return value.geoPointValue;
  if ('arrayValue' in value) return (value.arrayValue?.values || []).map(decodeFirestoreValue);
  if ('mapValue' in value) {
    return Object.fromEntries(Object.entries(value.mapValue?.fields || {}).map(([k,v])=>[k,decodeFirestoreValue(v)]));
  }
  return undefined;
}

export function decodeFirestoreDocument(doc={}) {
  const fields = Object.fromEntries(Object.entries(doc.fields || {}).map(([k,v])=>[k,decodeFirestoreValue(v)]));
  return { id:String(doc.name || '').split('/').pop() || '', ...fields };
}

export async function firestoreListCollection(collection, { pageSize=500, maxPages=12 }={}) {
  let session = await validSession();
  let pageToken = '';
  const rows = [];
  for (let page=0; page<maxPages; page += 1) {
    const qs = new URLSearchParams({ pageSize:String(pageSize) });
    if (pageToken) qs.set('pageToken', pageToken);
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${encodeURIComponent(collection)}?${qs}`;
    let response = await fetch(url, { headers:{Authorization:`Bearer ${session.idToken}`, Accept:'application/json'} });
    if (response.status === 401 && session.refreshToken) {
      session = await refreshSession();
      response = await fetch(url, { headers:{Authorization:`Bearer ${session.idToken}`, Accept:'application/json'} });
    }
    const data = await readJson(response);
    if (!response.ok) throw new Error(data?.error?.message || data?.error || `No se pudo leer ${collection}.`);
    rows.push(...(data.documents || []).map(decodeFirestoreDocument));
    pageToken = data.nextPageToken || '';
    if (!pageToken) break;
  }
  return rows;
}


function crmId(prefix='id') {
  const uuid = globalThis.crypto?.randomUUID?.();
  if (uuid) return `${prefix}_${uuid.replace(/-/g,'')}`;
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,10)}`;
}

function crmPlatformKey(value='') {
  return String(value || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]/g,'');
}

function crmPlatformNoPin(plataforma='') {
  const p=crmPlatformKey(plataforma);
  return p.includes('netflixvip') || p==='vipnetflix' || p.includes('spotify') || p.includes('deezer') || p.includes('youtube') || p.includes('office') || p.includes('paramount') || p.includes('vix') || p.includes('canva') || p.includes('gemini') || p.includes('chatgpt') || p.includes('duolingo') || p.includes('stella') || p.includes('oleada') || p.includes('latintv') || p.includes('liontv') || p.includes('evoutouch') || p.includes('iptv') || p.includes('viki') || p.includes('windows') || p.includes('adobe') || p.includes('eset');
}

function crmPlatformNoPassword(plataforma='') {
  const p=crmPlatformKey(plataforma);
  return p.includes('canva') || p.includes('gemini') || p.includes('chatgpt') || p.includes('duolingo') || p.includes('adobeexpress');
}

function crmPlatformNoEmail(plataforma='') {
  const p=crmPlatformKey(plataforma);
  return ['windows10','windows11','eset','esetnod32'].includes(p);
}

// Number(null) y Number('') dan 0: una venta NUEVA viajaba con servicioIndex:0 y el servidor decía
// "La ficha seleccionada cambió de posición". Solo un entero real cuenta como índice.
export function intOrNull(v) {
  if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) return null;
  const n = Number(v);
  return Number.isInteger(n) && n >= 0 ? n : null;
}

export function buildCrmUpsertPayload(form={}, ids={}) {
  const nombrePerfil=String(form.nombrePerfil || form.nombre || '').trim();
  const telefono=String(form.telefono || '').trim();
  const plataforma=String(form.plataforma || '').trim();
  const vendedor=String(form.vendedor || '').trim();
  const vendedorTelefono=String(form.vendedorTelefono || '').trim();
  const meses=Math.max(1, Math.min(24, Math.round(Number(form.mesesContratados || 1) || 1)));
  const precio=Number(form.precio || 0);
  const fechaRenovacion=String(form.fechaRenovacion || '').trim();
  const compraId=String(ids.compraId || form.compraId || crmId('compra'));
  const inputProfiles=Array.isArray(form.perfiles) && form.perfiles.length ? form.perfiles : [{
    perfilId:ids.perfilId || form.perfilId,
    nombre:form.perfil || nombrePerfil || 'Perfil 1', perfil:form.perfil || nombrePerfil || 'Perfil 1',
    correo:form.correo, clave:form.clave, pinPerfil:form.pinPerfil,
    dispositivo:form.dispositivo, esRoku:form.esRoku===true,
  }];
  const perfiles=inputProfiles.map((p,index)=>{
    const correo=crmPlatformNoEmail(plataforma) ? '' : String(p?.correo ?? form.correo ?? '').trim();
    const clave=crmPlatformNoPassword(plataforma) ? '' : String(p?.clave ?? form.clave ?? '').trim();
    const pinPerfil=crmPlatformNoPin(plataforma) ? '' : String(p?.pinPerfil ?? form.pinPerfil ?? '').trim();
    const dispositivo=['tv','cel'].includes(String(p?.dispositivo ?? form.dispositivo ?? '')) ? String(p?.dispositivo ?? form.dispositivo) : '';
    const nombre=String(p?.nombre || p?.perfil || form.perfil || nombrePerfil || `Perfil ${index+1}`).trim();
    const out={
      perfilId:String(p?.perfilId || (index===0 ? ids.perfilId : '') || crmId('perfil')),
      nombre, perfil:nombre, correo, clave, dispositivo,
      esRoku:dispositivo==='tv' && (p?.esRoku===true || form.esRoku===true),
    };
    if(pinPerfil) out.pinPerfil=pinPerfil;
    return out;
  });
  const principal=perfiles[0] || {};
  const servicio={
    compraId,
    modalidad:perfiles.length>1?'multiperfil':'individual',
    plataforma,
    precio:Number.isFinite(precio) ? precio : 0,
    fechaRenovacion,
    mesesContratados:meses,
    visibilidadUrl:form.visibilidadUrl && typeof form.visibilidadUrl==='object' ? form.visibilidadUrl : {modo:'plataforma'},
    correo:principal.correo || '',
    clave:principal.clave || '',
    perfil:principal.perfil || nombrePerfil,
    perfiles,
    vendedor,
    vendedor_norm:String(vendedor||'').toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' '),
    vendedorTelefono,
    beneficiarioTipo:String(form.beneficiarioTipo || 'titular')==='tercero'?'tercero':'titular',
    beneficiarioNombre:String(form.beneficiarioNombre || '').trim(),
    dispositivo:principal.dispositivo || '',
    esRoku:principal.dispositivo==='tv' && principal.esRoku===true,
    ...(form.iptvProveedor ? {iptvProveedor:String(form.iptvProveedor)} : {}),
    ...(Number(form.iptvPantallas||0) ? {iptvPantallas:Number(form.iptvPantallas)} : {}),
    ...(form.iptvLista ? {iptvLista:String(form.iptvLista)} : {}),
    ...(form.iptvHora ? {iptvHora:String(form.iptvHora)} : {}),
    ...(iptvUsesMaxPlayer(plataforma) ? {maxPlayer:form.maxPlayer===true, maxPlayerUsuario:form.maxPlayer===true?String(form.maxPlayerUsuario||'').trim():'', maxPlayerClave:form.maxPlayer===true?String(form.maxPlayerClave||'').trim():''} : {}),
    ...(Number(form.oleadaDispositivos||0) ? {oleadaDispositivos:Number(form.oleadaDispositivos)} : {}),
    ...(Number(form.stellaDispositivos||0) ? {stellaDispositivos:Number(form.stellaDispositivos)} : {}),
  };
  if (crmPlatformNoPassword(plataforma)) servicio.sinClave=true;
  if (crmPlatformNoPin(plataforma)) servicio.sinPinPerfil=true;
  else if (principal.pinPerfil) servicio.pinPerfil=principal.pinPerfil;
  return {
    accion:'ficha_upsert',
    ...(form.operationId ? { operationId:String(form.operationId) } : {}),
    clienteId:String(form.clienteId || ''),
    forzarNuevoServicio:form.forzarNuevoServicio===true,
    servicioIndex:intOrNull(form.servicioIndex),
    plataformaOriginal:String(form.plataformaOriginal || ''),
    correoOriginal:String(form.correoOriginal || ''),
    cliente:{ nombrePerfil, telefono, vendedor, vendedorTelefono },
    servicio,
    fichaTexto:String(form.fichaTexto || ''),
  };
}

export async function createCrmSale(form={}) {
  return authPost('/api/renovar', buildCrmUpsertPayload(form));
}

export function buildEnsureLinksPayload(clienteId='', beneficiarioKey='titular') {
  return { accion:'asegurar_enlaces', clienteId:String(clienteId||''), beneficiarioKey:String(beneficiarioKey||'titular') };
}

export async function ensureClientLinks(clienteId='', beneficiarioKey='titular') {
  return authPost('/api/renovar', buildEnsureLinksPayload(clienteId, beneficiarioKey));
}

export function buildNoRenewalPayload(row={}) {
  return {
    accion:'no_renovo',
    preservarFicha:true,
    clienteId:String(row?.clienteId || ''),
    clienteNorm:String(row?.nombreNorm || ''),
    telefono:String(row?.telefono || ''),
    plataforma:String(row?.plataforma || ''),
    correo:String(row?.correo || ''),
    servicioIndex:intOrNull(row?.servicioIndex),
    compraId:String(row?.compraId || ''),
  };
}

export async function removeNonRenewingService(row={}) {
  return authPost('/api/renovar', buildNoRenewalPayload(row));
}

export function buildRenewalPayload(row, options=30) {
  const opt=typeof options==='number' ? {days:options} : (options || {});
  const payload={
    accion:'renovar',
    clienteId:String(row?.clienteId || ''),
    clienteNorm:String(row?.nombreNorm || ''),
    telefono:String(row?.telefono || ''),
    plataforma:String(row?.plataforma || ''),
    correo:String(row?.correo || ''),
    servicioIndex:intOrNull(row?.servicioIndex),
    compraId:String(row?.compraId || ''),
    fechaActual:String(row?.fechaRenovacion || ''),
  };
  if (String(opt.exactDate || '').trim()) payload.fechaExacta=String(opt.exactDate).trim();
  else payload.dias=Math.max(1,Number(opt.days || 30));
  return payload;
}

export async function renewService(row, options=30) {
  return authPost('/api/renovar', buildRenewalPayload(row, options));
}

export async function registerRenewalPayment(row, amount) {
  const monto = Number(amount || row?.precio || 0);
  if (!monto) return { ok:true, skipped:true };
  const now = new Date();
  const yyyy = now.getFullYear(), mm=String(now.getMonth()+1).padStart(2,'0'), dd=String(now.getDate()).padStart(2,'0');
  return authPost('/api/finanzas', {
    accion:'registrar_cobro',
    // R72: si el servicio es de un tercero, el cobro queda a nombre de esa persona (la ficha sigue siendo del titular).
    clienteNombre:(String(row?.raw?.beneficiarioTipo||'').toLowerCase()==='tercero' && String(row?.raw?.beneficiarioNombre||'').trim()) ? String(row.raw.beneficiarioNombre).trim() : (row?.nombre || ''),
    clienteNorm:row?.nombreNorm || '',
    telefono:row?.telefono || '',
    plataforma:row?.plataforma || '',
    monto,
    metodoPago:'No especificado',
    vendedor:row?.vendedor || '',
    fechaPago:`${yyyy}-${mm}-${dd}`,
  });
}

export function buildChargeAiPayload(group={}, currentText='', today='', history=[]) {
  const services=Array.isArray(group?.servicios)&&group.servicios.length?group.servicios:[group];
  const names=services.map(s=>chargePlatformName(s?.plataforma||'Servicio')).filter(Boolean).join(' + ') || 'Servicio';
  const total=Number(group?.total ?? services.reduce((sum,s)=>sum+Number(s?.precio||0),0)) || 0;
  const date=String(group?.fechaRenovacion || services[0]?.fechaRenovacion || 'fecha por confirmar');
  // Variedad real: un estilo al azar por intento (no depende de que el modelo "decida" cambiar) +
  // la lista de mensajes ya usados en esta sesión, para que nunca reciba el mismo esqueleto dos veces
  // (mandar el mismo mensaje a distintos clientes es justo lo que puede parecer spam a WhatsApp).
  const styles=['cálido y cercano, como si le escribiera a un vecino de confianza','entusiasta y con energía, casi celebrando la renovación','elegante y breve, muy directo al grano','juguetón, con un chiste ligero sobre el entretenimiento','servicial y tranquilo, como una nota de recordatorio amable','curioso, abriendo con una pregunta en vez de un saludo','agradecido, resaltando que sigue confiando en el servicio','urgente mas no agresivo, recordando que la fecha está cerca'];
  const openers=['Empiece con un saludo directo por su nombre.','Empiece con una pregunta corta.','Empiece con una exclamación breve.','Empiece agradeciéndole por seguir con el servicio.','Empiece mencionando el día de hoy o la fecha.','No empiece con la palabra Hola.'];
  const style=styles[Math.floor(Math.random()*styles.length)];
  const opener=openers[Math.floor(Math.random()*openers.length)];
  const prevList=[...new Set([String(currentText||''),...(Array.isArray(history)?history:[]).map(String)])].filter(Boolean).slice(0,6);
  const prompt=`Genere un mensaje NUEVO de renovación de entretenimiento premium para WhatsApp.
REGLA OBLIGATORIA: exactamente 2 líneas cortas y máximo 300 caracteres en total.
Use "usted", español natural de Honduras, tono bonito, cordial y comercial, con 2 a 4 emojis.
Use negrita de WhatsApp con asteriscos en cliente, servicios y costo.
La primera línea debe saludar y emocionar; la segunda debe incluir servicio, fecha, costo y una pregunta breve para renovar.
PROHIBIDO agregar cuentas bancarias, transferencias, depósitos, tarjetas, comprobantes o cualquier método/detalle de pago.
No invente precios, fechas, servicios ni promociones. No escriba explicaciones, listas ni párrafos adicionales.
ESTILO DE ESTE MENSAJE: ${style}. ${opener}
Cliente: "${String(group?.nombre||'Cliente')}".
Servicios: ${names}.
Total: Lps ${total.toLocaleString('es-HN',{maximumFractionDigits:2})}.
Fecha: ${date}.
MENSAJES YA USADOS EN ESTA CONVERSACIÓN — el nuevo debe ser distinto en estructura, primeras palabras y frases a TODOS estos, no solo parecido:
${prevList.length?prevList.map((t,i)=>`(${i+1}) ${t}`).join('\n'):'(ninguno todavía)'}
Devuelva SOLO el nuevo mensaje, sin explicación.`;
  return {pregunta:prompt,hoy:String(today || new Date().toISOString().slice(0,10)),clientes:[],mode:'rewrite'};
}

export async function generateChargeMessageAI(group={}, currentText='', today='', history=[]) {
  return authPost('/api/chat', buildChargeAiPayload(group,currentText,today,history));
}

export async function loadMobileResource(resource, { pageSize=250, maxPages=24 }={}) {
  const items=[];
  let cursor='';
  for (let page=0; page<maxPages; page += 1) {
    const data=await authPost('/api/mobile-core', { action:'list', resource, limit:pageSize, cursor });
    items.push(...(Array.isArray(data?.items)?data.items:[]));
    cursor=String(data?.nextCursor || '');
    if (!cursor) break;
  }
  return items;
}

export async function loadCatalog() { return authPost('/api/catalogo-relojes', { accion:'cargar' }); }
export async function loadTickets(limit=80) { return authPost('/api/tickets', { accion:'listar', limit }); }
export async function ticketAction(payload={}) { return authPost('/api/tickets', payload); }
export async function deleteTicket(id) { return authPost('/api/tickets', { accion:'eliminar', id:String(id||'') }); }
// R77: códigos de plataformas desde el correo del hosting (Vercel, misma lógica del bot). Es lectura: no guarda nada.
export async function buscarCodigo(correo, modo='codigo') { return authPost('/api/codigos', { accion:'buscar', correo:String(correo||'').trim(), modo }); }
export async function loadAcademiaProgress() { return authPost('/api/academia', { accion:'obtener' }); }
export async function completeAcademiaLesson(leccion) { return authPost('/api/academia', { accion:'completar', leccion }); }
export async function loadProfile(usuario) { return authPost('/api/perfil', { accion:'obtener', usuario }); }
export function buildProfileSavePayload(usuario, profile={}) {
  const payload={ accion:'guardar', usuario:String(usuario||'').trim() };
  for (const key of ['nombre','cargo','telefono','area','funcionesExtra','color','emoji','tema','avatar','banner']) {
    if (typeof profile[key] === 'string') payload[key]=profile[key];
  }
  return payload;
}
export async function saveProfile(usuario, profile={}) { return authPost('/api/perfil', buildProfileSavePayload(usuario, profile)); }
export function raffleLoadPayload() { return { accion:'cargar' }; }
export async function loadRaffles() { return authPost('/api/sorteos', raffleLoadPayload()); }

export async function saveAcademiaSettings(avatar, mascot) { return authPost('/api/academia', { accion:'ajustes', avatar, mascot }); }
export async function searchMovies(query) { return authPost('/api/tmdb', { query:String(query||'').trim() }); }
export async function loadMatches(payload={}) { return authPost('/api/partidos', payload); }
export async function askSubli(pregunta, clientes=[], hoy='') {
  return authPost('/api/chat', { pregunta:String(pregunta||'').trim(), hoy:String(hoy || new Date().toISOString().slice(0,10)), clientes });
}

// Control financiero: egresos y cierre semanal (mismas acciones que usa Sublichat web en /api/finanzas).
export async function registerFinanceExpense({ motivo='', monto=0, banco='', fecha='' }={}) {
  return authPost('/api/finanzas', { accion:'registrar_egreso', motivo:String(motivo).trim(), monto:Number(monto), banco:String(banco).trim(), fecha:String(fecha||'').trim() });
}
export async function saveFinanceClosing({ fechaInicio='', fechaFin='', ingresos=0, egresos=0, neto=0, nota='' }={}) {
  return authPost('/api/finanzas', { accion:'guardar_cierre', fechaInicio, fechaFin, ingresos:Number(ingresos), egresos:Number(egresos), neto:Number(neto), nota:String(nota||'') });
}

export async function raffleAction(payload={}) { return authPost('/api/sorteos', payload); }

/* ───────────── Juegos PRO ───────────── */
export async function juegosResumen() { return authPost('/api/juegos', { accion: 'resumen' }); }
export async function juegosRegistrar(gameCode, roundId, metrics) { return authPost('/api/juegos', { accion: 'registrar', gameCode, roundId, metrics }); }
export async function juegosRanking(scope, extra = {}) { return authPost('/api/juegos', { accion: 'ranking', scope, ...extra }); }
