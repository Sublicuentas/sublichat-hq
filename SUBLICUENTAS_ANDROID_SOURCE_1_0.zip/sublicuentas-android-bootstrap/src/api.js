const env = (typeof import.meta !== 'undefined' && import.meta.env) ? import.meta.env : {};
export const API_BASE = String(env.VITE_API_BASE_URL || 'https://sublichat-hq.vercel.app').replace(/\/$/, '');
export const FIREBASE_API_KEY = 'AIzaSyA_b1a0Zo4OIAj4KayD5ChtPWToANQ1nrA';
export const FIREBASE_PROJECT_ID = 'sublicuentasbot';
const SESSION_KEY = 'sublicuentas-session-v1';

function storage() {
  try { return typeof sessionStorage !== 'undefined' ? sessionStorage : null; } catch (_) { return null; }
}

export function getSession() {
  const s = storage();
  if (!s) return null;
  try { return JSON.parse(s.getItem(SESSION_KEY) || 'null'); } catch (_) { return null; }
}

export function setSession(value) {
  const s = storage();
  if (!s) return;
  if (!value) s.removeItem(SESSION_KEY);
  else s.setItem(SESSION_KEY, JSON.stringify(value));
}

export function clearSession() { setSession(null); }

async function readJson(response) {
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch (_) { return { error:text.slice(0,300) }; }
}

async function requestJson(url, { method='GET', headers={}, body, retryAuth=true }={}) {
  const response = await fetch(url, {
    method,
    headers: { Accept:'application/json', ...headers },
    body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)),
  });
  const data = await readJson(response);
  if (response.status === 401 && retryAuth && getSession()?.refreshToken) {
    await refreshSession();
    const session = getSession();
    const nextHeaders = { ...headers, ...(session?.idToken ? { Authorization:`Bearer ${session.idToken}` } : {}) };
    return requestJson(url, { method, headers:nextHeaders, body, retryAuth:false });
  }
  if (!response.ok || data?.ok === false) {
    const error = new Error(data?.error || `Solicitud falló (${response.status})`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

export async function loginUser(usuario, clave) {
  const first = await requestJson(`${API_BASE}/api/login`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:{ usuario, clave }, retryAuth:false
  });
  if (!first?.token) throw new Error('El servidor no devolvió una sesión válida.');
  const auth = await requestJson(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${encodeURIComponent(FIREBASE_API_KEY)}`, {
    method:'POST', headers:{'Content-Type':'application/json'}, body:{ token:first.token, returnSecureToken:true }, retryAuth:false
  });
  const session = {
    usuario:first.usuario,
    role:first.role,
    uid:auth.localId || '',
    idToken:auth.idToken,
    refreshToken:auth.refreshToken,
    expiresAt:Date.now() + Math.max(60, Number(auth.expiresIn || 3600) - 60) * 1000,
  };
  setSession(session);
  return session;
}

export async function refreshSession() {
  const current = getSession();
  if (!current?.refreshToken) throw new Error('La sesión venció. Inicie sesión nuevamente.');
  const response = await fetch(`https://securetoken.googleapis.com/v1/token?key=${encodeURIComponent(FIREBASE_API_KEY)}`, {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`grant_type=refresh_token&refresh_token=${encodeURIComponent(current.refreshToken)}`,
  });
  const data = await readJson(response);
  if (!response.ok || !data.id_token) {
    clearSession();
    throw new Error('La sesión venció. Inicie sesión nuevamente.');
  }
  const next = {
    ...current,
    idToken:data.id_token,
    refreshToken:data.refresh_token || current.refreshToken,
    uid:data.user_id || current.uid,
    expiresAt:Date.now() + Math.max(60, Number(data.expires_in || 3600) - 60) * 1000,
  };
  setSession(next);
  return next;
}

async function validSession() {
  let session = getSession();
  if (!session) throw new Error('Inicie sesión.');
  if (Number(session.expiresAt || 0) <= Date.now()) session = await refreshSession();
  return session;
}

export async function authPost(path, body={}) {
  const session = await validSession();
  return requestJson(`${API_BASE}${path}`, {
    method:'POST',
    headers:{'Content-Type':'application/json', Authorization:`Bearer ${session.idToken}`},
    body,
  });
}

export function decodeFirestoreValue(value={}) {
  if ('nullValue' in value) return null;
  if ('stringValue' in value) return value.stringValue;
  if ('booleanValue' in value) return Boolean(value.booleanValue);
  if ('integerValue' in value) return Number(value.integerValue);
  if ('doubleValue' in value) return Number(value.doubleValue);
  if ('timestampValue' in value) return value.timestampValue;
  if ('referenceValue' in value) return value.referenceValue;
  if ('geoPointValue' in value) return value.geoPointValue;
  if ('arrayValue' in value) return (value.arrayValue?.values || []).map(decodeFirestoreValue);
  if ('mapValue' in value) {
    return Object.fromEntries(Object.entries(value.mapValue?.fields || {}).map(([k,v])=>[k,decodeFirestoreValue(v)]));
  }
  return undefined;
}

export function decodeFirestoreDocument(doc={}) {
  const fields = Object.fromEntries(Object.entries(doc.fields || {}).map(([k,v])=>[k,decodeFirestoreValue(v)]));
  return { id:String(doc.name || '').split('/').pop() || '', ...fields };
}

export async function firestoreListCollection(collection, { pageSize=500, maxPages=12 }={}) {
  let session = await validSession();
  let pageToken = '';
  const rows = [];
  for (let page=0; page<maxPages; page += 1) {
    const qs = new URLSearchParams({ pageSize:String(pageSize) });
    if (pageToken) qs.set('pageToken', pageToken);
    const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${encodeURIComponent(collection)}?${qs}`;
    let response = await fetch(url, { headers:{Authorization:`Bearer ${session.idToken}`, Accept:'application/json'} });
    if (response.status === 401 && session.refreshToken) {
      session = await refreshSession();
      response = await fetch(url, { headers:{Authorization:`Bearer ${session.idToken}`, Accept:'application/json'} });
    }
    const data = await readJson(response);
    if (!response.ok) throw new Error(data?.error?.message || data?.error || `No se pudo leer ${collection}.`);
    rows.push(...(data.documents || []).map(decodeFirestoreDocument));
    pageToken = data.nextPageToken || '';
    if (!pageToken) break;
  }
  return rows;
}

export function buildRenewalPayload(row, days=30) {
  return {
    accion:'renovar',
    clienteId:String(row?.clienteId || ''),
    clienteNorm:String(row?.nombreNorm || ''),
    telefono:String(row?.telefono || ''),
    plataforma:String(row?.plataforma || ''),
    correo:String(row?.correo || ''),
    servicioIndex:Number.isInteger(Number(row?.servicioIndex)) ? Number(row.servicioIndex) : null,
    compraId:String(row?.compraId || ''),
    dias:Number(days),
    fechaActual:String(row?.fechaRenovacion || ''),
  };
}

export async function renewService(row, days=30) {
  return authPost('/api/renovar', buildRenewalPayload(row, days));
}

export async function registerRenewalPayment(row, amount) {
  const monto = Number(amount || row?.precio || 0);
  if (!monto) return { ok:true, skipped:true };
  const now = new Date();
  const yyyy = now.getFullYear(), mm=String(now.getMonth()+1).padStart(2,'0'), dd=String(now.getDate()).padStart(2,'0');
  return authPost('/api/finanzas', {
    accion:'registrar_cobro',
    clienteNombre:row?.nombre || '',
    clienteNorm:row?.nombreNorm || '',
    telefono:row?.telefono || '',
    plataforma:row?.plataforma || '',
    monto,
    metodoPago:'No especificado',
    vendedor:row?.vendedor || '',
    fechaPago:`${yyyy}-${mm}-${dd}`,
  });
}

export async function loadCatalog() { return authPost('/api/catalogo-relojes', { accion:'cargar' }); }
export async function loadTickets(limit=80) { return authPost('/api/tickets', { accion:'listar', limit }); }
export async function loadProfile(usuario) { return authPost('/api/perfil', { accion:'obtener', usuario }); }
export function raffleLoadPayload() { return { accion:'cargar' }; }
export async function loadRaffles() { return authPost('/api/sorteos', raffleLoadPayload()); }
export async function loadTvAvailability() { return authPost('/api/activar-tv', { action:'availability' }); }
