// Prepara una foto del teléfono para subirla: la reduce y la comprime hasta que quepa en el límite del servidor
// (api/perfil.js acepta hasta 850 000 caracteres). Así una foto de cámara de varios MB ya no se rechaza.
export const AVATAR_MAX_CHARS = 420000;   // muy por debajo del límite (850 000) para dejar margen
export const AVATAR_STEPS = Object.freeze([[640, 0.86], [560, 0.8], [480, 0.74], [400, 0.68], [320, 0.6], [256, 0.55]]);

export function fitSize(width, height, maxSide) {
  const w = Number(width) || 0, h = Number(height) || 0;
  if (!w || !h) return { w: 0, h: 0 };
  const scale = Math.min(1, maxSide / Math.max(w, h));
  return { w: Math.max(1, Math.round(w * scale)), h: Math.max(1, Math.round(h * scale)) };
}

// draw(side, quality) → dataURL. Se prueban tamaños cada vez menores hasta que el resultado cabe.
export function compressToLimit(draw, { maxChars = AVATAR_MAX_CHARS, steps = AVATAR_STEPS } = {}) {
  let last = '';
  for (const [side, quality] of steps) {
    last = draw(side, quality);
    if (last && last.length <= maxChars) return last;
  }
  throw new Error('La foto es demasiado grande incluso reducida. Prueba con otra imagen.');
}

async function loadBitmap(file) {
  if (typeof createImageBitmap === 'function') {
    try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (_) { /* cae al método clásico */ }
  }
  const url = URL.createObjectURL(file);
  try {
    return await new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => reject(new Error('No se pudo leer la imagen.')); img.src = url; });
  } finally { URL.revokeObjectURL(url); }
}

export async function prepareAvatarImage(file, opts = {}) {
  if (!file || !String(file.type || '').startsWith('image/')) throw new Error('Seleccione una imagen válida.');
  if (file.size > 40 * 1024 * 1024) throw new Error('Esa imagen es enorme (más de 40 MB). Elige otra.');
  const bmp = await loadBitmap(file);
  const srcW = bmp.width || bmp.naturalWidth, srcH = bmp.height || bmp.naturalHeight;
  const draw = (side, quality) => {
    const { w, h } = fitSize(srcW, srcH, side);
    const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, w, h);          // PNG con transparencia: fondo blanco, no negro
    ctx.drawImage(bmp, 0, 0, w, h);
    return canvas.toDataURL('image/jpeg', quality);
  };
  try { return compressToLimit(draw, opts); } finally { if (typeof bmp.close === 'function') bmp.close(); }
}
