// Calculadora de venta (Sublicuentas): módulo aislado. Lógica pura + pantalla en HTML.
// Flujo: elegir productos → ajustar cantidades → descuento (L o %) o "Quiero cobrar" → total a cobrar, todo en tiempo real.
// Una sola fuente de verdad: el estado guarda SOLO lo que elige la persona; subtotal, descuento y total se calculan siempre desde ahí.
const esc = (v = '') => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export const CALC_STORAGE_KEY = 'sublichat-calc-v1';        // precios personalizados (mismo mecanismo que usa la app: localStorage)
export const CALC_HISTORY_KEY = 'sublichat-calc-history-v1'; // últimas cotizaciones guardadas
export const CALC_CATEGORIES = Object.freeze([['todos', 'Todos'], ['streaming', 'Streaming'], ['musica', 'Música'], ['herramientas', 'Herramientas'], ['iptv', 'IPTV']]);
export const QUICK_DISCOUNTS = Object.freeze([5, 10, 20, 30]);
export const QUICK_PERCENTS = Object.freeze([5, 10, 15, 20]);

// ÚNICO lugar con los precios iniciales (no están regados por el código). Se editan desde "Editar precios".
export const DEFAULT_CATALOG = Object.freeze([
  { id: 'netflix', nombre: 'Netflix', categoria: 'streaming', precio: 150, logo: 'netflix', activo: true },
  { id: 'prime', nombre: 'Prime Video', categoria: 'streaming', precio: 80, logo: 'prime', activo: true },
  { id: 'vix', nombre: 'VIX', categoria: 'streaming', precio: 60, logo: 'vix', activo: true },
  { id: 'disney', nombre: 'Disney+', categoria: 'streaming', precio: 100, logo: 'disney', activo: true },
  { id: 'max', nombre: 'Max', categoria: 'streaming', precio: 80, logo: 'hbo', activo: true },
  { id: 'crunchyroll', nombre: 'Crunchyroll', categoria: 'streaming', precio: 80, logo: 'crunchyroll', activo: true },
  { id: 'paramount', nombre: 'Paramount+', categoria: 'streaming', precio: 80, logo: 'paramount', activo: true },
  { id: 'spotify', nombre: 'Spotify', categoria: 'musica', precio: 70, logo: 'spotify', activo: true },
  { id: 'youtube', nombre: 'YouTube Premium', categoria: 'streaming', precio: 90, logo: 'youtube', activo: true },
  { id: 'deezer', nombre: 'Deezer', categoria: 'musica', precio: 60, logo: 'deezer', activo: true },
  { id: 'canva', nombre: 'Canva', categoria: 'herramientas', precio: 50, logo: 'canva', activo: true },
  { id: 'gemini', nombre: 'Gemini Pro', categoria: 'herramientas', precio: 500, logo: 'gemini', activo: true },
  { id: 'office365', nombre: 'Office 365', categoria: 'herramientas', precio: 350, logo: 'office365', activo: true },
  { id: 'iptv', nombre: 'IPTV', categoria: 'iptv', precio: 130, logo: 'iptv', activo: true },
  { id: 'oleada', nombre: 'Oleada TV', categoria: 'iptv', precio: 90, logo: 'oleada-tv', activo: true },
]);

/* ───────────── números y moneda ───────────── */
export const round2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
// Vacío es válido (= sin valor). Negativos, NaN y texto no lo son.
export function parseAmount(v) {
  if (v === '' || v == null) return { ok: true, value: null };
  const n = Number(String(v).replace(/,/g, '').trim());
  return Number.isFinite(n) && n >= 0 ? { ok: true, value: round2(n) } : { ok: false, value: null };
}
export function fmtL(n) {
  const v = round2(Number.isFinite(Number(n)) ? Number(n) : 0);
  const abs = Math.abs(v);
  const txt = abs.toLocaleString('en-US', Number.isInteger(abs) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${v < 0 ? '-' : ''}L ${txt}`;
}
export const fmtPct = n => `${round2(n)}%`;
export const clampQty = q => { const n = Math.floor(Number(q)); return Number.isFinite(n) ? Math.min(999, Math.max(1, n)) : 1; };

/* ───────────── catálogo con precios personalizados ───────────── */
// R69 · Paquete G — precios BASE desde la configuración remota; el precio personalizado del usuario sigue mandando.
export function remoteBaseCatalog(basePrices = null, base = DEFAULT_CATALOG) {
  if (!basePrices || typeof basePrices !== 'object') return base;
  return base.map(p => { const a = parseAmount(basePrices[p.id]); return a.ok && a.value != null ? { ...p, precio: a.value } : p; });
}
export function effectiveCatalog(overrides = {}, base = DEFAULT_CATALOG) {
  return base.filter(p => p.activo !== false).map(p => {
    const o = parseAmount(overrides?.[p.id]);
    return { ...p, precioBase: p.precio, precio: o.ok && o.value != null ? o.value : p.precio };
  });
}
export function sanitizePrices(raw = {}, base = DEFAULT_CATALOG) {
  const out = {};
  for (const p of base) { const a = parseAmount(raw?.[p.id]); if (a.ok && a.value != null && a.value !== p.precio) out[p.id] = a.value; }
  return out;
}
export function loadCalcPrices(storage) {
  try { return sanitizePrices(JSON.parse(storage?.getItem(CALC_STORAGE_KEY) || '{}')?.prices || {}); } catch (_) { return {}; }
}
export function saveCalcPrices(storage, prices) {
  try { storage?.setItem(CALC_STORAGE_KEY, JSON.stringify({ v: 1, prices: sanitizePrices(prices) })); return true; } catch (_) { return false; }
}

/* ───────────── el cálculo (fuente de verdad) ───────────── */
// state: { items:[{uid,source:'catalog'|'manual',id?,name?,price?,qty}], discountMode:'lempiras'|'porcentaje', discountValue:'', finalPrice:'' }
export function computeTotals(state = {}, catalog = effectiveCatalog()) {
  const map = new Map(catalog.map(p => [p.id, p]));
  const lines = (Array.isArray(state.items) ? state.items : []).map(it => {
    const p = it.source === 'manual' ? null : map.get(it.id);
    const unit = it.source === 'manual' ? (parseAmount(it.price).value ?? 0) : (p?.precio ?? 0);
    const qty = clampQty(it.qty);
    return { uid: it.uid, source: it.source === 'manual' ? 'manual' : 'catalog', id: it.id, name: it.source === 'manual' ? String(it.name || 'Producto') : (p?.nombre || 'Producto'), logo: p?.logo || '', unit, qty, amount: round2(unit * qty) };
  });
  const subtotal = round2(lines.reduce((t, l) => t + l.amount, 0));
  const errors = [];
  let discount = 0, increase = 0, total = subtotal, mode = 'none';
  const fin = parseAmount(state.finalPrice);
  if (state.finalPrice !== '' && state.finalPrice != null && !fin.ok) errors.push('El precio final no es válido.');
  if (fin.ok && fin.value != null) {
    mode = 'final';
    if (subtotal > 0) {
      if (fin.value <= subtotal) discount = round2(subtotal - fin.value); else increase = round2(fin.value - subtotal);
      total = fin.value;
    }
  } else {
    const dv = parseAmount(state.discountValue);
    if (state.discountValue !== '' && state.discountValue != null && !dv.ok) errors.push('El descuento no es válido.');
    if (dv.ok && dv.value != null) {
      if (state.discountMode === 'porcentaje') {
        if (dv.value > 100) errors.push('El porcentaje no puede pasar de 100.');
        discount = round2(subtotal * Math.min(100, dv.value) / 100); mode = 'porcentaje';
      } else {
        if (dv.value > subtotal) errors.push('El descuento no puede ser mayor que el subtotal.');
        discount = round2(Math.min(dv.value, subtotal)); mode = 'lempiras';
      }
    }
    total = Math.max(0, round2(subtotal - discount));
  }
  const savingPct = subtotal > 0 && discount > 0 ? round2(discount / subtotal * 100) : 0;
  return { lines, count: lines.length, units: lines.reduce((t, l) => t + l.qty, 0), subtotal, discount, increase, total, savingPct, mode, errors };
}

export function quoteText(t) {
  const rows = t.lines.map(l => `• ${l.name}${l.qty > 1 ? ` x${l.qty}` : ''} — ${fmtL(l.amount)}`);
  const tail = [`Subtotal: ${fmtL(t.subtotal)}`];
  if (t.discount > 0) tail.push(`Descuento: -${fmtL(t.discount)}`);
  if (t.increase > 0) tail.push(`Incremento: +${fmtL(t.increase)}`);
  tail.push(`*Total a cobrar: ${fmtL(t.total)}*`);
  return `🧾 *Cotización Sublicuentas*\n${rows.join('\n')}\n\n${tail.join('\n')}`;
}
export function pushCalcHistory(storage, entry, max = 20) {
  try {
    const list = JSON.parse(storage?.getItem(CALC_HISTORY_KEY) || '[]'); const next = [entry, ...(Array.isArray(list) ? list : [])].slice(0, max);
    storage?.setItem(CALC_HISTORY_KEY, JSON.stringify(next)); return next.length;
  } catch (_) { return 0; }
}

/* ───────────── estado inicial ───────────── */
export const calcInitialState = () => ({ mode: 'catalog', query: '', cat: 'todos', show: 'todas', editing: false, items: [], nextUid: 1, discountMode: 'lempiras', discountValue: '', finalPrice: '', manualName: '', manualPrice: '', manualError: '' });
export function calcAddCatalog(state, id) {
  const it = state.items.find(x => x.source === 'catalog' && x.id === id);
  if (it) it.qty = clampQty(it.qty + 1); else state.items.push({ uid: `c-${id}`, source: 'catalog', id, qty: 1 });
  return state;
}
export function calcAddManual(state, name, price) {
  const n = String(name || '').trim(); const p = parseAmount(price);
  if (!n) return { ok: false, error: 'Escribe el nombre del producto.' };
  if (!p.ok || p.value == null || p.value <= 0) return { ok: false, error: 'Escribe un precio válido mayor que cero.' };
  state.items.push({ uid: `m-${state.nextUid++}`, source: 'manual', name: n.slice(0, 60), price: p.value, qty: 1 });
  return { ok: true };
}
export function calcStep(state, uid, delta) {
  const it = state.items.find(x => x.uid === uid); if (!it) return state;
  const q = clampQty(it.qty + delta);
  if (it.qty + delta < 1) state.items = state.items.filter(x => x.uid !== uid); else it.qty = q;
  return state;
}
export const calcRemove = (state, uid) => { state.items = state.items.filter(x => x.uid !== uid); return state; };

/* ───────────── pantalla ───────────── */
const IC = {
  back: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#0a1f3a" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="m15 5-7 7 7 7"/></svg>',
  search: '<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="#0a1f3a" stroke-width="2.200" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.600-3.600"/></svg>',
  bag: '<svg viewBox="0 0 48 48" width="34" height="34" aria-hidden="true"><path d="M10 17h28l-2 23a3 3 0 0 1-3 2.700H15a3 3 0 0 1-3-2.700z" fill="#1f8ff0"/><path d="M17 20v-4a7 7 0 0 1 14 0v4" fill="none" stroke="#0a5fc4" stroke-width="3.400" stroke-linecap="round"/></svg>',
  pencil: '<svg viewBox="0 0 48 48" width="34" height="34" aria-hidden="true"><path d="m10 38 2.500-9.500L32 9a4.200 4.200 0 0 1 6 6L18.500 34.500z" fill="none" stroke="#0a1f3a" stroke-width="3" stroke-linejoin="round"/><path d="m28 13 7 7" stroke="#0a1f3a" stroke-width="3"/></svg>',
  gear: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.200"/><path d="M19.400 15a1.700 1.700 0 0 0 .3 1.900l.1.100a2 2 0 1 1-2.800 2.800l-.1-.1a1.700 1.700 0 0 0-1.900-.3 1.700 1.700 0 0 0-1 1.500V21a2 2 0 1 1-4 0v-.1a1.700 1.700 0 0 0-1.100-1.500 1.700 1.700 0 0 0-1.900.3l-.1.100a2 2 0 1 1-2.800-2.800l.1-.1a1.700 1.700 0 0 0 .3-1.900 1.700 1.700 0 0 0-1.500-1H3a2 2 0 1 1 0-4h.1a1.700 1.700 0 0 0 1.500-1.100 1.700 1.700 0 0 0-.3-1.900l-.1-.1a2 2 0 1 1 2.800-2.800l.1.100a1.700 1.700 0 0 0 1.900.3H9a1.700 1.700 0 0 0 1-1.500V3a2 2 0 1 1 4 0v.1a1.700 1.700 0 0 0 1 1.500 1.700 1.700 0 0 0 1.900-.3l.1-.1a2 2 0 1 1 2.800 2.800l-.1.100a1.700 1.700 0 0 0-.3 1.900V9a1.700 1.700 0 0 0 1.500 1H21a2 2 0 1 1 0 4h-.1a1.700 1.700 0 0 0-1.500 1z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  minus: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#0a1f3a" stroke-width="3" stroke-linecap="round"><path d="M5 12h14"/></svg>',
  plusDark: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#0a1f3a" stroke-width="3" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  trash: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#e2231a" stroke-width="2.100" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V4.500h6V7M6.500 7l1 13h9l1-13M10 11v6M14 11v6"/></svg>',
  calc: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="3"/><rect x="8" y="6" width="8" height="3.500" rx="1" fill="#fff"/><path d="M8.500 13h.01M12 13h.01M15.500 13h.01M8.500 17h.01M12 17h.01M15.500 17h.01"/></svg>',
  tag: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#1c8a3c" stroke-width="1.900" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.500" cy="8.500" r="1.400"/></svg>',
  down: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="#0a1f3a" stroke-width="2.600" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
  chevron: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.800" stroke-linecap="round" stroke-linejoin="round"><path d="m9 5 7 7-7 7"/></svg>',
};
export const CALC_CARD_ICON = '<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="10" y="4" width="44" height="56" rx="10" fill="#1f2a44"/><rect x="16" y="11" width="32" height="14" rx="4" fill="#bfe8ff"/><path d="M21 19h14" stroke="#0a5fc4" stroke-width="3" stroke-linecap="round"/><circle cx="21" cy="35" r="4" fill="#e2231a"/><circle cx="32" cy="35" r="4" fill="#dfe6f2"/><circle cx="43" cy="35" r="4" fill="#dfe6f2"/><circle cx="21" cy="46" r="4" fill="#dfe6f2"/><circle cx="32" cy="46" r="4" fill="#dfe6f2"/><rect x="38.500" y="41" width="9" height="10" rx="4.500" fill="#1f8ff0"/></svg>';
const logoHtml = (logo, name, cls = '') => (logo ? `<img class="pf-logo ${cls}" src="/assets/plataformas/${esc(logo)}.webp" alt="" loading="lazy">` : `<span class="pf-logo pf-fallback ${cls}">${esc(String(name || '?').charAt(0).toUpperCase())}</span>`);

export function calcSummaryHtml(t) {
  // Los espacios entre etiqueta y valor no cambian el diseño (flex) y hacen que el texto se lea "Subtotal L 290".
  const disc = t.increase > 0
    ? `<div class="cc-row"><span>Incremento</span> <b class="inc">+${fmtL(t.increase)}</b></div>`
    : `<div class="cc-row"><span>Descuento</span> <b class="${t.discount > 0 ? 'neg' : ''}">${t.discount > 0 ? `-${fmtL(t.discount)}` : fmtL(0)}</b></div>`;
  const save = t.discount > 0
    ? `<div class="cc-save"><i>${IC.tag}</i><div><b>Ahorras ${fmtL(t.discount)}</b> <small>${fmtPct(t.savingPct)} menos</small></div></div>`
    : (t.increase > 0 ? `<div class="cc-save inc"><i>${IC.tag}</i><div><b>Incremento ${fmtL(t.increase)}</b> <small>Precio final mayor que el subtotal</small></div></div>` : '');
  return `<div class="cc-row"><span>Subtotal</span> <b>${fmtL(t.subtotal)}</b></div>${disc}<div class="cc-total"><span>Total a cobrar</span> <b>${fmtL(t.total)}</b></div>${save}`;
}
export function calcHintsHtml(t) { return t.errors.length ? `<p class="cc-error">${t.errors.map(esc).join(' ')}</p>` : ''; }

export function calcScreenHtml({ st = calcInitialState(), catalog = effectiveCatalog(), totals = computeTotals(st, catalog) } = {}) {
  const q = String(st.query || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  const norm = v => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const selectedIds = new Set(st.items.filter(i => i.source === 'catalog').map(i => i.id));
  const shown = catalog.filter(p => (st.cat === 'todos' || p.categoria === st.cat) && (!q || norm(p.nombre).includes(q)) && (st.show !== 'sel' || selectedIds.has(p.id)));
  const empty = totals.count === 0;
  const isCatalog = st.mode === 'catalog';
  const tiles = shown.map(p => {
    const sel = st.items.find(i => i.source === 'catalog' && i.id === p.id);
    return st.editing
      ? `<div class="cc-tile edit">${logoHtml(p.logo, p.nombre)}<div><b>${esc(p.nombre)}</b><label>L <input type="number" inputmode="decimal" min="0" step="1" value="${p.precio}" data-calc-price="${esc(p.id)}" aria-label="Precio de ${esc(p.nombre)}"></label>${p.precio !== p.precioBase ? `<small>Base: ${fmtL(p.precioBase)}</small>` : ''}</div></div>`
      : `<button type="button" class="cc-tile ${sel ? 'on' : ''}" data-calc-add="${esc(p.id)}">${logoHtml(p.logo, p.nombre)}<span class="nm"><b>${esc(p.nombre)}</b><small>${fmtL(p.precio)}</small></span><i class="add">${sel ? `<em>${sel.qty}</em>` : IC.plus}</i></button>`;
  }).join('');
  const rows = totals.lines.map(l => `<div class="cc-line"><span class="lg">${logoHtml(l.logo, l.name)}</span><b class="nm">${esc(l.name)}${l.source === 'manual' ? '<small>manual</small>' : ''}</b><span class="stp"><button type="button" data-calc-minus="${esc(l.uid)}" aria-label="Menos">${IC.minus}</button><em>${l.qty}</em><button type="button" data-calc-plus="${esc(l.uid)}" aria-label="Más">${IC.plusDark}</button></span><span class="am" data-calc-amount="${esc(l.uid)}">${fmtL(l.amount)}</span><button type="button" class="del" data-calc-del="${esc(l.uid)}" aria-label="Eliminar">${IC.trash}</button></div>`).join('');
  const quick = (st.discountMode === 'porcentaje' ? QUICK_PERCENTS : QUICK_DISCOUNTS).map(v => `<button type="button" class="${Number(st.discountValue) === v ? 'on' : ''}" data-calc-quick="${v}" ${empty ? 'disabled' : ''}>${st.discountMode === 'porcentaje' ? `${v}%` : `− L ${v}`}</button>`).join('');
  const finalOn = st.finalPrice !== '' && st.finalPrice != null;
  return `<section class="cc-page">
    <div class="cc-top"><button type="button" class="sb-icon-btn" id="backMore" aria-label="Volver">${IC.back}</button><img class="cc-logo" src="/assets/sublicuentas-logo-oficial.png" alt="Sublicuentas"></div>
    <section class="cc-hero"><div class="cc-copy"><p class="eyebrow">HERRAMIENTA</p><h1>Calculadora de venta</h1><p>Seleccione productos, coloque precios, aplique descuentos y obtenga el total.</p></div><div class="cc-bot"><span class="cc-bubble">Calcula, combina y vende más. 🚀</span><img src="/assets/mas/robot-calc.webp" width="150" height="142" alt="Sublibot con calculadora"></div></section>
    <nav class="cc-seg"><button type="button" class="${isCatalog ? 'on' : ''}" data-calc-mode="catalog"><i>${IC.bag}</i><span><b>Productos del catálogo</b><small>Use sus precios guardados</small></span></button><button type="button" class="${!isCatalog ? 'on' : ''}" data-calc-mode="manual"><i>${IC.pencil}</i><span><b>Precios manuales</b><small>Escriba los productos y precios</small></span></button></nav>
    ${isCatalog ? `<div class="cc-searchrow"><div class="cc-search"><span>${IC.search}</span><input id="calcSearch" type="search" value="${esc(st.query)}" placeholder="Buscar producto…" autocomplete="off"></div><label class="cc-show"><select id="calcShow" aria-label="Mostrar"><option value="todas" ${st.show !== 'sel' ? 'selected' : ''}>Todas</option><option value="sel" ${st.show === 'sel' ? 'selected' : ''}>Elegidos</option></select></label></div>
    <div class="cc-cats">${CALC_CATEGORIES.map(([v, l]) => `<button type="button" class="${st.cat === v ? 'on' : ''}" data-calc-cat="${v}">${l}</button>`).join('')}</div>
    <div class="cc-head"><h2>Productos</h2><button type="button" class="cc-edit ${st.editing ? 'on' : ''}" id="calcEdit">${IC.gear} ${st.editing ? 'Listo' : 'Editar precios'}</button></div>
    ${st.editing ? '<p class="cc-note">Cambiar un precio aquí modifica el precio normal guardado del producto.</p>' : ''}
    <div class="cc-grid">${tiles || '<div class="cc-empty">No hay productos con ese filtro.</div>'}</div>` : ''}
    <section class="cc-card"><header><h3>Productos seleccionados</h3><span class="cc-count">${totals.count} producto${totals.count === 1 ? '' : 's'}</span></header><div id="calcLines">${rows || '<p class="cc-empty-sel">Aún no hay productos. Toca uno del catálogo o agrega uno manual.</p>'}</div></section>
    <div class="cc-two"><section class="cc-card"><header><h3>Aplicar descuento</h3><span class="cc-mode"><button type="button" class="${st.discountMode !== 'porcentaje' ? 'on' : ''}" data-calc-dmode="lempiras">Lempiras</button><button type="button" class="${st.discountMode === 'porcentaje' ? 'on' : ''}" data-calc-dmode="porcentaje">Porcentaje</button></span></header>
      <div class="cc-quick ${finalOn ? 'dim' : ''}">${quick}</div>
      <label class="cc-field ${finalOn ? 'dim' : ''}">Descuento personalizado<div class="cc-inp"><input id="calcDiscount" type="number" inputmode="decimal" min="0" step="any" value="${esc(st.discountValue)}" placeholder="0" ${empty || finalOn ? 'disabled' : ''}><b>${st.discountMode === 'porcentaje' ? '%' : 'L'}</b></div></label>
      <label class="cc-field">Quiero cobrar<div class="cc-inp"><input id="calcFinal" type="number" inputmode="decimal" min="0" step="any" value="${esc(st.finalPrice)}" placeholder="Precio final" ${empty ? 'disabled' : ''}><b>L</b></div><small>Precio final que quieres ofrecer; el descuento se calcula solo.</small></label>
      <div id="calcHints">${calcHintsHtml(totals)}</div></section>
    <section class="cc-card cc-summary"><header><h3>Resumen</h3></header><div id="calcSummary">${calcSummaryHtml(totals)}</div></section></div>
    <section class="cc-card"><header><h3>Agregar producto manualmente</h3>${isCatalog ? '' : '<button type="button" class="cc-link" id="calcUseSaved">Usar precios guardados ›</button>'}</header>
      <div class="cc-manual"><label>Nombre del producto<input id="calcManualName" maxlength="60" placeholder="Ej. Office 365" value="${esc(st.manualName)}"></label><label>Precio (Lps)<input id="calcManualPrice" type="number" inputmode="decimal" min="0" step="any" placeholder="Ej. 120" value="${esc(st.manualPrice)}"></label><button type="button" class="cc-add" id="calcManualAdd">${IC.plus} Agregar</button></div>
      ${st.manualError ? `<p class="cc-error">${esc(st.manualError)}</p>` : ''}</section>
    <div class="cc-actions"><button type="button" class="cc-clear" id="calcClear" ${empty && !st.discountValue && !st.finalPrice ? 'disabled' : ''}>🗑 Limpiar todo</button><button type="button" class="cc-save-btn" id="calcSave" ${empty ? 'disabled' : ''}>${IC.calc} Guardar / Usar total</button></div>
  </section>`;
}
