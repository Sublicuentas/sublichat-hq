// Guardar y compartir el Excel. En el teléfono: se escribe en la caché de la app y se abre la hoja de "Compartir"
// (Guardar en Archivos/Drive, WhatsApp, Correo, Excel…). En navegador: descarga normal.
function bufferToBase64(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(binary);
}
export const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

export async function saveAndShareXlsx(filename, buffer) {
  const { Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(new Blob([buffer], { type: XLSX_MIME }));
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return { mode: 'browser' };
  }
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  const written = await Filesystem.writeFile({ path: `reportes/${filename}`, data: bufferToBase64(buffer), directory: Directory.Cache, recursive: true });
  await Share.share({ title: filename, text: 'Reporte financiero de Sublichat', files: [written.uri], dialogTitle: 'Guardar o enviar el Excel' });
  return { mode: 'native', uri: written.uri };
}
export { bufferToBase64 };
