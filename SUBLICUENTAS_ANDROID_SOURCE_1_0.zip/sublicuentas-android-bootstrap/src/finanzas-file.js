// Guardar y compartir el Excel. En el teléfono: se escribe en la caché de la app y se abre la hoja de "Compartir"
// (Guardar en Archivos/Drive, WhatsApp, Correo, Excel…). En navegador: descarga normal.
function bufferToBase64(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(binary);
}
export const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

export async function saveAndShareXlsx(filename, buffer) {
  const { Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(new Blob([buffer], { type: XLSX_MIME }));
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return { mode: 'browser' };
  }
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  // R115: primero se GUARDA en el teléfono (Documentos/Sublicuentas); compartir es opcional.
  const data = bufferToBase64(buffer);
  let written = null, guardadoEn = '';
  try { written = await Filesystem.writeFile({ path: `Sublicuentas/${filename}`, data, directory: Directory.Documents, recursive: true }); guardadoEn = `Documentos/Sublicuentas/${filename}`; }
  catch (_) { written = await Filesystem.writeFile({ path: `reportes/${filename}`, data, directory: Directory.Data, recursive: true }); guardadoEn = 'la carpeta de la app'; }
  const compartir = typeof window !== 'undefined' && window.confirm ? window.confirm(`✅ Excel guardado en ${guardadoEn}.\n\n¿Quiere también compartirlo o abrirlo?`) : false;
  if (compartir) await Share.share({ title: filename, text: 'Reporte financiero de Sublichat', files: [written.uri], dialogTitle: 'Enviar o abrir el Excel' });
  return { mode: 'native', uri: written.uri, guardadoEn };
}
export { bufferToBase64 };

// R65 · guardar/compartir cualquier archivo (Excel, CSV o TXT) con la hoja nativa de Android.
export async function saveAndShareFile(filename, data, mime, text = 'Reporte de Sublichat') {
  const bytes = typeof data === 'string' ? new TextEncoder().encode(data) : (data instanceof Uint8Array ? data : new Uint8Array(data));
  const { Capacitor } = await import('@capacitor/core');
  if (!Capacitor.isNativePlatform()) {
    const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
    const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    return { mode: 'browser' };
  }
  const { Filesystem, Directory } = await import('@capacitor/filesystem');
  const { Share } = await import('@capacitor/share');
  const written = await Filesystem.writeFile({ path: `reportes/${filename}`, data: bufferToBase64(bytes), directory: Directory.Cache, recursive: true });
  await Share.share({ title: filename, text, files: [written.uri], dialogTitle: 'Guardar o compartir reporte' });
  return { mode: 'native', uri: written.uri };
}
