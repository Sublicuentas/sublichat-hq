package com.sublicuentas.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

/**
 * R74 · Widget "Cobros" de la pantalla de inicio: Hoy · Próximos · Vencidos, solo del usuario de la sesión.
 * Los números se calculan con la fecha del teléfono, así al cambiar el día se mueven solos
 * (Android refresca el widget cada 30 minutos y cada vez que la app sincroniza).
 */
public class CobrosWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "sublichat_widget";
    public static final String KEY_DATA = "data";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAll(context, appWidgetManager, appWidgetIds);
    }

    static String todayKey() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_DATA, "");
        int hoy = 0, proximos = 0, vencidos = 0;
        String proximoFecha = "";
        String vendedor = "";
        String actualizado = "";
        boolean hayDatos = false;
        try {
            if (raw != null && !raw.isEmpty()) {
                JSONObject json = new JSONObject(raw);
                vendedor = json.optString("vendedor", "");
                actualizado = json.optString("actualizado", "");
                JSONObject dias = json.optJSONObject("dias");
                if (dias != null) {
                    hayDatos = true;
                    String today = todayKey();
                    String next = null;
                    Iterator<String> keys = dias.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        int n = dias.optInt(k, 0);
                        int cmp = k.compareTo(today);
                        if (cmp == 0) hoy += n;
                        else if (cmp < 0) vencidos += n;
                        else if (next == null || k.compareTo(next) < 0) next = k;
                    }
                    if (next != null) {
                        proximos = dias.optInt(next, 0);
                        proximoFecha = next.substring(8, 10) + "/" + next.substring(5, 7);
                    }
                }
            }
        } catch (Exception ignored) {
            hayDatos = false;
        }

        Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        PendingIntent tap = null;
        if (open != null) {
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            tap = PendingIntent.getActivity(context, 7300, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }

        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_cobros);
            views.setTextViewText(R.id.widget_hoy, hayDatos ? String.valueOf(hoy) : "–");
            views.setTextViewText(R.id.widget_proximos, hayDatos ? String.valueOf(proximos) : "–");
            views.setTextViewText(R.id.widget_vencidos, hayDatos ? String.valueOf(vencidos) : "–");
            views.setTextViewText(R.id.widget_proximos_label, proximoFecha.isEmpty() ? "Próximos" : "Próx. " + proximoFecha);
            String titulo = vendedor.isEmpty() ? "Cobros" : "Cobros · " + vendedor;
            views.setTextViewText(R.id.widget_title, titulo);
            views.setTextViewText(R.id.widget_updated, hayDatos ? (actualizado.isEmpty() ? "" : "Actualizado " + actualizado) : "Abra la app para cargar");
            if (tap != null) views.setOnClickPendingIntent(R.id.widget_root, tap);
            manager.updateAppWidget(id, views);
        }
    }
}
