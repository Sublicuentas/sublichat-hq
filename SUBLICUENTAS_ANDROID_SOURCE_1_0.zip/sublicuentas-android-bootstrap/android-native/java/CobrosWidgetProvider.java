package com.sublicuentas.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

/**
 * R76 · Widget "Cobros" 4x2 (diseño Marca Sublicuentas): Hoy · Próximos · Vencidos con monto, solo del usuario.
 * Los números se calculan con la fecha del teléfono, así al cambiar el día se mueven solos
 * (Android refresca cada 30 minutos y también cada vez que la app sincroniza).
 * La versión pequeña 2x1 es CobrosWidgetMiniProvider y usa este mismo cálculo.
 */
public class CobrosWidgetProvider extends AppWidgetProvider {
    public static final String PREFS = "sublichat_widget";
    public static final String KEY_DATA = "data";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAll(context, appWidgetManager, appWidgetIds);
    }

    /** Resumen ya calculado para hoy. */
    static final class Resumen {
        boolean hayDatos = false;
        int hoy = 0, proximos = 0, vencidos = 0;
        double totalHoy = 0, totalProximos = 0, totalVencidos = 0;
        String proximoFecha = "";
        String vendedor = "";
        String actualizado = "";
    }

    static String todayKey() {
        Calendar c = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static String money(double v) {
        return String.format(Locale.US, "L %,.0f", v);
    }

    static Resumen leer(Context context) {
        Resumen r = new Resumen();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_DATA, "");
        try {
            if (raw == null || raw.isEmpty()) return r;
            JSONObject json = new JSONObject(raw);
            r.vendedor = json.optString("vendedor", "");
            r.actualizado = json.optString("actualizado", "");
            JSONObject dias = json.optJSONObject("dias");
            if (dias == null) return r;
            r.hayDatos = true;
            String today = todayKey();
            String next = null;
            Iterator<String> keys = dias.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject dia = dias.optJSONObject(k);
                int n = dia != null ? dia.optInt("n", 0) : dias.optInt(k, 0);
                double t = dia != null ? dia.optDouble("t", 0) : 0;
                int cmp = k.compareTo(today);
                if (cmp == 0) { r.hoy += n; r.totalHoy += t; }
                else if (cmp < 0) { r.vencidos += n; r.totalVencidos += t; }
                else if (next == null || k.compareTo(next) < 0) next = k;
            }
            if (next != null) {
                JSONObject dia = dias.optJSONObject(next);
                r.proximos = dia != null ? dia.optInt("n", 0) : dias.optInt(next, 0);
                r.totalProximos = dia != null ? dia.optDouble("t", 0) : 0;
                r.proximoFecha = next.substring(8, 10) + "/" + next.substring(5, 7);
            }
        } catch (Exception ignored) {
            r.hayDatos = false;
        }
        return r;
    }

    static PendingIntent abrirApp(Context context) {
        Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (open == null) return null;
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 7300, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        Resumen r = leer(context);
        PendingIntent tap = abrirApp(context);
        String sinDato = "–";
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_cobros);
            views.setTextViewText(R.id.widget_hoy, r.hayDatos ? String.valueOf(r.hoy) : sinDato);
            views.setTextViewText(R.id.widget_proximos, r.hayDatos ? String.valueOf(r.proximos) : sinDato);
            views.setTextViewText(R.id.widget_vencidos, r.hayDatos ? String.valueOf(r.vencidos) : sinDato);
            views.setTextViewText(R.id.widget_proximos_label, r.proximoFecha.isEmpty() ? "Próximos" : "Próx. " + r.proximoFecha);
            views.setTextViewText(R.id.widget_hoy_total, r.hayDatos ? money(r.totalHoy) : "");
            views.setTextViewText(R.id.widget_proximos_total, r.hayDatos ? money(r.totalProximos) : "");
            views.setTextViewText(R.id.widget_vencidos_total, r.hayDatos ? money(r.totalVencidos) : "");
            String meta = r.hayDatos ? (r.vendedor.isEmpty() ? r.actualizado : r.vendedor + " · " + r.actualizado) : "Abra la app para cargar";
            views.setTextViewText(R.id.widget_updated, meta);
            if (tap != null) views.setOnClickPendingIntent(R.id.widget_root, tap);
            manager.updateAppWidget(id, views);
        }
    }
}
