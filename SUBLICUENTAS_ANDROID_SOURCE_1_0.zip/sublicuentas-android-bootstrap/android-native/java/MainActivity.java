package com.sublicuentas.app;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

/** R74: registra el plugin del widget de Cobros (SubliWidgetPlugin). */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SubliWidgetPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
