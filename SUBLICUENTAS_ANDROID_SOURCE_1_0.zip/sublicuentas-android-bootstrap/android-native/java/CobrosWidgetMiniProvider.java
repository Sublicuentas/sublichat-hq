package com.sublicuentas.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/** R76 · Widget "Cobros" pequeño (2x1), mismo diseño Marca Sublicuentas y mismos números que el grande. */
public class CobrosWidgetMiniProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAll(context, appWidgetManager, appWidgetIds);
    }

    static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        CobrosWidgetProvider.Resumen r = CobrosWidgetProvider.leer(context);
        PendingIntent tap = CobrosWidgetProvider.abrirApp(context);
        String sinDato = "–";
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_cobros_mini);
            views.setTextViewText(R.id.widget_hoy, r.hayDatos ? String.valueOf(r.hoy) : sinDato);
            views.setTextViewText(R.id.widget_proximos, r.hayDatos ? String.valueOf(r.proximos) : sinDato);
            views.setTextViewText(R.id.widget_vencidos, r.hayDatos ? String.valueOf(r.vencidos) : sinDato);
            views.setTextViewText(R.id.widget_proximos_label, r.proximoFecha.isEmpty() ? "Próx." : r.proximoFecha);
            if (tap != null) views.setOnClickPendingIntent(R.id.widget_root, tap);
            manager.updateAppWidget(id, views);
        }
    }
}
