package com.sublicuentas.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import com.getcapacitor.JSObject;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * R74 · Puente entre la app (JavaScript) y el widget de la pantalla de inicio.
 * La app manda los cobros del usuario agrupados por fecha; aquí se guardan y se redibuja el widget.
 */
@CapacitorPlugin(name = "SubliWidget")
public class SubliWidgetPlugin extends Plugin {

    @PluginMethod
    public void update(PluginCall call) {
        String data = call.getString("data");
        Context ctx = getContext();
        SharedPreferences prefs = ctx.getSharedPreferences(CobrosWidgetProvider.PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        if (data == null || data.isEmpty()) editor.remove(CobrosWidgetProvider.KEY_DATA);
        else editor.putString(CobrosWidgetProvider.KEY_DATA, data);
        editor.apply();
        refresh(ctx);
        call.resolve();
    }

    /**
     * R186 · "Descargar Excel": guarda el archivo en la carpeta pública DESCARGAS del teléfono (no abre "Compartir").
     * Android 10+ usa MediaStore.Downloads (no pide permisos). Android 9 o menos: carpeta Descargas de la app.
     * data = contenido en base64 (el Excel se arma en la app con los datos del servidor). Nunca recibe tokens.
     */
    @PluginMethod
    public void guardarDescarga(PluginCall call) {
        String nombre = call.getString("nombre", "archivo.xlsx");
        String mime = call.getString("mime", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String data = call.getString("data");
        if (data == null || data.isEmpty()) { call.reject("Archivo vacío"); return; }
        nombre = nombre.replaceAll("[^A-Za-z0-9._ -]", "_");
        if (nombre.length() > 120) nombre = nombre.substring(0, 120);
        byte[] bytes;
        try { bytes = Base64.decode(data, Base64.DEFAULT); } catch (Exception e) { call.reject("Contenido inválido"); return; }
        Context ctx = getContext();
        try {
            JSObject out = new JSObject();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver cr = ctx.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) { call.reject("No se pudo crear el archivo en Descargas"); return; }
                try (OutputStream os = cr.openOutputStream(uri)) { if (os == null) throw new Exception("sin flujo"); os.write(bytes); }
                ContentValues fin = new ContentValues();
                fin.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(uri, fin, null, null);
                out.put("uri", uri.toString());
                out.put("carpeta", "Descargas");
            } else {
                File dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = ctx.getFilesDir();
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, nombre);
                try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                out.put("uri", Uri.fromFile(f).toString());
                out.put("carpeta", "Descargas de la app (Android 9 o menos)");
            }
            out.put("nombre", nombre);
            out.put("bytes", bytes.length);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("No se pudo guardar en Descargas: " + e.getMessage());
        }
    }

    static void refresh(Context ctx) {
        AppWidgetManager manager = AppWidgetManager.getInstance(ctx);
        int[] ids = manager.getAppWidgetIds(new ComponentName(ctx, CobrosWidgetProvider.class));
        if (ids != null && ids.length > 0) CobrosWidgetProvider.updateAll(ctx, manager, ids);
        int[] mini = manager.getAppWidgetIds(new ComponentName(ctx, CobrosWidgetMiniProvider.class)); // R76: widget 2x1
        if (mini != null && mini.length > 0) CobrosWidgetMiniProvider.updateAll(ctx, manager, mini);
    }
}
