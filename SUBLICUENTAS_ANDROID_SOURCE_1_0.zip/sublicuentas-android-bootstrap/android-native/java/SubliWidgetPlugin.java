package com.sublicuentas.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * R74 · Puente entre la app (JavaScript) y el widget de la pantalla de inicio.
 * La app manda los cobros del usuario agrupados por fecha; aquí se guardan y se redibuja el widget.
 */
@CapacitorPlugin(name = "SubliWidget")
public class SubliWidgetPlugin extends Plugin {

    @PluginMethod
    public void update(PluginCall call) {
        String data = call.getString("data");
        Context ctx = getContext();
        SharedPreferences prefs = ctx.getSharedPreferences(CobrosWidgetProvider.PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        if (data == null || data.isEmpty()) editor.remove(CobrosWidgetProvider.KEY_DATA);
        else editor.putString(CobrosWidgetProvider.KEY_DATA, data);
        editor.apply();
        refresh(ctx);
        call.resolve();
    }

    static void refresh(Context ctx) {
        AppWidgetManager manager = AppWidgetManager.getInstance(ctx);
        int[] ids = manager.getAppWidgetIds(new ComponentName(ctx, CobrosWidgetProvider.class));
        if (ids != null && ids.length > 0) CobrosWidgetProvider.updateAll(ctx, manager, ids);
        int[] mini = manager.getAppWidgetIds(new ComponentName(ctx, CobrosWidgetMiniProvider.class)); // R76: widget 2x1
        if (mini != null && mini.length > 0) CobrosWidgetMiniProvider.updateAll(ctx, manager, mini);
    }
}
