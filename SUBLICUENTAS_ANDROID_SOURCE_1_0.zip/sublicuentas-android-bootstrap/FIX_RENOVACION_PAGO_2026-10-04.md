# Fix urgente · Cobro y Renovación

Fecha: 2026-10-04

Cambios:
- Se reemplaza la pantalla confusa `Monto total + Recibido ahora` por dos estados: `Pagó` y `Pendiente`.
- `Pagó` muestra un solo campo `Monto pagado`.
- Si fue pago parcial, `+ Agregar saldo pendiente` abre únicamente `Saldo pendiente`.
- `Pendiente` muestra un solo campo `Monto pendiente`.
- El contrato financiero del backend NO cambia: la app sigue enviando `montoTotal` y `recibido` calculados internamente.
- Los errores de validación ahora se muestran dentro del modal, encima de `Confirmar y renovar`; ya no quedan escondidos detrás de la hoja.
- Banco obligatorio cuando entró dinero; responsable Cliente/Vendedor cuando queda pendiente.
- `Ajuste sin pago` se conserva sin cambios funcionales.

Prueba focal: `tests/r104-finanzas-libro.test.mjs` -> 7/7 OK.
