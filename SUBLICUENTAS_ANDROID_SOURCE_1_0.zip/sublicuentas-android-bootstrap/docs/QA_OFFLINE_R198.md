# Sublichat APK · Modo offline · Reporte de QA (R198, fases 1–5)

Fecha: 18/11/2026 · Datos de prueba ficticios · Sin datos reales de clientes, claves, PIN ni tokens.

**Simulado** = la app real (el mismo código de la APK) corriendo en pruebas automáticas con almacenamiento que sobrevive a
cerrar/abrir y modo avión. **Teléfono** = falta repetirla en el teléfono con la APK compilada (no compilada todavía: espera aprobación).

| # | Prueba del PDF | Estado | Evidencia |
|---|---|---|---|
| 01 | Iniciar sesión con internet, sincronizar y pasar a modo avión | Simulado ✓ · Teléfono pendiente | r198-offline-baul (1) |
| 02 | Cerrar la APK y abrirla sin conexión: Inicio sin bucle | Simulado ✓ · Teléfono pendiente | r198-offline-baul (1); captura 01 |
| 03 | Baúl desde cero: 6 plataformas, logos, pasos, códigos | Simulado ✓ | r198-offline-baul (1); capturas 02–03 |
| 04 | Copiar instrucciones y código Downloader sin internet | Simulado ✓ | r198-offline-baul (1) |
| 05 | Descargar un APK antes y abrirlo sin conexión | **No implementado** | Falta hash, tamaño, versión y «distribución autorizada» en el registro del Baúl (Web). Sin eso se muestra «Requiere internet para descargar». |
| 06 | Cliente, beneficiario, servicios y fecha sin conexión; búsqueda | Simulado ✓ | r198b (1); captura f2_01 |
| 07 | Inventario y cupos como última sincronización | Simulado ✓ | r198b (1); capturas f2_02–03 |
| 08 | Renovación y compra como borradores sin subir ingresos/costos | Renovación ✓ (en cola, ingreso solo al confirmar el servidor) · Compra de Finanzas: bloqueada sin señal con aviso, no borrador | r198c-apk (1) |
| 09 | Venta en Bodega sin señal + otro asigna por TG → conflicto | Servidor ✓ («sin_cupo») · Teléfono pendiente | r198c-servidor (1) |
| 10 | Mismo borrador dos veces / reintentos: una sola venta | Simulado ✓ | r198e (10); operationId en r198c-apk (3) |
| 11 | Cambio de precio/fecha/estado desde Web con la APK offline | Servidor ✓ («fecha_cambio», «ficha_cambio») · APK: «Requiere revisión» ✓ | r198c-servidor (2–3); r198c-apk (2) |
| 12 | Mensaje TG/WhatsApp sin señal: indica que NO se envió | Simulado ✓ (aviso; envíos al servidor: «no se envió ni se guardó nada») | r198d (4) |
| 13 | Sala de Juntas offline: agenda guardada, unirse bloqueado | Código ✓ · Teléfono pendiente (Sala 3D) | r198d (4) |
| 14 | Partidos offline: última programación, nunca «en vivo» | Simulado ✓ | r198d (1); captura f4_01 |
| 15 | Salir y entrar con otro usuario: sin datos del anterior | Simulado ✓ | r198e (15); r198 (3); r198b (3) |
| 16 | Quitar permiso / vencer ventana offline → bloqueo | Simulado ✓ (403 borra la copia; Finanzas 2 días; consulta 7 días; sesión 1 día sin uso) | r198e (16) |
| 17 | Reiniciar con borradores pendientes: ni se pierden ni duplican | Simulado ✓ | r198c-apk (1, 3) |
| 18 | Wi-Fi/datos alternando y red débil | Simulado ✓ | r198e (18) |
| 19 | Actualizar la APK sin perder borradores | Código ✓ (misma base y claves; campos nuevos opcionales) · Teléfono pendiente | r198e (19) |
| 20 | Métricas/evidencia sin claves, PIN ni datos de clientes | Simulado ✓ (copias sin secretos, cifradas) · No se agregó telemetría nueva | r198b (2) |

## Prueba en teléfono (para hacer con la APK compilada)
1. Instalar la APK nueva sobre la actual (no desinstalar: así se prueba la 19).
2. Entrar como Sublicuentas con internet, esperar «Actualizado», abrir Partidos, Finanzas y Pedidos de socios una vez.
3. Modo avión. Cerrar la APK desde recientes. Abrirla: debe entrar al Inicio con la banda «SIN CONEXIÓN».
4. Más › Baúl: 6 plataformas, Oleada › Fire TV › Copiar instrucciones y pegar en Notas.
5. Clientes: buscar un nombre; Control Maestro: ver «disponibilidad por confirmar».
6. Renovar un servicio: debe quedar «Pendiente» (Ver pendientes). Reiniciar el teléfono: sigue pendiente.
7. Quitar modo avión: pasa a «Confirmado» con ID; en la Web la fecha cambió UNA sola vez y Finanzas tiene UN cobro.
8. Conflicto: modo avión, renovar el mismo servicio en la APK; desde la Web renovarlo también; quitar modo avión → «Requiere revisión», sin doble renovación.
9. Salir de la sesión y entrar como Geisell en modo avión: no debe ver nada de Sublicuentas.
10. Prender y apagar Wi-Fi varias veces con un cambio en cola: un solo «Confirmado».
Guardar capturas con correos enmascarados; no fotografiar claves ni PIN.

## Despliegue gradual sugerido
1. APK de prueba (Debug) solo en el teléfono de Sublicuentas, 1–2 días de uso normal.
2. Relojes y Geisell.
3. Release firmada para todos. Volver atrás: reinstalar la APK anterior; lee la misma base y la cola (los campos nuevos se ignoran).
Servidor: `api/renovar.js` (R198c) debe estar en Vercel ANTES de repartir la APK; sin él, la cola funciona como antes pero sin detectar conflictos.

## Pendientes conocidos
- 05 · APK descargadas en el teléfono (falta registro con hash/derecho de distribución).
- Borradores offline de compra en Finanzas, tickets y notas (hoy: aviso «no se guardó nada»).
- Cola de cambios para Geisell (hoy: «renovar requiere internet»).
- Extras VIP sin cuenta en Control Maestro: el servidor no puede revisar su cupo.
