// Copia el ícono de Sublichat (robot) a android/app/src/main/res.
// Se ejecuta solo después de "npx cap sync android" (hook capacitor:sync:after), porque el workflow
// crea la carpeta android desde cero con "npx cap add android" en cada compilación.
import { cpSync, existsSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const from = path.join(root, 'android-res');
const to = path.join(root, 'android', 'app', 'src', 'main', 'res');
const platform = process.env.CAPACITOR_PLATFORM_NAME || 'android';
if (platform !== 'android') process.exit(0);
if (!existsSync(to)) { console.log('[iconos] android/ aún no existe, se omite'); process.exit(0); }
for (const dir of readdirSync(from)) cpSync(path.join(from, dir), path.join(to, dir), { recursive: true, force: true });
console.log('[iconos] ícono de Sublichat aplicado en', to);
