// R74: agrega el código nativo propio de Sublichat al proyecto Android que crea "npx cap add android":
//   · widget "Cobros" de la pantalla de inicio (CobrosWidgetProvider + SubliWidgetPlugin)
//   · MainActivity que registra el plugin del widget
// Corre después de "npx cap sync android" (hook capacitor:sync:after), igual que scripts/android-icons.mjs.
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.env.CAPACITOR_PLATFORM_NAME || 'android';
if (platform !== 'android') process.exit(0);
const appMain = path.join(root, 'android', 'app', 'src', 'main');
if (!existsSync(appMain)) { console.log('[nativo] android/ aún no existe, se omite'); process.exit(0); }

function findFile(dir, name) {
  for (const entry of readdirSync(dir)) {
    const p = path.join(dir, entry);
    if (statSync(p).isDirectory()) { const hit = findFile(p, name); if (hit) return hit; }
    else if (entry === name) return p;
  }
  return null;
}
const mainActivity = findFile(path.join(appMain, 'java'), 'MainActivity.java');
if (!mainActivity) { console.error('[nativo] ERROR: no se encontró MainActivity.java'); process.exit(1); }
const pkgDir = path.dirname(mainActivity);
const pkg = (readFileSync(mainActivity, 'utf8').match(/^package\s+([\w.]+);/m) || [])[1];
if (pkg !== 'com.sublicuentas.app') { console.error(`[nativo] ERROR: paquete inesperado ${pkg}`); process.exit(1); }

const from = path.join(root, 'android-native', 'java');
for (const f of readdirSync(from).filter(f => f.endsWith('.java'))) copyFileSync(path.join(from, f), path.join(pkgDir, f));

const manifestPath = path.join(appMain, 'AndroidManifest.xml');
let manifest = readFileSync(manifestPath, 'utf8');
const RECEIVERS = [ // R76: widget grande 4x2 y widget pequeño 2x1
  { name: '.CobrosWidgetProvider', label: 'Cobros Sublichat', info: 'widget_cobros_info' },
  { name: '.CobrosWidgetMiniProvider', label: 'Cobros Sublichat (pequeño)', info: 'widget_cobros_mini_info' },
];
if (!manifest.includes('</application>')) { console.error('[nativo] ERROR: manifest sin </application>'); process.exit(1); }
for (const r of RECEIVERS) {
  if (manifest.includes(`android:name="${r.name}"`)) continue;
  const receiver = `<!-- R74/R76: widget ${r.label} -->
        <receiver android:name="${r.name}" android:exported="false" android:label="${r.label}">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${r.info}" />
        </receiver>
    </application>`;
  manifest = manifest.replace('</application>', receiver);
}
// Fase 2 · Oct-2026 · Push (FCM). google-services.json NO vive en el repo ni en el ZIP: el workflow lo pasa
// en la variable GOOGLE_SERVICES_JSON (secreto de GitHub) y aquí se escribe en android/app/.
// El google-services.json de Firebase no es una llave privada (es configuración pública del cliente Android),
// pero igual se mantiene fuera del código. Sin él, la APK se compila igual y push queda apagado.
const gsRaw = String(process.env.GOOGLE_SERVICES_JSON || '').trim();
if (gsRaw) {
  let gs;
  try { gs = JSON.parse(gsRaw.startsWith('{') ? gsRaw : Buffer.from(gsRaw, 'base64').toString('utf8')); }
  catch (_) { console.error('[nativo] ERROR: GOOGLE_SERVICES_JSON no es un JSON válido (pegue el archivo completo o en base64).'); process.exit(1); }
  const paquetes = (gs.client || []).map(c => c?.client_info?.android_client_info?.package_name);
  if (!paquetes.includes('com.sublicuentas.app')) { console.error(`[nativo] ERROR: google-services.json es de otro paquete (${paquetes.join(', ') || 'ninguno'}). Debe ser com.sublicuentas.app.`); process.exit(1); }
  writeFileSync(path.join(root, 'android', 'app', 'google-services.json'), JSON.stringify(gs, null, 2));
  const META = [
    ['com.google.firebase.messaging.default_notification_icon', 'android:resource="@drawable/ic_stat_sublicuentas"'],
    ['com.google.firebase.messaging.default_notification_color', 'android:resource="@color/sublichat_push_color"'],
    ['com.google.firebase.messaging.default_notification_channel_id', 'android:value="sublichat_avisos"'],
  ];
  for (const [name, attr] of META) {
    if (manifest.includes(`android:name="${name}"`)) continue;
    manifest = manifest.replace('</application>', `    <meta-data android:name="${name}" ${attr} />\n    </application>`);
  }
  const valuesDir = path.join(appMain, 'res', 'values');
  writeFileSync(path.join(valuesDir, 'sublichat_push.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="sublichat_push_color">#E2231A</color>\n</resources>\n');
  console.log('[nativo] push FCM activado (google-services.json + ícono/canal de notificación)');
} else {
  console.log('[nativo] push FCM apagado: falta el secreto GOOGLE_SERVICES_JSON');
}
// R193 · Sala de Juntas DENTRO de la APK (WebRTC): micrófono y, si la persona la activa, cámara. Android pregunta el permiso
// en el momento (Capacitor responde la solicitud del WebView con el permiso de Android). La cámara no es obligatoria.
for (const p of ['android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS', 'android.permission.CAMERA']) {
  if (!manifest.includes(`android:name="${p}"`)) manifest = manifest.replace('<application', `<uses-permission android:name="${p}" />\n    <application`);
}
for (const ft of ['android.hardware.camera', 'android.hardware.microphone']) {
  if (!manifest.includes(`android:name="${ft}"`)) manifest = manifest.replace('<application', `<uses-feature android:name="${ft}" android:required="false" />\n    <application`);
}
// R201 · Protocolo de seguridad
// 1) Fijación de certificados (SSL Pinning) para *.capuchino.lat: solo se acepta una cadena que termine en una de estas
//    raíces públicas (las que usan Cloudflare y Vercel). Se fija la RAÍZ, no el certificado del sitio, para que la
//    renovación automática cada 90 días NO deje la app sin conexión. «expiration»: después de esa fecha Android deja de
//    exigir los pines (red de seguridad si una APK vieja queda instalada); antes de esa fecha se publica una APK nueva.
//    Las llamadas a Google (Firebase) no se fijan: Google rota sus certificados y lo desaconseja.
//    Además: sin tráfico sin cifrar (http) y sin confiar en certificados instalados por el usuario.
const PINES = [
  'C5+lpZ7tcVwmwQIMcRtPbsQtWLABXhQzejna0wHFr8M=', // ISRG Root X1 (Let's Encrypt)
  'diGVwiVYbubAI3RW4hB9xU8e/CH2GnkuvVFZE8zmgzI=', // ISRG Root X2 (Let's Encrypt)
  'hxqRlPTu1bMS/0DITB1SSu0vd4u/8l8TjPgfaAp63Gc=', // GTS Root R1 (Google Trust Services)
  'QXnt2YHvdHR3tJYmQIr0Paosp6t/nggsEGD4QJZ3Q0g=', // GTS Root R3
  'mEflZT5enoR1FuXLgYYGqnVEoZvmf9c2bVBpiOjYQ0c=', // GTS Root R4
  'G/ANXI8TwJTdF+AFBM8IiIUPEv0Gf6H5LA/b9guG4yE=', // SSL.com TLS ECC Root CA 2022
  'K89VOmb1cJAN3TK6bf4ezAbJGC1mLcG2Dh97dnwr3VQ=', // SSL.com TLS RSA Root CA 2022
  '0cRTd+vc1hjNFlHcLgLCHXUeWqn80bNDH/bs9qMTSPo=', // SSL.com Root Certification Authority RSA
  'oyD01TTXvpfBro3QSZc1vIlcMjrdLTiL/M9mLCPX+Zo=', // SSL.com Root Certification Authority ECC
  'x4QzPSC810K5/cMjb05Qm4k3Bw5zBn4lTdO/nEW/Td4=', // USERTrust RSA (Sectigo)
  'ICGRfpgmOUXIWcQ/HXPLQTkFPEFPoDyjvH7ohhQpjzs=', // USERTrust ECC (Sectigo)
];
const PIN_VENCE = process.env.SUBLI_PIN_EXPIRA || '2027-11-30';
const nsc = `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors><certificates src="system" /></trust-anchors>
    </base-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">capuchino.lat</domain>
        <trust-anchors><certificates src="system" /></trust-anchors>
        <pin-set expiration="${PIN_VENCE}">
${PINES.map((p) => `            <pin digest="SHA-256">${p}</pin>`).join('\n')}
        </pin-set>
    </domain-config>
</network-security-config>
`;
const xmlDir = path.join(appMain, 'res', 'xml');
if (!existsSync(xmlDir)) mkdirSync(xmlDir, { recursive: true });
writeFileSync(path.join(xmlDir, 'network_security_config.xml'), nsc);
if (!manifest.includes('android:networkSecurityConfig=')) manifest = manifest.replace('<application', '<application android:networkSecurityConfig="@xml/network_security_config"');
manifest = manifest.replace(/android:usesCleartextTraffic="true"/g, 'android:usesCleartextTraffic="false"');
// 2) Ofuscación R8 en la compilación release (minify + quitar recursos sin uso) con reglas que conservan Capacitor,
//    sus plugins y el código nativo propio (widgets). La lógica de la app es JavaScript; R8 protege la parte nativa.
const gradlePath = path.join(root, 'android', 'app', 'build.gradle');
if (!existsSync(gradlePath)) {
  if (process.env.GITHUB_ACTIONS === 'true') { console.error('[nativo] ERROR: falta android/app/build.gradle: no se puede activar R8'); process.exit(1); }
  console.log('[nativo] R201: sin android/app/build.gradle (prueba local): R8 no se aplica aquí');
} else {
let gradle = readFileSync(gradlePath, 'utf8');
if (!/minifyEnabled\s+true/.test(gradle)) {
  const n0 = gradle;
  gradle = gradle.replace(/minifyEnabled\s+false/, 'minifyEnabled true\n            shrinkResources true')
    .replace(/getDefaultProguardFile\('proguard-android\.txt'\)/, "getDefaultProguardFile('proguard-android-optimize.txt')");
  if (gradle === n0) { console.error('[nativo] ERROR: no se encontró «minifyEnabled false» en app/build.gradle'); process.exit(1); }
}
writeFileSync(gradlePath, gradle);
const rulesPath = path.join(root, 'android', 'app', 'proguard-rules.pro');
const REGLAS = `
# R201 · Sublichat: conservar lo que Capacitor llama por reflexión
-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin public class * { *; }
-keepclassmembers class * { @com.getcapacitor.PluginMethod public <methods>; }
-keep class com.sublicuentas.app.** { *; }
-keep class com.aparajita.** { *; }
-keep class app.capgo.** { *; }
-keep class com.google.firebase.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-dontwarn com.google.errorprone.annotations.**
-renamesourcefileattribute SourceFile
`;
const reglasPrev = existsSync(rulesPath) ? readFileSync(rulesPath, 'utf8') : '';
if (!reglasPrev.includes('R201 · Sublichat')) writeFileSync(rulesPath, reglasPrev + REGLAS);
}
console.log('[nativo] R201: SSL pinning *.capuchino.lat (vence ' + PIN_VENCE + '), sin http, R8 activado');
writeFileSync(manifestPath, manifest);
console.log('[nativo] widgets Cobros (grande y pequeño) y MainActivity aplicados en', pkgDir);
