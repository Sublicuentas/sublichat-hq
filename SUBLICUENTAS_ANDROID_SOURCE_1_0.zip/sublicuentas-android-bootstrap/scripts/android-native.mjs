// R74: agrega el código nativo propio de Sublichat al proyecto Android que crea "npx cap add android":
//   · widget "Cobros" de la pantalla de inicio (CobrosWidgetProvider + SubliWidgetPlugin)
//   · MainActivity que registra el plugin del widget
// Corre después de "npx cap sync android" (hook capacitor:sync:after), igual que scripts/android-icons.mjs.
import { copyFileSync, existsSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.env.CAPACITOR_PLATFORM_NAME || 'android';
if (platform !== 'android') process.exit(0);
const appMain = path.join(root, 'android', 'app', 'src', 'main');
if (!existsSync(appMain)) { console.log('[nativo] android/ aún no existe, se omite'); process.exit(0); }

function findFile(dir, name) {
  for (const entry of readdirSync(dir)) {
    const p = path.join(dir, entry);
    if (statSync(p).isDirectory()) { const hit = findFile(p, name); if (hit) return hit; }
    else if (entry === name) return p;
  }
  return null;
}
const mainActivity = findFile(path.join(appMain, 'java'), 'MainActivity.java');
if (!mainActivity) { console.error('[nativo] ERROR: no se encontró MainActivity.java'); process.exit(1); }
const pkgDir = path.dirname(mainActivity);
const pkg = (readFileSync(mainActivity, 'utf8').match(/^package\s+([\w.]+);/m) || [])[1];
if (pkg !== 'com.sublicuentas.app') { console.error(`[nativo] ERROR: paquete inesperado ${pkg}`); process.exit(1); }

const from = path.join(root, 'android-native', 'java');
for (const f of readdirSync(from).filter(f => f.endsWith('.java'))) copyFileSync(path.join(from, f), path.join(pkgDir, f));

const manifestPath = path.join(appMain, 'AndroidManifest.xml');
let manifest = readFileSync(manifestPath, 'utf8');
if (!manifest.includes('.CobrosWidgetProvider')) {
  const receiver = `
        <!-- R74: widget Cobros de la pantalla de inicio -->
        <receiver android:name=".CobrosWidgetProvider" android:exported="false" android:label="Cobros Sublichat">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/widget_cobros_info" />
        </receiver>
    </application>`;
  if (!manifest.includes('</application>')) { console.error('[nativo] ERROR: manifest sin </application>'); process.exit(1); }
  manifest = manifest.replace('</application>', receiver.trimStart());
  writeFileSync(manifestPath, manifest);
}
console.log('[nativo] widget Cobros y MainActivity aplicados en', pkgDir);
