// R74: agrega el código nativo propio de Sublichat al proyecto Android que crea "npx cap add android":
//   · widget "Cobros" de la pantalla de inicio (CobrosWidgetProvider + SubliWidgetPlugin)
//   · MainActivity que registra el plugin del widget
// Corre después de "npx cap sync android" (hook capacitor:sync:after), igual que scripts/android-icons.mjs.
import { copyFileSync, existsSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const platform = process.env.CAPACITOR_PLATFORM_NAME || 'android';
if (platform !== 'android') process.exit(0);
const appMain = path.join(root, 'android', 'app', 'src', 'main');
if (!existsSync(appMain)) { console.log('[nativo] android/ aún no existe, se omite'); process.exit(0); }

function findFile(dir, name) {
  for (const entry of readdirSync(dir)) {
    const p = path.join(dir, entry);
    if (statSync(p).isDirectory()) { const hit = findFile(p, name); if (hit) return hit; }
    else if (entry === name) return p;
  }
  return null;
}
const mainActivity = findFile(path.join(appMain, 'java'), 'MainActivity.java');
if (!mainActivity) { console.error('[nativo] ERROR: no se encontró MainActivity.java'); process.exit(1); }
const pkgDir = path.dirname(mainActivity);
const pkg = (readFileSync(mainActivity, 'utf8').match(/^package\s+([\w.]+);/m) || [])[1];
if (pkg !== 'com.sublicuentas.app') { console.error(`[nativo] ERROR: paquete inesperado ${pkg}`); process.exit(1); }

const from = path.join(root, 'android-native', 'java');
for (const f of readdirSync(from).filter(f => f.endsWith('.java'))) copyFileSync(path.join(from, f), path.join(pkgDir, f));

const manifestPath = path.join(appMain, 'AndroidManifest.xml');
let manifest = readFileSync(manifestPath, 'utf8');
const RECEIVERS = [ // R76: widget grande 4x2 y widget pequeño 2x1
  { name: '.CobrosWidgetProvider', label: 'Cobros Sublichat', info: 'widget_cobros_info' },
  { name: '.CobrosWidgetMiniProvider', label: 'Cobros Sublichat (pequeño)', info: 'widget_cobros_mini_info' },
];
if (!manifest.includes('</application>')) { console.error('[nativo] ERROR: manifest sin </application>'); process.exit(1); }
for (const r of RECEIVERS) {
  if (manifest.includes(`android:name="${r.name}"`)) continue;
  const receiver = `<!-- R74/R76: widget ${r.label} -->
        <receiver android:name="${r.name}" android:exported="false" android:label="${r.label}">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${r.info}" />
        </receiver>
    </application>`;
  manifest = manifest.replace('</application>', receiver);
}
// Fase 2 · Oct-2026 · Push (FCM). google-services.json NO vive en el repo ni en el ZIP: el workflow lo pasa
// en la variable GOOGLE_SERVICES_JSON (secreto de GitHub) y aquí se escribe en android/app/.
// El google-services.json de Firebase no es una llave privada (es configuración pública del cliente Android),
// pero igual se mantiene fuera del código. Sin él, la APK se compila igual y push queda apagado.
const gsRaw = String(process.env.GOOGLE_SERVICES_JSON || '').trim();
if (gsRaw) {
  let gs;
  try { gs = JSON.parse(gsRaw.startsWith('{') ? gsRaw : Buffer.from(gsRaw, 'base64').toString('utf8')); }
  catch (_) { console.error('[nativo] ERROR: GOOGLE_SERVICES_JSON no es un JSON válido (pegue el archivo completo o en base64).'); process.exit(1); }
  const paquetes = (gs.client || []).map(c => c?.client_info?.android_client_info?.package_name);
  if (!paquetes.includes('com.sublicuentas.app')) { console.error(`[nativo] ERROR: google-services.json es de otro paquete (${paquetes.join(', ') || 'ninguno'}). Debe ser com.sublicuentas.app.`); process.exit(1); }
  writeFileSync(path.join(root, 'android', 'app', 'google-services.json'), JSON.stringify(gs, null, 2));
  const META = [
    ['com.google.firebase.messaging.default_notification_icon', 'android:resource="@drawable/ic_stat_sublicuentas"'],
    ['com.google.firebase.messaging.default_notification_color', 'android:resource="@color/sublichat_push_color"'],
    ['com.google.firebase.messaging.default_notification_channel_id', 'android:value="sublichat_avisos"'],
  ];
  for (const [name, attr] of META) {
    if (manifest.includes(`android:name="${name}"`)) continue;
    manifest = manifest.replace('</application>', `    <meta-data android:name="${name}" ${attr} />\n    </application>`);
  }
  const valuesDir = path.join(appMain, 'res', 'values');
  writeFileSync(path.join(valuesDir, 'sublichat_push.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="sublichat_push_color">#E2231A</color>\n</resources>\n');
  console.log('[nativo] push FCM activado (google-services.json + ícono/canal de notificación)');
} else {
  console.log('[nativo] push FCM apagado: falta el secreto GOOGLE_SERVICES_JSON');
}
// R193 · Sala de Juntas DENTRO de la APK (WebRTC): micrófono y, si la persona la activa, cámara. Android pregunta el permiso
// en el momento (Capacitor responde la solicitud del WebView con el permiso de Android). La cámara no es obligatoria.
for (const p of ['android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS', 'android.permission.CAMERA']) {
  if (!manifest.includes(`android:name="${p}"`)) manifest = manifest.replace('<application', `<uses-permission android:name="${p}" />\n    <application`);
}
for (const ft of ['android.hardware.camera', 'android.hardware.microphone']) {
  if (!manifest.includes(`android:name="${ft}"`)) manifest = manifest.replace('<application', `<uses-feature android:name="${ft}" android:required="false" />\n    <application`);
}
writeFileSync(manifestPath, manifest);
console.log('[nativo] widgets Cobros (grande y pequeño) y MainActivity aplicados en', pkgDir);
